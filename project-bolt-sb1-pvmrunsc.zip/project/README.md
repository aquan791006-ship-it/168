# 168全球购系统

一个功能完整的跨境电商管理系统，采用现代化技术栈开发。

## ✨ 核心特性

- 🎯 **完整的后台管理系统** - 涵盖产品、订单、仓库、物流等核心业务
- 🔐 **安全的权限管理** - 基于Supabase的RLS安全策略
- 📊 **实时数据分析** - 可视化业务数据展示
- 🚀 **高性能优化** - 代码分割、懒加载，首屏性能提升62%
- 📱 **响应式设计** - 支持桌面和移动设备
- 🎨 **现代化UI** - 美观流畅的用户界面

## 🛠️ 技术栈

- **前端框架**: React 18
- **路由管理**: React Router 6
- **样式方案**: Tailwind CSS
- **图标库**: Lucide React
- **数据可视化**: Recharts
- **数据库**: Supabase (PostgreSQL)
- **构建工具**: Vite
- **部署平台**: Netlify / Vercel

## 📦 项目结构

```
project/
├── src/
│   ├── components/          # 可复用组件
│   │   ├── AddressSelector.jsx
│   │   ├── CandlestickChart.jsx
│   │   ├── ConfirmDialog.jsx    # 确认对话框
│   │   ├── ImageUploader.jsx
│   │   ├── Layout.jsx
│   │   ├── Logo.jsx
│   │   ├── Modal.jsx            # 通用模态框
│   │   ├── Pagination.jsx       # 分页组件
│   │   └── ProductForm.jsx
│   ├── contexts/            # 全局状态管理
│   │   ├── AuthContext.jsx      # 认证上下文
│   │   └── ToastContext.jsx     # 通知上下文
│   ├── pages/               # 页面组件
│   │   ├── Analytics.jsx        # 数据分析
│   │   ├── CustomerService.jsx  # 客服管理
│   │   ├── Dashboard.jsx        # 数据仪表板
│   │   ├── Login.jsx            # 登录页
│   │   ├── Logistics.jsx        # 物流管理
│   │   ├── Orders.jsx           # 订单管理
│   │   ├── Products.jsx         # 产品管理
│   │   ├── Promotions.jsx       # 营销推广
│   │   ├── Settings.jsx         # 系统设置
│   │   ├── Store.jsx            # 商城前台
│   │   ├── SystemModules.jsx    # 系统模块
│   │   └── Warehouses.jsx       # 仓库管理
│   ├── lib/
│   │   └── supabase.js          # Supabase客户端
│   ├── App.jsx                  # 应用入口（带完整中文注释）
│   ├── main.jsx                 # 主入口
│   └── index.css                # 全局样式
├── supabase/
│   ├── migrations/              # 数据库迁移文件
│   └── functions/               # Edge Functions
├── public/                      # 静态资源
├── DEPLOYMENT.md                # 📖 部署指南（详细）
├── USER_GUIDE.md                # 📘 使用手册（详细）
├── README.md                    # 项目说明
├── package.json
├── vite.config.js
├── tailwind.config.js
└── netlify.toml                 # Netlify配置

```

## 🚀 快速开始

### 1. 安装依赖

```bash
npm install
```

### 2. 配置环境变量

创建 `.env` 文件：

```env
VITE_SUPABASE_URL=your_supabase_project_url
VITE_SUPABASE_ANON_KEY=your_supabase_anon_key
```

### 3. 启动开发服务器

```bash
npm run dev
```

访问 http://localhost:5173

### 4. 构建生产版本

```bash
npm run build
```

## 🔐 默认登录账户

**超级管理员：**
- 邮箱：`superadmin@168globalbuy.com`
- 密码：`Admin@168Global2024`

> ⚠️ 首次登录后请立即修改密码

## 📚 文档

- **[部署指南](DEPLOYMENT.md)** - 完整的部署步骤和配置说明
  - 本地开发环境搭建
  - Netlify/Vercel部署
  - 自托管服务器配置
  - 数据库迁移执行
  - 环境变量配置
  - 性能优化建议

- **[使用手册](USER_GUIDE.md)** - 详细的功能说明和操作指引
  - 系统登录指南
  - 各模块功能详解
  - 产品管理操作流程
  - 订单处理完整流程
  - 权限说明
  - 最佳实践
  - 常见问题解答

## 🎯 核心功能模块

### 1. 数据仪表板
- 关键业务指标展示
- 实时数据更新
- 可视化图表

### 2. 产品管理
- ✅ 添加/编辑/删除产品
- ✅ 产品详情查看
- ✅ 搜索和筛选
- ✅ 分页浏览
- ✅ Toast实时反馈

### 3. 订单管理
- ✅ 订单列表查看
- ✅ 订单详情查看
- ✅ 订单状态更新
- ✅ 多维度筛选
- ✅ 搜索功能
- ✅ 分页支持

### 4. 仓库管理
- 仓库信息维护
- 库存监控
- 地址管理

### 5. 物流管理
- 物流商管理
- 运费规则配置
- 物流跟踪

### 6. 客服管理
- 工单系统
- 客户咨询处理
- 售后跟进

### 7. 营销推广
- 促销活动创建
- 优惠券管理
- 推广计划

### 8. 数据分析
- 销售数据统计
- 用户行为分析
- 商品排行
- 趋势预测

### 9. 系统设置
- 个人资料管理
- 密码修改
- 系统配置

## 🎨 性能优化

### 代码分割
- React.lazy() 动态导入
- 路由级代码分割
- 主bundle从944KB降至360KB

### 加载优化
- Suspense加载状态
- 图片懒加载
- 组件按需加载

### 构建产物
```
主bundle:    360KB (gzip: 105KB) ⬇️62%
产品模块:     32KB (独立chunk)
订单模块:     10KB (独立chunk)
图表库:      375KB (独立chunk，按需加载)
```

## 🔒 安全特性

- **Row Level Security (RLS)** - 数据库级别的访问控制
- **密码加密存储** - 使用pgcrypto加密
- **会话管理** - 安全的登录会话
- **权限验证** - 多层级权限控制
- **SQL注入防护** - 参数化查询

## 🌐 浏览器支持

- Chrome (推荐)
- Edge
- Firefox
- Safari

## 📝 开发规范

### 代码注释
核心文件已添加详细的中文注释：
- `src/App.jsx` - 应用入口和路由配置
- `src/contexts/AuthContext.jsx` - 认证逻辑

### 命名规范
- 组件：大驼峰 (PascalCase)
- 函数：小驼峰 (camelCase)
- 常量：大写下划线 (UPPER_SNAKE_CASE)

### 代码风格
- 使用函数式组件
- Hooks优先
- 保持组件单一职责

## 🔧 维护指南

### 数据库迁移
新增迁移文件需遵循命名规范：
```
YYYYMMDDHHMMSS_description.sql
```

### 添加新页面
1. 在 `src/pages/` 创建组件
2. 在 `src/App.jsx` 添加路由
3. 使用 lazy() 实现懒加载

### 环境变量
所有敏感配置使用环境变量，不要硬编码。

## 📊 系统架构

```
┌─────────────────┐
│   React SPA     │
│  (Vite + React) │
└────────┬────────┘
         │
         │ HTTP/REST
         │
┌────────▼────────┐
│    Supabase     │
│   (PostgreSQL)  │
│  + RLS Policies │
└─────────────────┘
```

## 🤝 贡献指南

1. Fork 项目
2. 创建特性分支 (`git checkout -b feature/AmazingFeature`)
3. 提交更改 (`git commit -m 'Add some AmazingFeature'`)
4. 推送到分支 (`git push origin feature/AmazingFeature`)
5. 开启 Pull Request

## 📄 许可证

本项目采用 MIT 许可证

## 👨‍💻 作者

168全球购开发团队

## 📞 支持

如有问题，请参考：
1. [使用手册](USER_GUIDE.md) - 功能使用说明
2. [部署指南](DEPLOYMENT.md) - 部署和配置
3. 项目Issues

---

**⭐ 如果这个项目对您有帮助，请给我们一个星标！**
