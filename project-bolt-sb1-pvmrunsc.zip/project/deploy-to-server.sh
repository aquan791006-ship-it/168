#!/bin/bash

# ===================================
# SmartInsight AI ERP 自动部署脚本
# 域名: ygou88.com
# 服务器: 159.198.44.80
# ===================================

set -e

echo "======================================"
echo "  SmartInsight AI ERP 部署脚本"
echo "======================================"
echo ""

# 颜色定义
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# 配置变量（请根据实际情况修改）
SERVER_IP="159.198.44.80"
SERVER_USER="root"
DEPLOY_PATH="/var/www/smartinsight"
APP_NAME="smartinsight"

# 检查是否在项目根目录
if [ ! -f "package.json" ]; then
    echo -e "${RED}错误: 请在项目根目录运行此脚本${NC}"
    exit 1
fi

# 步骤 1: 构建前端项目
echo -e "${YELLOW}[1/7] 构建前端项目...${NC}"
npm run build

if [ ! -d "dist" ]; then
    echo -e "${RED}错误: dist 目录不存在，构建失败${NC}"
    exit 1
fi

echo -e "${GREEN}✓ 前端构建完成${NC}"
echo ""

# 步骤 2: 打包文件
echo -e "${YELLOW}[2/7] 打包部署文件...${NC}"
tar -czf deploy-$(date +%Y%m%d-%H%M%S).tar.gz \
    dist/ \
    server/ \
    package.json \
    nginx.ygou88.conf

DEPLOY_FILE=$(ls -t deploy-*.tar.gz | head -1)
echo -e "${GREEN}✓ 打包完成: ${DEPLOY_FILE}${NC}"
echo ""

# 步骤 3: 上传到服务器
echo -e "${YELLOW}[3/7] 上传文件到服务器...${NC}"
scp ${DEPLOY_FILE} ${SERVER_USER}@${SERVER_IP}:/tmp/

echo -e "${GREEN}✓ 文件上传完成${NC}"
echo ""

# 步骤 4: 在服务器上执行部署
echo -e "${YELLOW}[4/7] 在服务器上部署应用...${NC}"
ssh ${SERVER_USER}@${SERVER_IP} << 'ENDSSH'

# 创建部署目录
sudo mkdir -p /var/www/smartinsight
cd /var/www/smartinsight

# 备份旧版本（如果存在）
if [ -d "dist" ]; then
    echo "备份旧版本..."
    tar -czf backup-$(date +%Y%m%d-%H%M%S).tar.gz dist/ server/ 2>/dev/null || true
fi

# 解压新版本
echo "解压新版本..."
DEPLOY_FILE=$(ls -t /tmp/deploy-*.tar.gz | head -1)
tar -xzf ${DEPLOY_FILE}

# 安装后端依赖
echo "安装后端依赖..."
cd server
npm install --production

# 检查环境变量
if [ ! -f ".env" ]; then
    echo "创建环境变量文件..."
    cp .env.production .env
    echo "⚠️  警告: 请编辑 /var/www/smartinsight/server/.env 配置正确的环境变量"
fi

cd /var/www/smartinsight

echo "✓ 应用部署完成"

ENDSSH

echo -e "${GREEN}✓ 服务器部署完成${NC}"
echo ""

# 步骤 5: 配置 Nginx
echo -e "${YELLOW}[5/7] 配置 Nginx...${NC}"
ssh ${SERVER_USER}@${SERVER_IP} << 'ENDSSH'

# 检查 Nginx 是否安装
if ! command -v nginx &> /dev/null; then
    echo "安装 Nginx..."
    sudo apt update
    sudo apt install nginx -y
fi

# 复制 Nginx 配置
sudo cp /var/www/smartinsight/nginx.ygou88.conf /etc/nginx/sites-available/ygou88.com

# 创建符号链接
sudo ln -sf /etc/nginx/sites-available/ygou88.com /etc/nginx/sites-enabled/

# 删除默认配置（如果存在）
sudo rm -f /etc/nginx/sites-enabled/default

# 测试 Nginx 配置
sudo nginx -t

# 重启 Nginx
sudo systemctl restart nginx
sudo systemctl enable nginx

echo "✓ Nginx 配置完成"

ENDSSH

echo -e "${GREEN}✓ Nginx 配置完成${NC}"
echo ""

# 步骤 6: 使用 PM2 启动应用
echo -e "${YELLOW}[6/7] 启动应用...${NC}"
ssh ${SERVER_USER}@${SERVER_IP} << 'ENDSSH'

# 检查 PM2 是否安装
if ! command -v pm2 &> /dev/null; then
    echo "安装 PM2..."
    sudo npm install -g pm2
fi

cd /var/www/smartinsight/server

# 停止旧进程（如果存在）
pm2 stop smartinsight 2>/dev/null || true
pm2 delete smartinsight 2>/dev/null || true

# 启动应用
pm2 start src/index.js --name smartinsight

# 设置开机自启
pm2 startup | tail -n 1 | sudo bash
pm2 save

echo "✓ 应用启动完成"

ENDSSH

echo -e "${GREEN}✓ 应用启动完成${NC}"
echo ""

# 步骤 7: 检查部署状态
echo -e "${YELLOW}[7/7] 检查部署状态...${NC}"
ssh ${SERVER_USER}@${SERVER_IP} << 'ENDSSH'

echo ""
echo "==================================="
echo "  部署状态检查"
echo "==================================="
echo ""

# 检查 PM2 状态
echo "📊 PM2 进程状态:"
pm2 list

echo ""
echo "📝 应用日志 (最后 20 行):"
pm2 logs smartinsight --lines 20 --nostream

echo ""
echo "🌐 Nginx 状态:"
sudo systemctl status nginx | grep Active

echo ""
echo "🔥 防火墙状态:"
sudo ufw status | grep -E "80|443" || echo "防火墙未启用或未配置"

ENDSSH

echo ""
echo -e "${GREEN}======================================"
echo "  ✓ 部署完成！"
echo "======================================${NC}"
echo ""
echo "🌐 访问地址: http://ygou88.com"
echo ""
echo "📝 后续步骤:"
echo "  1. 访问 http://ygou88.com 测试网站"
echo "  2. 配置环境变量: ssh ${SERVER_USER}@${SERVER_IP} 'nano /var/www/smartinsight/server/.env'"
echo "  3. 申请 SSL 证书: ssh ${SERVER_USER}@${SERVER_IP} 'sudo certbot --nginx -d ygou88.com -d www.ygou88.com'"
echo "  4. 查看日志: ssh ${SERVER_USER}@${SERVER_IP} 'pm2 logs smartinsight'"
echo ""
echo "⚠️  重要提醒:"
echo "  - 请确保已正确配置 /var/www/smartinsight/server/.env 文件"
echo "  - 特别是 JWT_SECRET 和 Supabase 相关配置"
echo "  - 建议立即申请 SSL 证书以启用 HTTPS"
echo ""

# 清理临时文件
rm -f ${DEPLOY_FILE}
echo -e "${GREEN}✓ 临时文件已清理${NC}"
