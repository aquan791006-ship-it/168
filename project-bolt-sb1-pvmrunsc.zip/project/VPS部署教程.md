# 🚀 VPS 一键部署教程

> 适用于任何 Linux VPS 主机（阿里云、腾讯云、华为云等）

## ✅ 前提条件

- VPS 服务器（1核2GB内存以上）
- SSH 访问权限
- 本地电脑已安装 Node.js 18+

## 🎯 一键部署步骤

### 1. 准备工作

确保您能够 SSH 连接到服务器：
```bash
ssh root@你的服务器IP
```

如果可以连接，按 `Ctrl+D` 退出。

### 2. 运行部署脚本

在**本地项目目录**运行：

```bash
chmod +x VPS一键部署.sh
./VPS一键部署.sh
```

### 3. 按提示输入信息

```
请输入您的服务器IP地址: 159.198.44.80
请输入SSH用户名 (默认: root): root
请输入域名 (可选，直接回车跳过): ygou88.com
```

### 4. 等待自动部署

脚本会自动完成：
- ✅ 构建前端项目
- ✅ 打包所有文件
- ✅ 上传到服务器
- ✅ 安装 Node.js、Nginx、PM2
- ✅ 解压并配置应用
- ✅ 启动后端服务
- ✅ 配置 Nginx 反向代理
- ✅ 设置开机自启

**时间**: 约 3-5 分钟

## 📝 部署后配置

### 配置环境变量（必需）

SSH 连接到服务器：
```bash
ssh root@你的服务器IP
sudo nano /var/www/smartinsight/server/.env
```

修改以下内容：
```env
SUPABASE_URL=https://你的项目ID.supabase.co
SUPABASE_ANON_KEY=你的匿名密钥
SUPABASE_SERVICE_KEY=你的服务密钥
JWT_SECRET=保持自动生成的即可
```

保存并退出（`Ctrl+X`，然后 `Y`，最后 `Enter`）

重启应用：
```bash
pm2 restart smartinsight
```

### 配置域名（可选）

如果您有域名，配置 DNS：

| 类型 | 主机记录 | 记录值 |
|------|---------|--------|
| A | @ | 你的服务器IP |
| A | www | 你的服务器IP |

等待 DNS 生效（通常 5-10 分钟）

### 配置 HTTPS（推荐）

```bash
ssh root@你的服务器IP
sudo apt install certbot python3-certbot-nginx -y
sudo certbot --nginx -d 你的域名.com -d www.你的域名.com
```

按提示输入邮箱，同意条款即可。

证书会自动续期！

## 🎉 访问应用

**IP访问**: http://你的服务器IP
**域名访问**: http://你的域名.com
**HTTPS访问**: https://你的域名.com（配置SSL后）

**默认登录**:
- 用户名: `admin`
- 密码: `admin123`

⚠️ **首次登录后立即修改密码！**

## 🔧 常用管理命令

### 查看应用状态
```bash
ssh root@服务器IP 'pm2 status'
```

### 查看实时日志
```bash
ssh root@服务器IP 'pm2 logs smartinsight'
```

### 重启应用
```bash
ssh root@服务器IP 'pm2 restart smartinsight'
```

### 停止应用
```bash
ssh root@服务器IP 'pm2 stop smartinsight'
```

### 查看 Nginx 状态
```bash
ssh root@服务器IP 'sudo systemctl status nginx'
```

### 重启 Nginx
```bash
ssh root@服务器IP 'sudo systemctl restart nginx'
```

## 📦 更新应用

当您有新版本时：

```bash
# 本地运行
./VPS一键部署.sh
```

输入相同的服务器信息即可，脚本会自动备份旧版本。

## 🆘 常见问题

### Q: SSH 连接失败？
A: 检查：
- 服务器 IP 是否正确
- 防火墙是否开放 22 端口
- SSH 密钥/密码是否正确

### Q: 访问显示 502 错误？
A: 后端服务未启动，运行：
```bash
ssh root@服务器IP 'cd /var/www/smartinsight/server && pm2 restart smartinsight'
```

### Q: 无法登录？
A: 检查：
1. 环境变量是否配置正确
2. Supabase 数据库是否已初始化
3. 查看日志：`pm2 logs smartinsight`

### Q: 域名无法访问？
A: 检查：
1. DNS 是否已生效（`ping 你的域名.com`）
2. Nginx 配置中 server_name 是否正确
3. 防火墙是否开放 80/443 端口

### Q: HTTPS 证书申请失败？
A: 确保：
1. 域名已正确解析到服务器
2. 80 和 443 端口已开放
3. Nginx 正在运行

## 💡 性能优化建议

### 1. 配置 CDN（可选）
使用阿里云、腾讯云等 CDN 加速静态资源

### 2. 升级服务器配置
建议配置：
- 2核4GB：适合小型应用（100+ 用户）
- 4核8GB：适合中型应用（1000+ 用户）

### 3. 配置数据库备份
定期备份 Supabase 数据

### 4. 监控告警
- 配置 PM2 监控
- 配置服务器监控告警

## 🎓 VPS 提供商推荐

| 提供商 | 最低配置 | 价格/月 | 适合场景 |
|--------|---------|---------|---------|
| 阿里云 ECS | 1核2GB | ¥99 | 国内应用 |
| 腾讯云 CVM | 1核2GB | ¥88 | 国内应用 |
| 华为云 | 1核2GB | ¥95 | 国内应用 |
| Vultr | 1核1GB | $6 | 国际应用 |
| DigitalOcean | 1核1GB | $6 | 国际应用 |

---

**需要帮助？** 查看项目的其他部署文档或联系技术支持。
