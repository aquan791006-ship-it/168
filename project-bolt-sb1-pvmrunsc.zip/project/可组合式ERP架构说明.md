# 可组合式 ERP 系统架构说明

## 🎯 核心概念

本系统已成功改造为**可组合式 ERP (Composable ERP)**，采用微前端 (Micro-frontends) 和微服务 (Microservices) 架构，支持模块化热插拔，无需重启系统即可动态启用/禁用功能模块。

## 🏗️ 架构设计

### 1. 技术栈

#### 前端 - 微前端架构
- **动态模块加载器** (`src/lib/moduleLoader.js`)
  - 基于 React.lazy 的懒加载机制
  - 运行时动态注册和加载模块组件
  - 支持模块热插拔

- **模块上下文** (`src/contexts/ModuleContext.jsx`)
  - 全局模块状态管理
  - 自动监听模块启用/禁用事件
  - 动态更新路由和菜单

- **动态路由系统**
  - 从数据库实时获取已启用模块的路由
  - 自动渲染菜单和导航
  - 支持路由级别的权限控制

#### 后端 - 微服务架构
- **Supabase Edge Functions** 作为微服务层
- 每个模块可配置独立的 API 端点
- 统一的 API Gateway 路由管理
- 标准化的请求/响应格式

### 2. 核心数据库架构

#### 主表结构

**sys_modules** - 模块注册表
```sql
- module_key: 模块唯一标识 (如 'module.products')
- module_name: 多语言名称
- status: 状态 (registered/installing/installed/enabled/disabled/error)
- is_core: 是否核心模块（核心模块不可禁用）
- is_system: 是否系统模块
- module_type: 类型 (full/frontend_only/backend_only/widget/integration)
- config_schema: 配置架构
- current_config: 当前配置
```

**sys_module_routes** - 模块路由表
```sql
- route_path: 路由路径
- component_name: 组件名称
- menu_label: 菜单标签（多语言）
- menu_icon: 图标名称
- menu_order: 菜单排序
- is_menu_item: 是否显示在菜单
- requires_auth: 是否需要认证
```

**sys_module_apis** - 模块 API 端点表
```sql
- api_path: API 路径
- http_method: HTTP 方法
- edge_function_name: Edge Function 名称
- requires_auth: 是否需要认证
- rate_limit: 速率限制
```

**sys_module_events** - 事件总线表
```sql
- event_name: 事件名称
- publisher_module_id: 发布者模块
- event_data: 事件数据 (JSONB)
- status: 处理状态
```

**sys_module_dependencies** - 模块依赖关系
```sql
- module_id: 模块ID
- depends_on_module_id: 依赖的模块ID
- dependency_type: 依赖类型 (required/optional/peer)
```

## 🔥 核心功能

### 1. 模块热插拔

**启用模块流程**:
```
1. 用户点击"启用"按钮
2. 系统检查依赖关系是否满足
3. 更新模块状态为 'enabled'
4. 发布 'module.enabled' 事件
5. 前端监听事件，自动重新加载路由
6. 菜单自动更新，新模块立即可用
```

**禁用模块流程**:
```
1. 用户点击"禁用"按钮
2. 系统检查是否有其他模块依赖它
3. 如有依赖且为 required，禁止禁用
4. 更新模块状态为 'disabled'
5. 发布 'module.disabled' 事件
6. 前端自动移除相关路由和菜单
```

### 2. 事件总线系统

**发布事件** (`src/lib/eventBus.js`):
```javascript
// 前端事件
eventBus.publish('product.created', { productId: '123' });

// 数据库事件（跨模块通信）
eventBus.publishToSupabase(
  supabase,
  'inventory.updated',
  'module.warehouses',
  { warehouseId: '456', quantity: 100 }
);
```

**订阅事件**:
```javascript
// 前端订阅
const unsubscribe = eventBus.subscribe('product.created', (data) => {
  console.log('新商品创建:', data);
});

// 订阅数据库事件
const channel = await eventBus.subscribeToSupabaseEvents(
  supabase,
  'module.orders',
  'inventory.*'
);
```

### 3. 数据隔离

**模块数据表命名规范**:
- 核心系统: `sys_*` (如 `sys_products`, `sys_orders`)
- 采购模块: `pur_*` (如 `pur_suppliers`, `pur_purchase_orders`)
- 仓储模块: `wms_*` (如 `wms_inventory`, `wms_inbound`)
- 客服模块: `cs_*` (如 `cs_conversations`, `cs_tickets`)

**动态扩展数据表**:
```sql
-- 新模块可以在 sys_module_data_schemas 注册表结构
INSERT INTO sys_module_data_schemas (
  module_id,
  table_name,
  table_schema,
  migration_sql
) VALUES (...);

-- 系统自动执行迁移，不破坏现有表结构
```

## 📦 已注册模块列表

### 核心模块（不可禁用）
1. **core.system** - 系统核心
2. **core.dashboard** - 数据仪表板

### 业务模块（可热插拔）
1. **module.products** - 商品管理
2. **module.product_fields** - 商品字段配置
3. **module.smart_purchase** - 智能采购
4. **module.orders** - 订单管理
5. **module.warehouses** - 仓储管理
6. **module.stock_alerts** - 库存预警
7. **module.logistics** - 物流管理
8. **module.customer_service** - 客户服务
9. **module.promotions** - 营销推广
10. **module.analytics** - 数据分析

## 🛠️ 核心 API

### 模块管理函数

**启用模块**:
```sql
SELECT enable_module('module.products', current_user_id);
```

**禁用模块**:
```sql
SELECT disable_module('module.products', current_user_id);
```

**批量启用**:
```sql
SELECT batch_enable_modules(
  ARRAY['module.products', 'module.orders'],
  current_user_id
);
```

**获取已启用模块的路由**:
```sql
SELECT * FROM get_enabled_module_routes();
```

**获取模块统计信息**:
```sql
SELECT get_module_statistics();
```

## 🚀 使用指南

### 1. 访问模块管理中心

```
URL: /admin/modules
功能: 查看所有模块、一键启用/禁用、查看依赖关系
```

### 2. 开发新模块

#### 步骤 1: 注册模块
```sql
INSERT INTO sys_modules (
  module_key,
  module_name,
  description,
  category,
  icon,
  status,
  module_version
) VALUES (
  'module.crm',
  '{"zh": "客户关系管理", "en": "CRM"}',
  '{"zh": "CRM系统", "en": "CRM System"}',
  'business',
  'Users',
  'installed',
  '1.0.0'
);
```

#### 步骤 2: 注册路由
```sql
INSERT INTO sys_module_routes (
  module_id,
  route_path,
  component_name,
  menu_label,
  menu_icon,
  menu_order
) VALUES (
  (SELECT id FROM sys_modules WHERE module_key = 'module.crm'),
  '/admin/crm',
  'CRM',
  '{"zh": "客户管理", "en": "CRM"}',
  'Users',
  100
);
```

#### 步骤 3: 创建组件
```javascript
// src/pages/CRM.jsx
export default function CRM() {
  return <div>CRM 模块</div>;
}
```

#### 步骤 4: 注册到模块加载器
```javascript
// src/lib/moduleLoader.js
const componentMap = {
  'CRM': () => import('../pages/CRM'),
  // ... 其他组件
};
```

#### 步骤 5: 启用模块
```sql
SELECT enable_module('module.crm');
```

### 3. 模块间通信

**发布事件**:
```javascript
import { eventBus, ModuleEvents } from '../lib/eventBus';

// 商品模块发布事件
eventBus.publish(ModuleEvents.PRODUCT_CREATED, {
  productId: newProduct.id,
  productName: newProduct.title
});
```

**订阅事件**:
```javascript
import { eventBus, ModuleEvents } from '../lib/eventBus';

// 库存模块订阅商品创建事件
useEffect(() => {
  const unsubscribe = eventBus.subscribe(
    ModuleEvents.PRODUCT_CREATED,
    (data) => {
      // 自动为新商品初始化库存
      initializeInventory(data.productId);
    }
  );

  return () => unsubscribe();
}, []);
```

## 🎨 架构优势

### 1. 灵活性
- ✅ 按需启用功能模块，轻量化部署
- ✅ 支持自定义模块开发
- ✅ 模块版本独立管理

### 2. 可扩展性
- ✅ 新模块无需修改核心代码
- ✅ 数据库动态扩展不破坏现有结构
- ✅ API 端点动态注册

### 3. 可维护性
- ✅ 模块独立开发、测试、部署
- ✅ 故障隔离，单模块问题不影响系统
- ✅ 清晰的依赖关系管理

### 4. 性能
- ✅ 按需加载，减少初始包大小
- ✅ 未启用模块不加载
- ✅ 独立的模块缓存策略

### 5. 安全性
- ✅ 模块级权限控制
- ✅ RLS 数据隔离
- ✅ 独立的 API 访问控制

## 📊 系统监控

### 模块状态监控
- 已启用模块数
- 已禁用模块数
- 模块使用频率统计
- 模块安装/卸载历史

### 事件总线监控
- 事件发布/订阅统计
- 事件处理延迟
- 失败事件重试

### API 调用监控
- API 调用次数
- 响应时间
- 错误率统计

## 🔒 安全考虑

### 1. 模块权限
- 每个模块定义独立的权限集
- 用户角色绑定模块权限
- 动态权限检查

### 2. 数据访问控制
- Row Level Security (RLS) 策略
- 模块数据隔离
- API 级别的认证授权

### 3. 审计日志
- 模块启用/禁用记录
- 配置变更历史
- 操作人追踪

## 📝 最佳实践

### 1. 模块设计
- 单一职责原则
- 低耦合高内聚
- 清晰的接口定义

### 2. 依赖管理
- 最小化模块间依赖
- 使用事件总线解耦
- 避免循环依赖

### 3. 数据设计
- 使用命名空间前缀
- 避免跨模块直接查询
- 通过 API 或事件通信

### 4. 性能优化
- 合理使用懒加载
- 模块级代码分割
- 缓存策略设计

## 🚧 未来扩展

### 1. 模块市场
- 第三方模块上传
- 模块评分和评论
- 一键安装机制

### 2. 可视化模块编辑器
- 低代码/无代码配置
- 拖拽式界面构建
- 实时预览

### 3. 多租户支持
- 租户级模块配置
- 独立的模块订阅
- 计费和计量

### 4. 微服务增强
- 独立的服务部署
- 服务发现和注册
- 负载均衡和容错

## 📚 相关文件

### 数据库迁移
- `supabase/migrations/*_create_composable_erp_core_system.sql`
- `supabase/migrations/*_create_module_management_functions.sql`
- `supabase/migrations/*_initialize_core_modules.sql`

### 核心代码
- `src/lib/moduleLoader.js` - 模块加载器
- `src/lib/eventBus.js` - 事件总线
- `src/contexts/ModuleContext.jsx` - 模块上下文
- `src/pages/ModuleManager.jsx` - 模块管理页面
- `src/App.jsx` - 微前端路由配置
- `src/components/Layout.jsx` - 动态菜单渲染

---

**🎉 恭喜！您的系统已成功升级为可组合式 ERP 架构！**

现在您可以：
1. 访问 `/admin/modules` 管理模块
2. 一键启用/禁用功能模块
3. 实时查看系统状态
4. 轻松扩展新模块

系统已实现真正的模块化、热插拔、数据隔离和微服务架构！
