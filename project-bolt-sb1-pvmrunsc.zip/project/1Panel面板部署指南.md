# 🚀 SmartInsight AI - 1Panel 面板部署指南

**适用版本**: SmartInsight AI v1.0.0
**面板版本**: 1Panel v1.9+
**难度等级**: ⭐⭐☆☆☆ (简单)
**预计时间**: 15-20 分钟

---

## 📋 目录

1. [部署前准备](#部署前准备)
2. [方案一：使用 Node.js 运行时（推荐）](#方案一使用-nodejs-运行时推荐)
3. [方案二：使用 Docker 容器](#方案二使用-docker-容器)
4. [配置 Nginx 反向代理](#配置-nginx-反向代理)
5. [配置 SSL 证书](#配置-ssl-证书)
6. [验证和测试](#验证和测试)
7. [常见问题](#常见问题)
8. [维护和更新](#维护和更新)

---

## 📋 部署前准备

### 1. 服务器要求

**最低配置**:
- CPU: 1 核
- 内存: 1 GB
- 磁盘: 10 GB
- 系统: Ubuntu 20.04+ / Debian 11+ / CentOS 8+

**推荐配置**:
- CPU: 2 核
- 内存: 2 GB
- 磁盘: 20 GB
- 带宽: 5 Mbps+

### 2. 安装 1Panel

如果还没安装 1Panel，执行以下命令：

```bash
# 一键安装 1Panel
curl -sSL https://resource.fit2cloud.com/1panel/package/quick_start.sh -o quick_start.sh && bash quick_start.sh

# 安装完成后，访问面板
# 地址: http://你的服务器IP:面板端口
# 默认端口: 28188
```

### 3. 准备 Supabase 数据库

访问 [Supabase](https://supabase.com/) 并准备好以下信息：

1. **Supabase URL**: `https://xxx.supabase.co`
2. **Anon Key**: `eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...`
3. **Service Role Key**: `eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...`

> 💡 获取方式: Supabase Dashboard → Settings → API

### 4. 准备 JWT Secret

生成一个安全的 JWT 密钥：

```bash
# 方法 1: 使用 openssl（推荐）
openssl rand -base64 32

# 方法 2: 使用 Node.js
node -e "console.log(require('crypto').randomBytes(32).toString('base64'))"

# 方法 3: 在线生成
# 访问 https://generate-secret.now.sh/32
```

保存生成的密钥，后面配置时需要用到。

---

## 🎯 方案一：使用 Node.js 运行时（推荐）

这是最简单的部署方式，适合大多数用户。

### 步骤 1: 上传部署包

1. **登录 1Panel 管理面板**
   ```
   http://你的服务器IP:28188
   ```

2. **进入文件管理**
   - 左侧菜单 → `文件` → `文件管理`
   - 点击 `/opt` 目录（推荐位置）

3. **上传部署包**
   - 点击 `上传` 按钮
   - 选择 `deployment-package.tar.gz`
   - 等待上传完成

### 步骤 2: 解压部署包

1. **在文件管理中操作**
   - 找到上传的 `deployment-package.tar.gz`
   - 右键点击 → `解压`
   - 解压到当前目录 `/opt`

2. **重命名文件夹（可选）**
   - 将解压后的文件夹重命名为 `smartinsight-ai`
   - 最终路径: `/opt/smartinsight-ai`

### 步骤 3: 安装 Node.js 运行时

1. **进入运行时管理**
   - 左侧菜单 → `应用商店` → `运行环境`
   - 找到 `Node.js`

2. **安装 Node.js 18+**
   - 点击 `Node.js` → `安装`
   - 选择版本: `18.x` 或更高
   - 等待安装完成

3. **验证安装**
   ```bash
   # 在 1Panel 终端中执行
   node --version    # 应该显示 v18.x.x
   npm --version     # 应该显示 9.x.x
   ```

### 步骤 4: 安装项目依赖

1. **进入终端**
   - 左侧菜单 → `主机` → `终端`

2. **安装后端依赖**
   ```bash
   # 进入项目目录
   cd /opt/smartinsight-ai/server

   # 安装依赖（需要 2-3 分钟）
   npm install --production

   # 验证安装
   ls node_modules | wc -l  # 应该显示有很多依赖包
   ```

### 步骤 5: 配置环境变量

1. **复制环境变量模板**
   ```bash
   cd /opt/smartinsight-ai/server
   cp .env.example .env
   ```

2. **编辑 .env 文件**

   在 1Panel 文件管理中：
   - 找到 `/opt/smartinsight-ai/server/.env`
   - 点击编辑

   填入以下内容：
   ```env
   # Supabase 数据库配置（必需）
   SUPABASE_URL="https://你的项目ID.supabase.co"
   SUPABASE_ANON_KEY="你的anon密钥"
   SUPABASE_SERVICE_KEY="你的service_role密钥"

   # JWT 配置（必需）
   JWT_SECRET="刚才生成的32位随机字符串"
   JWT_EXPIRES_IN="7d"

   # 服务器配置
   PORT=3000
   NODE_ENV="production"

   # 文件上传配置
   MAX_FILE_SIZE=10485760
   UPLOAD_DIR="./uploads"
   ```

   保存文件。

### 步骤 6: 测试启动

1. **手动测试启动**
   ```bash
   cd /opt/smartinsight-ai/server
   node src/index.js
   ```

2. **查看输出**
   ```
   ✓ Server is running on port 3000
   ✓ Health check available at http://localhost:3000/health
   ✓ Environment: production
   ✓ Static files serving from: /opt/smartinsight-ai/dist
   ```

3. **测试访问**
   - 在浏览器中访问: `http://你的服务器IP:3000`
   - 应该能看到登录页面

4. **停止测试**
   - 按 `Ctrl + C` 停止进程

### 步骤 7: 使用 PM2 守护进程

1. **安装 PM2**
   ```bash
   npm install -g pm2
   ```

2. **启动应用**
   ```bash
   cd /opt/smartinsight-ai/server

   # 使用 PM2 启动
   pm2 start src/index.js --name smartinsight-ai

   # 查看状态
   pm2 status

   # 查看日志
   pm2 logs smartinsight-ai
   ```

3. **设置开机自启**
   ```bash
   # 生成启动脚本
   pm2 startup

   # 按照提示执行命令（复制输出的命令并执行）
   # 例如: sudo env PATH=$PATH:/usr/bin pm2 startup systemd -u root --hp /root

   # 保存当前进程列表
   pm2 save
   ```

4. **验证 PM2 状态**
   ```bash
   pm2 list
   ```

   应该看到：
   ```
   ┌─────┬──────────────────┬─────────┬─────────┬──────────┐
   │ id  │ name             │ status  │ restart │ uptime   │
   ├─────┼──────────────────┼─────────┼─────────┼──────────┤
   │ 0   │ smartinsight-ai  │ online  │ 0       │ 2m       │
   └─────┴──────────────────┴─────────┴─────────┴──────────┘
   ```

### 步骤 8: 在 1Panel 中添加监控

1. **添加到监控列表**
   - 左侧菜单 → `主机` → `进程`
   - 可以看到 `PM2` 进程
   - 可以查看 CPU、内存使用情况

### 步骤 9: 配置反向代理

> 继续查看后面的 [配置 Nginx 反向代理](#配置-nginx-反向代理) 章节

---

## 🐳 方案二：使用 Docker 容器

适合熟悉 Docker 的用户。

### 步骤 1: 创建 Dockerfile

1. **上传部署包并解压**（同方案一步骤 1-2）

2. **创建 Dockerfile**

   在 `/opt/smartinsight-ai` 目录创建 `Dockerfile`：
   ```dockerfile
   # 使用 Node.js 18 官方镜像
   FROM node:18-alpine

   # 设置工作目录
   WORKDIR /app

   # 安装 PM2
   RUN npm install -g pm2

   # 复制前端构建文件
   COPY dist ./dist
   COPY public ./public

   # 复制后端文件
   COPY server/package*.json ./server/
   COPY server/src ./server/src

   # 安装依赖
   WORKDIR /app/server
   RUN npm install --production

   # 暴露端口
   EXPOSE 3000

   # 使用 PM2 启动
   CMD ["pm2-runtime", "start", "src/index.js", "--name", "smartinsight-ai"]
   ```

3. **创建 .dockerignore**
   ```
   node_modules
   .git
   .env
   *.tar.gz
   ```

### 步骤 2: 构建 Docker 镜像

1. **进入 1Panel 终端**
   ```bash
   cd /opt/smartinsight-ai

   # 构建镜像
   docker build -t smartinsight-ai:1.0.0 .

   # 验证镜像
   docker images | grep smartinsight-ai
   ```

### 步骤 3: 使用 1Panel 容器管理

1. **进入容器管理**
   - 左侧菜单 → `容器` → `容器`

2. **创建容器**
   - 点击 `创建` 按钮
   - 填写配置：
     - **名称**: `smartinsight-ai`
     - **镜像**: `smartinsight-ai:1.0.0`
     - **端口映射**: `3000:3000`
     - **环境变量**: 点击添加，填入所有 .env 中的配置
     - **重启策略**: `always`
     - **网络模式**: `bridge`

3. **启动容器**
   - 点击 `创建并启动`
   - 查看日志确认启动成功

### 步骤 4: 验证容器运行

```bash
# 查看容器状态
docker ps | grep smartinsight-ai

# 查看容器日志
docker logs -f smartinsight-ai

# 访问测试
curl http://localhost:3000/health
```

---

## 🔧 配置 Nginx 反向代理

使用 1Panel 的 OpenResty（Nginx）功能配置反向代理。

### 方法 1: 使用 1Panel 网站管理（推荐）

#### 步骤 1: 创建网站

1. **进入网站管理**
   - 左侧菜单 → `网站` → `网站`
   - 点击 `创建网站`

2. **填写网站信息**
   - **网站类型**: 选择 `反向代理`
   - **域名**: `yourdomain.com`（或填写服务器IP）
   - **代理地址**: `http://127.0.0.1:3000`
   - **备注**: `SmartInsight AI 系统`

3. **高级设置**
   - 点击 `高级配置`
   - 开启 `WebSocket 支持`（如果需要）
   - 设置 `客户端最大请求体大小`: `10M`

4. **保存并创建**

#### 步骤 2: 配置额外的 Nginx 规则

1. **编辑网站配置**
   - 在网站列表中找到刚创建的网站
   - 点击 `配置文件`

2. **添加以下配置**

   在 `location /` 块中添加：
   ```nginx
   # 客户端最大请求体大小
   client_max_body_size 10M;

   # 代理超时设置
   proxy_connect_timeout 60s;
   proxy_send_timeout 60s;
   proxy_read_timeout 60s;

   # 代理缓冲设置
   proxy_buffering on;
   proxy_buffer_size 4k;
   proxy_buffers 8 4k;

   # 代理头设置
   proxy_set_header Host $host;
   proxy_set_header X-Real-IP $remote_addr;
   proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
   proxy_set_header X-Forwarded-Proto $scheme;

   # 代理到后端
   proxy_pass http://127.0.0.1:3000;
   ```

3. **添加静态资源缓存**

   在 `server` 块中添加：
   ```nginx
   # 静态资源缓存
   location ~* \.(jpg|jpeg|png|gif|ico|css|js|svg|woff|woff2|ttf|eot)$ {
       proxy_pass http://127.0.0.1:3000;
       expires 7d;
       add_header Cache-Control "public, immutable";
   }

   # API 路由不缓存
   location /api/ {
       proxy_pass http://127.0.0.1:3000;
       proxy_set_header Host $host;
       proxy_set_header X-Real-IP $remote_addr;
       proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
       proxy_set_header X-Forwarded-Proto $scheme;
       proxy_cache_bypass 1;
       proxy_no_cache 1;
   }
   ```

4. **保存并重载配置**
   - 点击 `保存`
   - 1Panel 会自动重载 Nginx

#### 步骤 3: 验证代理

```bash
# 测试访问（使用域名或IP）
curl http://yourdomain.com/health

# 应该返回
{"status":"ok"}
```

### 方法 2: 手动配置（高级用户）

如果需要更精细的控制，可以手动配置：

1. **进入配置目录**
   ```bash
   cd /opt/1panel/apps/openresty/openresty/conf/conf.d
   ```

2. **创建配置文件**
   ```bash
   nano smartinsight-ai.conf
   ```

3. **添加完整配置**
   ```nginx
   server {
       listen 80;
       server_name yourdomain.com;  # 修改为你的域名

       # 日志配置
       access_log /opt/1panel/apps/openresty/openresty/logs/smartinsight-access.log;
       error_log /opt/1panel/apps/openresty/openresty/logs/smartinsight-error.log;

       # 安全头
       add_header X-Frame-Options "SAMEORIGIN" always;
       add_header X-Content-Type-Options "nosniff" always;
       add_header X-XSS-Protection "1; mode=block" always;

       # 客户端最大请求体大小
       client_max_body_size 10M;

       # 根路径代理
       location / {
           proxy_pass http://127.0.0.1:3000;
           proxy_set_header Host $host;
           proxy_set_header X-Real-IP $remote_addr;
           proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
           proxy_set_header X-Forwarded-Proto $scheme;

           # 超时设置
           proxy_connect_timeout 60s;
           proxy_send_timeout 60s;
           proxy_read_timeout 60s;
       }

       # 静态资源缓存
       location ~* \.(jpg|jpeg|png|gif|ico|css|js|svg|woff|woff2|ttf|eot)$ {
           proxy_pass http://127.0.0.1:3000;
           expires 7d;
           add_header Cache-Control "public, immutable";
       }

       # API 路由
       location /api/ {
           proxy_pass http://127.0.0.1:3000;
           proxy_set_header Host $host;
           proxy_set_header X-Real-IP $remote_addr;
           proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
           proxy_set_header X-Forwarded-Proto $scheme;
           proxy_cache_bypass 1;
           proxy_no_cache 1;
       }

       # 健康检查
       location /health {
           proxy_pass http://127.0.0.1:3000;
           access_log off;
       }
   }
   ```

4. **测试并重载配置**
   ```bash
   # 测试配置
   openresty -t

   # 重载配置
   openresty -s reload
   ```

---

## 🔒 配置 SSL 证书

使用 1Panel 快速配置 SSL。

### 方法 1: Let's Encrypt 免费证书（推荐）

1. **在网站管理中操作**
   - 左侧菜单 → `网站` → `网站`
   - 找到你的网站，点击 `SSL`

2. **申请证书**
   - 选择 `Let's Encrypt`
   - 填写邮箱地址
   - 点击 `申请`
   - 等待自动申请和配置

3. **开启 HTTPS**
   - 申请成功后，开启 `强制 HTTPS` 开关
   - 开启 `HSTS` （可选，增强安全性）

4. **验证 HTTPS**
   ```bash
   curl https://yourdomain.com/health
   ```

### 方法 2: 上传已有证书

1. **进入 SSL 管理**
   - 左侧菜单 → `网站` → `SSL`
   - 点击 `上传证书`

2. **上传证书文件**
   - **证书文件**: 上传 `.crt` 或 `.pem` 文件
   - **私钥文件**: 上传 `.key` 文件
   - **证书名称**: `smartinsight-ai-ssl`

3. **应用到网站**
   - 回到网站列表
   - 点击网站的 `SSL` 按钮
   - 选择刚上传的证书
   - 点击 `保存`

### SSL 配置优化

在网站配置文件中添加：

```nginx
# SSL 优化配置
ssl_protocols TLSv1.2 TLSv1.3;
ssl_ciphers HIGH:!aNULL:!MD5;
ssl_prefer_server_ciphers on;
ssl_session_cache shared:SSL:10m;
ssl_session_timeout 10m;

# HSTS（可选）
add_header Strict-Transport-Security "max-age=31536000; includeSubDomains" always;
```

---

## ✅ 验证和测试

### 1. 健康检查

```bash
# HTTP 测试
curl http://yourdomain.com/health
# 应该返回: {"status":"ok"}

# HTTPS 测试
curl https://yourdomain.com/health
# 应该返回: {"status":"ok"}
```

### 2. 登录测试

1. **访问网站**
   ```
   https://yourdomain.com
   ```

2. **使用默认账号登录**
   - 用户名: `admin`
   - 密码: `admin123`

3. **立即修改密码**
   - 登录后 → 右上角头像 → `账号设置`
   - 修改为强密码

### 3. 功能测试

- ✅ 登录/登出
- ✅ 仪表板加载
- ✅ 商品管理
- ✅ 订单管理
- ✅ 数据统计
- ✅ AI 功能

### 4. 性能测试

在 1Panel 中查看：
- 左侧菜单 → `主机` → `监控`
- 查看 CPU、内存、网络使用情况

预期资源使用：
- **内存**: 150-300 MB
- **CPU**: < 5% (空闲时)
- **磁盘**: < 100 MB

---

## ❓ 常见问题

### Q1: 端口 3000 被占用怎么办？

**方案 1: 修改应用端口**
```bash
# 编辑 .env 文件
nano /opt/smartinsight-ai/server/.env

# 修改 PORT
PORT=3001

# 重启应用
pm2 restart smartinsight-ai
```

**方案 2: 停止占用端口的进程**
```bash
# 查看占用端口的进程
lsof -i :3000

# 停止进程
kill -9 <PID>
```

### Q2: 无法访问网站

**检查清单**:
1. 检查服务器防火墙
   ```bash
   # 在 1Panel 中
   左侧菜单 → 主机 → 防火墙
   确保 80 和 443 端口已开放
   ```

2. 检查云服务商安全组
   - 阿里云/腾讯云/AWS 等
   - 开放 80、443 端口

3. 检查应用状态
   ```bash
   pm2 status
   # 确保状态是 online
   ```

4. 检查 Nginx 状态
   ```bash
   systemctl status openresty
   # 或在 1Panel 中查看
   ```

### Q3: 静态资源 404

**原因**: dist 目录路径配置错误

**解决**:
```bash
# 检查 dist 目录
ls /opt/smartinsight-ai/dist

# 确保后端能找到 dist 目录
cd /opt/smartinsight-ai/server
ls ../dist  # 应该能看到 index.html
```

### Q4: PM2 进程经常重启

**查看日志**:
```bash
pm2 logs smartinsight-ai --lines 100
```

**常见原因**:
1. 内存不足 → 升级服务器
2. .env 配置错误 → 检查环境变量
3. 端口冲突 → 修改端口

### Q5: 数据库连接失败

**检查清单**:
1. 验证 Supabase 配置
   ```bash
   cat /opt/smartinsight-ai/server/.env
   # 确保 SUPABASE_URL 和密钥正确
   ```

2. 测试网络连接
   ```bash
   curl https://你的项目ID.supabase.co
   ```

3. 检查 Supabase 项目状态
   - 访问 Supabase Dashboard
   - 确保项目处于活动状态

### Q6: SSL 证书申请失败

**原因**:
1. 域名未正确解析
2. 80 端口未开放
3. 已达到申请限额

**解决**:
```bash
# 1. 验证域名解析
ping yourdomain.com

# 2. 检查 80 端口
telnet yourdomain.com 80

# 3. 查看 Let's Encrypt 日志
# 在 1Panel 中: 网站 → SSL → 查看日志
```

### Q7: 如何查看应用日志？

**方法 1: 使用 PM2**
```bash
# 实时日志
pm2 logs smartinsight-ai

# 最近 100 行
pm2 logs smartinsight-ai --lines 100

# 错误日志
pm2 logs smartinsight-ai --err
```

**方法 2: 使用 1Panel**
- 左侧菜单 → `容器` → `容器`
- 找到容器，点击 `日志`

**方法 3: 查看文件**
```bash
# PM2 日志文件位置
ls ~/.pm2/logs/
```

### Q8: 如何备份数据？

**数据库备份**（Supabase 自动备份）:
- Supabase Dashboard → Database → Backups
- 自动每日备份

**配置文件备份**:
```bash
# 备份 .env 文件
cp /opt/smartinsight-ai/server/.env ~/backup/env-$(date +%Y%m%d).bak

# 或使用 1Panel 文件管理下载
```

### Q9: 如何更新应用？

**步骤**:
```bash
# 1. 停止应用
pm2 stop smartinsight-ai

# 2. 备份当前版本
cp -r /opt/smartinsight-ai /opt/smartinsight-ai.bak

# 3. 上传并解压新版本到临时目录
# 使用 1Panel 文件管理操作

# 4. 复制新文件（保留 .env）
cp /tmp/new-version/server/.env /opt/smartinsight-ai/server/.env
rm -rf /opt/smartinsight-ai/dist /opt/smartinsight-ai/server/src
cp -r /tmp/new-version/dist /opt/smartinsight-ai/
cp -r /tmp/new-version/server/src /opt/smartinsight-ai/server/

# 5. 重新安装依赖（如果 package.json 有更新）
cd /opt/smartinsight-ai/server
npm install --production

# 6. 重启应用
pm2 restart smartinsight-ai
```

---

## 🔧 维护和更新

### 日常维护

**1. 查看应用状态**
```bash
# PM2 状态
pm2 status

# 系统资源
pm2 monit
```

**2. 日志清理**
```bash
# 清理 PM2 日志
pm2 flush

# 查看日志文件大小
du -sh ~/.pm2/logs/
```

**3. 进程管理**
```bash
# 重启应用
pm2 restart smartinsight-ai

# 停止应用
pm2 stop smartinsight-ai

# 删除应用
pm2 delete smartinsight-ai

# 重新加载（零停机）
pm2 reload smartinsight-ai
```

### 性能优化

**1. 在 1Panel 中监控**
- 左侧菜单 → `主机` → `监控`
- 查看实时性能数据

**2. PM2 集群模式（多核服务器）**
```bash
# 停止当前实例
pm2 delete smartinsight-ai

# 使用集群模式启动
cd /opt/smartinsight-ai/server
pm2 start src/index.js -i max --name smartinsight-ai

# 保存配置
pm2 save
```

**3. 配置 PM2 生态系统文件**

创建 `ecosystem.config.js`:
```javascript
module.exports = {
  apps: [{
    name: 'smartinsight-ai',
    script: 'src/index.js',
    cwd: '/opt/smartinsight-ai/server',
    instances: 2,  // 或 'max'
    exec_mode: 'cluster',
    env: {
      NODE_ENV: 'production'
    },
    error_file: '~/.pm2/logs/smartinsight-error.log',
    out_file: '~/.pm2/logs/smartinsight-out.log',
    log_date_format: 'YYYY-MM-DD HH:mm:ss',
    merge_logs: true,
    max_memory_restart: '500M'
  }]
}
```

使用生态系统文件启动：
```bash
pm2 start ecosystem.config.js
pm2 save
```

### 安全加固

**1. 定期更新系统**
```bash
# Ubuntu/Debian
apt update && apt upgrade -y

# CentOS
yum update -y
```

**2. 配置防火墙**

在 1Panel 中：
- 左侧菜单 → `主机` → `防火墙`
- 只开放必要端口: 80, 443, 22, 1Panel端口

**3. 修改默认密码**
- 应用管理员密码
- 1Panel 面板密码
- 服务器 root 密码

**4. 启用 Fail2Ban（可选）**
```bash
apt install fail2ban -y
systemctl enable fail2ban
systemctl start fail2ban
```

---

## 📊 监控和告警

### 1. 使用 1Panel 内置监控

- 左侧菜单 → `主机` → `监控`
- 实时查看 CPU、内存、磁盘、网络

### 2. PM2 监控

```bash
# 安装 PM2 Web 界面（可选）
pm2 install pm2-server-monit

# 访问监控
# 打开 http://你的服务器IP:9615
```

### 3. 配置告警（高级）

如果需要告警，可以使用第三方服务：
- UptimeRobot (免费)
- Pingdom
- New Relic
- 腾讯云监控
- 阿里云监控

---

## 🎉 完成部署！

恭喜！您已经成功在 1Panel 上部署了 SmartInsight AI 系统。

### 快速访问

- **网站地址**: https://yourdomain.com
- **默认账号**: admin / admin123
- **健康检查**: https://yourdomain.com/health

### 下一步

1. ✅ 立即修改管理员密码
2. ✅ 配置系统基本信息
3. ✅ 添加商品和店铺
4. ✅ 配置 Supabase 数据库表
5. ✅ 测试所有功能模块

### 需要帮助？

- 📖 查看 [快速部署手册.md]
- 📖 查看 [使用手册.md]
- 📖 查看 [常见问题.md]

---

## 📞 技术支持

如果遇到问题：

1. 先查看本文档的 [常见问题](#常见问题) 章节
2. 查看应用日志: `pm2 logs smartinsight-ai`
3. 查看系统日志: 1Panel → 主机 → 日志
4. 检查 Supabase 控制台日志

---

**文档版本**: 1.0.0
**最后更新**: 2026-01-08
**适用系统**: SmartInsight AI v1.0.0
**适用面板**: 1Panel v1.9+
