import { createContext, useContext, useState, useEffect } from 'react';
import api from '../lib/api';
import { moduleLoader } from '../lib/moduleLoader';
import { eventBus, ModuleEvents } from '../lib/eventBus';

const ModuleContext = createContext();

export function ModuleProvider({ children }) {
  const [modules, setModules] = useState([]);
  const [routes, setRoutes] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    loadModules();

    eventBus.subscribe(ModuleEvents.MODULE_ENABLED, handleModuleChange);
    eventBus.subscribe(ModuleEvents.MODULE_DISABLED, handleModuleChange);

    return () => {
      eventBus.unsubscribe(ModuleEvents.MODULE_ENABLED, handleModuleChange);
      eventBus.unsubscribe(ModuleEvents.MODULE_DISABLED, handleModuleChange);
    };
  }, []);

  const loadModules = async () => {
    try {
      setLoading(true);
      setError(null);

      const loadedRoutes = await moduleLoader.loadEnabledModules(api);
      setRoutes(loadedRoutes);

      const modulesData = await api.modules.list({ is_enabled: true });
      setModules(modulesData || []);
    } catch (err) {
      console.error('Failed to load modules:', err);
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const handleModuleChange = async () => {
    await loadModules();
  };

  const getModuleByKey = (moduleKey) => {
    return modules.find(m => m.module_key === moduleKey);
  };

  const isModuleEnabled = (moduleKey) => {
    const module = getModuleByKey(moduleKey);
    return module && module.is_enabled;
  };

  const reloadModules = async () => {
    await loadModules();
  };

  const value = {
    modules,
    routes,
    loading,
    error,
    getModuleByKey,
    isModuleEnabled,
    reloadModules
  };

  return (
    <ModuleContext.Provider value={value}>
      {children}
    </ModuleContext.Provider>
  );
}

export function useModules() {
  const context = useContext(ModuleContext);
  if (!context) {
    throw new Error('useModules must be used within ModuleProvider');
  }
  return context;
}
