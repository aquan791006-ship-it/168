import React, { createContext, useContext, useEffect, useState } from 'react';
import api from '../lib/api';

const AuthContext = createContext({});

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within AuthProvider');
  }
  return context;
};

export const AuthProvider = ({ children }) => {
  const [admin, setAdmin] = useState(null);
  const [loading, setLoading] = useState(true);
  const [sessionExpiry, setSessionExpiry] = useState(null);

  useEffect(() => {
    checkAdmin();
  }, []);

  useEffect(() => {
    if (!admin || !sessionExpiry) {
      return;
    }

    const interval = setInterval(() => {
      const now = new Date().getTime();
      if (now > sessionExpiry) {
        logout();
      }
    }, 60000);

    return () => clearInterval(interval);
  }, [admin, sessionExpiry]);

  const checkAdmin = async () => {
    try {
      const token = api.getToken();
      if (!token) {
        setLoading(false);
        return;
      }

      const adminData = await api.auth.getMe();

      if (adminData && adminData.is_active) {
        setAdmin(adminData);
        localStorage.setItem('admin', JSON.stringify(adminData));
      } else {
        logout();
      }
    } catch (error) {
      console.error('Check admin error:', error);
      logout();
    } finally {
      setLoading(false);
    }
  };

  const login = async (username, password) => {
    const response = await api.auth.login({ username, password });

    if (!response.token) {
      throw new Error('登录失败');
    }

    api.setToken(response.token);

    const adminData = response.admin;
    const expiry = new Date().getTime() + (7 * 24 * 60 * 60 * 1000);

    setAdmin(adminData);
    setSessionExpiry(expiry);
    localStorage.setItem('admin', JSON.stringify(adminData));
    localStorage.setItem('session_expiry', expiry.toString());

    return adminData;
  };

  const logout = () => {
    api.setToken(null);
    setAdmin(null);
    setSessionExpiry(null);
    localStorage.removeItem('admin');
    localStorage.removeItem('session_expiry');
  };

  const value = {
    admin,
    loading,
    login,
    logout,
    sessionExpiry,
    refreshSession: checkAdmin,
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};
