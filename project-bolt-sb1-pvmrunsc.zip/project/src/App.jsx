/**
 * 168全球购系统 - 主应用入口
 *
 * 功能说明：
 * 1. 路由配置与管理
 * 2. 全局状态提供（认证、通知）
 * 3. 代码分割与懒加载
 * 4. 权限路由保护
 */

import React, { lazy, Suspense } from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider, useAuth } from './contexts/AuthContext';
import { ToastProvider } from './contexts/ToastContext';
import { ModuleProvider, useModules } from './contexts/ModuleContext';
import Layout from './components/Layout';
import ErrorBoundary from './components/ErrorBoundary';
import PWAInstallPrompt from './components/PWAInstallPrompt';
import { moduleLoader } from './lib/moduleLoader';

const Store = lazy(() => import('./pages/Store'));
const Login = lazy(() => import('./pages/Login'));
const ModuleManager = lazy(() => import('./pages/ModuleManager'));

/**
 * 加载中占位组件
 * 在页面组件加载时显示
 */
function LoadingFallback() {
  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-50">
      <div className="text-center">
        <div className="relative">
          <div className="animate-spin rounded-full h-16 w-16 border-4 border-blue-200 mx-auto"></div>
          <div className="animate-spin rounded-full h-16 w-16 border-4 border-blue-600 border-t-transparent absolute top-0 left-1/2 -translate-x-1/2"></div>
        </div>
        <p className="mt-4 text-gray-600 font-medium">加载中...</p>
      </div>
    </div>
  );
}

/**
 * 受保护路由组件
 * 功能：验证用户登录状态，未登录则重定向到登录页
 */
function ProtectedRoute({ children }) {
  const { admin, loading } = useAuth();

  // 加载中状态
  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-4 border-blue-500 border-t-transparent"></div>
      </div>
    );
  }

  // 未登录则跳转登录页
  if (!admin) {
    return <Navigate to="/login" replace />;
  }

  // 已登录则渲染带布局的页面
  return <Layout>{children}</Layout>;
}

function AppRoutes() {
  const { admin, loading: authLoading } = useAuth();
  const { routes, loading: modulesLoading } = useModules();

  if (authLoading || modulesLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-4 border-blue-500 border-t-transparent"></div>
      </div>
    );
  }

  return (
    <Suspense fallback={<LoadingFallback />}>
      <Routes>
        <Route path="/" element={<Store />} />
        <Route
          path="/admin/login"
          element={admin ? <Navigate to="/admin/dashboard" replace /> : <Login />}
        />
        <Route
          path="/admin/modules"
          element={
            <ProtectedRoute>
              <ModuleManager />
            </ProtectedRoute>
          }
        />

        {routes.map((route) => {
          const Component = moduleLoader.getComponent(route.component_name);

          if (!Component) {
            console.warn(`Component not found: ${route.component_name}`);
            return null;
          }

          return (
            <Route
              key={route.route_path}
              path={route.route_path}
              element={
                <ProtectedRoute>
                  <Component />
                </ProtectedRoute>
              }
            />
          );
        })}

        <Route path="/login" element={<Navigate to="/admin/login" replace />} />
        <Route path="/dashboard" element={<Navigate to="/admin/dashboard" replace />} />
      </Routes>
    </Suspense>
  );
}

/**
 * 应用根组件
 *
 * 组件层级：
 * BrowserRouter (路由容器)
 *   └─ ToastProvider (全局通知提供者)
 *       └─ AuthProvider (认证状态提供者)
 *           └─ AppRoutes (路由配置)
 */
export default function App() {
  return (
    <ErrorBoundary>
      <BrowserRouter>
        <ToastProvider>
          <AuthProvider>
            <ModuleProvider>
              <AppRoutes />
              <PWAInstallPrompt />
            </ModuleProvider>
          </AuthProvider>
        </ToastProvider>
      </BrowserRouter>
    </ErrorBoundary>
  );
}
