import { useEffect, useRef, useCallback } from 'react';
import { supabase } from '../lib/supabase';

export function usePerformanceMonitor(componentName, enabled = true) {
  const renderCount = useRef(0);
  const mountTime = useRef(Date.now());
  const metricsBuffer = useRef([]);
  const domainId = useRef(null);

  useEffect(() => {
    const fetchDomainId = async () => {
      try {
        const { data } = await supabase
          .from('sys_domains')
          .select('id')
          .limit(1)
          .maybeSingle();
        if (data) {
          domainId.current = data.id;
        }
      } catch (error) {
        console.error('Failed to fetch domain ID:', error);
      }
    };
    fetchDomainId();
  }, []);

  const recordMetric = useCallback(async (metricType, metricName, responseTime = null, success = true) => {
    if (!enabled || !domainId.current) return;

    try {
      await supabase.rpc('record_performance_metric', {
        p_domain_id: domainId.current,
        p_module_code: componentName,
        p_metric_type: metricType,
        p_metric_name: metricName,
        p_response_time: responseTime,
        p_success: success
      });
    } catch (error) {
      console.error('Failed to record metric:', error);
    }
  }, [componentName, enabled]);

  const flushMetrics = async () => {
    if (metricsBuffer.current.length === 0) return;
    metricsBuffer.current = [];
  };

  useEffect(() => {
    if (!enabled) return;

    renderCount.current++;

    const renderTime = Date.now() - mountTime.current;
    if (renderCount.current === 1) {
      recordMetric('component_load', `${componentName}_mount`, renderTime);
    }

    return () => {
      if (renderCount.current === 1) {
        const totalTime = Date.now() - mountTime.current;
        recordMetric('component_lifecycle', `${componentName}_unmount`, totalTime);
        flushMetrics();
      }
    };
  }, [componentName, enabled, recordMetric]);

  return {
    recordMetric,
    renderCount: renderCount.current
  };
}

export function measureAsync(name, fn) {
  return async (...args) => {
    const start = performance.now();
    try {
      const result = await fn(...args);
      const duration = performance.now() - start;

      if (duration > 1000) {
        console.warn(`Slow operation: ${name} took ${duration.toFixed(2)}ms`);
      }

      return result;
    } catch (error) {
      const duration = performance.now() - start;
      console.error(`Operation failed: ${name} after ${duration.toFixed(2)}ms`, error);
      throw error;
    }
  };
}

export function useMemoizedCallback(fn, deps, ttl = 5000) {
  const cache = useRef(new Map());
  const timers = useRef(new Map());

  return useCallback((...args) => {
    const key = JSON.stringify(args);

    if (cache.current.has(key)) {
      return cache.current.get(key);
    }

    const result = fn(...args);
    cache.current.set(key, result);

    if (timers.current.has(key)) {
      clearTimeout(timers.current.get(key));
    }

    const timer = setTimeout(() => {
      cache.current.delete(key);
      timers.current.delete(key);
    }, ttl);

    timers.current.set(key, timer);

    return result;
  }, deps);
}
