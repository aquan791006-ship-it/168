import { useState, useEffect, useCallback } from 'react';
import api from '../lib/api';
import { cacheManager } from '../lib/cacheManager';

export function useApiQuery(queryFn, dependencies = []) {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const fetchData = useCallback(async () => {
    try {
      setLoading(true);
      setError(null);
      const result = await queryFn(api);
      setData(result);
    } catch (err) {
      console.error('API Query Error:', err);
      setError(err);
    } finally {
      setLoading(false);
    }
  }, dependencies);

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  const refetch = useCallback(async () => {
    try {
      setLoading(true);
      setError(null);
      const result = await queryFn(api);
      setData(result);
      return result;
    } catch (err) {
      console.error('API Query Error:', err);
      setError(err);
      throw err;
    } finally {
      setLoading(false);
    }
  }, [queryFn]);

  return { data, error, loading, refetch };
}

export function useSupabaseQuery(queryFn, dependencies = []) {
  return useApiQuery(queryFn, dependencies);
}
