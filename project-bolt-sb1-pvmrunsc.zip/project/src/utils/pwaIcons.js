export function generatePWAIcon(size) {
  const canvas = document.createElement('canvas');
  canvas.width = size;
  canvas.height = size;
  const ctx = canvas.getContext('2d');

  const gradient = ctx.createLinearGradient(0, 0, size, size);
  gradient.addColorStop(0, '#10b981');
  gradient.addColorStop(0.5, '#14b8a6');
  gradient.addColorStop(1, '#06b6d4');

  const radius = size * 0.2;
  ctx.fillStyle = gradient;
  ctx.beginPath();
  ctx.roundRect(0, 0, size, size, radius);
  ctx.fill();

  const overlayGradient = ctx.createRadialGradient(
    size * 0.3, size * 0.3, 0,
    size * 0.3, size * 0.3, size * 0.7
  );
  overlayGradient.addColorStop(0, 'rgba(255, 255, 255, 0.3)');
  overlayGradient.addColorStop(1, 'rgba(255, 255, 255, 0)');
  ctx.fillStyle = overlayGradient;
  ctx.fillRect(0, 0, size, size);

  ctx.fillStyle = '#ffffff';
  ctx.font = `bold ${size * 0.35}px -apple-system, BlinkMacSystemFont, sans-serif`;
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.shadowColor = 'rgba(0, 0, 0, 0.3)';
  ctx.shadowBlur = size * 0.02;
  ctx.shadowOffsetX = 0;
  ctx.shadowOffsetY = size * 0.01;
  ctx.fillText('168', size / 2, size / 2);

  return canvas.toDataURL('image/png');
}

export async function downloadPWAIcons() {
  const sizes = [192, 512];

  for (const size of sizes) {
    const dataUrl = generatePWAIcon(size);
    const link = document.createElement('a');
    link.download = `pwa-icon-${size}.png`;
    link.href = dataUrl;
    link.click();
  }
}

export function createPWAIconsInPublic() {
  if (typeof document === 'undefined') return;

  const sizes = [192, 512];
  sizes.forEach(size => {
    const canvas = document.createElement('canvas');
    canvas.width = size;
    canvas.height = size;
    const ctx = canvas.getContext('2d');

    const gradient = ctx.createLinearGradient(0, 0, size, size);
    gradient.addColorStop(0, '#10b981');
    gradient.addColorStop(0.5, '#14b8a6');
    gradient.addColorStop(1, '#06b6d4');

    const radius = size * 0.2;
    ctx.fillStyle = gradient;
    ctx.beginPath();
    ctx.roundRect(0, 0, size, size, radius);
    ctx.fill();

    const overlayGradient = ctx.createRadialGradient(
      size * 0.3, size * 0.3, 0,
      size * 0.3, size * 0.3, size * 0.7
    );
    overlayGradient.addColorStop(0, 'rgba(255, 255, 255, 0.3)');
    overlayGradient.addColorStop(1, 'rgba(255, 255, 255, 0)');
    ctx.fillStyle = overlayGradient;
    ctx.fillRect(0, 0, size, size);

    ctx.fillStyle = '#ffffff';
    ctx.font = `bold ${size * 0.35}px -apple-system, BlinkMacSystemFont, sans-serif`;
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.shadowColor = 'rgba(0, 0, 0, 0.3)';
    ctx.shadowBlur = size * 0.02;
    ctx.shadowOffsetX = 0;
    ctx.shadowOffsetY = size * 0.01;
    ctx.fillText('168', size / 2, size / 2);

    canvas.toBlob((blob) => {
      console.log(`Generated pwa-icon-${size}.png`);
    }, 'image/png');
  });
}
