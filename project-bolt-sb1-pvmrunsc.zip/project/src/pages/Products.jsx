import React, { useEffect, useState } from 'react';
import { supabase } from '../lib/supabase';
import ProductForm from '../components/ProductForm';
import Modal from '../components/Modal';
import ConfirmDialog from '../components/ConfirmDialog';
import Pagination from '../components/Pagination';
import { useToast } from '../contexts/ToastContext';
import { Package, Plus, Search, Edit, Trash2, Eye, DollarSign } from 'lucide-react';

export default function Products() {
  const { success, error: showError } = useToast();
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [showAddForm, setShowAddForm] = useState(false);
  const [showEditForm, setShowEditForm] = useState(false);
  const [showDetailModal, setShowDetailModal] = useState(false);
  const [selectedProduct, setSelectedProduct] = useState(null);
  const [showDeleteDialog, setShowDeleteDialog] = useState(false);
  const [productToDelete, setProductToDelete] = useState(null);
  const [currentPage, setCurrentPage] = useState(1);
  const [itemsPerPage] = useState(10);

  useEffect(() => {
    loadProducts();
  }, []);

  const loadProducts = async () => {
    try {
      const { data, error } = await supabase
        .from('products')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) throw error;
      setProducts(data || []);
    } catch (error) {
      console.error('Error loading products:', error);
      showError('加载产品列表失败');
    } finally {
      setLoading(false);
    }
  };

  const handleProductAdded = () => {
    loadProducts();
    success('产品添加成功');
  };

  const handleProductUpdated = () => {
    loadProducts();
    success('产品更新成功');
  };

  const handleViewProduct = (product) => {
    setSelectedProduct(product);
    setShowDetailModal(true);
  };

  const handleEditProduct = (product) => {
    setSelectedProduct(product);
    setShowEditForm(true);
  };

  const handleDeleteClick = (product) => {
    setProductToDelete(product);
    setShowDeleteDialog(true);
  };

  const handleDeleteConfirm = async () => {
    if (!productToDelete) return;

    try {
      const { error } = await supabase
        .from('products')
        .delete()
        .eq('id', productToDelete.id);

      if (error) throw error;

      loadProducts();
      success('产品删除成功');
      setProductToDelete(null);
    } catch (error) {
      console.error('Error deleting product:', error);
      showError('删除产品失败');
    }
  };

  const getTitle = (titleObj) => {
    if (typeof titleObj === 'string') return titleObj;
    return titleObj?.zh || titleObj?.en || '未命名产品';
  };

  const getStatusColor = (status) => {
    return status === 'active'
      ? 'bg-green-100 text-green-700'
      : 'bg-gray-100 text-gray-700';
  };

  const getStatusText = (status) => {
    return status === 'active' ? '在售' : '下架';
  };

  const filteredProducts = products.filter(product => {
    const title = getTitle(product.title).toLowerCase();
    const serial = (product.serial_number || '').toLowerCase();
    const search = searchTerm.toLowerCase();
    return title.includes(search) || serial.includes(search);
  });

  const totalPages = Math.ceil(filteredProducts.length / itemsPerPage);
  const paginatedProducts = filteredProducts.slice(
    (currentPage - 1) * itemsPerPage,
    currentPage * itemsPerPage
  );

  const handlePageChange = (page) => {
    setCurrentPage(page);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  useEffect(() => {
    setCurrentPage(1);
  }, [searchTerm]);

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-4 border-blue-500 border-t-transparent"></div>
      </div>
    );
  }

  return (
    <>
      {showAddForm && (
        <ProductForm
          onClose={() => setShowAddForm(false)}
          onSuccess={handleProductAdded}
        />
      )}

      {showEditForm && selectedProduct && (
        <ProductForm
          product={selectedProduct}
          onClose={() => {
            setShowEditForm(false);
            setSelectedProduct(null);
          }}
          onSuccess={handleProductUpdated}
        />
      )}

      <Modal
        isOpen={showDetailModal}
        onClose={() => {
          setShowDetailModal(false);
          setSelectedProduct(null);
        }}
        title="产品详情"
        size="lg"
      >
        {selectedProduct && (
          <div className="space-y-4">
            <div>
              <label className="text-sm font-medium text-gray-500">产品名称</label>
              <p className="text-lg font-semibold text-gray-900">{getTitle(selectedProduct.title)}</p>
            </div>
            <div>
              <label className="text-sm font-medium text-gray-500">产品编号</label>
              <p className="text-gray-900">{selectedProduct.serial_number || '-'}</p>
            </div>
            <div>
              <label className="text-sm font-medium text-gray-500">价格</label>
              <p className="text-2xl font-bold text-emerald-600">¥{Number(selectedProduct.base_price).toLocaleString()}</p>
            </div>
            <div>
              <label className="text-sm font-medium text-gray-500">分类</label>
              <p className="text-gray-900">{selectedProduct.category || '未分类'}</p>
            </div>
            <div>
              <label className="text-sm font-medium text-gray-500">创建时间</label>
              <p className="text-gray-900">{new Date(selectedProduct.created_at).toLocaleString('zh-CN')}</p>
            </div>
          </div>
        )}
      </Modal>

      <ConfirmDialog
        isOpen={showDeleteDialog}
        onClose={() => {
          setShowDeleteDialog(false);
          setProductToDelete(null);
        }}
        onConfirm={handleDeleteConfirm}
        title="删除产品"
        message={`确定要删除产品"${productToDelete ? getTitle(productToDelete.title) : ''}"吗？此操作无法撤销。`}
        type="danger"
      />

      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">产品模块管理</h1>
            <p className="text-gray-500 mt-1">管理您的产品库存和信息</p>
          </div>
          <button
            onClick={() => setShowAddForm(true)}
            className="flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-orange-500 to-amber-600 text-white rounded-lg hover:shadow-lg transition-all hover:scale-105"
          >
            <Plus className="w-5 h-5" />
            <span>添加产品</span>
          </button>
        </div>

        <div className="bg-white rounded-xl border border-gray-200">
          <div className="p-6 border-b border-gray-200">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
              <input
                type="text"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder="搜索产品名称或编号..."
                className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">产品编号</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">产品名称</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">价格</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">类型</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">状态</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">创建时间</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">操作</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-200">
                {paginatedProducts.map((product) => (
                  <tr key={product.id} className="hover:bg-gray-50 transition-colors">
                    <td className="px-6 py-4 text-sm font-medium text-gray-900">
                      {product.serial_number || '-'}
                    </td>
                    <td className="px-6 py-4">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded-lg bg-blue-50 flex items-center justify-center">
                          <Package className="w-5 h-5 text-blue-600" />
                        </div>
                        <div>
                          <p className="text-sm font-medium text-gray-900">{getTitle(product.title)}</p>
                          <p className="text-xs text-gray-500">{product.category || '未分类'}</p>
                        </div>
                      </div>
                    </td>
                    <td className="px-6 py-4 text-sm font-medium text-gray-900">
                      <div className="flex items-center gap-1">
                        <DollarSign className="w-4 h-4" />
                        {Number(product.base_price).toLocaleString()}
                      </div>
                    </td>
                    <td className="px-6 py-4 text-sm text-gray-600">
                      {product.product_type || '常规'}
                    </td>
                    <td className="px-6 py-4">
                      <span className={`inline-flex px-2 py-1 text-xs font-medium rounded-full ${getStatusColor(product.status)}`}>
                        {getStatusText(product.status)}
                      </span>
                    </td>
                    <td className="px-6 py-4 text-sm text-gray-500">
                      {new Date(product.created_at).toLocaleDateString('zh-CN')}
                    </td>
                    <td className="px-6 py-4">
                      <div className="flex items-center gap-2">
                        <button
                          onClick={() => handleViewProduct(product)}
                          className="p-2 hover:bg-blue-50 rounded-lg transition-colors group"
                          title="查看详情"
                        >
                          <Eye className="w-4 h-4 text-gray-600 group-hover:text-blue-600" />
                        </button>
                        <button
                          onClick={() => handleEditProduct(product)}
                          className="p-2 hover:bg-green-50 rounded-lg transition-colors group"
                          title="编辑"
                        >
                          <Edit className="w-4 h-4 text-gray-600 group-hover:text-green-600" />
                        </button>
                        <button
                          onClick={() => handleDeleteClick(product)}
                          className="p-2 hover:bg-red-50 rounded-lg transition-colors group"
                          title="删除"
                        >
                          <Trash2 className="w-4 h-4 text-gray-600 group-hover:text-red-600" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {filteredProducts.length === 0 && (
            <div className="text-center py-12">
              <Package className="w-12 h-12 text-gray-400 mx-auto mb-3" />
              <p className="text-gray-500">暂无产品数据</p>
            </div>
          )}

          {filteredProducts.length > 0 && (
            <Pagination
              currentPage={currentPage}
              totalPages={totalPages}
              onPageChange={handlePageChange}
              itemsPerPage={itemsPerPage}
              totalItems={filteredProducts.length}
            />
          )}
        </div>
      </div>
    </>
  );
}
