import { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';
import { Clock, Globe, Settings, Save, AlertCircle, CheckCircle, Power } from 'lucide-react';
import { useToast } from '../contexts/ToastContext';

export default function LuckyDrawSettings() {
  const { user } = useAuth();
  const { showToast } = useToast();
  const [loading, setLoading] = useState(true);
  const [domains, setDomains] = useState([]);
  const [selectedDomain, setSelectedDomain] = useState(null);
  const [permissionCheck, setPermissionCheck] = useState(null);
  const [businessStatus, setBusinessStatus] = useState(null);
  const [allowedRegions, setAllowedRegions] = useState([]);

  const [settings, setSettings] = useState({
    enable_lucky_draw: false,
    lucky_draw_region_code: '',
    lucky_draw_timezone: 'Asia/Kuala_Lumpur',
    lucky_draw_business_hours: {
      enabled: true,
      timezone: 'Asia/Kuala_Lumpur',
      default_hours: {
        open: '09:00',
        close: '23:00'
      },
      weekly_schedule: {
        monday: { open: '09:00', close: '23:00', enabled: true },
        tuesday: { open: '09:00', close: '23:00', enabled: true },
        wednesday: { open: '09:00', close: '23:00', enabled: true },
        thursday: { open: '09:00', close: '23:00', enabled: true },
        friday: { open: '09:00', close: '23:00', enabled: true },
        saturday: { open: '09:00', close: '23:00', enabled: true },
        sunday: { open: '09:00', close: '23:00', enabled: true }
      },
      special_dates: []
    }
  });

  const timezones = [
    { value: 'Asia/Kuala_Lumpur', label: '马来西亚 (UTC+8)' },
    { value: 'Asia/Bangkok', label: '泰国 (UTC+7)' },
    { value: 'Asia/Ho_Chi_Minh', label: '越南 (UTC+7)' },
    { value: 'Asia/Jakarta', label: '印度尼西亚 (UTC+7)' },
    { value: 'Asia/Manila', label: '菲律宾 (UTC+8)' }
  ];

  const weekDays = [
    { key: 'monday', label: '周一' },
    { key: 'tuesday', label: '周二' },
    { key: 'wednesday', label: '周三' },
    { key: 'thursday', label: '周四' },
    { key: 'friday', label: '周五' },
    { key: 'saturday', label: '周六' },
    { key: 'sunday', label: '周日' }
  ];

  useEffect(() => {
    loadDomains();
    loadAllowedRegions();
  }, [user]);

  useEffect(() => {
    if (selectedDomain) {
      loadDomainSettings();
      checkPermission();
      checkBusinessStatus();
    }
  }, [selectedDomain]);

  const loadDomains = async () => {
    try {
      setLoading(true);
      let query = supabase.from('sys_domains').select('*');

      if (!user?.is_super_admin) {
        query = query.eq('owner_id', user.id);
      }

      const { data, error } = await query;
      if (error) throw error;

      setDomains(data || []);
      if (data && data.length > 0) {
        setSelectedDomain(data[0].id);
      }
    } catch (error) {
      showToast('error', '加载域名列表失败');
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  const loadAllowedRegions = async () => {
    try {
      const { data, error } = await supabase
        .from('sys_lucky_draw_allowed_regions')
        .select('*')
        .eq('is_active', true)
        .order('country_name');

      if (error) throw error;
      setAllowedRegions(data || []);
    } catch (error) {
      console.error('加载地区列表失败:', error);
    }
  };

  const loadDomainSettings = async () => {
    try {
      const { data, error } = await supabase
        .from('sys_domains')
        .select('enable_lucky_draw, lucky_draw_region_code, lucky_draw_timezone, lucky_draw_business_hours')
        .eq('id', selectedDomain)
        .single();

      if (error) throw error;
      if (data) {
        setSettings({
          enable_lucky_draw: data.enable_lucky_draw || false,
          lucky_draw_region_code: data.lucky_draw_region_code || '',
          lucky_draw_timezone: data.lucky_draw_timezone || 'Asia/Kuala_Lumpur',
          lucky_draw_business_hours: data.lucky_draw_business_hours || settings.lucky_draw_business_hours
        });
      }
    } catch (error) {
      console.error('加载设置失败:', error);
    }
  };

  const checkPermission = async () => {
    if (!selectedDomain) return;

    try {
      const { data, error } = await supabase.rpc('check_lucky_draw_permission', {
        p_domain_id: selectedDomain
      });

      if (error) throw error;
      setPermissionCheck(data);
    } catch (error) {
      console.error('权限检查失败:', error);
    }
  };

  const checkBusinessStatus = async () => {
    if (!selectedDomain) return;

    try {
      const { data, error } = await supabase.rpc('check_lucky_draw_business_hours', {
        p_domain_id: selectedDomain
      });

      if (error) throw error;
      setBusinessStatus(data);
    } catch (error) {
      console.error('营业状态检查失败:', error);
    }
  };

  const handleSave = async () => {
    try {
      const { error } = await supabase
        .from('sys_domains')
        .update({
          enable_lucky_draw: settings.enable_lucky_draw,
          lucky_draw_region_code: settings.lucky_draw_region_code,
          lucky_draw_timezone: settings.lucky_draw_timezone,
          lucky_draw_business_hours: settings.lucky_draw_business_hours
        })
        .eq('id', selectedDomain);

      if (error) throw error;
      showToast('success', '设置保存成功');
      checkPermission();
      checkBusinessStatus();
    } catch (error) {
      showToast('error', '保存失败');
      console.error(error);
    }
  };

  const updateWeeklySchedule = (day, field, value) => {
    setSettings(prev => ({
      ...prev,
      lucky_draw_business_hours: {
        ...prev.lucky_draw_business_hours,
        weekly_schedule: {
          ...prev.lucky_draw_business_hours.weekly_schedule,
          [day]: {
            ...prev.lucky_draw_business_hours.weekly_schedule[day],
            [field]: value
          }
        }
      }
    }));
  };

  const applyToAllDays = (field, value) => {
    const updatedSchedule = {};
    weekDays.forEach(({ key }) => {
      updatedSchedule[key] = {
        ...settings.lucky_draw_business_hours.weekly_schedule[key],
        [field]: value
      };
    });

    setSettings(prev => ({
      ...prev,
      lucky_draw_business_hours: {
        ...prev.lucky_draw_business_hours,
        weekly_schedule: updatedSchedule
      }
    }));
  };

  if (loading) {
    return <div className="p-6">加载中...</div>;
  }

  if (domains.length === 0) {
    return (
      <div className="p-6">
        <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4 text-yellow-800">
          您还没有管理的店铺
        </div>
      </div>
    );
  }

  return (
    <div className="p-6 max-w-6xl mx-auto">
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-gray-900 flex items-center gap-2">
          <Settings className="w-6 h-6" />
          一元购功能设置
        </h1>
        <p className="text-sm text-gray-600 mt-1">
          配置店铺的一元购功能和营业时间
        </p>
      </div>

      <div className="mb-6">
        <label className="block text-sm font-medium text-gray-700 mb-2">选择店铺</label>
        <select
          value={selectedDomain || ''}
          onChange={(e) => setSelectedDomain(e.target.value)}
          className="w-full px-4 py-2 border rounded-lg"
        >
          {domains.map((domain) => (
            <option key={domain.id} value={domain.id}>
              {domain.display_name} ({domain.domain})
            </option>
          ))}
        </select>
      </div>

      {permissionCheck && !permissionCheck.allowed && (
        <div className="mb-6 bg-red-50 border border-red-200 rounded-lg p-4">
          <div className="flex items-start gap-2">
            <AlertCircle className="w-5 h-5 text-red-600 mt-0.5" />
            <div>
              <p className="font-medium text-red-800">无法启用一元购功能</p>
              <p className="text-sm text-red-700 mt-1">{permissionCheck.reason}</p>
            </div>
          </div>
        </div>
      )}

      {businessStatus && (
        <div className={`mb-6 rounded-lg p-4 ${businessStatus.is_open ? 'bg-green-50 border border-green-200' : 'bg-yellow-50 border border-yellow-200'}`}>
          <div className="flex items-start gap-2">
            {businessStatus.is_open ? (
              <CheckCircle className="w-5 h-5 text-green-600 mt-0.5" />
            ) : (
              <Clock className="w-5 h-5 text-yellow-600 mt-0.5" />
            )}
            <div>
              <p className={`font-medium ${businessStatus.is_open ? 'text-green-800' : 'text-yellow-800'}`}>
                {businessStatus.reason}
              </p>
              {businessStatus.current_time && (
                <p className="text-sm mt-1">
                  当前时间: {businessStatus.current_time} ({businessStatus.timezone})
                </p>
              )}
              {businessStatus.business_hours && (
                <p className="text-sm">
                  营业时间: {businessStatus.business_hours.open} - {businessStatus.business_hours.close}
                </p>
              )}
              {businessStatus.next_open_time && (
                <p className="text-sm text-yellow-700">
                  下次开放: {businessStatus.next_open_time}
                </p>
              )}
            </div>
          </div>
        </div>
      )}

      <div className="space-y-6">
        <div className="bg-white rounded-lg shadow-md p-6">
          <h2 className="text-lg font-semibold mb-4 flex items-center gap-2">
            <Power className="w-5 h-5" />
            基本设置
          </h2>

          <div className="space-y-4">
            <div>
              <label className="flex items-center gap-2">
                <input
                  type="checkbox"
                  checked={settings.enable_lucky_draw}
                  onChange={(e) => setSettings({ ...settings, enable_lucky_draw: e.target.checked })}
                  className="rounded"
                  disabled={permissionCheck && !permissionCheck.allowed}
                />
                <span className="font-medium">启用一元购功能</span>
              </label>
              <p className="text-xs text-gray-500 mt-1 ml-6">
                开启后，用户可以参与一元购活动
              </p>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                店铺所在地区 *
              </label>
              <select
                value={settings.lucky_draw_region_code}
                onChange={(e) => setSettings({ ...settings, lucky_draw_region_code: e.target.value })}
                className="w-full px-4 py-2 border rounded-lg"
              >
                <option value="">请选择地区</option>
                {allowedRegions.map((region) => (
                  <option key={region.id} value={region.country_code}>
                    {region.country_name} ({region.country_code})
                  </option>
                ))}
              </select>
              <p className="text-xs text-gray-500 mt-1">
                只有超级管理员允许的地区才能开启一元购功能
              </p>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                时区设置
              </label>
              <select
                value={settings.lucky_draw_timezone}
                onChange={(e) => {
                  const newTimezone = e.target.value;
                  setSettings({
                    ...settings,
                    lucky_draw_timezone: newTimezone,
                    lucky_draw_business_hours: {
                      ...settings.lucky_draw_business_hours,
                      timezone: newTimezone
                    }
                  });
                }}
                className="w-full px-4 py-2 border rounded-lg"
              >
                {timezones.map((tz) => (
                  <option key={tz.value} value={tz.value}>
                    {tz.label}
                  </option>
                ))}
              </select>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-lg shadow-md p-6">
          <h2 className="text-lg font-semibold mb-4 flex items-center gap-2">
            <Clock className="w-5 h-5" />
            营业时间设置
          </h2>

          <div className="mb-4">
            <label className="flex items-center gap-2">
              <input
                type="checkbox"
                checked={settings.lucky_draw_business_hours.enabled}
                onChange={(e) => setSettings({
                  ...settings,
                  lucky_draw_business_hours: {
                    ...settings.lucky_draw_business_hours,
                    enabled: e.target.checked
                  }
                })}
                className="rounded"
              />
              <span className="font-medium">启用营业时间限制</span>
            </label>
            <p className="text-xs text-gray-500 mt-1 ml-6">
              关闭后将24小时营业，开启后仅在设置的时间段内开放
            </p>
          </div>

          {settings.lucky_draw_business_hours.enabled && (
            <>
              <div className="mb-6 p-4 bg-gray-50 rounded-lg">
                <h3 className="text-sm font-medium mb-3">快速设置（应用到所有天）</h3>
                <div className="flex gap-4">
                  <div>
                    <label className="block text-xs text-gray-600 mb-1">开门时间</label>
                    <input
                      type="time"
                      onChange={(e) => applyToAllDays('open', e.target.value)}
                      className="px-3 py-2 border rounded-lg"
                    />
                  </div>
                  <div>
                    <label className="block text-xs text-gray-600 mb-1">关门时间</label>
                    <input
                      type="time"
                      onChange={(e) => applyToAllDays('close', e.target.value)}
                      className="px-3 py-2 border rounded-lg"
                    />
                  </div>
                </div>
              </div>

              <div className="space-y-3">
                <h3 className="text-sm font-medium">每周营业时间</h3>
                {weekDays.map(({ key, label }) => {
                  const schedule = settings.lucky_draw_business_hours.weekly_schedule[key];
                  return (
                    <div key={key} className="flex items-center gap-4 p-3 bg-gray-50 rounded-lg">
                      <div className="w-16">
                        <label className="flex items-center gap-2">
                          <input
                            type="checkbox"
                            checked={schedule.enabled}
                            onChange={(e) => updateWeeklySchedule(key, 'enabled', e.target.checked)}
                            className="rounded"
                          />
                          <span className="text-sm font-medium">{label}</span>
                        </label>
                      </div>
                      {schedule.enabled && (
                        <>
                          <div>
                            <label className="block text-xs text-gray-600 mb-1">开门</label>
                            <input
                              type="time"
                              value={schedule.open}
                              onChange={(e) => updateWeeklySchedule(key, 'open', e.target.value)}
                              className="px-3 py-1 border rounded"
                            />
                          </div>
                          <span className="text-gray-400">-</span>
                          <div>
                            <label className="block text-xs text-gray-600 mb-1">关门</label>
                            <input
                              type="time"
                              value={schedule.close}
                              onChange={(e) => updateWeeklySchedule(key, 'close', e.target.value)}
                              className="px-3 py-1 border rounded"
                            />
                          </div>
                          {schedule.close < schedule.open && (
                            <span className="text-xs text-orange-600">
                              （跨天营业）
                            </span>
                          )}
                        </>
                      )}
                      {!schedule.enabled && (
                        <span className="text-sm text-gray-400">不营业</span>
                      )}
                    </div>
                  );
                })}
              </div>

              <div className="mt-4 p-3 bg-blue-50 border border-blue-200 rounded-lg">
                <p className="text-xs text-blue-800">
                  <strong>提示：</strong>
                  支持跨天营业时间设置。例如：设置关门时间早于开门时间（如 23:00 开门，02:00 关门）表示跨越午夜营业。
                </p>
              </div>
            </>
          )}
        </div>

        <div className="flex justify-end">
          <button
            onClick={handleSave}
            className="flex items-center gap-2 px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
          >
            <Save className="w-4 h-4" />
            保存设置
          </button>
        </div>
      </div>
    </div>
  );
}
