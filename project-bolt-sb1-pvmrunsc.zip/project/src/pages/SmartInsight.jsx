import { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import { useToast } from '../contexts/ToastContext';
import {
  Brain,
  Shield,
  Database,
  CheckCircle,
  XCircle,
  Clock,
  AlertTriangle,
  Eye,
  EyeOff,
  Activity,
  BookOpen,
  Settings,
  Play,
  Pause,
  BarChart3,
  Users,
  FileText,
  Lock,
  Unlock,
  Search,
  Filter,
  RefreshCw,
  Code2,
  Plus,
  Trash2,
  Save,
  Sparkles
} from 'lucide-react';
import Modal from '../components/Modal';
import CodeEditor from '../components/CodeEditor';

export default function SmartInsight() {
  const [activeTab, setActiveTab] = useState('modules');
  const [modules, setModules] = useState([]);
  const [operationQueue, setOperationQueue] = useState([]);
  const [learningData, setLearningData] = useState([]);
  const [maskingRules, setMaskingRules] = useState([]);
  const [executionLogs, setExecutionLogs] = useState([]);
  const [isSuperAdmin, setIsSuperAdmin] = useState(false);
  const [loading, setLoading] = useState(true);
  const [selectedModule, setSelectedModule] = useState(null);
  const [showDetailsModal, setShowDetailsModal] = useState(false);
  const [showReviewModal, setShowReviewModal] = useState(false);
  const [selectedOperation, setSelectedOperation] = useState(null);
  const [reviewNotes, setReviewNotes] = useState('');

  const [codeProjects, setCodeProjects] = useState([]);
  const [selectedProject, setSelectedProject] = useState(null);
  const [codeFiles, setCodeFiles] = useState([]);
  const [currentFile, setCurrentFile] = useState(null);
  const [showNewProjectModal, setShowNewProjectModal] = useState(false);
  const [showNewFileModal, setShowNewFileModal] = useState(false);
  const [newProject, setNewProject] = useState({ name: '', description: '', language: 'javascript', framework: '' });
  const [newFile, setNewFile] = useState({ name: '', language: 'javascript', prompt: '' });
  const [generatingCode, setGeneratingCode] = useState(false);

  const { showToast } = useToast();

  useEffect(() => {
    loadData();
    checkSuperAdmin();
  }, []);

  const checkSuperAdmin = async () => {
    const { data } = await supabase
      .from('sys_admins')
      .select('is_super_admin')
      .eq('id', (await supabase.auth.getUser()).data.user.id)
      .single();

    if (data) {
      setIsSuperAdmin(data.is_super_admin);
    }
  };

  const loadData = async () => {
    setLoading(true);
    try {
      await Promise.all([
        loadModules(),
        loadOperationQueue(),
        loadLearningData(),
        loadMaskingRules(),
        loadExecutionLogs(),
        loadCodeProjects()
      ]);
    } catch (error) {
      console.error('Error loading data:', error);
      showToast('加载数据失败', 'error');
    } finally {
      setLoading(false);
    }
  };

  const loadModules = async () => {
    const { data, error } = await supabase
      .from('ai_module_registry')
      .select('*')
      .order('module_key');

    if (!error && data) {
      setModules(data);
    }
  };

  const loadOperationQueue = async () => {
    const { data: domainData } = await supabase
      .from('sys_domains')
      .select('id')
      .limit(1)
      .single();

    if (domainData) {
      const { data, error } = await supabase
        .from('ai_operation_queue')
        .select(`
          *,
          requester:requested_by(full_name),
          reviewer:reviewed_by(full_name)
        `)
        .eq('domain_id', domainData.id)
        .order('created_at', { ascending: false })
        .limit(50);

      if (!error && data) {
        setOperationQueue(data);
      }
    }
  };

  const loadLearningData = async () => {
    const { data: domainData } = await supabase
      .from('sys_domains')
      .select('id')
      .limit(1)
      .single();

    if (domainData) {
      const { data, error } = await supabase
        .from('ai_learning_data')
        .select('*')
        .eq('domain_id', domainData.id)
        .order('created_at', { ascending: false })
        .limit(50);

      if (!error && data) {
        setLearningData(data);
      }
    }
  };

  const loadMaskingRules = async () => {
    const { data, error } = await supabase
      .from('ai_data_masking_rules')
      .select('*')
      .order('module_key, table_name, field_name');

    if (!error && data) {
      setMaskingRules(data);
    }
  };

  const loadExecutionLogs = async () => {
    const { data: domainData } = await supabase
      .from('sys_domains')
      .select('id')
      .limit(1)
      .single();

    if (domainData) {
      const { data, error } = await supabase
        .from('ai_execution_logs')
        .select(`
          *,
          executor:executed_by(full_name)
        `)
        .eq('domain_id', domainData.id)
        .order('created_at', { ascending: false })
        .limit(50);

      if (!error && data) {
        setExecutionLogs(data);
      }
    }
  };

  const loadCodeProjects = async () => {
    const { data: domainData } = await supabase
      .from('sys_domains')
      .select('id')
      .limit(1)
      .single();

    if (domainData) {
      const { data, error } = await supabase
        .from('ai_code_projects')
        .select('*')
        .eq('domain_id', domainData.id)
        .order('updated_at', { ascending: false });

      if (!error && data) {
        setCodeProjects(data);
      }
    }
  };

  const loadCodeFiles = async (projectId) => {
    const { data, error } = await supabase
      .from('ai_code_files')
      .select('*')
      .eq('project_id', projectId)
      .eq('is_active', true)
      .order('created_at', { ascending: false });

    if (!error && data) {
      setCodeFiles(data);
    }
  };

  const handleCreateProject = async () => {
    if (!newProject.name) {
      showToast('请输入项目名称', 'error');
      return;
    }

    const { data: domainData } = await supabase
      .from('sys_domains')
      .select('id')
      .limit(1)
      .single();

    if (!domainData) {
      showToast('获取域信息失败', 'error');
      return;
    }

    const { data: userData } = await supabase.auth.getUser();

    try {
      const { data, error } = await supabase
        .from('ai_code_projects')
        .insert([{
          domain_id: domainData.id,
          project_name: newProject.name,
          description: newProject.description,
          language: newProject.language,
          framework: newProject.framework,
          created_by: userData.user.id
        }])
        .select()
        .single();

      if (error) throw error;

      showToast('项目创建成功', 'success');
      setShowNewProjectModal(false);
      setNewProject({ name: '', description: '', language: 'javascript', framework: '' });
      loadCodeProjects();
    } catch (error) {
      console.error('Error creating project:', error);
      showToast('创建项目失败: ' + error.message, 'error');
    }
  };

  const handleGenerateCode = async () => {
    if (!selectedProject) {
      showToast('请先选择一个项目', 'error');
      return;
    }

    if (!newFile.prompt) {
      showToast('请输入代码需求描述', 'error');
      return;
    }

    setGeneratingCode(true);

    try {
      const generatedCode = generateCodeFromPrompt(newFile.prompt, newFile.language);

      const { data: userData } = await supabase.auth.getUser();

      const { data, error } = await supabase
        .from('ai_code_files')
        .insert([{
          project_id: selectedProject.id,
          file_name: newFile.name || 'untitled',
          language: newFile.language,
          code_content: generatedCode,
          ai_prompt: newFile.prompt,
          ai_model: 'SmartInsight AI v1.0',
          created_by: userData.user.id,
          file_size: generatedCode.length
        }])
        .select()
        .single();

      if (error) throw error;

      showToast('代码生成成功', 'success');
      setShowNewFileModal(false);
      setNewFile({ name: '', language: 'javascript', prompt: '' });
      loadCodeFiles(selectedProject.id);
      setCurrentFile(data);
    } catch (error) {
      console.error('Error generating code:', error);
      showToast('生成代码失败: ' + error.message, 'error');
    } finally {
      setGeneratingCode(false);
    }
  };

  const generateCodeFromPrompt = (prompt, language) => {
    const templates = {
      javascript: `// ${prompt}\n\nfunction main() {\n  // TODO: 实现功能\n  console.log('${prompt}');\n}\n\nmain();\n`,
      typescript: `// ${prompt}\n\nfunction main(): void {\n  // TODO: 实现功能\n  console.log('${prompt}');\n}\n\nmain();\n`,
      python: `# ${prompt}\n\ndef main():\n    # TODO: 实现功能\n    print('${prompt}')\n\nif __name__ == '__main__':\n    main()\n`,
      java: `// ${prompt}\n\npublic class Main {\n    public static void main(String[] args) {\n        // TODO: 实现功能\n        System.out.println("${prompt}");\n    }\n}\n`,
      csharp: `// ${prompt}\n\nusing System;\n\nclass Program {\n    static void Main() {\n        // TODO: 实现功能\n        Console.WriteLine("${prompt}");\n    }\n}\n`,
      php: `<?php\n// ${prompt}\n\nfunction main() {\n    // TODO: 实现功能\n    echo "${prompt}";\n}\n\nmain();\n`,
      go: `// ${prompt}\n\npackage main\n\nimport "fmt"\n\nfunc main() {\n    // TODO: 实现功能\n    fmt.Println("${prompt}")\n}\n`,
      rust: `// ${prompt}\n\nfn main() {\n    // TODO: 实现功能\n    println!("${prompt}");\n}\n`,
      sql: `-- ${prompt}\n\nSELECT * FROM table_name;\n`,
      html: `<!DOCTYPE html>\n<html lang="zh-CN">\n<head>\n    <meta charset="UTF-8">\n    <title>${prompt}</title>\n</head>\n<body>\n    <h1>${prompt}</h1>\n</body>\n</html>\n`,
      css: `/* ${prompt} */\n\n.container {\n    display: flex;\n    justify-content: center;\n    align-items: center;\n}\n`,
      json: `{\n  "description": "${prompt}",\n  "data": {}\n}\n`
    };

    return templates[language] || `// ${prompt}\n\n// TODO: 实现功能\n`;
  };

  const handleSaveFile = async () => {
    if (!currentFile) return;

    try {
      const { error } = await supabase
        .from('ai_code_files')
        .update({
          code_content: currentFile.code_content,
          file_name: currentFile.file_name,
          language: currentFile.language,
          updated_at: new Date().toISOString(),
          file_size: currentFile.code_content.length
        })
        .eq('id', currentFile.id);

      if (error) throw error;

      showToast('保存成功', 'success');
      loadCodeFiles(selectedProject.id);
    } catch (error) {
      console.error('Error saving file:', error);
      showToast('保存失败: ' + error.message, 'error');
    }
  };

  const handleDeleteFile = async (fileId) => {
    if (!confirm('确定要删除这个文件吗？')) return;

    try {
      const { error } = await supabase
        .from('ai_code_files')
        .delete()
        .eq('id', fileId);

      if (error) throw error;

      showToast('删除成功', 'success');
      if (currentFile?.id === fileId) {
        setCurrentFile(null);
      }
      loadCodeFiles(selectedProject.id);
    } catch (error) {
      console.error('Error deleting file:', error);
      showToast('删除失败: ' + error.message, 'error');
    }
  };

  const handleDeleteProject = async (projectId) => {
    if (!confirm('确定要删除这个项目吗？这将删除项目下的所有文件。')) return;

    try {
      const { error } = await supabase
        .from('ai_code_projects')
        .delete()
        .eq('id', projectId);

      if (error) throw error;

      showToast('删除成功', 'success');
      if (selectedProject?.id === projectId) {
        setSelectedProject(null);
        setCodeFiles([]);
        setCurrentFile(null);
      }
      loadCodeProjects();
    } catch (error) {
      console.error('Error deleting project:', error);
      showToast('删除失败: ' + error.message, 'error');
    }
  };

  const handleReviewOperation = async (operationId, approve) => {
    if (!isSuperAdmin) {
      showToast('只有超级管理员可以审核操作', 'error');
      return;
    }

    try {
      const { data, error } = await supabase.rpc('ai_review_operation', {
        p_operation_id: operationId,
        p_approve: approve,
        p_review_notes: reviewNotes
      });

      if (error) throw error;

      showToast(approve ? '操作已批准' : '操作已拒绝', 'success');
      setShowReviewModal(false);
      setReviewNotes('');
      loadOperationQueue();
    } catch (error) {
      console.error('Error reviewing operation:', error);
      showToast('审核失败: ' + error.message, 'error');
    }
  };

  const handleExecuteOperation = async (operationId) => {
    if (!isSuperAdmin) {
      showToast('只有超级管理员可以执行操作', 'error');
      return;
    }

    try {
      const { data, error } = await supabase.rpc('ai_execute_operation', {
        p_operation_id: operationId
      });

      if (error) throw error;

      if (data && data.success) {
        showToast('操作执行成功', 'success');
        loadOperationQueue();
        loadExecutionLogs();
      } else {
        throw new Error(data.error || '执行失败');
      }
    } catch (error) {
      console.error('Error executing operation:', error);
      showToast('执行失败: ' + error.message, 'error');
    }
  };

  const getStatusBadge = (status) => {
    const statusConfig = {
      pending: { bg: 'bg-yellow-100', text: 'text-yellow-800', label: '待审核', icon: Clock },
      approved: { bg: 'bg-green-100', text: 'text-green-800', label: '已批准', icon: CheckCircle },
      rejected: { bg: 'bg-red-100', text: 'text-red-800', label: '已拒绝', icon: XCircle },
      executed: { bg: 'bg-blue-100', text: 'text-blue-800', label: '已执行', icon: CheckCircle },
      failed: { bg: 'bg-red-100', text: 'text-red-800', label: '失败', icon: XCircle },
      cancelled: { bg: 'bg-gray-100', text: 'text-gray-800', label: '已取消', icon: XCircle }
    };
    const config = statusConfig[status] || statusConfig.pending;
    const Icon = config.icon;
    return (
      <span className={`inline-flex items-center gap-1 px-2 py-1 rounded-full text-xs font-medium ${config.bg} ${config.text}`}>
        <Icon className="w-3 h-3" />
        {config.label}
      </span>
    );
  };

  const getRiskBadge = (riskLevel) => {
    const riskConfig = {
      low: { bg: 'bg-blue-100', text: 'text-blue-800', label: '低风险' },
      medium: { bg: 'bg-yellow-100', text: 'text-yellow-800', label: '中风险' },
      high: { bg: 'bg-orange-100', text: 'text-orange-800', label: '高风险' },
      critical: { bg: 'bg-red-100', text: 'text-red-800', label: '严重风险' }
    };
    const config = riskConfig[riskLevel] || riskConfig.medium;
    return (
      <span className={`px-2 py-1 rounded-full text-xs font-medium ${config.bg} ${config.text}`}>
        {config.label}
      </span>
    );
  };

  const getSensitivityBadge = (sensitivity) => {
    const sensitivityConfig = {
      low: { bg: 'bg-green-100', text: 'text-green-800', label: '低敏感' },
      normal: { bg: 'bg-blue-100', text: 'text-blue-800', label: '普通' },
      high: { bg: 'bg-orange-100', text: 'text-orange-800', label: '高敏感' },
      critical: { bg: 'bg-red-100', text: 'text-red-800', label: '极敏感' }
    };
    const config = sensitivityConfig[sensitivity] || sensitivityConfig.normal;
    return (
      <span className={`px-2 py-1 rounded-full text-xs font-medium ${config.bg} ${config.text}`}>
        {config.label}
      </span>
    );
  };

  const tabs = [
    { id: 'modules', name: 'AI模块管理', icon: Database, adminOnly: false },
    { id: 'codestudio', name: 'AI代码工作室', icon: Code2, adminOnly: false },
    { id: 'queue', name: '操作审核队列', icon: CheckCircle, adminOnly: true },
    { id: 'learning', name: '学习数据', icon: BookOpen, adminOnly: false },
    { id: 'masking', name: '数据脱敏', icon: Shield, adminOnly: true },
    { id: 'logs', name: '执行日志', icon: Activity, adminOnly: false }
  ];

  const filteredTabs = tabs.filter(tab => !tab.adminOnly || isSuperAdmin);

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-start">
        <div>
          <div className="flex items-center gap-3 mb-2">
            <div className="w-12 h-12 bg-gradient-to-br from-purple-500 to-indigo-600 rounded-lg flex items-center justify-center">
              <Brain className="w-7 h-7 text-white" />
            </div>
            <div>
              <h1 className="text-2xl font-bold text-gray-900">SmartInsight AI 中心</h1>
              <p className="text-gray-600 mt-1">AI智能模块管理与自学习系统</p>
            </div>
          </div>
          {isSuperAdmin && (
            <div className="flex items-center gap-2 mt-2 px-3 py-2 bg-purple-50 border border-purple-200 rounded-lg w-fit">
              <Shield className="w-4 h-4 text-purple-600" />
              <span className="text-sm font-medium text-purple-900">超级管理员模式</span>
            </div>
          )}
        </div>
        <button
          onClick={loadData}
          className="flex items-center gap-2 px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50 transition-colors"
        >
          <RefreshCw className="w-5 h-5" />
          刷新
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-gradient-to-br from-blue-50 to-blue-100 rounded-lg shadow-sm border border-blue-200 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-blue-700 font-medium">可访问模块</p>
              <p className="text-2xl font-bold text-blue-900 mt-1">
                {modules.filter(m => m.is_active).length}
              </p>
            </div>
            <div className="p-3 bg-blue-500 rounded-lg">
              <Database className="w-6 h-6 text-white" />
            </div>
          </div>
        </div>

        <div className="bg-gradient-to-br from-yellow-50 to-yellow-100 rounded-lg shadow-sm border border-yellow-200 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-yellow-700 font-medium">待审核操作</p>
              <p className="text-2xl font-bold text-yellow-900 mt-1">
                {operationQueue.filter(o => o.status === 'pending').length}
              </p>
            </div>
            <div className="p-3 bg-yellow-500 rounded-lg">
              <Clock className="w-6 h-6 text-white" />
            </div>
          </div>
        </div>

        <div className="bg-gradient-to-br from-green-50 to-green-100 rounded-lg shadow-sm border border-green-200 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-green-700 font-medium">学习样本</p>
              <p className="text-2xl font-bold text-green-900 mt-1">
                {learningData.length}
              </p>
            </div>
            <div className="p-3 bg-green-500 rounded-lg">
              <BookOpen className="w-6 h-6 text-white" />
            </div>
          </div>
        </div>

        <div className="bg-gradient-to-br from-purple-50 to-purple-100 rounded-lg shadow-sm border border-purple-200 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-purple-700 font-medium">脱敏规则</p>
              <p className="text-2xl font-bold text-purple-900 mt-1">
                {maskingRules.filter(r => r.is_active).length}
              </p>
            </div>
            <div className="p-3 bg-purple-500 rounded-lg">
              <Shield className="w-6 h-6 text-white" />
            </div>
          </div>
        </div>
      </div>

      <div className="bg-white rounded-lg shadow-sm border border-gray-200">
        <div className="border-b border-gray-200">
          <nav className="flex -mb-px">
            {filteredTabs.map((tab) => {
              const Icon = tab.icon;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`flex items-center gap-2 px-6 py-4 border-b-2 font-medium text-sm transition-colors ${
                    activeTab === tab.id
                      ? 'border-purple-500 text-purple-600'
                      : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                  }`}
                >
                  <Icon className="w-5 h-5" />
                  {tab.name}
                  {tab.id === 'queue' && operationQueue.filter(o => o.status === 'pending').length > 0 && (
                    <span className="px-2 py-0.5 bg-red-500 text-white text-xs rounded-full">
                      {operationQueue.filter(o => o.status === 'pending').length}
                    </span>
                  )}
                </button>
              );
            })}
          </nav>
        </div>

        <div className="p-6">
          {activeTab === 'modules' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-lg font-semibold text-gray-900">AI可访问的系统模块</h2>
                <p className="text-sm text-gray-600">AI可以从这些模块获取数据进行分析和学习</p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {modules.map((module) => (
                  <div
                    key={module.id}
                    className={`bg-gradient-to-br from-gray-50 to-gray-100 rounded-lg p-6 border-2 transition-all hover:shadow-md ${
                      module.is_active
                        ? 'border-green-200 hover:border-green-300'
                        : 'border-gray-200 opacity-60'
                    }`}
                  >
                    <div className="flex items-start justify-between mb-4">
                      <div className="flex-1">
                        <h3 className="font-semibold text-gray-900 mb-1">
                          {module.module_name?.zh || module.module_key}
                        </h3>
                        <p className="text-xs text-gray-600 mb-2">{module.module_key}</p>
                      </div>
                      {module.is_active ? (
                        <Unlock className="w-5 h-5 text-green-600" />
                      ) : (
                        <Lock className="w-5 h-5 text-gray-400" />
                      )}
                    </div>

                    <div className="space-y-2 mb-4">
                      <div className="flex items-center justify-between text-sm">
                        <span className="text-gray-600">数据敏感度:</span>
                        {getSensitivityBadge(module.data_sensitivity)}
                      </div>
                      <div className="flex items-center justify-between text-sm">
                        <span className="text-gray-600">数据脱敏:</span>
                        {module.requires_masking ? (
                          <span className="flex items-center gap-1 text-orange-600">
                            <EyeOff className="w-3 h-3" />
                            启用
                          </span>
                        ) : (
                          <span className="flex items-center gap-1 text-gray-600">
                            <Eye className="w-3 h-3" />
                            禁用
                          </span>
                        )}
                      </div>
                      <div className="text-sm">
                        <span className="text-gray-600">访问次数: </span>
                        <span className="font-medium text-gray-900">{module.access_count}</span>
                      </div>
                    </div>

                    <div className="flex flex-wrap gap-1 mb-3">
                      {module.allowed_operations?.map((op) => (
                        <span
                          key={op}
                          className="px-2 py-1 bg-blue-100 text-blue-700 text-xs rounded"
                        >
                          {op}
                        </span>
                      ))}
                    </div>

                    {module.table_names && module.table_names.length > 0 && (
                      <div className="text-xs text-gray-600">
                        <span className="font-medium">表:</span> {module.table_names.join(', ')}
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}

          {activeTab === 'queue' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-lg font-semibold text-gray-900">AI操作审核队列</h2>
                <p className="text-sm text-gray-600">所有AI建议的操作需要人工确认后才能执行</p>
              </div>

              {operationQueue.length === 0 ? (
                <div className="text-center py-12">
                  <CheckCircle className="w-12 h-12 text-gray-400 mx-auto mb-3" />
                  <p className="text-gray-600">暂无待审核操作</p>
                </div>
              ) : (
                <div className="space-y-3">
                  {operationQueue.map((operation) => (
                    <div
                      key={operation.id}
                      className={`bg-white rounded-lg p-6 border-2 ${
                        operation.status === 'pending'
                          ? 'border-yellow-200 bg-yellow-50'
                          : operation.status === 'approved'
                          ? 'border-green-200'
                          : operation.status === 'rejected'
                          ? 'border-red-200'
                          : 'border-gray-200'
                      }`}
                    >
                      <div className="flex items-start justify-between mb-4">
                        <div className="flex-1">
                          <div className="flex items-center gap-3 mb-2">
                            <h3 className="font-semibold text-gray-900">
                              {operation.operation_type.toUpperCase()} - {operation.target_module}
                            </h3>
                            {getStatusBadge(operation.status)}
                            {getRiskBadge(operation.risk_level)}
                          </div>
                          <p className="text-sm text-gray-700 mb-2">
                            <span className="font-medium">目标表:</span> {operation.target_table}
                          </p>
                          <p className="text-sm text-gray-600 mb-3">
                            <span className="font-medium">AI推理:</span> {operation.ai_reasoning}
                          </p>
                          {operation.estimated_impact && (
                            <p className="text-sm text-orange-700 bg-orange-50 px-3 py-2 rounded-lg mb-3">
                              <span className="font-medium">预估影响:</span> {operation.estimated_impact}
                            </p>
                          )}
                          <div className="flex items-center gap-4 text-xs text-gray-500">
                            <span>请求人: {operation.requester?.full_name || '未知'}</span>
                            <span>时间: {new Date(operation.created_at).toLocaleString('zh-CN')}</span>
                            {operation.reviewed_by && (
                              <span>审核人: {operation.reviewer?.full_name}</span>
                            )}
                          </div>
                        </div>
                      </div>

                      {operation.status === 'pending' && isSuperAdmin && (
                        <div className="flex gap-3 pt-4 border-t border-gray-200">
                          <button
                            onClick={() => {
                              setSelectedOperation(operation);
                              setShowReviewModal(true);
                            }}
                            className="flex items-center gap-2 px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors"
                          >
                            <CheckCircle className="w-4 h-4" />
                            批准
                          </button>
                          <button
                            onClick={() => handleReviewOperation(operation.id, false)}
                            className="flex items-center gap-2 px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors"
                          >
                            <XCircle className="w-4 h-4" />
                            拒绝
                          </button>
                        </div>
                      )}

                      {operation.status === 'approved' && isSuperAdmin && (
                        <div className="flex gap-3 pt-4 border-t border-gray-200">
                          <button
                            onClick={() => handleExecuteOperation(operation.id)}
                            className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
                          >
                            <Play className="w-4 h-4" />
                            执行操作
                          </button>
                        </div>
                      )}

                      {operation.review_notes && (
                        <div className="mt-4 pt-4 border-t border-gray-200">
                          <p className="text-sm text-gray-700">
                            <span className="font-medium">审核备注:</span> {operation.review_notes}
                          </p>
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {activeTab === 'learning' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-lg font-semibold text-gray-900">AI学习数据</h2>
                <p className="text-sm text-gray-600">AI从用户交互中学习的知识（已自动脱敏）</p>
              </div>

              {learningData.length === 0 ? (
                <div className="text-center py-12">
                  <BookOpen className="w-12 h-12 text-gray-400 mx-auto mb-3" />
                  <p className="text-gray-600">暂无学习数据</p>
                </div>
              ) : (
                <div className="space-y-3">
                  {learningData.map((learning) => (
                    <div
                      key={learning.id}
                      className="bg-gradient-to-br from-purple-50 to-blue-50 rounded-lg p-6 border border-purple-200"
                    >
                      <div className="flex items-start justify-between mb-3">
                        <div className="flex items-center gap-2">
                          <span className="px-3 py-1 bg-purple-600 text-white text-xs rounded-full font-medium">
                            {learning.learning_type}
                          </span>
                          {learning.is_masked && (
                            <span className="flex items-center gap-1 px-2 py-1 bg-green-100 text-green-700 text-xs rounded-full">
                              <Shield className="w-3 h-3" />
                              已脱敏
                            </span>
                          )}
                        </div>
                        {learning.feedback_score && (
                          <span className="text-sm font-medium text-gray-700">
                            评分: {learning.feedback_score}/5
                          </span>
                        )}
                      </div>

                      <div className="space-y-2">
                        <div>
                          <p className="text-xs text-gray-600 mb-1">用户输入:</p>
                          <p className="text-sm text-gray-900 bg-white px-3 py-2 rounded-lg">
                            {learning.user_input}
                          </p>
                        </div>
                        <div>
                          <p className="text-xs text-gray-600 mb-1">AI响应:</p>
                          <p className="text-sm text-gray-900 bg-white px-3 py-2 rounded-lg">
                            {learning.ai_response}
                          </p>
                        </div>
                      </div>

                      <div className="flex items-center gap-4 mt-3 text-xs text-gray-600">
                        <span>置信度: {(learning.confidence_score || 0).toFixed(1)}%</span>
                        <span>{learning.is_successful ? '成功' : '失败'}</span>
                        <span>{new Date(learning.created_at).toLocaleString('zh-CN')}</span>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {activeTab === 'masking' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-lg font-semibold text-gray-900">数据脱敏规则</h2>
                <p className="text-sm text-gray-600">保护客户隐私的数据脱敏配置</p>
              </div>

              <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-4">
                <div className="flex items-start gap-3">
                  <Shield className="w-5 h-5 text-blue-600 flex-shrink-0 mt-0.5" />
                  <div>
                    <h3 className="text-sm font-semibold text-blue-900 mb-1">隐私保护说明</h3>
                    <p className="text-sm text-blue-800">
                      所有敏感数据在AI访问前都会自动脱敏处理，确保客户隐私不被泄露。
                      AI模型训练仅使用脱敏后的数据。
                    </p>
                  </div>
                </div>
              </div>

              {maskingRules.length === 0 ? (
                <div className="text-center py-12">
                  <Shield className="w-12 h-12 text-gray-400 mx-auto mb-3" />
                  <p className="text-gray-600">暂无脱敏规则</p>
                </div>
              ) : (
                <div className="overflow-x-auto">
                  <table className="min-w-full divide-y divide-gray-200">
                    <thead className="bg-gray-50">
                      <tr>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                          模块
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                          表名
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                          字段
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                          字段类型
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                          脱敏方法
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                          状态
                        </th>
                      </tr>
                    </thead>
                    <tbody className="bg-white divide-y divide-gray-200">
                      {maskingRules.map((rule) => (
                        <tr key={rule.id}>
                          <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                            {rule.module_key}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-600">
                            {rule.table_name}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                            {rule.field_name}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap">
                            <span className="px-2 py-1 bg-blue-100 text-blue-700 text-xs rounded">
                              {rule.field_type}
                            </span>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap">
                            <span className="px-2 py-1 bg-purple-100 text-purple-700 text-xs rounded">
                              {rule.masking_method}
                            </span>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap">
                            {rule.is_active ? (
                              <span className="flex items-center gap-1 text-green-600 text-sm">
                                <CheckCircle className="w-4 h-4" />
                                活跃
                              </span>
                            ) : (
                              <span className="flex items-center gap-1 text-gray-600 text-sm">
                                <XCircle className="w-4 h-4" />
                                禁用
                              </span>
                            )}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          )}

          {activeTab === 'codestudio' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between mb-4">
                <div>
                  <h2 className="text-lg font-semibold text-gray-900 flex items-center gap-2">
                    <Sparkles className="w-5 h-5 text-blue-600" />
                    AI代码工作室
                  </h2>
                  <p className="text-sm text-gray-600 mt-1">使用AI生成、编辑和管理代码</p>
                </div>
                <button
                  onClick={() => setShowNewProjectModal(true)}
                  className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
                >
                  <Plus className="w-4 h-4" />
                  新建项目
                </button>
              </div>

              <div className="grid grid-cols-12 gap-6">
                <div className="col-span-3 space-y-4">
                  <div className="bg-gray-50 rounded-lg p-4">
                    <h3 className="font-semibold text-gray-900 mb-3">项目列表</h3>
                    {codeProjects.length === 0 ? (
                      <p className="text-sm text-gray-600 text-center py-8">暂无项目</p>
                    ) : (
                      <div className="space-y-2">
                        {codeProjects.map((project) => (
                          <div
                            key={project.id}
                            className={`p-3 rounded-lg cursor-pointer transition-colors ${
                              selectedProject?.id === project.id
                                ? 'bg-blue-100 border-2 border-blue-500'
                                : 'bg-white border border-gray-200 hover:border-blue-300'
                            }`}
                            onClick={() => {
                              setSelectedProject(project);
                              loadCodeFiles(project.id);
                            }}
                          >
                            <div className="flex items-start justify-between">
                              <div className="flex-1 min-w-0">
                                <h4 className="font-medium text-gray-900 text-sm truncate">
                                  {project.project_name}
                                </h4>
                                <p className="text-xs text-gray-600 mt-1">
                                  {project.language}
                                </p>
                              </div>
                              <button
                                onClick={(e) => {
                                  e.stopPropagation();
                                  handleDeleteProject(project.id);
                                }}
                                className="ml-2 p-1 text-red-600 hover:bg-red-50 rounded"
                              >
                                <Trash2 className="w-4 h-4" />
                              </button>
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>

                  {selectedProject && (
                    <div className="bg-gray-50 rounded-lg p-4">
                      <div className="flex items-center justify-between mb-3">
                        <h3 className="font-semibold text-gray-900">文件列表</h3>
                        <button
                          onClick={() => setShowNewFileModal(true)}
                          className="p-1 text-blue-600 hover:bg-blue-50 rounded"
                        >
                          <Plus className="w-4 h-4" />
                        </button>
                      </div>
                      {codeFiles.length === 0 ? (
                        <p className="text-sm text-gray-600 text-center py-4">暂无文件</p>
                      ) : (
                        <div className="space-y-2">
                          {codeFiles.map((file) => (
                            <div
                              key={file.id}
                              className={`p-2 rounded cursor-pointer transition-colors ${
                                currentFile?.id === file.id
                                  ? 'bg-blue-100 border border-blue-500'
                                  : 'bg-white border border-gray-200 hover:border-blue-300'
                              }`}
                              onClick={() => setCurrentFile(file)}
                            >
                              <div className="flex items-center justify-between">
                                <span className="text-sm text-gray-900 truncate flex-1">
                                  {file.file_name}
                                </span>
                                <button
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    handleDeleteFile(file.id);
                                  }}
                                  className="ml-2 p-1 text-red-600 hover:bg-red-50 rounded"
                                >
                                  <Trash2 className="w-3 h-3" />
                                </button>
                              </div>
                              <span className="text-xs text-gray-500">{file.language}</span>
                            </div>
                          ))}
                        </div>
                      )}
                    </div>
                  )}
                </div>

                <div className="col-span-9">
                  {currentFile ? (
                    <div className="space-y-4">
                      <div className="flex items-center justify-between">
                        <div>
                          <h3 className="font-semibold text-gray-900">{currentFile.file_name}</h3>
                          {currentFile.ai_prompt && (
                            <p className="text-sm text-gray-600 mt-1">
                              需求: {currentFile.ai_prompt}
                            </p>
                          )}
                        </div>
                        <button
                          onClick={handleSaveFile}
                          className="flex items-center gap-2 px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors"
                        >
                          <Save className="w-4 h-4" />
                          保存
                        </button>
                      </div>

                      <CodeEditor
                        code={currentFile.code_content}
                        onChange={(newCode) =>
                          setCurrentFile({ ...currentFile, code_content: newCode })
                        }
                        language={currentFile.language}
                        onLanguageChange={(lang) =>
                          setCurrentFile({ ...currentFile, language: lang })
                        }
                        fileName={currentFile.file_name}
                        onFileNameChange={(name) =>
                          setCurrentFile({ ...currentFile, file_name: name })
                        }
                      />

                      <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                        <div className="flex items-start gap-3">
                          <Sparkles className="w-5 h-5 text-blue-600 flex-shrink-0 mt-0.5" />
                          <div className="flex-1">
                            <h4 className="text-sm font-semibold text-blue-900 mb-1">AI生成信息</h4>
                            <p className="text-sm text-blue-800">
                              模型: {currentFile.ai_model || 'SmartInsight AI'}
                            </p>
                            <p className="text-sm text-blue-800">
                              创建时间: {new Date(currentFile.created_at).toLocaleString('zh-CN')}
                            </p>
                          </div>
                        </div>
                      </div>
                    </div>
                  ) : (
                    <div className="h-full flex items-center justify-center bg-gray-50 rounded-lg border-2 border-dashed border-gray-300">
                      <div className="text-center">
                        <Code2 className="w-16 h-16 text-gray-400 mx-auto mb-4" />
                        <p className="text-gray-600 mb-2">选择一个文件开始编辑</p>
                        <p className="text-sm text-gray-500">
                          或创建新项目和文件来使用AI代码生成
                        </p>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </div>
          )}

          {activeTab === 'logs' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-lg font-semibold text-gray-900">执行日志</h2>
                <p className="text-sm text-gray-600">AI操作的完整执行记录</p>
              </div>

              {executionLogs.length === 0 ? (
                <div className="text-center py-12">
                  <Activity className="w-12 h-12 text-gray-400 mx-auto mb-3" />
                  <p className="text-gray-600">暂无执行日志</p>
                </div>
              ) : (
                <div className="space-y-3">
                  {executionLogs.map((log) => (
                    <div
                      key={log.id}
                      className={`bg-white rounded-lg p-6 border-2 ${
                        log.execution_status === 'success'
                          ? 'border-green-200'
                          : log.execution_status === 'failed'
                          ? 'border-red-200'
                          : 'border-yellow-200'
                      }`}
                    >
                      <div className="flex items-start justify-between mb-3">
                        <div className="flex-1">
                          <div className="flex items-center gap-3 mb-2">
                            <h3 className="font-semibold text-gray-900">
                              {log.operation_type.toUpperCase()} - {log.target_module}
                            </h3>
                            <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                              log.execution_status === 'success'
                                ? 'bg-green-100 text-green-800'
                                : log.execution_status === 'failed'
                                ? 'bg-red-100 text-red-800'
                                : 'bg-yellow-100 text-yellow-800'
                            }`}>
                              {log.execution_status === 'success' ? '成功' : log.execution_status === 'failed' ? '失败' : '部分'}
                            </span>
                          </div>
                          <p className="text-sm text-gray-700 mb-2">
                            <span className="font-medium">操作:</span> {log.operation_summary}
                          </p>
                          <p className="text-sm text-gray-600">
                            <span className="font-medium">目标表:</span> {log.target_table}
                          </p>
                          {log.records_affected > 0 && (
                            <p className="text-sm text-blue-700 mt-1">
                              影响 {log.records_affected} 条记录
                            </p>
                          )}
                          {log.error_message && (
                            <p className="text-sm text-red-700 bg-red-50 px-3 py-2 rounded-lg mt-2">
                              错误: {log.error_message}
                            </p>
                          )}
                        </div>
                      </div>

                      <div className="flex items-center gap-4 text-xs text-gray-500">
                        <span>执行人: {log.executor?.full_name || '系统'}</span>
                        <span>时间: {new Date(log.created_at).toLocaleString('zh-CN')}</span>
                        {log.execution_time_ms && (
                          <span>耗时: {log.execution_time_ms}ms</span>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}
        </div>
      </div>

      <div className="bg-gradient-to-r from-purple-50 to-blue-50 rounded-lg p-6 border border-purple-200">
        <div className="flex items-start gap-4">
          <div className="w-12 h-12 bg-white rounded-lg flex items-center justify-center flex-shrink-0">
            <Brain className="w-6 h-6 text-purple-600" />
          </div>
          <div>
            <h3 className="text-lg font-semibold text-gray-900 mb-2">
              AI安全保护机制
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="bg-white rounded-lg p-4">
                <Shield className="w-6 h-6 text-green-600 mb-2" />
                <h4 className="font-medium text-gray-900 text-sm mb-1">数据脱敏</h4>
                <p className="text-xs text-gray-600">
                  所有敏感数据自动脱敏，AI训练不会泄露客户隐私
                </p>
              </div>
              <div className="bg-white rounded-lg p-4">
                <CheckCircle className="w-6 h-6 text-blue-600 mb-2" />
                <h4 className="font-medium text-gray-900 text-sm mb-1">人工审核</h4>
                <p className="text-xs text-gray-600">
                  所有AI建议的操作必须经过人工确认才能执行
                </p>
              </div>
              <div className="bg-white rounded-lg p-4">
                <Activity className="w-6 h-6 text-orange-600 mb-2" />
                <h4 className="font-medium text-gray-900 text-sm mb-1">完整审计</h4>
                <p className="text-xs text-gray-600">
                  所有AI操作都有完整的日志记录，可追溯审计
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {showReviewModal && selectedOperation && (
        <Modal
          isOpen={showReviewModal}
          onClose={() => {
            setShowReviewModal(false);
            setReviewNotes('');
          }}
          title="审核AI操作"
        >
          <div className="space-y-4">
            <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
              <h3 className="font-semibold text-gray-900 mb-2">操作详情</h3>
              <div className="space-y-2 text-sm">
                <p><span className="font-medium">操作类型:</span> {selectedOperation.operation_type}</p>
                <p><span className="font-medium">目标模块:</span> {selectedOperation.target_module}</p>
                <p><span className="font-medium">目标表:</span> {selectedOperation.target_table}</p>
                <p><span className="font-medium">风险等级:</span> {getRiskBadge(selectedOperation.risk_level)}</p>
                <p className="pt-2"><span className="font-medium">AI推理:</span></p>
                <p className="text-gray-700">{selectedOperation.ai_reasoning}</p>
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                审核备注
              </label>
              <textarea
                value={reviewNotes}
                onChange={(e) => setReviewNotes(e.target.value)}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                rows="4"
                placeholder="请输入审核意见..."
              />
            </div>

            <div className="flex gap-3 pt-4">
              <button
                onClick={() => handleReviewOperation(selectedOperation.id, true)}
                className="flex-1 flex items-center justify-center gap-2 px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors"
              >
                <CheckCircle className="w-4 h-4" />
                批准执行
              </button>
              <button
                onClick={() => handleReviewOperation(selectedOperation.id, false)}
                className="flex-1 flex items-center justify-center gap-2 px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors"
              >
                <XCircle className="w-4 h-4" />
                拒绝
              </button>
            </div>
          </div>
        </Modal>
      )}

      {showNewProjectModal && (
        <Modal
          isOpen={showNewProjectModal}
          onClose={() => {
            setShowNewProjectModal(false);
            setNewProject({ name: '', description: '', language: 'javascript', framework: '' });
          }}
          title="创建新项目"
        >
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                项目名称 *
              </label>
              <input
                type="text"
                value={newProject.name}
                onChange={(e) => setNewProject({ ...newProject, name: e.target.value })}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                placeholder="例如: 我的第一个项目"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                项目描述
              </label>
              <textarea
                value={newProject.description}
                onChange={(e) => setNewProject({ ...newProject, description: e.target.value })}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                rows="3"
                placeholder="简单描述一下项目用途..."
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  主要语言
                </label>
                <select
                  value={newProject.language}
                  onChange={(e) => setNewProject({ ...newProject, language: e.target.value })}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                >
                  <option value="javascript">JavaScript</option>
                  <option value="typescript">TypeScript</option>
                  <option value="python">Python</option>
                  <option value="java">Java</option>
                  <option value="csharp">C#</option>
                  <option value="php">PHP</option>
                  <option value="go">Go</option>
                  <option value="rust">Rust</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  框架 (可选)
                </label>
                <input
                  type="text"
                  value={newProject.framework}
                  onChange={(e) => setNewProject({ ...newProject, framework: e.target.value })}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  placeholder="例如: React, Vue, Django"
                />
              </div>
            </div>

            <div className="flex gap-3 pt-4">
              <button
                onClick={() => {
                  setShowNewProjectModal(false);
                  setNewProject({ name: '', description: '', language: 'javascript', framework: '' });
                }}
                className="flex-1 px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors"
              >
                取消
              </button>
              <button
                onClick={handleCreateProject}
                className="flex-1 flex items-center justify-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
              >
                <Plus className="w-4 h-4" />
                创建项目
              </button>
            </div>
          </div>
        </Modal>
      )}

      {showNewFileModal && (
        <Modal
          isOpen={showNewFileModal}
          onClose={() => {
            setShowNewFileModal(false);
            setNewFile({ name: '', language: 'javascript', prompt: '' });
          }}
          title="AI生成代码文件"
        >
          <div className="space-y-4">
            <div className="bg-gradient-to-r from-blue-50 to-purple-50 border border-blue-200 rounded-lg p-4">
              <div className="flex items-start gap-3">
                <Sparkles className="w-5 h-5 text-blue-600 flex-shrink-0 mt-0.5" />
                <div>
                  <h4 className="text-sm font-semibold text-blue-900 mb-1">AI代码生成助手</h4>
                  <p className="text-sm text-blue-800">
                    描述您想要实现的功能，AI会根据您的需求生成相应的代码模板
                  </p>
                </div>
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                文件名
              </label>
              <input
                type="text"
                value={newFile.name}
                onChange={(e) => setNewFile({ ...newFile, name: e.target.value })}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                placeholder="例如: main, utils, api"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                编程语言
              </label>
              <select
                value={newFile.language}
                onChange={(e) => setNewFile({ ...newFile, language: e.target.value })}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              >
                <option value="javascript">JavaScript</option>
                <option value="typescript">TypeScript</option>
                <option value="python">Python</option>
                <option value="java">Java</option>
                <option value="csharp">C#</option>
                <option value="php">PHP</option>
                <option value="go">Go</option>
                <option value="rust">Rust</option>
                <option value="sql">SQL</option>
                <option value="html">HTML</option>
                <option value="css">CSS</option>
                <option value="json">JSON</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                功能需求描述 *
              </label>
              <textarea
                value={newFile.prompt}
                onChange={(e) => setNewFile({ ...newFile, prompt: e.target.value })}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                rows="4"
                placeholder="请详细描述您想要实现的功能，例如：创建一个用户登录功能，包含表单验证和错误处理..."
              />
            </div>

            <div className="flex gap-3 pt-4">
              <button
                onClick={() => {
                  setShowNewFileModal(false);
                  setNewFile({ name: '', language: 'javascript', prompt: '' });
                }}
                className="flex-1 px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors"
                disabled={generatingCode}
              >
                取消
              </button>
              <button
                onClick={handleGenerateCode}
                disabled={generatingCode}
                className="flex-1 flex items-center justify-center gap-2 px-4 py-2 bg-gradient-to-r from-blue-600 to-purple-600 text-white rounded-lg hover:from-blue-700 hover:to-purple-700 transition-colors disabled:opacity-50"
              >
                <Sparkles className="w-4 h-4" />
                {generatingCode ? '生成中...' : 'AI生成代码'}
              </button>
            </div>
          </div>
        </Modal>
      )}
    </div>
  );
}
