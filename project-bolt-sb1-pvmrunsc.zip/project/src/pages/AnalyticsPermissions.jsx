import { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';
import { useToast } from '../contexts/ToastContext';
import { Shield, Users, Plus, Edit2, Save, X, Check, AlertCircle, Calendar } from 'lucide-react';

export default function AnalyticsPermissions() {
  const { user } = useAuth();
  const { showToast } = useToast();
  const [permissions, setPermissions] = useState([]);
  const [domains, setDomains] = useState([]);
  const [admins, setAdmins] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showAddForm, setShowAddForm] = useState(false);
  const [editingId, setEditingId] = useState(null);
  const [formData, setFormData] = useState({
    domain_id: '',
    admin_id: '',
    can_view_analytics: true,
    can_create_links: true,
    can_manage_links: false,
    can_export_data: false,
    expires_at: null,
    notes: ''
  });

  useEffect(() => {
    if (!user?.is_super_admin) {
      showToast('error', '仅超级管理员可访问此页面');
      return;
    }
    loadData();
  }, [user]);

  const loadData = async () => {
    try {
      setLoading(true);
      await Promise.all([
        loadPermissions(),
        loadDomains(),
        loadAdmins()
      ]);
    } catch (error) {
      console.error('Error loading data:', error);
      showToast('error', '加载数据失败');
    } finally {
      setLoading(false);
    }
  };

  const loadPermissions = async () => {
    const { data, error } = await supabase
      .from('sys_analytics_permissions')
      .select(`
        *,
        domain:sys_domains(domain, display_name),
        admin:sys_admins!sys_analytics_permissions_admin_id_fkey(username, email),
        granted_by_admin:sys_admins!sys_analytics_permissions_granted_by_fkey(username)
      `)
      .order('created_at', { ascending: false });

    if (error) throw error;
    setPermissions(data || []);
  };

  const loadDomains = async () => {
    const { data, error } = await supabase
      .from('sys_domains')
      .select('id, domain, display_name')
      .order('display_name');

    if (error) throw error;
    setDomains(data || []);
  };

  const loadAdmins = async () => {
    const { data, error } = await supabase
      .from('sys_admins')
      .select('id, username, email, is_super_admin')
      .order('username');

    if (error) throw error;
    setAdmins(data || []);
  };

  const handleAdd = async () => {
    try {
      if (!formData.domain_id || !formData.admin_id) {
        showToast('error', '请选择店铺和管理员');
        return;
      }

      const { error } = await supabase
        .from('sys_analytics_permissions')
        .insert([{
          ...formData,
          granted_by: user.id,
          expires_at: formData.expires_at || null
        }]);

      if (error) throw error;

      showToast('success', '权限添加成功');
      setShowAddForm(false);
      resetForm();
      loadPermissions();
    } catch (error) {
      console.error('Error adding permission:', error);
      showToast('error', '添加失败：' + error.message);
    }
  };

  const handleUpdate = async (id) => {
    try {
      const permission = permissions.find(p => p.id === id);
      const { error } = await supabase
        .from('sys_analytics_permissions')
        .update({
          can_view_analytics: permission.can_view_analytics,
          can_create_links: permission.can_create_links,
          can_manage_links: permission.can_manage_links,
          can_export_data: permission.can_export_data,
          expires_at: permission.expires_at,
          notes: permission.notes
        })
        .eq('id', id);

      if (error) throw error;

      showToast('success', '权限更新成功');
      setEditingId(null);
      loadPermissions();
    } catch (error) {
      console.error('Error updating permission:', error);
      showToast('error', '更新失败');
    }
  };

  const handleDelete = async (id) => {
    if (!confirm('确定要删除此权限吗？')) return;

    try {
      const { error } = await supabase
        .from('sys_analytics_permissions')
        .delete()
        .eq('id', id);

      if (error) throw error;

      showToast('success', '权限删除成功');
      loadPermissions();
    } catch (error) {
      console.error('Error deleting permission:', error);
      showToast('error', '删除失败');
    }
  };

  const resetForm = () => {
    setFormData({
      domain_id: '',
      admin_id: '',
      can_view_analytics: true,
      can_create_links: true,
      can_manage_links: false,
      can_export_data: false,
      expires_at: null,
      notes: ''
    });
  };

  const updatePermission = (id, field, value) => {
    setPermissions(permissions.map(p =>
      p.id === id ? { ...p, [field]: value } : p
    ));
  };

  if (!user?.is_super_admin) {
    return (
      <div className="p-6">
        <div className="bg-red-50 border border-red-200 rounded-lg p-4 text-red-800">
          仅超级管理员可访问此页面
        </div>
      </div>
    );
  }

  if (loading) {
    return <div className="p-6">加载中...</div>;
  }

  return (
    <div className="p-6">
      <div className="mb-6 flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900 flex items-center gap-2">
            <Shield className="w-6 h-6" />
            统计分析权限管理
          </h1>
          <p className="text-sm text-gray-600 mt-1">
            管理店铺管理员的链接统计和分析权限
          </p>
        </div>
        <button
          onClick={() => setShowAddForm(true)}
          className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
        >
          <Plus className="w-4 h-4" />
          添加权限
        </button>
      </div>

      {showAddForm && (
        <div className="mb-6 bg-white rounded-lg shadow-md p-6">
          <h3 className="text-lg font-semibold mb-4">添加统计权限</h3>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                选择店铺 *
              </label>
              <select
                value={formData.domain_id}
                onChange={(e) => setFormData({ ...formData, domain_id: e.target.value })}
                className="w-full px-3 py-2 border rounded-lg"
              >
                <option value="">请选择店铺</option>
                {domains.map((domain) => (
                  <option key={domain.id} value={domain.id}>
                    {domain.display_name} ({domain.domain})
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                选择管理员 *
              </label>
              <select
                value={formData.admin_id}
                onChange={(e) => setFormData({ ...formData, admin_id: e.target.value })}
                className="w-full px-3 py-2 border rounded-lg"
              >
                <option value="">请选择管理员</option>
                {admins.map((admin) => (
                  <option key={admin.id} value={admin.id}>
                    {admin.username} ({admin.email})
                    {admin.is_super_admin && ' [超管]'}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                过期时间
              </label>
              <input
                type="datetime-local"
                value={formData.expires_at || ''}
                onChange={(e) => setFormData({ ...formData, expires_at: e.target.value || null })}
                className="w-full px-3 py-2 border rounded-lg"
              />
            </div>

            <div className="col-span-2">
              <label className="block text-sm font-medium text-gray-700 mb-2">
                权限设置
              </label>
              <div className="space-y-2">
                <label className="flex items-center gap-2">
                  <input
                    type="checkbox"
                    checked={formData.can_view_analytics}
                    onChange={(e) => setFormData({ ...formData, can_view_analytics: e.target.checked })}
                    className="rounded"
                  />
                  <span className="text-sm">查看统计数据</span>
                </label>
                <label className="flex items-center gap-2">
                  <input
                    type="checkbox"
                    checked={formData.can_create_links}
                    onChange={(e) => setFormData({ ...formData, can_create_links: e.target.checked })}
                    className="rounded"
                  />
                  <span className="text-sm">创建追踪链接</span>
                </label>
                <label className="flex items-center gap-2">
                  <input
                    type="checkbox"
                    checked={formData.can_manage_links}
                    onChange={(e) => setFormData({ ...formData, can_manage_links: e.target.checked })}
                    className="rounded"
                  />
                  <span className="text-sm">管理和删除链接</span>
                </label>
                <label className="flex items-center gap-2">
                  <input
                    type="checkbox"
                    checked={formData.can_export_data}
                    onChange={(e) => setFormData({ ...formData, can_export_data: e.target.checked })}
                    className="rounded"
                  />
                  <span className="text-sm">导出数据</span>
                </label>
              </div>
            </div>

            <div className="col-span-2">
              <label className="block text-sm font-medium text-gray-700 mb-1">
                备注
              </label>
              <textarea
                value={formData.notes}
                onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                className="w-full px-3 py-2 border rounded-lg"
                rows={2}
                placeholder="可选备注说明"
              />
            </div>
          </div>

          <div className="mt-4 flex gap-2">
            <button
              onClick={handleAdd}
              className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
            >
              添加
            </button>
            <button
              onClick={() => {
                setShowAddForm(false);
                resetForm();
              }}
              className="px-4 py-2 bg-gray-200 text-gray-700 rounded-lg hover:bg-gray-300"
            >
              取消
            </button>
          </div>
        </div>
      )}

      <div className="bg-white rounded-lg shadow-md overflow-hidden">
        <table className="w-full">
          <thead className="bg-gray-50 border-b">
            <tr>
              <th className="px-4 py-3 text-left text-sm font-semibold text-gray-900">店铺</th>
              <th className="px-4 py-3 text-left text-sm font-semibold text-gray-900">管理员</th>
              <th className="px-4 py-3 text-left text-sm font-semibold text-gray-900">权限</th>
              <th className="px-4 py-3 text-left text-sm font-semibold text-gray-900">过期时间</th>
              <th className="px-4 py-3 text-left text-sm font-semibold text-gray-900">授权人</th>
              <th className="px-4 py-3 text-right text-sm font-semibold text-gray-900">操作</th>
            </tr>
          </thead>
          <tbody className="divide-y">
            {permissions.map((permission) => {
              const isExpired = permission.expires_at && new Date(permission.expires_at) < new Date();
              const isEditing = editingId === permission.id;

              return (
                <tr key={permission.id} className={`hover:bg-gray-50 ${isExpired ? 'opacity-50' : ''}`}>
                  <td className="px-4 py-3">
                    <div className="font-medium text-gray-900">
                      {permission.domain?.display_name}
                    </div>
                    <div className="text-xs text-gray-500">
                      {permission.domain?.domain}
                    </div>
                  </td>
                  <td className="px-4 py-3">
                    <div className="font-medium text-gray-900">
                      {permission.admin?.username}
                    </div>
                    <div className="text-xs text-gray-500">
                      {permission.admin?.email}
                    </div>
                  </td>
                  <td className="px-4 py-3">
                    {isEditing ? (
                      <div className="space-y-1">
                        <label className="flex items-center gap-1 text-xs">
                          <input
                            type="checkbox"
                            checked={permission.can_view_analytics}
                            onChange={(e) => updatePermission(permission.id, 'can_view_analytics', e.target.checked)}
                            className="rounded"
                          />
                          查看
                        </label>
                        <label className="flex items-center gap-1 text-xs">
                          <input
                            type="checkbox"
                            checked={permission.can_create_links}
                            onChange={(e) => updatePermission(permission.id, 'can_create_links', e.target.checked)}
                            className="rounded"
                          />
                          创建
                        </label>
                        <label className="flex items-center gap-1 text-xs">
                          <input
                            type="checkbox"
                            checked={permission.can_manage_links}
                            onChange={(e) => updatePermission(permission.id, 'can_manage_links', e.target.checked)}
                            className="rounded"
                          />
                          管理
                        </label>
                        <label className="flex items-center gap-1 text-xs">
                          <input
                            type="checkbox"
                            checked={permission.can_export_data}
                            onChange={(e) => updatePermission(permission.id, 'can_export_data', e.target.checked)}
                            className="rounded"
                          />
                          导出
                        </label>
                      </div>
                    ) : (
                      <div className="flex flex-wrap gap-1">
                        {permission.can_view_analytics && (
                          <span className="px-2 py-0.5 bg-blue-100 text-blue-700 text-xs rounded">查看</span>
                        )}
                        {permission.can_create_links && (
                          <span className="px-2 py-0.5 bg-green-100 text-green-700 text-xs rounded">创建</span>
                        )}
                        {permission.can_manage_links && (
                          <span className="px-2 py-0.5 bg-orange-100 text-orange-700 text-xs rounded">管理</span>
                        )}
                        {permission.can_export_data && (
                          <span className="px-2 py-0.5 bg-purple-100 text-purple-700 text-xs rounded">导出</span>
                        )}
                      </div>
                    )}
                  </td>
                  <td className="px-4 py-3">
                    {isEditing ? (
                      <input
                        type="datetime-local"
                        value={permission.expires_at ? new Date(permission.expires_at).toISOString().slice(0, 16) : ''}
                        onChange={(e) => updatePermission(permission.id, 'expires_at', e.target.value || null)}
                        className="px-2 py-1 border rounded text-sm"
                      />
                    ) : (
                      <div className="text-sm">
                        {permission.expires_at ? (
                          <div className={isExpired ? 'text-red-600' : 'text-gray-600'}>
                            <div className="flex items-center gap-1">
                              <Calendar className="w-3 h-3" />
                              {new Date(permission.expires_at).toLocaleString('zh-CN')}
                            </div>
                            {isExpired && (
                              <div className="text-xs text-red-500">已过期</div>
                            )}
                          </div>
                        ) : (
                          <span className="text-gray-400">永久</span>
                        )}
                      </div>
                    )}
                  </td>
                  <td className="px-4 py-3 text-sm text-gray-600">
                    {permission.granted_by_admin?.username || '-'}
                  </td>
                  <td className="px-4 py-3 text-right">
                    {isEditing ? (
                      <div className="flex items-center justify-end gap-2">
                        <button
                          onClick={() => handleUpdate(permission.id)}
                          className="p-1 text-green-600 hover:bg-green-50 rounded"
                        >
                          <Save className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => {
                            setEditingId(null);
                            loadPermissions();
                          }}
                          className="p-1 text-gray-600 hover:bg-gray-50 rounded"
                        >
                          <X className="w-4 h-4" />
                        </button>
                      </div>
                    ) : (
                      <div className="flex items-center justify-end gap-2">
                        <button
                          onClick={() => setEditingId(permission.id)}
                          className="p-1 text-blue-600 hover:bg-blue-50 rounded"
                        >
                          <Edit2 className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => handleDelete(permission.id)}
                          className="p-1 text-red-600 hover:bg-red-50 rounded"
                        >
                          <X className="w-4 h-4" />
                        </button>
                      </div>
                    )}
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>

        {permissions.length === 0 && (
          <div className="p-8 text-center text-gray-500">
            暂无权限配置，请添加管理员权限
          </div>
        )}
      </div>

      <div className="mt-6 bg-blue-50 border border-blue-200 rounded-lg p-4">
        <div className="flex items-start gap-2">
          <AlertCircle className="w-5 h-5 text-blue-600 mt-0.5" />
          <div className="text-sm text-blue-800">
            <p className="font-medium mb-1">权限说明：</p>
            <ul className="list-disc list-inside space-y-1 text-xs">
              <li><strong>查看统计</strong>：可以查看链接访问统计数据</li>
              <li><strong>创建链接</strong>：可以创建新的追踪链接</li>
              <li><strong>管理链接</strong>：可以编辑和删除追踪链接</li>
              <li><strong>导出数据</strong>：可以导出统计数据为CSV/Excel</li>
              <li>超级管理员默认拥有所有权限，无需单独配置</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
}
