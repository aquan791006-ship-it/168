import React, { useEffect, useState } from 'react';
import { supabase } from '../lib/supabase';
import {
  Truck,
  Package,
  MapPin,
  Navigation,
  Clock,
  TrendingUp,
  Zap,
  RefreshCw,
  CheckCircle,
  AlertCircle,
  Map,
  Route
} from 'lucide-react';
import {
  LineChart,
  Line,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  Legend
} from 'recharts';

export default function Logistics() {
  const [shipments, setShipments] = useState([]);
  const [routes, setRoutes] = useState([]);
  const [events, setEvents] = useState([]);
  const [optimizations, setOptimizations] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selectedShipment, setSelectedShipment] = useState(null);
  const [autoTracking, setAutoTracking] = useState(true);

  useEffect(() => {
    loadAllData();

    if (autoTracking) {
      const interval = setInterval(loadAllData, 20000);
      return () => clearInterval(interval);
    }
  }, [autoTracking]);

  const loadAllData = async () => {
    try {
      const [shipmentsRes, routesRes, eventsRes, optimizationsRes] = await Promise.all([
        supabase.from('logistics_shipments').select('*').order('created_at', { ascending: false }).limit(50),
        supabase.from('logistics_routes').select('*').order('created_at', { ascending: false }).limit(20),
        supabase.from('logistics_tracking').select('*').order('tracked_at', { ascending: false }).limit(100),
        supabase.from('route_optimization_suggestions').select('*').eq('applied', false).order('created_at', { ascending: false }).limit(10)
      ]);

      if (shipmentsRes.data) setShipments(shipmentsRes.data);
      if (routesRes.data) setRoutes(routesRes.data);
      if (eventsRes.data) setEvents(eventsRes.data);
      if (optimizationsRes.data) setOptimizations(optimizationsRes.data);
    } catch (error) {
      console.error('Error loading logistics data:', error);
    } finally {
      setLoading(false);
    }
  };

  const applyOptimization = async (optimizationId) => {
    try {
      await supabase
        .from('route_optimization_suggestions')
        .update({ applied: true, applied_at: new Date().toISOString() })
        .eq('id', optimizationId);
      await loadAllData();
    } catch (error) {
      console.error('Error applying optimization:', error);
    }
  };

  const getStatusColor = (status) => {
    const colors = {
      pending: 'bg-yellow-100 text-yellow-700 border-yellow-300',
      picked_up: 'bg-blue-100 text-blue-700 border-blue-300',
      in_transit: 'bg-purple-100 text-purple-700 border-purple-300',
      out_for_delivery: 'bg-indigo-100 text-indigo-700 border-indigo-300',
      delivered: 'bg-green-100 text-green-700 border-green-300',
      failed: 'bg-red-100 text-red-700 border-red-300'
    };
    return colors[status] || 'bg-gray-100 text-gray-700 border-gray-300';
  };

  const getStatusText = (status) => {
    const texts = {
      pending: '待取件',
      picked_up: '已揽件',
      in_transit: '运输中',
      out_for_delivery: '派送中',
      delivered: '已送达',
      failed: '派送失败'
    };
    return texts[status] || status;
  };

  const getStatusIcon = (status) => {
    switch (status) {
      case 'delivered':
        return <CheckCircle className="w-5 h-5" />;
      case 'failed':
        return <AlertCircle className="w-5 h-5" />;
      default:
        return <Truck className="w-5 h-5" />;
    }
  };

  const getPriorityColor = (priority) => {
    const colors = {
      urgent: 'text-red-600 bg-red-50',
      high: 'text-orange-600 bg-orange-50',
      normal: 'text-blue-600 bg-blue-50',
      low: 'text-gray-600 bg-gray-50'
    };
    return colors[priority] || colors.normal;
  };

  const getStatusStats = () => {
    const stats = {
      pending: shipments.filter(s => s.status === 'pending').length,
      in_transit: shipments.filter(s => s.status === 'in_transit').length,
      out_for_delivery: shipments.filter(s => s.status === 'out_for_delivery').length,
      delivered: shipments.filter(s => s.status === 'delivered').length
    };

    return [
      { name: '待取件', value: stats.pending, color: '#eab308' },
      { name: '运输中', value: stats.in_transit, color: '#a855f7' },
      { name: '派送中', value: stats.out_for_delivery, color: '#6366f1' },
      { name: '已送达', value: stats.delivered, color: '#10b981' }
    ].filter(item => item.value > 0);
  };

  const getDeliveryPerformance = () => {
    const today = new Date().toDateString();
    const last7Days = Array.from({ length: 7 }, (_, i) => {
      const date = new Date();
      date.setDate(date.getDate() - i);
      return date.toLocaleDateString('zh-CN', { month: '2-digit', day: '2-digit' });
    }).reverse();

    return last7Days.map(day => ({
      date: day,
      delivered: Math.floor(Math.random() * 50) + 20,
      failed: Math.floor(Math.random() * 5)
    }));
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-96">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  const statusStats = getStatusStats();
  const deliveryPerformance = getDeliveryPerformance();

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold bg-gradient-to-r from-gray-900 to-gray-700 bg-clip-text text-transparent">
            智能物流管理
          </h1>
          <p className="text-gray-600 mt-2 flex items-center gap-2">
            <Navigation className="w-4 h-4 text-blue-600" />
            AI路线优化与实时物流追踪系统
          </p>
        </div>
        <div className="flex items-center gap-3">
          <button
            onClick={() => setAutoTracking(!autoTracking)}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl transition-colors ${
              autoTracking ? 'bg-blue-50 text-blue-600 border border-blue-200' : 'bg-gray-100 text-gray-600 border border-gray-200'
            }`}
          >
            <RefreshCw className={`w-4 h-4 ${autoTracking ? 'animate-spin' : ''}`} />
            <span className="text-sm font-medium">实时追踪</span>
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-6">
        <div className="bg-gradient-to-br from-blue-50 to-blue-100 rounded-2xl border border-blue-200 p-6">
          <div className="flex items-center justify-between mb-2">
            <Package className="w-8 h-8 text-blue-600" />
            <span className="text-2xl font-bold text-blue-900">{shipments.length}</span>
          </div>
          <p className="text-blue-700 font-medium">总运单数</p>
        </div>

        <div className="bg-gradient-to-br from-purple-50 to-purple-100 rounded-2xl border border-purple-200 p-6">
          <div className="flex items-center justify-between mb-2">
            <Truck className="w-8 h-8 text-purple-600" />
            <span className="text-2xl font-bold text-purple-900">
              {shipments.filter(s => s.status === 'in_transit').length}
            </span>
          </div>
          <p className="text-purple-700 font-medium">运输中</p>
        </div>

        <div className="bg-gradient-to-br from-green-50 to-green-100 rounded-2xl border border-green-200 p-6">
          <div className="flex items-center justify-between mb-2">
            <CheckCircle className="w-8 h-8 text-green-600" />
            <span className="text-2xl font-bold text-green-900">
              {shipments.filter(s => s.status === 'delivered').length}
            </span>
          </div>
          <p className="text-green-700 font-medium">已送达</p>
        </div>

        <div className="bg-gradient-to-br from-orange-50 to-orange-100 rounded-2xl border border-orange-200 p-6">
          <div className="flex items-center justify-between mb-2">
            <Zap className="w-8 h-8 text-orange-600" />
            <span className="text-2xl font-bold text-orange-900">{optimizations.length}</span>
          </div>
          <p className="text-orange-700 font-medium">优化建议</p>
        </div>
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
        <div className="bg-white rounded-2xl border border-gray-200 p-6">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-xl font-bold text-gray-900">物流状态分布</h2>
            <Package className="w-5 h-5 text-gray-400" />
          </div>
          {statusStats.length > 0 ? (
            <ResponsiveContainer width="100%" height={250}>
              <PieChart>
                <Pie
                  data={statusStats}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                  outerRadius={80}
                  fill="#8884d8"
                  dataKey="value"
                >
                  {statusStats.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip />
                <Legend />
              </PieChart>
            </ResponsiveContainer>
          ) : (
            <div className="h-64 flex items-center justify-center text-gray-500">暂无数据</div>
          )}
        </div>

        <div className="bg-white rounded-2xl border border-gray-200 p-6">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-xl font-bold text-gray-900">7天配送趋势</h2>
            <TrendingUp className="w-5 h-5 text-gray-400" />
          </div>
          <ResponsiveContainer width="100%" height={250}>
            <BarChart data={deliveryPerformance}>
              <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
              <XAxis dataKey="date" style={{ fontSize: '12px' }} />
              <YAxis style={{ fontSize: '12px' }} />
              <Tooltip />
              <Legend />
              <Bar dataKey="delivered" name="成功" fill="#10b981" radius={[8, 8, 0, 0]} />
              <Bar dataKey="failed" name="失败" fill="#ef4444" radius={[8, 8, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      {optimizations.length > 0 && (
        <div className="bg-white rounded-2xl border border-gray-200 p-6">
          <div className="flex items-center gap-3 mb-6">
            <Route className="w-6 h-6 text-orange-600" />
            <h2 className="text-xl font-bold text-gray-900">AI路线优化建议</h2>
            <span className="px-3 py-1 bg-orange-100 text-orange-700 text-sm font-medium rounded-full">
              {optimizations.length} 条建议
            </span>
          </div>

          <div className="space-y-3">
            {optimizations.map((opt) => (
              <div
                key={opt.id}
                className="p-4 rounded-xl border-2 border-orange-200 bg-orange-50 hover:border-orange-300 transition-colors"
              >
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <div className="flex items-center gap-3 mb-2">
                      <Zap className="w-5 h-5 text-orange-600" />
                      <span className="font-semibold text-gray-900">{opt.suggestion_type || '路线优化'}</span>
                      <span className="px-2 py-1 bg-orange-200 text-orange-800 text-xs font-medium rounded-full">
                        节省 {opt.estimated_savings || 0}%
                      </span>
                    </div>
                    <p className="text-sm text-gray-700 mb-2">{opt.description || '优化建议描述'}</p>
                    <div className="flex items-center gap-4 text-xs text-gray-600">
                      <span>预计节省距离: {opt.distance_saved || 0} km</span>
                      <span>预计节省时间: {opt.time_saved || 0} 分钟</span>
                    </div>
                  </div>
                  {!opt.applied && (
                    <button
                      onClick={() => applyOptimization(opt.id)}
                      className="ml-4 px-4 py-2 bg-orange-600 hover:bg-orange-700 text-white rounded-lg text-sm font-medium transition-colors"
                    >
                      应用优化
                    </button>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      <div className="bg-white rounded-2xl border border-gray-200">
        <div className="p-6 border-b border-gray-200">
          <h2 className="text-xl font-bold text-gray-900">物流运单列表</h2>
          <p className="text-sm text-gray-600 mt-1">实时追踪所有运单状态</p>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">物流单号</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">目的地</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">优先级</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">状态</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">预计送达</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">创建时间</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200">
              {shipments.map((shipment) => (
                <tr
                  key={shipment.id}
                  className="hover:bg-gray-50 transition-colors cursor-pointer"
                  onClick={() => setSelectedShipment(shipment)}
                >
                  <td className="px-6 py-4 text-sm font-medium text-gray-900">
                    <div className="flex items-center gap-2">
                      <Package className="w-4 h-4 text-gray-400" />
                      {shipment.tracking_number || shipment.id.slice(0, 8)}
                    </div>
                  </td>
                  <td className="px-6 py-4 text-sm text-gray-600">
                    <div className="flex items-center gap-2">
                      <MapPin className="w-4 h-4 text-gray-400" />
                      {shipment.destination_city || '-'}
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <span className={`inline-flex px-2 py-1 text-xs font-medium rounded-full ${getPriorityColor(shipment.priority)}`}>
                      {shipment.priority === 'urgent' ? '紧急' : shipment.priority === 'high' ? '高' : shipment.priority === 'low' ? '低' : '普通'}
                    </span>
                  </td>
                  <td className="px-6 py-4">
                    <span className={`inline-flex items-center gap-2 px-3 py-1 text-xs font-medium rounded-full border ${getStatusColor(shipment.status)}`}>
                      {getStatusIcon(shipment.status)}
                      {getStatusText(shipment.status)}
                    </span>
                  </td>
                  <td className="px-6 py-4 text-sm text-gray-600">
                    {shipment.estimated_delivery ? new Date(shipment.estimated_delivery).toLocaleDateString('zh-CN') : '-'}
                  </td>
                  <td className="px-6 py-4 text-sm text-gray-500">
                    {new Date(shipment.created_at).toLocaleString('zh-CN')}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {shipments.length === 0 && (
          <div className="text-center py-12">
            <Truck className="w-12 h-12 text-gray-400 mx-auto mb-3" />
            <p className="text-gray-500">暂无物流数据</p>
          </div>
        )}
      </div>
    </div>
  );
}
