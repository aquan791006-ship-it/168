import React, { useState, useEffect } from 'react';
import {
  Activity,
  AlertCircle,
  CheckCircle,
  TrendingUp,
  TrendingDown,
  Zap,
  Database,
  Server,
  RefreshCw,
  Settings,
  Shield,
  BarChart3,
  Clock
} from 'lucide-react';
import { supabase } from '../lib/supabase';

export default function SystemHealth() {
  const [loading, setLoading] = useState(false);
  const [healthOverview, setHealthOverview] = useState(null);
  const [moduleHealth, setModuleHealth] = useState([]);
  const [activeAlerts, setActiveAlerts] = useState([]);
  const [performanceSummary, setPerformanceSummary] = useState(null);
  const [autoRefresh, setAutoRefresh] = useState(false);

  useEffect(() => {
    loadSystemHealth();

    let interval;
    if (autoRefresh) {
      interval = setInterval(loadSystemHealth, 30000);
    }

    return () => {
      if (interval) clearInterval(interval);
    };
  }, [autoRefresh]);

  const loadSystemHealth = async () => {
    setLoading(true);
    try {
      const { data: domainData } = await supabase
        .from('sys_domains')
        .select('id')
        .limit(1)
        .maybeSingle();

      if (domainData) {
        await Promise.all([
          loadHealthOverview(domainData.id),
          loadModuleHealth(domainData.id),
          loadActiveAlerts(domainData.id),
          loadPerformanceSummary(domainData.id)
        ]);
      }
    } catch (error) {
      console.error('Error loading system health:', error);
    } finally {
      setLoading(false);
    }
  };

  const loadHealthOverview = async (domainId) => {
    const { data, error } = await supabase.rpc('get_system_health_overview', {
      p_domain_id: domainId
    });

    if (!error && data) {
      setHealthOverview(data);
    }
  };

  const loadModuleHealth = async (domainId) => {
    const { data, error } = await supabase
      .from('sys_module_health')
      .select('*')
      .eq('domain_id', domainId)
      .order('error_rate', { ascending: false });

    if (!error && data) {
      setModuleHealth(data);
    }
  };

  const loadActiveAlerts = async (domainId) => {
    const { data, error } = await supabase
      .from('sys_ai_alerts')
      .select('*')
      .eq('domain_id', domainId)
      .eq('status', 'active')
      .order('created_at', { ascending: false })
      .limit(10);

    if (!error && data) {
      setActiveAlerts(data);
    }
  };

  const loadPerformanceSummary = async (domainId) => {
    const { data, error } = await supabase.rpc('get_system_performance_summary', {
      p_domain_id: domainId
    });

    if (!error && data) {
      setPerformanceSummary(data);
    }
  };

  const runDiagnostics = async () => {
    setLoading(true);
    try {
      const { data: domainData } = await supabase
        .from('sys_domains')
        .select('id')
        .limit(1)
        .maybeSingle();

      if (domainData) {
        await supabase.rpc('detect_system_anomalies', {
          p_domain_id: domainData.id
        });

        await supabase.rpc('cleanup_expired_data');

        await loadSystemHealth();
      }
    } catch (error) {
      console.error('Error running diagnostics:', error);
    } finally {
      setLoading(false);
    }
  };

  const dismissAlert = async (alertId) => {
    const { error } = await supabase
      .from('sys_ai_alerts')
      .update({ status: 'dismissed' })
      .eq('id', alertId);

    if (!error) {
      setActiveAlerts(activeAlerts.filter(a => a.id !== alertId));
    }
  };

  const getStatusColor = (status) => {
    const colors = {
      healthy: 'text-green-600 bg-green-50',
      warning: 'text-yellow-600 bg-yellow-50',
      degraded: 'text-orange-600 bg-orange-50',
      critical: 'text-red-600 bg-red-50'
    };
    return colors[status] || colors.warning;
  };

  const getStatusIcon = (status) => {
    if (status === 'healthy') return CheckCircle;
    if (status === 'critical') return AlertCircle;
    return Activity;
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-start">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">系统健康监控</h1>
          <p className="text-gray-600 mt-1">实时监控系统状态和性能指标</p>
        </div>
        <div className="flex gap-3">
          <button
            onClick={() => setAutoRefresh(!autoRefresh)}
            className={`flex items-center gap-2 px-4 py-2 rounded-lg border transition-colors ${
              autoRefresh
                ? 'bg-blue-600 text-white border-blue-600'
                : 'bg-white text-gray-700 border-gray-300 hover:bg-gray-50'
            }`}
          >
            <RefreshCw className={`w-5 h-5 ${autoRefresh ? 'animate-spin' : ''}`} />
            {autoRefresh ? '自动刷新中' : '自动刷新'}
          </button>
          <button
            onClick={runDiagnostics}
            disabled={loading}
            className="flex items-center gap-2 bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 disabled:bg-gray-400 transition-colors"
          >
            <Zap className="w-5 h-5" />
            运行诊断
          </button>
        </div>
      </div>

      {healthOverview && (
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <div className={`rounded-lg p-6 border-2 ${getStatusColor(healthOverview.overall_status)}`}>
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium opacity-75">系统状态</p>
                <p className="text-2xl font-bold mt-1 capitalize">
                  {healthOverview.overall_status === 'healthy' ? '健康' :
                   healthOverview.overall_status === 'warning' ? '警告' :
                   healthOverview.overall_status === 'critical' ? '严重' : '降级'}
                </p>
              </div>
              <div className="p-3 bg-white rounded-lg">
                {React.createElement(getStatusIcon(healthOverview.overall_status), {
                  className: 'w-8 h-8'
                })}
              </div>
            </div>
          </div>

          <div className="bg-white rounded-lg border border-gray-200 p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">模块监控</p>
                <p className="text-2xl font-bold text-gray-900 mt-1">
                  {healthOverview.healthy_modules}/{healthOverview.total_modules}
                </p>
              </div>
              <div className="p-3 bg-blue-50 rounded-lg">
                <Server className="w-6 h-6 text-blue-600" />
              </div>
            </div>
            <p className="text-xs text-gray-500 mt-2">
              {healthOverview.critical_modules > 0 &&
                `${healthOverview.critical_modules} 个模块需要注意`}
            </p>
          </div>

          <div className="bg-white rounded-lg border border-gray-200 p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">活跃告警</p>
                <p className="text-2xl font-bold text-gray-900 mt-1">
                  {healthOverview.active_critical_alerts || 0}
                </p>
              </div>
              <div className="p-3 bg-red-50 rounded-lg">
                <AlertCircle className="w-6 h-6 text-red-600" />
              </div>
            </div>
          </div>

          <div className="bg-white rounded-lg border border-gray-200 p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">平均响应</p>
                <p className="text-2xl font-bold text-gray-900 mt-1">
                  {healthOverview.avg_response_time}ms
                </p>
              </div>
              <div className="p-3 bg-green-50 rounded-lg">
                <Clock className="w-6 h-6 text-green-600" />
              </div>
            </div>
          </div>
        </div>
      )}

      {activeAlerts.length > 0 && (
        <div className="bg-white rounded-lg border border-gray-200">
          <div className="p-6 border-b border-gray-200">
            <h2 className="text-lg font-semibold text-gray-900">活跃告警</h2>
          </div>
          <div className="p-6 space-y-3">
            {activeAlerts.map((alert) => (
              <div
                key={alert.id}
                className={`rounded-lg p-4 border ${
                  alert.severity === 'critical' ? 'border-red-200 bg-red-50' :
                  alert.severity === 'high' ? 'border-orange-200 bg-orange-50' :
                  'border-yellow-200 bg-yellow-50'
                }`}
              >
                <div className="flex items-start justify-between gap-4">
                  <div className="flex items-start gap-3 flex-1">
                    <AlertCircle className={`w-5 h-5 mt-0.5 ${
                      alert.severity === 'critical' ? 'text-red-600' :
                      alert.severity === 'high' ? 'text-orange-600' :
                      'text-yellow-600'
                    }`} />
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <h3 className="font-medium text-gray-900">{alert.title}</h3>
                        <span className={`px-2 py-0.5 text-xs rounded-full ${
                          alert.severity === 'critical' ? 'bg-red-100 text-red-700' :
                          alert.severity === 'high' ? 'bg-orange-100 text-orange-700' :
                          'bg-yellow-100 text-yellow-700'
                        }`}>
                          {alert.severity === 'critical' ? '严重' :
                           alert.severity === 'high' ? '高' : '中'}
                        </span>
                        {alert.ai_confidence_score && (
                          <span className="text-xs text-gray-500">
                            AI置信度: {alert.ai_confidence_score}%
                          </span>
                        )}
                      </div>
                      <p className="text-sm text-gray-700 mb-2">{alert.description}</p>
                      {alert.module_code && (
                        <p className="text-xs text-gray-600 mb-2">
                          模块: {alert.module_code}
                        </p>
                      )}
                      {alert.recommended_actions && alert.recommended_actions.length > 0 && (
                        <div className="mt-2 bg-white bg-opacity-50 rounded p-2">
                          <p className="text-xs font-medium text-gray-700 mb-1">建议操作:</p>
                          <ul className="text-xs text-gray-600 space-y-0.5">
                            {alert.recommended_actions.map((action, idx) => (
                              <li key={idx}>• {action}</li>
                            ))}
                          </ul>
                        </div>
                      )}
                    </div>
                  </div>
                  <button
                    onClick={() => dismissAlert(alert.id)}
                    className="text-gray-400 hover:text-gray-600"
                    title="忽略告警"
                  >
                    ×
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white rounded-lg border border-gray-200">
          <div className="p-6 border-b border-gray-200">
            <h2 className="text-lg font-semibold text-gray-900">模块健康状态</h2>
          </div>
          <div className="p-6">
            {moduleHealth.length === 0 ? (
              <p className="text-center text-gray-500 py-8">暂无监控数据</p>
            ) : (
              <div className="space-y-3">
                {moduleHealth.slice(0, 10).map((module) => (
                  <div key={module.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                    <div className="flex items-center gap-3">
                      <div className={`w-2 h-2 rounded-full ${
                        module.health_status === 'healthy' ? 'bg-green-500' :
                        module.health_status === 'warning' ? 'bg-yellow-500' :
                        module.health_status === 'degraded' ? 'bg-orange-500' :
                        'bg-red-500'
                      }`} />
                      <div>
                        <p className="font-medium text-gray-900">{module.module_code}</p>
                        <p className="text-xs text-gray-500">
                          运行时间: {module.uptime_percentage}%
                        </p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="text-sm font-medium text-gray-900">
                        {module.avg_response_time.toFixed(0)}ms
                      </p>
                      <p className="text-xs text-gray-500">
                        错误率: {module.error_rate.toFixed(1)}%
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

        {performanceSummary && (
          <div className="bg-white rounded-lg border border-gray-200">
            <div className="p-6 border-b border-gray-200">
              <h2 className="text-lg font-semibold text-gray-900">性能概览</h2>
            </div>
            <div className="p-6 space-y-4">
              <div className="flex items-center justify-between p-4 bg-blue-50 rounded-lg">
                <div className="flex items-center gap-3">
                  <Database className="w-5 h-5 text-blue-600" />
                  <div>
                    <p className="text-sm font-medium text-gray-900">缓存条目</p>
                    <p className="text-xs text-gray-600">查询缓存数量</p>
                  </div>
                </div>
                <p className="text-2xl font-bold text-blue-600">
                  {performanceSummary.cache_entries}
                </p>
              </div>

              <div className="flex items-center justify-between p-4 bg-green-50 rounded-lg">
                <div className="flex items-center gap-3">
                  <TrendingUp className="w-5 h-5 text-green-600" />
                  <div>
                    <p className="text-sm font-medium text-gray-900">缓存命中</p>
                    <p className="text-xs text-gray-600">总命中次数</p>
                  </div>
                </div>
                <p className="text-2xl font-bold text-green-600">
                  {performanceSummary.cache_hits}
                </p>
              </div>

              <div className="flex items-center justify-between p-4 bg-purple-50 rounded-lg">
                <div className="flex items-center gap-3">
                  <Server className="w-5 h-5 text-purple-600" />
                  <div>
                    <p className="text-sm font-medium text-gray-900">监控模块</p>
                    <p className="text-xs text-gray-600">活跃监控数</p>
                  </div>
                </div>
                <p className="text-2xl font-bold text-purple-600">
                  {performanceSummary.modules_monitored}
                </p>
              </div>
            </div>
          </div>
        )}
      </div>

      <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
        <div className="flex items-start gap-2">
          <Shield className="w-5 h-5 text-blue-600 mt-0.5" />
          <div className="text-sm text-blue-800">
            <p className="font-medium mb-1">AI智能监控说明：</p>
            <ul className="list-disc list-inside space-y-1 text-xs">
              <li>实时监控所有模块的运行状态和性能指标</li>
              <li>AI自动检测异常并生成预警</li>
              <li>智能缓存机制优化查询性能</li>
              <li>自动清理过期数据节省存储空间</li>
              <li>建议每30秒自动刷新以获取最新状态</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
}
