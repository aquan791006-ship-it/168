import React, { useState } from 'react';
import { Store, Package, ShoppingCart, Gift, Settings } from 'lucide-react';
import StoreDisplay from '../components/store/StoreDisplay';
import ProductsManager from '../components/store/ProductsManager';
import OrdersManager from '../components/store/OrdersManager';
import PromotionsManager from '../components/store/PromotionsManager';
import StoreSettings from '../components/store/StoreSettings';

export default function StoreManagement() {
  const [activeTab, setActiveTab] = useState('store');

  const tabs = [
    { id: 'store', name: '商城前台模块', icon: Store },
    { id: 'products', name: '商品管理模块', icon: Package },
    { id: 'orders', name: '订单管理模块', icon: ShoppingCart },
    { id: 'promotions', name: '促销活动模块', icon: Gift },
    { id: 'settings', name: '商城配置', icon: Settings }
  ];

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-gray-900">商城模块管理</h1>
        <p className="text-gray-500 mt-1">管理商城前台展示、商品、订单和促销活动</p>
      </div>

      <div className="border-b border-gray-200">
        <nav className="-mb-px flex gap-6">
          {tabs.map((tab) => {
            const Icon = tab.icon;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`flex items-center gap-2 py-3 px-1 border-b-2 font-medium text-sm transition-colors ${
                  activeTab === tab.id
                    ? 'border-blue-600 text-blue-600'
                    : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                }`}
              >
                <Icon className="w-5 h-5" />
                {tab.name}
              </button>
            );
          })}
        </nav>
      </div>

      <div>
        {activeTab === 'store' && <StoreDisplay />}
        {activeTab === 'products' && <ProductsManager />}
        {activeTab === 'orders' && <OrdersManager />}
        {activeTab === 'promotions' && <PromotionsManager />}
        {activeTab === 'settings' && <StoreSettings />}
      </div>
    </div>
  );
}
