import { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';
import { useToast } from '../contexts/ToastContext';
import {
  Activity,
  AlertTriangle,
  CheckCircle,
  XCircle,
  TrendingUp,
  Server,
  Database,
  Zap,
  Clock,
  RefreshCw,
  Download
} from 'lucide-react';
import { LineChart, Line, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';

export default function SystemMonitor() {
  const { user } = useAuth();
  const { showToast } = useToast();
  const [loading, setLoading] = useState(true);
  const [systemHealth, setSystemHealth] = useState(null);
  const [performanceData, setPerformanceData] = useState([]);
  const [errorData, setErrorData] = useState([]);
  const [resourceUsage, setResourceUsage] = useState([]);
  const [optimizationTasks, setOptimizationTasks] = useState([]);
  const [autoRefresh, setAutoRefresh] = useState(true);

  useEffect(() => {
    if (!user?.is_super_admin) {
      showToast('error', '仅超级管理员可访问');
      return;
    }

    loadSystemData();

    let interval;
    if (autoRefresh) {
      interval = setInterval(() => {
        loadSystemData();
      }, 30000);
    }

    return () => {
      if (interval) clearInterval(interval);
    };
  }, [user, autoRefresh]);

  const loadSystemData = async () => {
    try {
      await Promise.all([
        loadSystemHealth(),
        loadPerformanceMetrics(),
        loadErrors(),
        loadResourceUsage(),
        loadOptimizationTasks()
      ]);
    } catch (error) {
      console.error('Error loading system data:', error);
      showToast('error', '加载系统数据失败');
    } finally {
      setLoading(false);
    }
  };

  const loadSystemHealth = async () => {
    const { data, error } = await supabase.rpc('get_system_health_status');

    if (!error && data) {
      setSystemHealth(data);
    }
  };

  const loadPerformanceMetrics = async () => {
    const { data, error } = await supabase
      .from('v_daily_performance')
      .select('*')
      .order('day', { ascending: true })
      .limit(7);

    if (!error && data) {
      const formatted = data.map(item => ({
        date: new Date(item.day).toLocaleDateString('zh-CN'),
        avgValue: parseFloat(item.avg_value) || 0,
        maxValue: parseFloat(item.max_value) || 0,
        type: item.metric_type
      }));

      setPerformanceData(formatted);
    }
  };

  const loadErrors = async () => {
    const { data, error } = await supabase
      .from('v_daily_errors')
      .select('*')
      .order('day', { ascending: true })
      .limit(7);

    if (!error && data) {
      const formatted = data.map(item => ({
        date: new Date(item.day).toLocaleDateString('zh-CN'),
        count: item.error_count || 0,
        type: item.error_type,
        severity: item.severity
      }));

      setErrorData(formatted);
    }
  };

  const loadResourceUsage = async () => {
    const { data, error } = await supabase
      .from('sys_resource_usage')
      .select('*')
      .order('recorded_at', { ascending: false })
      .limit(10);

    if (!error && data) {
      setResourceUsage(data);
    }
  };

  const loadOptimizationTasks = async () => {
    const { data, error } = await supabase
      .from('sys_optimization_tasks')
      .select('*')
      .in('status', ['pending', 'approved'])
      .order('priority', { ascending: true })
      .limit(10);

    if (!error && data) {
      setOptimizationTasks(data);
    }
  };

  const handleCleanup = async () => {
    if (!confirm('确定要清理历史数据吗？')) return;

    try {
      const { data, error } = await supabase.rpc('cleanup_old_data');

      if (error) throw error;

      showToast('success', `清理完成: 已删除 ${data.deleted_metrics} 条性能数据和 ${data.deleted_errors} 条错误日志`);
      loadSystemData();
    } catch (error) {
      console.error('Cleanup error:', error);
      showToast('error', '清理失败');
    }
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'healthy':
        return 'text-green-600 bg-green-100';
      case 'warning':
        return 'text-yellow-600 bg-yellow-100';
      case 'critical':
        return 'text-red-600 bg-red-100';
      default:
        return 'text-gray-600 bg-gray-100';
    }
  };

  const getStatusIcon = (status) => {
    switch (status) {
      case 'healthy':
        return <CheckCircle className="w-5 h-5" />;
      case 'warning':
        return <AlertTriangle className="w-5 h-5" />;
      case 'critical':
        return <XCircle className="w-5 h-5" />;
      default:
        return <Activity className="w-5 h-5" />;
    }
  };

  if (!user?.is_super_admin) {
    return (
      <div className="p-6">
        <div className="bg-red-50 border border-red-200 rounded-lg p-4 text-red-800">
          仅超级管理员可访问此页面
        </div>
      </div>
    );
  }

  if (loading) {
    return <div className="p-6">加载中...</div>;
  }

  return (
    <div className="p-6">
      <div className="mb-6 flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900 flex items-center gap-2">
            <Activity className="w-6 h-6" />
            系统监控中心
          </h1>
          <p className="text-sm text-gray-600 mt-1">
            实时监控系统性能、资源使用和健康状态
          </p>
        </div>
        <div className="flex gap-3">
          <label className="flex items-center gap-2 px-4 py-2 bg-white border rounded-lg">
            <input
              type="checkbox"
              checked={autoRefresh}
              onChange={(e) => setAutoRefresh(e.target.checked)}
              className="rounded"
            />
            <span className="text-sm">自动刷新</span>
          </label>
          <button
            onClick={loadSystemData}
            className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 flex items-center gap-2"
          >
            <RefreshCw className="w-4 h-4" />
            刷新
          </button>
          <button
            onClick={handleCleanup}
            className="px-4 py-2 bg-gray-600 text-white rounded-lg hover:bg-gray-700 flex items-center gap-2"
          >
            <Database className="w-4 h-4" />
            清理数据
          </button>
        </div>
      </div>

      {systemHealth && (
        <div className="mb-6 bg-white rounded-lg shadow-md p-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-semibold">系统健康状态</h2>
            <div className={`flex items-center gap-2 px-3 py-1 rounded-full ${getStatusColor(systemHealth.status)}`}>
              {getStatusIcon(systemHealth.status)}
              <span className="font-semibold capitalize">{systemHealth.status}</span>
            </div>
          </div>

          <div className="grid grid-cols-3 gap-4 mb-4">
            <div className="p-4 bg-gray-50 rounded-lg">
              <div className="text-sm text-gray-600">最近1小时错误</div>
              <div className="text-2xl font-bold text-gray-900">{systemHealth.errors_last_hour}</div>
            </div>
            <div className="p-4 bg-gray-50 rounded-lg">
              <div className="text-sm text-gray-600">关键错误</div>
              <div className="text-2xl font-bold text-red-600">{systemHealth.critical_errors}</div>
            </div>
            <div className="p-4 bg-gray-50 rounded-lg">
              <div className="text-sm text-gray-600">检查时间</div>
              <div className="text-sm font-medium text-gray-900">
                {new Date(systemHealth.timestamp).toLocaleString('zh-CN')}
              </div>
            </div>
          </div>

          {systemHealth.recommendations && systemHealth.recommendations.length > 0 && (
            <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
              <div className="font-medium text-blue-900 mb-2">AI建议：</div>
              <ul className="list-disc list-inside text-sm text-blue-800 space-y-1">
                {systemHealth.recommendations.map((rec, idx) => (
                  <li key={idx}>{rec}</li>
                ))}
              </ul>
            </div>
          )}
        </div>
      )}

      <div className="grid grid-cols-2 gap-6 mb-6">
        <div className="bg-white rounded-lg shadow-md p-6">
          <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
            <TrendingUp className="w-5 h-5" />
            性能趋势
          </h3>
          <ResponsiveContainer width="100%" height={250}>
            <LineChart data={performanceData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="date" />
              <YAxis />
              <Tooltip />
              <Legend />
              <Line type="monotone" dataKey="avgValue" stroke="#3b82f6" name="平均值" />
              <Line type="monotone" dataKey="maxValue" stroke="#ef4444" name="最大值" />
            </LineChart>
          </ResponsiveContainer>
        </div>

        <div className="bg-white rounded-lg shadow-md p-6">
          <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
            <AlertTriangle className="w-5 h-5" />
            错误统计
          </h3>
          <ResponsiveContainer width="100%" height={250}>
            <BarChart data={errorData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="date" />
              <YAxis />
              <Tooltip />
              <Legend />
              <Bar dataKey="count" fill="#ef4444" name="错误数量" />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-6 mb-6">
        <div className="bg-white rounded-lg shadow-md p-6">
          <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
            <Server className="w-5 h-5" />
            资源使用情况
          </h3>
          <div className="space-y-3">
            {resourceUsage.slice(0, 5).map((resource) => (
              <div key={resource.id} className="border-b pb-3 last:border-b-0">
                <div className="flex items-center justify-between mb-1">
                  <span className="text-sm font-medium text-gray-700">
                    {resource.resource_type}
                  </span>
                  <span className="text-sm font-semibold text-gray-900">
                    {parseFloat(resource.usage_percent || 0).toFixed(1)}%
                  </span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <div
                    className={`h-2 rounded-full ${
                      resource.usage_percent > 80
                        ? 'bg-red-500'
                        : resource.usage_percent > 60
                        ? 'bg-yellow-500'
                        : 'bg-green-500'
                    }`}
                    style={{ width: `${resource.usage_percent}%` }}
                  />
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-white rounded-lg shadow-md p-6">
          <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
            <Zap className="w-5 h-5" />
            优化建议
          </h3>
          <div className="space-y-3">
            {optimizationTasks.length > 0 ? (
              optimizationTasks.map((task) => (
                <div key={task.id} className="p-3 bg-gray-50 rounded-lg">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="font-medium text-gray-900">{task.title}</div>
                      <div className="text-xs text-gray-500 mt-1">{task.description}</div>
                    </div>
                    <span className={`px-2 py-0.5 text-xs rounded-full ${
                      task.priority === 'urgent' ? 'bg-red-100 text-red-700' :
                      task.priority === 'high' ? 'bg-orange-100 text-orange-700' :
                      'bg-blue-100 text-blue-700'
                    }`}>
                      {task.priority}
                    </span>
                  </div>
                </div>
              ))
            ) : (
              <div className="text-center py-8 text-gray-500">
                <CheckCircle className="w-12 h-12 mx-auto mb-2 text-green-500" />
                <p>系统运行良好，暂无优化建议</p>
              </div>
            )}
          </div>
        </div>
      </div>

      <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
        <div className="flex items-start gap-2">
          <Activity className="w-5 h-5 text-blue-600 mt-0.5" />
          <div className="text-sm text-blue-800">
            <p className="font-medium mb-1">监控说明：</p>
            <ul className="list-disc list-inside space-y-1 text-xs">
              <li>系统每30秒自动刷新一次数据（可关闭自动刷新）</li>
              <li>性能指标和错误日志会自动清理90天前的数据</li>
              <li>AI会根据系统状态自动生成优化建议</li>
              <li>关键错误会立即触发告警</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
}
