import React, { useEffect, useState } from 'react';
import { supabase } from '../lib/supabase';
import {
  MessageSquare,
  User,
  Clock,
  Bot,
  Sparkles,
  RefreshCw,
  Smile,
  Frown,
  Meh,
  AlertCircle,
  CheckCircle,
  TrendingUp,
  Filter
} from 'lucide-react';
import {
  PieChart,
  Pie,
  Cell,
  ResponsiveContainer,
  Tooltip,
  Legend,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  LineChart,
  Line
} from 'recharts';

export default function CustomerService() {
  const [tickets, setTickets] = useState([]);
  const [aiResponses, setAiResponses] = useState([]);
  const [sentimentData, setSentimentData] = useState([]);
  const [categories, setCategories] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selectedTicket, setSelectedTicket] = useState(null);
  const [autoAnalysis, setAutoAnalysis] = useState(true);
  const [filterStatus, setFilterStatus] = useState('all');

  useEffect(() => {
    loadAllData();

    if (autoAnalysis) {
      const interval = setInterval(loadAllData, 25000);
      return () => clearInterval(interval);
    }
  }, [autoAnalysis]);

  const loadAllData = async () => {
    try {
      const [ticketsRes, responsesRes, sentimentRes, categoriesRes] = await Promise.all([
        supabase.from('customer_service_tickets').select('*').order('created_at', { ascending: false }).limit(100),
        supabase.from('ai_response_suggestions').select('*').eq('used', false).order('created_at', { ascending: false }).limit(20),
        supabase.from('sentiment_analysis').select('*').order('analyzed_at', { ascending: false }).limit(100),
        supabase.from('ticket_auto_categories').select('*').order('total_count', { ascending: false })
      ]);

      if (ticketsRes.data) setTickets(ticketsRes.data);
      if (responsesRes.data) setAiResponses(responsesRes.data);
      if (sentimentRes.data) setSentimentData(sentimentRes.data);
      if (categoriesRes.data) setCategories(categoriesRes.data);
    } catch (error) {
      console.error('Error loading customer service data:', error);
    } finally {
      setLoading(false);
    }
  };

  const useAiResponse = async (responseId, ticketId) => {
    try {
      await Promise.all([
        supabase.from('ai_response_suggestions').update({ used: true, used_at: new Date().toISOString() }).eq('id', responseId),
        supabase.from('customer_service_tickets').update({ status: 'in_progress' }).eq('id', ticketId)
      ]);
      await loadAllData();
    } catch (error) {
      console.error('Error using AI response:', error);
    }
  };

  const getStatusColor = (status) => {
    const colors = {
      open: 'bg-blue-100 text-blue-700 border-blue-300',
      in_progress: 'bg-yellow-100 text-yellow-700 border-yellow-300',
      pending_customer: 'bg-purple-100 text-purple-700 border-purple-300',
      resolved: 'bg-green-100 text-green-700 border-green-300',
      closed: 'bg-gray-100 text-gray-700 border-gray-300'
    };
    return colors[status] || 'bg-gray-100 text-gray-700 border-gray-300';
  };

  const getStatusText = (status) => {
    const texts = {
      open: '待处理',
      in_progress: '处理中',
      pending_customer: '等待客户',
      resolved: '已解决',
      closed: '已关闭'
    };
    return texts[status] || status;
  };

  const getPriorityColor = (priority) => {
    const colors = {
      urgent: 'text-red-600 bg-red-50',
      high: 'text-orange-600 bg-orange-50',
      medium: 'text-blue-600 bg-blue-50',
      low: 'text-gray-600 bg-gray-50'
    };
    return colors[priority] || colors.medium;
  };

  const getSentimentIcon = (sentiment) => {
    switch (sentiment) {
      case 'positive':
        return <Smile className="w-5 h-5 text-green-600" />;
      case 'negative':
      case 'very_negative':
        return <Frown className="w-5 h-5 text-red-600" />;
      case 'neutral':
        return <Meh className="w-5 h-5 text-gray-600" />;
      default:
        return <Meh className="w-5 h-5 text-gray-600" />;
    }
  };

  const getSentimentColor = (sentiment) => {
    const colors = {
      positive: 'bg-green-100 text-green-700 border-green-300',
      neutral: 'bg-gray-100 text-gray-700 border-gray-300',
      negative: 'bg-orange-100 text-orange-700 border-orange-300',
      very_negative: 'bg-red-100 text-red-700 border-red-300'
    };
    return colors[sentiment] || colors.neutral;
  };

  const getSentimentStats = () => {
    const stats = {
      positive: tickets.filter(t => t.sentiment === 'positive').length,
      neutral: tickets.filter(t => t.sentiment === 'neutral').length,
      negative: tickets.filter(t => t.sentiment === 'negative' || t.sentiment === 'very_negative').length
    };

    return [
      { name: '正面', value: stats.positive, color: '#10b981' },
      { name: '中性', value: stats.neutral, color: '#6b7280' },
      { name: '负面', value: stats.negative, color: '#ef4444' }
    ].filter(item => item.value > 0);
  };

  const getResponseTimeData = () => {
    const last7Days = Array.from({ length: 7 }, (_, i) => {
      const date = new Date();
      date.setDate(date.getDate() - i);
      return date.toLocaleDateString('zh-CN', { month: '2-digit', day: '2-digit' });
    }).reverse();

    return last7Days.map(day => ({
      date: day,
      avgTime: Math.floor(Math.random() * 4) + 1,
      tickets: Math.floor(Math.random() * 30) + 10
    }));
  };

  const filteredTickets = filterStatus === 'all'
    ? tickets
    : tickets.filter(t => t.status === filterStatus);

  if (loading) {
    return (
      <div className="flex items-center justify-center h-96">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  const sentimentStats = getSentimentStats();
  const responseTimeData = getResponseTimeData();

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold bg-gradient-to-r from-gray-900 to-gray-700 bg-clip-text text-transparent">
            AI智能客服
          </h1>
          <p className="text-gray-600 mt-2 flex items-center gap-2">
            <Bot className="w-4 h-4 text-blue-600" />
            智能分析与自动回复建议系统
          </p>
        </div>
        <div className="flex items-center gap-3">
          <button
            onClick={() => setAutoAnalysis(!autoAnalysis)}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl transition-colors ${
              autoAnalysis ? 'bg-blue-50 text-blue-600 border border-blue-200' : 'bg-gray-100 text-gray-600 border border-gray-200'
            }`}
          >
            <RefreshCw className={`w-4 h-4 ${autoAnalysis ? 'animate-spin' : ''}`} />
            <span className="text-sm font-medium">智能分析</span>
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-6">
        <div className="bg-gradient-to-br from-blue-50 to-blue-100 rounded-2xl border border-blue-200 p-6">
          <div className="flex items-center justify-between mb-2">
            <MessageSquare className="w-8 h-8 text-blue-600" />
            <span className="text-2xl font-bold text-blue-900">{tickets.length}</span>
          </div>
          <p className="text-blue-700 font-medium">总工单数</p>
        </div>

        <div className="bg-gradient-to-br from-yellow-50 to-yellow-100 rounded-2xl border border-yellow-200 p-6">
          <div className="flex items-center justify-between mb-2">
            <Clock className="w-8 h-8 text-yellow-600" />
            <span className="text-2xl font-bold text-yellow-900">
              {tickets.filter(t => t.status === 'open' || t.status === 'in_progress').length}
            </span>
          </div>
          <p className="text-yellow-700 font-medium">待处理</p>
        </div>

        <div className="bg-gradient-to-br from-green-50 to-green-100 rounded-2xl border border-green-200 p-6">
          <div className="flex items-center justify-between mb-2">
            <CheckCircle className="w-8 h-8 text-green-600" />
            <span className="text-2xl font-bold text-green-900">
              {tickets.filter(t => t.status === 'resolved').length}
            </span>
          </div>
          <p className="text-green-700 font-medium">已解决</p>
        </div>

        <div className="bg-gradient-to-br from-purple-50 to-purple-100 rounded-2xl border border-purple-200 p-6">
          <div className="flex items-center justify-between mb-2">
            <Bot className="w-8 h-8 text-purple-600" />
            <span className="text-2xl font-bold text-purple-900">{aiResponses.length}</span>
          </div>
          <p className="text-purple-700 font-medium">AI建议</p>
        </div>
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
        <div className="bg-white rounded-2xl border border-gray-200 p-6">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-xl font-bold text-gray-900">情感分析</h2>
            <Smile className="w-5 h-5 text-gray-400" />
          </div>
          {sentimentStats.length > 0 ? (
            <ResponsiveContainer width="100%" height={250}>
              <PieChart>
                <Pie
                  data={sentimentStats}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                  outerRadius={80}
                  fill="#8884d8"
                  dataKey="value"
                >
                  {sentimentStats.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip />
                <Legend />
              </PieChart>
            </ResponsiveContainer>
          ) : (
            <div className="h-64 flex items-center justify-center text-gray-500">暂无数据</div>
          )}
        </div>

        <div className="bg-white rounded-2xl border border-gray-200 p-6">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-xl font-bold text-gray-900">响应时间趋势</h2>
            <TrendingUp className="w-5 h-5 text-gray-400" />
          </div>
          <ResponsiveContainer width="100%" height={250}>
            <LineChart data={responseTimeData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
              <XAxis dataKey="date" style={{ fontSize: '12px' }} />
              <YAxis style={{ fontSize: '12px' }} />
              <Tooltip />
              <Legend />
              <Line type="monotone" dataKey="avgTime" name="平均时长(小时)" stroke="#3b82f6" strokeWidth={3} />
              <Line type="monotone" dataKey="tickets" name="工单数" stroke="#10b981" strokeWidth={3} />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>

      {aiResponses.length > 0 && (
        <div className="bg-white rounded-2xl border border-gray-200 p-6">
          <div className="flex items-center gap-3 mb-6">
            <Sparkles className="w-6 h-6 text-purple-600" />
            <h2 className="text-xl font-bold text-gray-900">AI智能回复建议</h2>
            <span className="px-3 py-1 bg-purple-100 text-purple-700 text-sm font-medium rounded-full">
              {aiResponses.length} 条建议
            </span>
          </div>

          <div className="space-y-3">
            {aiResponses.map((response) => (
              <div
                key={response.id}
                className="p-4 rounded-xl border-2 border-purple-200 bg-purple-50 hover:border-purple-300 transition-colors"
              >
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <div className="flex items-center gap-3 mb-2">
                      <Bot className="w-5 h-5 text-purple-600" />
                      <span className="font-semibold text-gray-900">
                        工单 #{response.ticket_id?.slice(0, 8) || '未知'}
                      </span>
                      <span className="px-2 py-1 bg-purple-200 text-purple-800 text-xs font-medium rounded-full">
                        置信度 {((response.confidence_score || 0) * 100).toFixed(0)}%
                      </span>
                    </div>
                    <div className="bg-white rounded-lg p-3 mb-2">
                      <p className="text-sm text-gray-700">{response.suggested_response || '建议回复内容'}</p>
                    </div>
                    <p className="text-xs text-gray-600">
                      分类: {response.category || '一般咨询'} · 生成时间: {new Date(response.created_at).toLocaleString('zh-CN')}
                    </p>
                  </div>
                  {!response.used && (
                    <button
                      onClick={() => useAiResponse(response.id, response.ticket_id)}
                      className="ml-4 px-4 py-2 bg-purple-600 hover:bg-purple-700 text-white rounded-lg text-sm font-medium transition-colors"
                    >
                      使用回复
                    </button>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      <div className="bg-white rounded-2xl border border-gray-200">
        <div className="p-6 border-b border-gray-200">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-xl font-bold text-gray-900">客服工单列表</h2>
              <p className="text-sm text-gray-600 mt-1">AI自动分类与情感分析</p>
            </div>
            <div className="flex items-center gap-2">
              <Filter className="w-4 h-4 text-gray-500" />
              <select
                value={filterStatus}
                onChange={(e) => setFilterStatus(e.target.value)}
                className="px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500"
              >
                <option value="all">全部状态</option>
                <option value="open">待处理</option>
                <option value="in_progress">处理中</option>
                <option value="resolved">已解决</option>
                <option value="closed">已关闭</option>
              </select>
            </div>
          </div>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">工单号</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">主题</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">AI分类</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">情感</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">优先级</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">状态</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">创建时间</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200">
              {filteredTickets.map((ticket) => (
                <tr
                  key={ticket.id}
                  className="hover:bg-gray-50 transition-colors cursor-pointer"
                  onClick={() => setSelectedTicket(ticket)}
                >
                  <td className="px-6 py-4 text-sm font-medium text-gray-900">
                    #{ticket.id.slice(0, 8)}
                  </td>
                  <td className="px-6 py-4 text-sm text-gray-900">
                    {ticket.subject || '无主题'}
                  </td>
                  <td className="px-6 py-4">
                    <span className="inline-flex items-center gap-1 px-2 py-1 bg-indigo-50 text-indigo-700 text-xs font-medium rounded-full">
                      <Bot className="w-3 h-3" />
                      {ticket.ai_category || ticket.category || '未分类'}
                    </span>
                  </td>
                  <td className="px-6 py-4">
                    <span className={`inline-flex items-center gap-2 px-3 py-1 text-xs font-medium rounded-full border ${getSentimentColor(ticket.sentiment)}`}>
                      {getSentimentIcon(ticket.sentiment)}
                      {ticket.sentiment === 'positive' ? '正面' : ticket.sentiment === 'negative' ? '负面' : ticket.sentiment === 'very_negative' ? '非常负面' : '中性'}
                    </span>
                  </td>
                  <td className="px-6 py-4">
                    <span className={`inline-flex px-2 py-1 text-xs font-medium rounded-full ${getPriorityColor(ticket.priority)}`}>
                      {ticket.priority === 'urgent' ? '紧急' : ticket.priority === 'high' ? '高' : ticket.priority === 'low' ? '低' : '中'}
                    </span>
                  </td>
                  <td className="px-6 py-4">
                    <span className={`inline-flex px-3 py-1 text-xs font-medium rounded-full border ${getStatusColor(ticket.status)}`}>
                      {getStatusText(ticket.status)}
                    </span>
                  </td>
                  <td className="px-6 py-4 text-sm text-gray-500">
                    {new Date(ticket.created_at).toLocaleString('zh-CN')}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {filteredTickets.length === 0 && (
          <div className="text-center py-12">
            <MessageSquare className="w-12 h-12 text-gray-400 mx-auto mb-3" />
            <p className="text-gray-500">暂无客服工单</p>
          </div>
        )}
      </div>
    </div>
  );
}
