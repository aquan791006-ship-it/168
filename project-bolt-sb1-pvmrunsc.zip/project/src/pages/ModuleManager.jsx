import { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import { useToast } from '../contexts/ToastContext';
import {
  Puzzle,
  Power,
  PowerOff,
  CheckCircle,
  XCircle,
  Clock,
  AlertTriangle,
  Settings,
  Info,
  GitBranch,
  TrendingUp
} from 'lucide-react';

export default function ModuleManager() {
  const [modules, setModules] = useState([]);
  const [stats, setStats] = useState({});
  const [loading, setLoading] = useState(true);
  const [processingModule, setProcessingModule] = useState(null);
  const [selectedCategory, setSelectedCategory] = useState('all');
  const { showToast } = useToast();

  useEffect(() => {
    loadModules();
    loadStats();
  }, []);

  const loadModules = async () => {
    try {
      setLoading(true);
      const { data, error } = await supabase
        .from('sys_modules')
        .select(`
          *,
          dependencies:sys_module_dependencies!module_id(
            depends_on_module:sys_modules!depends_on_module_id(
              module_key,
              module_name,
              status
            )
          )
        `)
        .order('category')
        .order('module_name');

      if (error) throw error;
      setModules(data || []);
    } catch (error) {
      showToast('加载模块失败: ' + error.message, 'error');
    } finally {
      setLoading(false);
    }
  };

  const loadStats = async () => {
    try {
      const { data, error } = await supabase.rpc('get_module_statistics');
      if (error) throw error;
      setStats(data || {});
    } catch (error) {
      console.error('Load stats error:', error);
    }
  };

  const handleToggleModule = async (module) => {
    if (module.is_core || module.is_system) {
      showToast('核心模块和系统模块无法禁用', 'warning');
      return;
    }

    setProcessingModule(module.id);
    try {
      const action = module.status === 'enabled' ? 'disable_module' : 'enable_module';
      const { data, error } = await supabase.rpc(action, {
        p_module_key: module.module_key
      });

      if (error) throw error;

      if (data && !data.success) {
        throw new Error(data.error || '操作失败');
      }

      showToast(
        module.status === 'enabled' ? '模块已禁用' : '模块已启用',
        'success'
      );

      await loadModules();
      await loadStats();
    } catch (error) {
      showToast('操作失败: ' + error.message, 'error');
    } finally {
      setProcessingModule(null);
    }
  };

  const getStatusBadge = (status, isCore, isSystem) => {
    if (isCore || isSystem) {
      return (
        <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
          <CheckCircle className="w-3 h-3" />
          {isCore ? '核心模块' : '系统模块'}
        </span>
      );
    }

    const badges = {
      enabled: { text: '已启用', className: 'bg-green-100 text-green-800', icon: CheckCircle },
      disabled: { text: '已禁用', className: 'bg-gray-100 text-gray-800', icon: PowerOff },
      installed: { text: '已安装', className: 'bg-blue-100 text-blue-800', icon: Clock },
      error: { text: '错误', className: 'bg-red-100 text-red-800', icon: XCircle }
    };

    const badge = badges[status] || badges.disabled;
    const Icon = badge.icon;

    return (
      <span className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-medium ${badge.className}`}>
        <Icon className="w-3 h-3" />
        {badge.text}
      </span>
    );
  };

  const getCategoryLabel = (category) => {
    const labels = {
      business: '业务管理',
      finance: '财务管理',
      supply_chain: '供应链',
      sales: '销售管理',
      hr: '人力资源',
      system: '系统功能',
      integration: '系统集成',
      analytics: '数据分析',
      other: '其他'
    };
    return labels[category] || category;
  };

  const filteredModules = selectedCategory === 'all'
    ? modules
    : modules.filter(m => m.category === selectedCategory);

  const categories = [...new Set(modules.map(m => m.category))];

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-gray-500">加载中...</div>
      </div>
    );
  }

  return (
    <div className="p-6">
      <div className="mb-6">
        <div className="flex items-center gap-2 mb-2">
          <Puzzle className="w-6 h-6 text-blue-600" />
          <h1 className="text-2xl font-bold text-gray-900">模块管理中心</h1>
        </div>
        <p className="text-gray-600">
          可组合式 ERP 架构 - 一键启用或禁用功能模块，支持热插拔，不影响系统运行
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
        <div className="bg-white rounded-lg shadow p-6">
          <div className="flex items-center justify-between">
            <div>
              <div className="text-gray-500 text-sm">总模块数</div>
              <div className="text-2xl font-bold text-gray-900 mt-1">
                {stats.total_modules || 0}
              </div>
            </div>
            <Puzzle className="w-10 h-10 text-blue-500 opacity-20" />
          </div>
        </div>
        <div className="bg-white rounded-lg shadow p-6">
          <div className="flex items-center justify-between">
            <div>
              <div className="text-gray-500 text-sm">已启用</div>
              <div className="text-2xl font-bold text-green-600 mt-1">
                {stats.enabled_modules || 0}
              </div>
            </div>
            <CheckCircle className="w-10 h-10 text-green-500 opacity-20" />
          </div>
        </div>
        <div className="bg-white rounded-lg shadow p-6">
          <div className="flex items-center justify-between">
            <div>
              <div className="text-gray-500 text-sm">已禁用</div>
              <div className="text-2xl font-bold text-gray-600 mt-1">
                {stats.disabled_modules || 0}
              </div>
            </div>
            <PowerOff className="w-10 h-10 text-gray-500 opacity-20" />
          </div>
        </div>
        <div className="bg-white rounded-lg shadow p-6">
          <div className="flex items-center justify-between">
            <div>
              <div className="text-gray-500 text-sm">核心模块</div>
              <div className="text-2xl font-bold text-blue-600 mt-1">
                {stats.core_modules || 0}
              </div>
            </div>
            <Settings className="w-10 h-10 text-blue-500 opacity-20" />
          </div>
        </div>
      </div>

      <div className="bg-white rounded-lg shadow mb-6 p-4">
        <div className="flex items-center gap-2 flex-wrap">
          <span className="text-sm font-medium text-gray-700">分类筛选:</span>
          <button
            onClick={() => setSelectedCategory('all')}
            className={`px-3 py-1 rounded-lg text-sm transition-colors ${
              selectedCategory === 'all'
                ? 'bg-blue-600 text-white'
                : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
            }`}
          >
            全部 ({modules.length})
          </button>
          {categories.map(cat => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-3 py-1 rounded-lg text-sm transition-colors ${
                selectedCategory === cat
                  ? 'bg-blue-600 text-white'
                  : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
              }`}
            >
              {getCategoryLabel(cat)} ({modules.filter(m => m.category === cat).length})
            </button>
          ))}
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredModules.map((module) => (
          <div
            key={module.id}
            className="bg-white rounded-lg shadow hover:shadow-lg transition-shadow border-l-4"
            style={{ borderLeftColor: module.color || '#3B82F6' }}
          >
            <div className="p-6">
              <div className="flex items-start justify-between mb-4">
                <div className="flex items-center gap-3">
                  <div
                    className="w-12 h-12 rounded-lg flex items-center justify-center text-white"
                    style={{ backgroundColor: module.color || '#3B82F6' }}
                  >
                    <Puzzle className="w-6 h-6" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-gray-900">
                      {module.module_name.zh}
                    </h3>
                    <p className="text-xs text-gray-500">{module.module_key}</p>
                  </div>
                </div>
                {getStatusBadge(module.status, module.is_core, module.is_system)}
              </div>

              <p className="text-sm text-gray-600 mb-4 line-clamp-2">
                {module.description.zh}
              </p>

              <div className="flex items-center justify-between text-xs text-gray-500 mb-4">
                <span className="flex items-center gap-1">
                  <Info className="w-3 h-3" />
                  {getCategoryLabel(module.category)}
                </span>
                <span>v{module.module_version}</span>
              </div>

              {module.dependencies && module.dependencies.length > 0 && (
                <div className="mb-4 pb-4 border-t pt-3">
                  <div className="flex items-center gap-1 text-xs text-gray-500 mb-2">
                    <GitBranch className="w-3 h-3" />
                    <span>依赖模块:</span>
                  </div>
                  <div className="flex flex-wrap gap-1">
                    {module.dependencies.map((dep, idx) => (
                      <span
                        key={idx}
                        className="px-2 py-0.5 bg-gray-100 text-gray-700 rounded text-xs"
                      >
                        {dep.depends_on_module.module_name.zh}
                      </span>
                    ))}
                  </div>
                </div>
              )}

              <div className="flex gap-2">
                {!module.is_core && !module.is_system && (
                  <button
                    onClick={() => handleToggleModule(module)}
                    disabled={processingModule === module.id}
                    className={`flex-1 flex items-center justify-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
                      module.status === 'enabled'
                        ? 'bg-red-50 text-red-700 hover:bg-red-100'
                        : 'bg-green-50 text-green-700 hover:bg-green-100'
                    } ${processingModule === module.id ? 'opacity-50 cursor-not-allowed' : ''}`}
                  >
                    {processingModule === module.id ? (
                      <>
                        <Clock className="w-4 h-4 animate-spin" />
                        处理中...
                      </>
                    ) : module.status === 'enabled' ? (
                      <>
                        <PowerOff className="w-4 h-4" />
                        禁用
                      </>
                    ) : (
                      <>
                        <Power className="w-4 h-4" />
                        启用
                      </>
                    )}
                  </button>
                )}
                {(module.is_core || module.is_system) && (
                  <div className="flex-1 text-center text-sm text-gray-500 py-2">
                    核心模块无法禁用
                  </div>
                )}
              </div>
            </div>
          </div>
        ))}
      </div>

      <div className="mt-6 bg-blue-50 border border-blue-200 rounded-lg p-4">
        <h3 className="text-sm font-medium text-blue-900 mb-2 flex items-center gap-2">
          <Info className="w-4 h-4" />
          可组合式 ERP 架构说明
        </h3>
        <ul className="text-sm text-blue-700 space-y-1">
          <li>• <strong>模块化设计</strong>: 每个功能独立为可插拔模块，互不干扰</li>
          <li>• <strong>热插拔</strong>: 运行时一键启用/禁用模块，无需重启系统</li>
          <li>• <strong>依赖管理</strong>: 自动检测模块依赖关系，防止误操作</li>
          <li>• <strong>数据隔离</strong>: 模块数据独立管理，新增模块不破坏现有结构</li>
          <li>• <strong>权限控制</strong>: 每个模块独立的权限配置</li>
          <li>• <strong>微前端架构</strong>: 前端组件动态加载，按需渲染</li>
          <li>• <strong>微服务后端</strong>: 每个模块可配置独立的 API 端点</li>
          <li>• <strong>事件总线</strong>: 模块间通过事件进行松耦合通信</li>
        </ul>
      </div>
    </div>
  );
}
