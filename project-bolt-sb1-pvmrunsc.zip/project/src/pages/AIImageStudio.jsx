import { useState, useEffect, useRef } from 'react';
import { supabase } from '../lib/supabase';
import { useToast } from '../contexts/ToastContext';
import {
  Image as ImageIcon,
  Send,
  Download,
  Settings,
  Sparkles,
  Wand2,
  Palette,
  Layout,
  Film,
  FileImage,
  Plus,
  Trash2,
  Heart,
  Copy,
  ExternalLink,
  RefreshCw,
  Loader,
  Check,
  X,
  MessageSquare,
  Grid3x3,
  List,
  Filter,
  Search,
  Upload,
  ZoomIn,
  Share2
} from 'lucide-react';
import Modal from '../components/Modal';

export default function AIImageStudio() {
  const [activeTab, setActiveTab] = useState('generate');
  const [mediaType, setMediaType] = useState('image');
  const [conversations, setConversations] = useState([]);
  const [activeConversation, setActiveConversation] = useState(null);
  const [messages, setMessages] = useState([]);
  const [inputMessage, setInputMessage] = useState('');
  const [generations, setGenerations] = useState([]);
  const [library, setLibrary] = useState([]);
  const [templates, setTemplates] = useState([]);
  const [styles, setStyles] = useState([]);
  const [selectedStyle, setSelectedStyle] = useState('realistic');
  const [selectedSize, setSelectedSize] = useState('1024x1024');
  const [selectedFormat, setSelectedFormat] = useState('png');
  const [selectedQuality, setSelectedQuality] = useState('standard');
  const [videoDuration, setVideoDuration] = useState(3);
  const [videoFPS, setVideoFPS] = useState(30);
  const [videoQuality, setVideoQuality] = useState('1080p');
  const [isGenerating, setIsGenerating] = useState(false);
  const [showSettings, setShowSettings] = useState(false);
  const [showTemplates, setShowTemplates] = useState(false);
  const [showImageModal, setShowImageModal] = useState(false);
  const [selectedImage, setSelectedImage] = useState(null);
  const [viewMode, setViewMode] = useState('grid');
  const [filterCategory, setFilterCategory] = useState('all');
  const [searchQuery, setSearchQuery] = useState('');
  const messagesEndRef = useRef(null);
  const { showToast } = useToast();

  useEffect(() => {
    loadData();
  }, []);

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  const loadData = async () => {
    try {
      await Promise.all([
        loadConversations(),
        loadGenerations(),
        loadLibrary(),
        loadTemplates(),
        loadStyles()
      ]);
    } catch (error) {
      console.error('Error loading data:', error);
      showToast('加载数据失败', 'error');
    }
  };

  const loadConversations = async () => {
    const { data: domainData } = await supabase
      .from('sys_domains')
      .select('id')
      .limit(1)
      .single();

    if (domainData) {
      const { data, error } = await supabase
        .from('ai_image_conversations')
        .select('*')
        .eq('domain_id', domainData.id)
        .eq('is_archived', false)
        .order('updated_at', { ascending: false });

      if (!error && data) {
        setConversations(data);
        if (data.length > 0 && !activeConversation) {
          setActiveConversation(data[0]);
          loadMessages(data[0].id);
        }
      }
    }
  };

  const loadMessages = async (conversationId) => {
    const { data, error } = await supabase
      .from('ai_image_messages')
      .select('*')
      .eq('conversation_id', conversationId)
      .order('created_at', { ascending: true });

    if (!error && data) {
      setMessages(data);
    }
  };

  const loadGenerations = async () => {
    const { data: domainData } = await supabase
      .from('sys_domains')
      .select('id')
      .limit(1)
      .single();

    if (domainData) {
      const { data, error } = await supabase
        .from('ai_image_generations')
        .select('*')
        .eq('domain_id', domainData.id)
        .order('created_at', { ascending: false })
        .limit(50);

      if (!error && data) {
        setGenerations(data);
      }
    }
  };

  const loadLibrary = async () => {
    const { data: domainData } = await supabase
      .from('sys_domains')
      .select('id')
      .limit(1)
      .single();

    if (domainData) {
      const { data, error } = await supabase
        .from('ai_image_library')
        .select('*')
        .eq('domain_id', domainData.id)
        .order('created_at', { ascending: false });

      if (!error && data) {
        setLibrary(data);
      }
    }
  };

  const loadTemplates = async () => {
    const { data, error } = await supabase
      .from('ai_image_templates')
      .select('*')
      .eq('is_active', true)
      .order('usage_count', { ascending: false });

    if (!error && data) {
      setTemplates(data);
    }
  };

  const loadStyles = async () => {
    const { data, error } = await supabase
      .from('ai_image_styles')
      .select('*')
      .eq('is_active', true)
      .order('usage_count', { ascending: false });

    if (!error && data) {
      setStyles(data);
    }
  };

  const handleCreateConversation = async () => {
    const { data: domainData } = await supabase
      .from('sys_domains')
      .select('id')
      .limit(1)
      .single();

    if (!domainData) return;

    const { data: userData } = await supabase.auth.getUser();
    if (!userData.user) return;

    const { data, error } = await supabase
      .from('ai_image_conversations')
      .insert({
        domain_id: domainData.id,
        title: '新对话 ' + new Date().toLocaleString('zh-CN'),
        created_by: userData.user.id
      })
      .select()
      .single();

    if (error) {
      showToast('创建对话失败', 'error');
      return;
    }

    setConversations([data, ...conversations]);
    setActiveConversation(data);
    setMessages([]);
  };

  const handleSendMessage = async () => {
    if (!inputMessage.trim() || !activeConversation || isGenerating) return;

    const userMessage = inputMessage.trim();
    setInputMessage('');
    setIsGenerating(true);

    try {
      const { data: userMsg, error: msgError } = await supabase
        .from('ai_image_messages')
        .insert({
          conversation_id: activeConversation.id,
          role: 'user',
          content: userMessage
        })
        .select()
        .single();

      if (msgError) throw msgError;

      setMessages([...messages, userMsg]);

      const { data: domainData } = await supabase
        .from('sys_domains')
        .select('id')
        .limit(1)
        .single();

      const { data: userData } = await supabase.auth.getUser();

      const selectedStyleData = styles.find(s => s.style_key === selectedStyle);
      const fullPrompt = userMessage + (selectedStyleData ? ', ' + selectedStyleData.prompt_suffix : '');

      const { data: generation, error: genError } = await supabase
        .from('ai_image_generations')
        .insert({
          domain_id: domainData.id,
          conversation_id: activeConversation.id,
          message_id: userMsg.id,
          prompt: fullPrompt,
          negative_prompt: selectedStyleData?.negative_prompt,
          style: selectedStyle,
          size: selectedSize,
          format: selectedFormat,
          quality: selectedQuality,
          status: 'generating',
          created_by: userData.user.id
        })
        .select()
        .single();

      if (genError) throw genError;

      setTimeout(async () => {
        const mockImageUrl = `https://via.placeholder.com/${selectedSize.replace('x', 'x')}/6366f1/ffffff?text=AI+Generated+Image`;

        const { error: updateError } = await supabase
          .from('ai_image_generations')
          .update({
            status: 'completed',
            image_url: mockImageUrl,
            thumbnail_url: mockImageUrl,
            width: parseInt(selectedSize.split('x')[0]),
            height: parseInt(selectedSize.split('x')[1]),
            generation_time_ms: 3000
          })
          .eq('id', generation.id);

        if (!updateError) {
          const { data: assistantMsg } = await supabase
            .from('ai_image_messages')
            .insert({
              conversation_id: activeConversation.id,
              role: 'assistant',
              content: '我已经根据您的描述生成了图片。您可以下载或进行格式转换。',
              image_ids: [generation.id]
            })
            .select()
            .single();

          if (assistantMsg) {
            setMessages(prev => [...prev, assistantMsg]);
          }

          await loadGenerations();
        }

        setIsGenerating(false);
      }, 3000);

    } catch (error) {
      console.error('Error sending message:', error);
      showToast('发送消息失败', 'error');
      setIsGenerating(false);
    }
  };

  const handleUseTemplate = (template) => {
    setInputMessage(template.prompt_template);
    setSelectedStyle(template.default_style);
    setSelectedSize(template.default_size);
    setSelectedFormat(template.default_format);
    setShowTemplates(false);
    showToast(`已应用模板: ${template.template_name.zh}`, 'success');
  };

  const handleDownloadImage = (image) => {
    const link = document.createElement('a');
    link.href = image.image_url;
    link.download = `ai-generated-${image.id}.${image.format}`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    showToast('开始下载图片', 'success');
  };

  const handleAddToLibrary = async (generation) => {
    const { data: domainData } = await supabase
      .from('sys_domains')
      .select('id')
      .limit(1)
      .single();

    const { data: userData } = await supabase.auth.getUser();

    const { error } = await supabase
      .from('ai_image_library')
      .insert({
        domain_id: domainData.id,
        generation_id: generation.id,
        title: generation.prompt.substring(0, 100),
        image_url: generation.image_url,
        thumbnail_url: generation.thumbnail_url,
        file_path: generation.file_path,
        file_size: generation.file_size,
        width: generation.width,
        height: generation.height,
        format: generation.format,
        category: 'ai_generated',
        created_by: userData.user.id
      });

    if (error) {
      showToast('添加到图片库失败', 'error');
    } else {
      showToast('已添加到图片库', 'success');
      await loadLibrary();
    }
  };

  const handleConvertFormat = async (image, targetFormat) => {
    const { data: domainData } = await supabase
      .from('sys_domains')
      .select('id')
      .limit(1)
      .single();

    const { data: userData } = await supabase.auth.getUser();

    const { error } = await supabase
      .from('ai_image_conversions')
      .insert({
        domain_id: domainData.id,
        source_image_id: image.id,
        source_format: image.format,
        target_format: targetFormat,
        source_url: image.image_url,
        status: 'processing',
        created_by: userData.user.id
      });

    if (error) {
      showToast('格式转换失败', 'error');
    } else {
      showToast(`开始转换为 ${targetFormat.toUpperCase()} 格式`, 'success');
    }
  };

  const filteredLibrary = library.filter(item => {
    const matchesCategory = filterCategory === 'all' || item.category === filterCategory;
    const matchesSearch = !searchQuery ||
      item.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.description?.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  const sizes = [
    { value: '512x512', label: '512×512' },
    { value: '768x768', label: '768×768' },
    { value: '1024x1024', label: '1024×1024' },
    { value: '1024x768', label: '1024×768' },
    { value: '768x1024', label: '768×1024' },
    { value: '1920x1080', label: '1920×1080' }
  ];

  const formats = [
    { value: 'png', label: 'PNG', icon: FileImage },
    { value: 'jpg', label: 'JPG', icon: FileImage },
    { value: 'webp', label: 'WebP', icon: FileImage },
    { value: 'gif', label: 'GIF', icon: Film },
    { value: 'svg', label: 'SVG', icon: Palette }
  ];

  const qualities = [
    { value: 'draft', label: '草图' },
    { value: 'standard', label: '标准' },
    { value: 'hd', label: '高清' },
    { value: 'ultra', label: '超清' }
  ];

  const tabs = [
    { id: 'generate', name: 'AI生成', icon: Sparkles },
    { id: 'library', name: '图片库', icon: Grid3x3 },
    { id: 'templates', name: '模板', icon: Layout }
  ];

  return (
    <div className="h-full flex flex-col">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 bg-gradient-to-br from-pink-500 to-purple-600 rounded-lg flex items-center justify-center">
            <ImageIcon className="w-7 h-7 text-white" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-gray-900">AI作图工作室</h1>
            <p className="text-gray-600 mt-1">智能对话式图片生成与编辑</p>
          </div>
        </div>
      </div>

      <div className="flex-1 flex gap-4 min-h-0">
        <div className="w-80 bg-white rounded-lg shadow-sm border border-gray-200 flex flex-col">
          <div className="p-4 border-b border-gray-200">
            <button
              onClick={handleCreateConversation}
              className="w-full flex items-center justify-center gap-2 px-4 py-2 bg-gradient-to-r from-pink-500 to-purple-600 text-white rounded-lg hover:from-pink-600 hover:to-purple-700 transition-all"
            >
              <Plus className="w-5 h-5" />
              新建对话
            </button>
          </div>

          <div className="flex-1 overflow-y-auto p-4 space-y-2">
            {conversations.map((conversation) => (
              <button
                key={conversation.id}
                onClick={() => {
                  setActiveConversation(conversation);
                  loadMessages(conversation.id);
                }}
                className={`w-full text-left p-3 rounded-lg transition-all ${
                  activeConversation?.id === conversation.id
                    ? 'bg-gradient-to-r from-pink-50 to-purple-50 border-2 border-purple-300'
                    : 'bg-gray-50 hover:bg-gray-100 border-2 border-transparent'
                }`}
              >
                <div className="flex items-start justify-between gap-2">
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-1">
                      <MessageSquare className="w-4 h-4 text-purple-600 flex-shrink-0" />
                      <h3 className="font-medium text-gray-900 text-sm truncate">
                        {conversation.title}
                      </h3>
                    </div>
                    <p className="text-xs text-gray-500">
                      {new Date(conversation.updated_at).toLocaleDateString('zh-CN')}
                    </p>
                  </div>
                </div>
              </button>
            ))}
          </div>
        </div>

        <div className="flex-1 bg-white rounded-lg shadow-sm border border-gray-200 flex flex-col min-w-0">
          <div className="border-b border-gray-200">
            <nav className="flex -mb-px">
              {tabs.map((tab) => {
                const Icon = tab.icon;
                return (
                  <button
                    key={tab.id}
                    onClick={() => setActiveTab(tab.id)}
                    className={`flex items-center gap-2 px-6 py-4 border-b-2 font-medium text-sm transition-colors ${
                      activeTab === tab.id
                        ? 'border-purple-500 text-purple-600'
                        : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                    }`}
                  >
                    <Icon className="w-5 h-5" />
                    {tab.name}
                  </button>
                );
              })}
            </nav>
          </div>

          {activeTab === 'generate' && (
            <div className="flex-1 flex flex-col min-h-0">
              <div className="flex-1 overflow-y-auto p-6 space-y-4">
                {messages.length === 0 ? (
                  <div className="h-full flex items-center justify-center">
                    <div className="text-center">
                      <div className="w-20 h-20 bg-gradient-to-br from-pink-100 to-purple-100 rounded-full flex items-center justify-center mx-auto mb-4">
                        <Sparkles className="w-10 h-10 text-purple-600" />
                      </div>
                      <h3 className="text-lg font-semibold text-gray-900 mb-2">
                        开始创作
                      </h3>
                      <p className="text-gray-600 mb-4">
                        描述您想要生成的图片，AI将为您创作
                      </p>
                      <button
                        onClick={() => setShowTemplates(true)}
                        className="inline-flex items-center gap-2 px-4 py-2 bg-purple-100 text-purple-700 rounded-lg hover:bg-purple-200 transition-colors"
                      >
                        <Layout className="w-4 h-4" />
                        选择模板开始
                      </button>
                    </div>
                  </div>
                ) : (
                  <>
                    {messages.map((message) => (
                      <div
                        key={message.id}
                        className={`flex gap-3 ${
                          message.role === 'user' ? 'justify-end' : 'justify-start'
                        }`}
                      >
                        {message.role === 'assistant' && (
                          <div className="w-8 h-8 bg-gradient-to-br from-pink-500 to-purple-600 rounded-full flex items-center justify-center flex-shrink-0">
                            <Sparkles className="w-4 h-4 text-white" />
                          </div>
                        )}
                        <div
                          className={`max-w-2xl ${
                            message.role === 'user'
                              ? 'bg-gradient-to-r from-pink-500 to-purple-600 text-white'
                              : 'bg-gray-100 text-gray-900'
                          } rounded-lg p-4`}
                        >
                          <p className="text-sm whitespace-pre-wrap">{message.content}</p>
                          {message.image_ids && message.image_ids.length > 0 && (
                            <div className="mt-3 space-y-2">
                              {generations
                                .filter(gen => message.image_ids.includes(gen.id))
                                .map((gen) => (
                                  <div
                                    key={gen.id}
                                    className="bg-white rounded-lg p-2 border border-gray-200"
                                  >
                                    {gen.status === 'generating' ? (
                                      <div className="flex items-center justify-center py-12">
                                        <div className="text-center">
                                          <Loader className="w-8 h-8 text-purple-600 animate-spin mx-auto mb-2" />
                                          <p className="text-sm text-gray-600">正在生成图片...</p>
                                        </div>
                                      </div>
                                    ) : gen.status === 'completed' ? (
                                      <>
                                        <img
                                          src={gen.image_url}
                                          alt={gen.prompt}
                                          className="w-full rounded-lg cursor-pointer hover:opacity-90 transition-opacity"
                                          onClick={() => {
                                            setSelectedImage(gen);
                                            setShowImageModal(true);
                                          }}
                                        />
                                        <div className="flex items-center gap-2 mt-2">
                                          <button
                                            onClick={() => handleDownloadImage(gen)}
                                            className="flex-1 flex items-center justify-center gap-1 px-3 py-1.5 bg-purple-600 text-white text-sm rounded hover:bg-purple-700 transition-colors"
                                          >
                                            <Download className="w-4 h-4" />
                                            下载
                                          </button>
                                          <button
                                            onClick={() => handleAddToLibrary(gen)}
                                            className="flex-1 flex items-center justify-center gap-1 px-3 py-1.5 bg-blue-600 text-white text-sm rounded hover:bg-blue-700 transition-colors"
                                          >
                                            <Plus className="w-4 h-4" />
                                            图片库
                                          </button>
                                        </div>
                                      </>
                                    ) : (
                                      <div className="text-center py-8 text-red-600">
                                        <X className="w-8 h-8 mx-auto mb-2" />
                                        <p className="text-sm">生成失败</p>
                                      </div>
                                    )}
                                  </div>
                                ))}
                            </div>
                          )}
                        </div>
                        {message.role === 'user' && (
                          <div className="w-8 h-8 bg-blue-500 rounded-full flex items-center justify-center flex-shrink-0">
                            <span className="text-white text-sm font-medium">我</span>
                          </div>
                        )}
                      </div>
                    ))}
                    {isGenerating && (
                      <div className="flex gap-3 justify-start">
                        <div className="w-8 h-8 bg-gradient-to-br from-pink-500 to-purple-600 rounded-full flex items-center justify-center flex-shrink-0">
                          <Sparkles className="w-4 h-4 text-white" />
                        </div>
                        <div className="bg-gray-100 rounded-lg p-4">
                          <Loader className="w-5 h-5 text-purple-600 animate-spin" />
                        </div>
                      </div>
                    )}
                    <div ref={messagesEndRef} />
                  </>
                )}
              </div>

              <div className="border-t border-gray-200 p-4">
                <div className="flex items-center gap-2 mb-3">
                  <button
                    onClick={() => setShowTemplates(true)}
                    className="flex items-center gap-1 px-3 py-1.5 bg-purple-100 text-purple-700 text-sm rounded-lg hover:bg-purple-200 transition-colors"
                  >
                    <Layout className="w-4 h-4" />
                    模板
                  </button>
                  <button
                    onClick={() => setShowSettings(!showSettings)}
                    className="flex items-center gap-1 px-3 py-1.5 bg-gray-100 text-gray-700 text-sm rounded-lg hover:bg-gray-200 transition-colors"
                  >
                    <Settings className="w-4 h-4" />
                    设置
                  </button>
                  <div className="flex-1 flex items-center gap-2 text-xs text-gray-600">
                    <span className="px-2 py-1 bg-blue-100 text-blue-700 rounded">
                      {selectedSize}
                    </span>
                    <span className="px-2 py-1 bg-green-100 text-green-700 rounded">
                      {selectedFormat.toUpperCase()}
                    </span>
                    <span className="px-2 py-1 bg-purple-100 text-purple-700 rounded">
                      {styles.find(s => s.style_key === selectedStyle)?.style_name.zh}
                    </span>
                  </div>
                </div>

                {showSettings && (
                  <div className="grid grid-cols-4 gap-3 mb-3 p-4 bg-gray-50 rounded-lg">
                    <div>
                      <label className="block text-xs font-medium text-gray-700 mb-2">
                        尺寸
                      </label>
                      <select
                        value={selectedSize}
                        onChange={(e) => setSelectedSize(e.target.value)}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-purple-500"
                      >
                        {sizes.map((size) => (
                          <option key={size.value} value={size.value}>
                            {size.label}
                          </option>
                        ))}
                      </select>
                    </div>

                    <div>
                      <label className="block text-xs font-medium text-gray-700 mb-2">
                        格式
                      </label>
                      <select
                        value={selectedFormat}
                        onChange={(e) => setSelectedFormat(e.target.value)}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-purple-500"
                      >
                        {formats.map((format) => (
                          <option key={format.value} value={format.value}>
                            {format.label}
                          </option>
                        ))}
                      </select>
                    </div>

                    <div>
                      <label className="block text-xs font-medium text-gray-700 mb-2">
                        质量
                      </label>
                      <select
                        value={selectedQuality}
                        onChange={(e) => setSelectedQuality(e.target.value)}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-purple-500"
                      >
                        {qualities.map((quality) => (
                          <option key={quality.value} value={quality.value}>
                            {quality.label}
                          </option>
                        ))}
                      </select>
                    </div>

                    <div>
                      <label className="block text-xs font-medium text-gray-700 mb-2">
                        风格
                      </label>
                      <select
                        value={selectedStyle}
                        onChange={(e) => setSelectedStyle(e.target.value)}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-purple-500"
                      >
                        {styles.map((style) => (
                          <option key={style.style_key} value={style.style_key}>
                            {style.style_name.zh}
                          </option>
                        ))}
                      </select>
                    </div>
                  </div>
                )}

                <div className="flex gap-2">
                  <input
                    type="text"
                    value={inputMessage}
                    onChange={(e) => setInputMessage(e.target.value)}
                    onKeyPress={(e) => e.key === 'Enter' && !e.shiftKey && handleSendMessage()}
                    placeholder="描述您想要生成的图片..."
                    disabled={isGenerating || !activeConversation}
                    className="flex-1 px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent disabled:bg-gray-100 disabled:cursor-not-allowed"
                  />
                  <button
                    onClick={handleSendMessage}
                    disabled={isGenerating || !inputMessage.trim() || !activeConversation}
                    className="px-6 py-3 bg-gradient-to-r from-pink-500 to-purple-600 text-white rounded-lg hover:from-pink-600 hover:to-purple-700 disabled:opacity-50 disabled:cursor-not-allowed transition-all flex items-center gap-2"
                  >
                    {isGenerating ? (
                      <Loader className="w-5 h-5 animate-spin" />
                    ) : (
                      <Send className="w-5 h-5" />
                    )}
                  </button>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'library' && (
            <div className="flex-1 flex flex-col min-h-0">
              <div className="p-4 border-b border-gray-200">
                <div className="flex items-center gap-3">
                  <div className="flex-1 relative">
                    <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                    <input
                      type="text"
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      placeholder="搜索图片..."
                      className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500"
                    />
                  </div>
                  <select
                    value={filterCategory}
                    onChange={(e) => setFilterCategory(e.target.value)}
                    className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500"
                  >
                    <option value="all">全部分类</option>
                    <option value="ai_generated">AI生成</option>
                    <option value="uploaded">上传</option>
                    <option value="converted">格式转换</option>
                  </select>
                  <button
                    onClick={() => setViewMode(viewMode === 'grid' ? 'list' : 'grid')}
                    className="p-2 border border-gray-300 rounded-lg hover:bg-gray-50"
                  >
                    {viewMode === 'grid' ? (
                      <List className="w-5 h-5" />
                    ) : (
                      <Grid3x3 className="w-5 h-5" />
                    )}
                  </button>
                </div>
              </div>

              <div className="flex-1 overflow-y-auto p-6">
                {filteredLibrary.length === 0 ? (
                  <div className="h-full flex items-center justify-center">
                    <div className="text-center">
                      <Grid3x3 className="w-12 h-12 text-gray-400 mx-auto mb-3" />
                      <p className="text-gray-600">图片库为空</p>
                    </div>
                  </div>
                ) : viewMode === 'grid' ? (
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
                    {filteredLibrary.map((item) => (
                      <div
                        key={item.id}
                        className="group bg-white rounded-lg border-2 border-gray-200 overflow-hidden hover:border-purple-300 hover:shadow-lg transition-all cursor-pointer"
                        onClick={() => {
                          setSelectedImage(item);
                          setShowImageModal(true);
                        }}
                      >
                        <div className="aspect-square bg-gray-100 relative overflow-hidden">
                          <img
                            src={item.thumbnail_url || item.image_url}
                            alt={item.title}
                            className="w-full h-full object-cover group-hover:scale-110 transition-transform"
                          />
                          <div className="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-30 transition-all flex items-center justify-center">
                            <ZoomIn className="w-8 h-8 text-white opacity-0 group-hover:opacity-100 transition-opacity" />
                          </div>
                        </div>
                        <div className="p-3">
                          <h3 className="font-medium text-gray-900 text-sm truncate mb-1">
                            {item.title}
                          </h3>
                          <div className="flex items-center justify-between text-xs text-gray-500">
                            <span>{item.format.toUpperCase()}</span>
                            <span>{item.width}×{item.height}</span>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="space-y-2">
                    {filteredLibrary.map((item) => (
                      <div
                        key={item.id}
                        className="flex items-center gap-4 p-4 bg-white rounded-lg border border-gray-200 hover:border-purple-300 hover:shadow-md transition-all cursor-pointer"
                        onClick={() => {
                          setSelectedImage(item);
                          setShowImageModal(true);
                        }}
                      >
                        <img
                          src={item.thumbnail_url || item.image_url}
                          alt={item.title}
                          className="w-20 h-20 object-cover rounded-lg"
                        />
                        <div className="flex-1 min-w-0">
                          <h3 className="font-medium text-gray-900 mb-1">{item.title}</h3>
                          <div className="flex items-center gap-3 text-xs text-gray-500">
                            <span>{item.format.toUpperCase()}</span>
                            <span>{item.width}×{item.height}</span>
                            <span>{new Date(item.created_at).toLocaleDateString('zh-CN')}</span>
                          </div>
                        </div>
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            handleDownloadImage(item);
                          }}
                          className="p-2 text-purple-600 hover:bg-purple-50 rounded-lg transition-colors"
                        >
                          <Download className="w-5 h-5" />
                        </button>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          )}

          {activeTab === 'templates' && (
            <div className="flex-1 overflow-y-auto p-6">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {templates.map((template) => (
                  <div
                    key={template.id}
                    className="bg-gradient-to-br from-purple-50 to-pink-50 rounded-lg border-2 border-purple-200 p-6 hover:border-purple-400 hover:shadow-lg transition-all"
                  >
                    <div className="flex items-start justify-between mb-4">
                      <div className="w-12 h-12 bg-gradient-to-br from-pink-500 to-purple-600 rounded-lg flex items-center justify-center">
                        <Layout className="w-6 h-6 text-white" />
                      </div>
                      <span className="px-2 py-1 bg-purple-100 text-purple-700 text-xs rounded-full">
                        {template.category}
                      </span>
                    </div>
                    <h3 className="font-semibold text-gray-900 mb-2">
                      {template.template_name.zh}
                    </h3>
                    <p className="text-sm text-gray-600 mb-4">
                      {template.description?.zh}
                    </p>
                    <button
                      onClick={() => handleUseTemplate(template)}
                      className="w-full flex items-center justify-center gap-2 px-4 py-2 bg-gradient-to-r from-pink-500 to-purple-600 text-white rounded-lg hover:from-pink-600 hover:to-purple-700 transition-all"
                    >
                      <Wand2 className="w-4 h-4" />
                      使用模板
                    </button>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>

      {showImageModal && selectedImage && (
        <Modal
          isOpen={showImageModal}
          onClose={() => {
            setShowImageModal(false);
            setSelectedImage(null);
          }}
          title="图片详情"
          size="large"
        >
          <div className="space-y-4">
            <img
              src={selectedImage.image_url}
              alt={selectedImage.title || selectedImage.prompt}
              className="w-full rounded-lg"
            />
            <div className="grid grid-cols-2 gap-4 text-sm">
              <div>
                <span className="text-gray-600">尺寸:</span>
                <span className="ml-2 font-medium">{selectedImage.width}×{selectedImage.height}</span>
              </div>
              <div>
                <span className="text-gray-600">格式:</span>
                <span className="ml-2 font-medium">{selectedImage.format.toUpperCase()}</span>
              </div>
              {selectedImage.prompt && (
                <div className="col-span-2">
                  <span className="text-gray-600">提示词:</span>
                  <p className="mt-1 text-gray-900">{selectedImage.prompt}</p>
                </div>
              )}
            </div>
            <div className="flex gap-2">
              <button
                onClick={() => handleDownloadImage(selectedImage)}
                className="flex-1 flex items-center justify-center gap-2 px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors"
              >
                <Download className="w-4 h-4" />
                下载原图
              </button>
              <button
                onClick={() => handleConvertFormat(selectedImage, 'webp')}
                className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
              >
                <RefreshCw className="w-4 h-4" />
                转WebP
              </button>
              <button
                onClick={() => handleConvertFormat(selectedImage, 'gif')}
                className="flex items-center gap-2 px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors"
              >
                <Film className="w-4 h-4" />
                转GIF
              </button>
            </div>
          </div>
        </Modal>
      )}
    </div>
  );
}
