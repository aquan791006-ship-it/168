import React, { useEffect, useState } from 'react';
import {
  TrendingUp,
  TrendingDown,
  Users,
  Eye,
  Activity,
  ArrowUp,
  ArrowDown,
  RefreshCw,
  Download,
  Calendar,
  TrendingUp as TrendUp
} from 'lucide-react';
import {
  LineChart,
  Line,
  BarChart,
  Bar,
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer
} from 'recharts';
import { supabase } from '../lib/supabase';
import CandlestickChart from '../components/CandlestickChart';

export default function Analytics() {
  const [onlineUsers, setOnlineUsers] = useState(0);
  const [realtimeData, setRealtimeData] = useState({
    totalVisitors: 0,
    activeNow: 0,
    bounceRate: 0,
    avgSessionTime: '0:00'
  });
  const [salesData, setSalesData] = useState([]);
  const [revenueData, setRevenueData] = useState([]);
  const [hourlyData, setHourlyData] = useState([]);
  const [timeRange, setTimeRange] = useState('7d');
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  const fetchAnalyticsData = async () => {
    try {
      const [salesRes, revenueRes, hourlyRes, realtimeRes] = await Promise.all([
        supabase.from('daily_sales').select('*').order('date', { ascending: true }).limit(30),
        supabase.from('monthly_revenue').select('*').order('month', { ascending: true }).limit(12),
        supabase.from('hourly_activity').select('*').eq('date', new Date().toISOString().split('T')[0]).order('hour'),
        supabase.from('realtime_stats').select('*').order('timestamp', { ascending: false }).limit(1)
      ]);

      if (salesRes.data) {
        const formattedSales = salesRes.data.map(item => ({
          date: new Date(item.date).toLocaleDateString('zh-CN', { month: '2-digit', day: '2-digit' }),
          open: parseFloat(item.open),
          high: parseFloat(item.high),
          low: parseFloat(item.low),
          close: parseFloat(item.close),
          volume: item.volume
        }));
        setSalesData(formattedSales);
      }

      if (revenueRes.data) {
        const formattedRevenue = revenueRes.data.map(item => ({
          month: new Date(item.month).toLocaleDateString('zh-CN', { month: 'long' }),
          revenue: parseFloat(item.revenue),
          orders: item.orders,
          visitors: item.visitors
        }));
        setRevenueData(formattedRevenue);
      }

      if (hourlyRes.data) {
        const formattedHourly = hourlyRes.data.map(item => ({
          hour: `${item.hour.toString().padStart(2, '0')}:00`,
          users: item.users
        }));
        setHourlyData(formattedHourly);
      }

      if (realtimeRes.data && realtimeRes.data.length > 0) {
        const stats = realtimeRes.data[0];
        setRealtimeData({
          totalVisitors: stats.total_visitors,
          activeNow: stats.active_now,
          bounceRate: parseFloat(stats.bounce_rate),
          avgSessionTime: stats.avg_session_time
        });
        setOnlineUsers(stats.online_users);
      }
    } catch (error) {
      console.error('Error fetching analytics data:', error);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  useEffect(() => {
    fetchAnalyticsData();

    const onlineInterval = setInterval(() => {
      setOnlineUsers(prev => {
        const change = Math.floor(Math.random() * 20) - 10;
        const newValue = prev + change;
        return Math.max(250, Math.min(400, newValue));
      });
    }, 3000);

    return () => clearInterval(onlineInterval);
  }, []);

  const handleRefresh = async () => {
    setRefreshing(true);
    await fetchAnalyticsData();
  };

  const handleExport = (type) => {
    let dataToExport = [];
    let filename = '';

    switch (type) {
      case 'sales':
        dataToExport = salesData;
        filename = 'sales_data.csv';
        break;
      case 'revenue':
        dataToExport = revenueData;
        filename = 'revenue_data.csv';
        break;
      case 'hourly':
        dataToExport = hourlyData;
        filename = 'hourly_activity.csv';
        break;
      default:
        return;
    }

    const headers = Object.keys(dataToExport[0] || {}).join(',');
    const rows = dataToExport.map(row => Object.values(row).join(',')).join('\n');
    const csv = `${headers}\n${rows}`;

    const blob = new Blob(['\ufeff' + csv], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    const url = URL.createObjectURL(blob);
    link.setAttribute('href', url);
    link.setAttribute('download', filename);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const stats = [
    {
      title: '实时在线',
      value: onlineUsers,
      change: '+12.5%',
      icon: Activity,
      gradient: 'from-emerald-500 to-teal-600',
      bgGradient: 'from-emerald-50 to-teal-50',
      isPositive: true
    },
    {
      title: '今日访客',
      value: realtimeData.totalVisitors.toLocaleString(),
      change: '+8.2%',
      icon: Eye,
      gradient: 'from-blue-500 to-cyan-600',
      bgGradient: 'from-blue-50 to-cyan-50',
      isPositive: true
    },
    {
      title: '活跃用户',
      value: realtimeData.activeNow,
      change: '+15.3%',
      icon: Users,
      gradient: 'from-violet-500 to-purple-600',
      bgGradient: 'from-violet-50 to-purple-50',
      isPositive: true
    },
    {
      title: '跳出率',
      value: `${realtimeData.bounceRate}%`,
      change: '-3.1%',
      icon: TrendingDown,
      gradient: 'from-rose-500 to-pink-600',
      bgGradient: 'from-rose-50 to-pink-50',
      isPositive: true
    }
  ];

  if (loading) {
    return (
      <div className="flex items-center justify-center h-96">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between animate-slide-up">
        <div>
          <h1 className="text-3xl font-bold bg-gradient-to-r from-gray-900 to-gray-700 bg-clip-text text-transparent">数据分析</h1>
          <p className="text-gray-600 mt-2 flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
            实时业务数据和趋势分析
          </p>
        </div>
        <div className="flex items-center gap-3">
          <button
            onClick={handleRefresh}
            disabled={refreshing}
            className="flex items-center gap-2 px-4 py-2 bg-white border border-gray-300 rounded-xl hover:bg-gray-50 transition-colors disabled:opacity-50"
          >
            <RefreshCw className={`w-4 h-4 ${refreshing ? 'animate-spin' : ''}`} />
            <span className="text-sm font-medium">刷新数据</span>
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-6">
        {stats.map((stat, index) => {
          const Icon = stat.icon;
          return (
            <div
              key={index}
              className="card-hover bg-white rounded-2xl border border-gray-200/50 p-6 shadow-sm animate-scale-in"
              style={{ animationDelay: `${index * 100}ms` }}
            >
              <div className="flex items-start justify-between mb-4">
                <div className={`p-3 rounded-xl bg-gradient-to-br ${stat.bgGradient} shadow-sm`}>
                  <Icon className={`w-6 h-6 bg-gradient-to-br ${stat.gradient} bg-clip-text text-transparent`} strokeWidth={2.5} />
                </div>
                <div className={`flex items-center gap-1 px-2 py-1 rounded-lg ${stat.isPositive ? 'bg-emerald-50' : 'bg-rose-50'}`}>
                  {stat.isPositive ? (
                    <ArrowUp className="w-3 h-3 text-emerald-600" />
                  ) : (
                    <ArrowDown className="w-3 h-3 text-rose-600" />
                  )}
                  <span className={`text-xs font-semibold ${stat.isPositive ? 'text-emerald-600' : 'text-rose-600'}`}>
                    {stat.change}
                  </span>
                </div>
              </div>
              <h3 className="text-gray-600 text-sm font-medium mb-2">{stat.title}</h3>
              <p className="text-3xl font-bold text-gray-900">
                {stat.title === '实时在线' ? (
                  <span className="flex items-center gap-2">
                    {stat.value}
                    <span className="relative flex h-3 w-3">
                      <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                      <span className="relative inline-flex rounded-full h-3 w-3 bg-emerald-500"></span>
                    </span>
                  </span>
                ) : (
                  stat.value
                )}
              </p>
            </div>
          );
        })}
      </div>

      <div className="bg-white rounded-2xl border border-gray-200/50 shadow-sm p-6 animate-slide-up">
        <div className="mb-6 flex items-center justify-between">
          <div>
            <h2 className="text-xl font-bold text-gray-900 mb-1">销售K线图</h2>
            <p className="text-sm text-gray-600">每日销售额走势（开盘、收盘、最高、最低）</p>
          </div>
          <button
            onClick={() => handleExport('sales')}
            className="flex items-center gap-2 px-4 py-2 text-sm font-medium text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"
          >
            <Download className="w-4 h-4" />
            导出数据
          </button>
        </div>
        {salesData.length > 0 ? (
          <CandlestickChart data={salesData} height={420} />
        ) : (
          <div className="h-96 flex items-center justify-center text-gray-500">
            暂无数据
          </div>
        )}
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
        <div className="bg-white rounded-2xl border border-gray-200/50 shadow-sm p-6 animate-slide-up">
          <div className="mb-6 flex items-center justify-between">
            <div>
              <h2 className="text-xl font-bold text-gray-900 mb-1">月度营收趋势</h2>
              <p className="text-sm text-gray-600">最近12个月的营收数据</p>
            </div>
            <button
              onClick={() => handleExport('revenue')}
              className="flex items-center gap-2 px-3 py-2 text-sm font-medium text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"
            >
              <Download className="w-4 h-4" />
            </button>
          </div>
          {revenueData.length > 0 ? (
            <ResponsiveContainer width="100%" height={300}>
              <AreaChart data={revenueData} margin={{ top: 10, right: 30, left: 0, bottom: 0 }}>
                <defs>
                  <linearGradient id="revenueGradient" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.3} />
                    <stop offset="95%" stopColor="#06b6d4" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
                <XAxis dataKey="month" stroke="#64748b" style={{ fontSize: '12px' }} />
                <YAxis stroke="#64748b" style={{ fontSize: '12px' }} />
                <Tooltip
                  contentStyle={{
                    backgroundColor: 'rgba(255, 255, 255, 0.95)',
                    backdropFilter: 'blur(10px)',
                    border: '1px solid #e5e7eb',
                    borderRadius: '12px',
                    padding: '12px'
                  }}
                />
                <Area
                  type="monotone"
                  dataKey="revenue"
                  stroke="#3b82f6"
                  strokeWidth={3}
                  fill="url(#revenueGradient)"
                />
              </AreaChart>
            </ResponsiveContainer>
          ) : (
            <div className="h-72 flex items-center justify-center text-gray-500">
              暂无数据
            </div>
          )}
        </div>

        <div className="bg-white rounded-2xl border border-gray-200/50 shadow-sm p-6 animate-slide-up">
          <div className="mb-6 flex items-center justify-between">
            <div>
              <h2 className="text-xl font-bold text-gray-900 mb-1">24小时用户活跃度</h2>
              <p className="text-sm text-gray-600">今日每小时在线用户统计</p>
            </div>
            <button
              onClick={() => handleExport('hourly')}
              className="flex items-center gap-2 px-3 py-2 text-sm font-medium text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"
            >
              <Download className="w-4 h-4" />
            </button>
          </div>
          {hourlyData.length > 0 ? (
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={hourlyData} margin={{ top: 10, right: 30, left: 0, bottom: 0 }}>
                <defs>
                  <linearGradient id="barGradient" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#10b981" stopOpacity={0.8} />
                    <stop offset="95%" stopColor="#14b8a6" stopOpacity={0.6} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
                <XAxis dataKey="hour" stroke="#64748b" style={{ fontSize: '12px' }} />
                <YAxis stroke="#64748b" style={{ fontSize: '12px' }} />
                <Tooltip
                  contentStyle={{
                    backgroundColor: 'rgba(255, 255, 255, 0.95)',
                    backdropFilter: 'blur(10px)',
                    border: '1px solid #e5e7eb',
                    borderRadius: '12px',
                    padding: '12px'
                  }}
                />
                <Bar dataKey="users" fill="url(#barGradient)" radius={[8, 8, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          ) : (
            <div className="h-72 flex items-center justify-center text-gray-500">
              暂无数据
            </div>
          )}
        </div>
      </div>

      <div className="bg-white rounded-2xl border border-gray-200/50 shadow-sm p-6 animate-slide-up">
        <div className="mb-6">
          <h2 className="text-xl font-bold text-gray-900 mb-1">综合数据对比</h2>
          <p className="text-sm text-gray-600">营收、订单量与访客数的关联分析</p>
        </div>
        {revenueData.length > 0 ? (
          <ResponsiveContainer width="100%" height={350}>
            <LineChart data={revenueData} margin={{ top: 10, right: 30, left: 0, bottom: 0 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
              <XAxis dataKey="month" stroke="#64748b" style={{ fontSize: '12px' }} />
              <YAxis stroke="#64748b" style={{ fontSize: '12px' }} />
              <Tooltip
                contentStyle={{
                  backgroundColor: 'rgba(255, 255, 255, 0.95)',
                  backdropFilter: 'blur(10px)',
                  border: '1px solid #e5e7eb',
                  borderRadius: '12px',
                  padding: '12px'
                }}
              />
              <Legend
                wrapperStyle={{
                  paddingTop: '20px'
                }}
              />
              <Line
                type="monotone"
                dataKey="revenue"
                name="营收"
                stroke="#3b82f6"
                strokeWidth={3}
                dot={{ fill: '#3b82f6', strokeWidth: 2, r: 5 }}
                activeDot={{ r: 7 }}
              />
              <Line
                type="monotone"
                dataKey="orders"
                name="订单量"
                stroke="#10b981"
                strokeWidth={3}
                dot={{ fill: '#10b981', strokeWidth: 2, r: 5 }}
                activeDot={{ r: 7 }}
              />
              <Line
                type="monotone"
                dataKey="visitors"
                name="访客数"
                stroke="#f59e0b"
                strokeWidth={3}
                dot={{ fill: '#f59e0b', strokeWidth: 2, r: 5 }}
                activeDot={{ r: 7 }}
              />
            </LineChart>
          </ResponsiveContainer>
        ) : (
          <div className="h-80 flex items-center justify-center text-gray-500">
            暂无数据
          </div>
        )}
      </div>
    </div>
  );
}
