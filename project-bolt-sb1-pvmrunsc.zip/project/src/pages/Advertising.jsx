import React, { useState, useEffect } from 'react';
import {
  TrendingUp,
  DollarSign,
  Eye,
  MousePointer,
  Target,
  Plus,
  Play,
  Pause,
  Settings,
  BarChart3,
  Zap,
  AlertCircle,
  CheckCircle,
  TrendingDown,
  Calendar,
  Filter,
  Download
} from 'lucide-react';
import { supabase } from '../lib/supabase';
import Modal from '../components/Modal';

export default function Advertising() {
  const [activeTab, setActiveTab] = useState('overview');
  const [campaigns, setCampaigns] = useState([]);
  const [platforms, setPlatforms] = useState([]);
  const [accounts, setAccounts] = useState([]);
  const [stats, setStats] = useState({
    totalSpend: 0,
    totalRevenue: 0,
    totalImpressions: 0,
    totalClicks: 0,
    avgCTR: 0,
    avgROAS: 0
  });
  const [loading, setLoading] = useState(false);
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [showAccountModal, setShowAccountModal] = useState(false);
  const [selectedDateRange, setSelectedDateRange] = useState('7d');
  const [aiRecommendations, setAiRecommendations] = useState([]);
  const [generatingAI, setGeneratingAI] = useState(false);

  const [newCampaign, setNewCampaign] = useState({
    campaign_name: '',
    campaign_objective: 'conversions',
    account_id: '',
    daily_budget: '',
    start_date: '',
    end_date: '',
    status: 'draft'
  });

  const [newAccount, setNewAccount] = useState({
    platform_id: '',
    account_name: '',
    account_id: '',
    daily_budget: '',
    currency: 'CNY'
  });

  useEffect(() => {
    loadData();
    if (activeTab === 'automation') {
      loadAIRecommendations();
    }
  }, [selectedDateRange, activeTab]);

  const loadData = async () => {
    setLoading(true);
    try {
      await Promise.all([
        loadPlatforms(),
        loadAccounts(),
        loadCampaigns(),
        loadStats()
      ]);
    } catch (error) {
      console.error('Error loading data:', error);
    } finally {
      setLoading(false);
    }
  };

  const loadPlatforms = async () => {
    const { data, error } = await supabase
      .from('ad_platforms')
      .select('*')
      .eq('is_active', true)
      .order('platform_name');

    if (!error && data) {
      setPlatforms(data);
    }
  };

  const loadAccounts = async () => {
    const { data: domainData } = await supabase
      .from('sys_domains')
      .select('id')
      .limit(1)
      .single();

    if (domainData) {
      const { data, error } = await supabase
        .from('ad_accounts')
        .select(`
          *,
          platform:ad_platforms(platform_name, platform_name_cn)
        `)
        .eq('domain_id', domainData.id)
        .order('created_at', { ascending: false });

      if (!error && data) {
        setAccounts(data);
      }
    }
  };

  const loadCampaigns = async () => {
    const { data: domainData } = await supabase
      .from('sys_domains')
      .select('id')
      .limit(1)
      .single();

    if (domainData) {
      const { data, error } = await supabase
        .from('ad_campaigns')
        .select(`
          *,
          account:ad_accounts(account_name, platform:ad_platforms(platform_name_cn))
        `)
        .eq('domain_id', domainData.id)
        .order('created_at', { ascending: false });

      if (!error && data) {
        setCampaigns(data);
      }
    }
  };

  const loadStats = async () => {
    const { data: domainData } = await supabase
      .from('sys_domains')
      .select('id')
      .limit(1)
      .single();

    if (domainData) {
      const daysMap = { '7d': 7, '30d': 30, '90d': 90 };
      const days = daysMap[selectedDateRange] || 7;
      const startDate = new Date();
      startDate.setDate(startDate.getDate() - days);

      const { data, error } = await supabase
        .from('ad_stats')
        .select('*')
        .eq('domain_id', domainData.id)
        .gte('stat_date', startDate.toISOString().split('T')[0]);

      if (!error && data && data.length > 0) {
        const totalSpend = data.reduce((sum, s) => sum + parseFloat(s.spend || 0), 0);
        const totalRevenue = data.reduce((sum, s) => sum + parseFloat(s.revenue || 0), 0);
        const totalImpressions = data.reduce((sum, s) => sum + parseInt(s.impressions || 0), 0);
        const totalClicks = data.reduce((sum, s) => sum + parseInt(s.clicks || 0), 0);

        setStats({
          totalSpend,
          totalRevenue,
          totalImpressions,
          totalClicks,
          avgCTR: totalImpressions > 0 ? (totalClicks / totalImpressions * 100) : 0,
          avgROAS: totalSpend > 0 ? (totalRevenue / totalSpend) : 0
        });
      }
    }
  };

  const handleCreateAccount = async (e) => {
    e.preventDefault();
    setLoading(true);

    try {
      const { data: domainData } = await supabase
        .from('sys_domains')
        .select('id')
        .limit(1)
        .single();

      if (domainData) {
        const { error } = await supabase
          .from('ad_accounts')
          .insert({
            ...newAccount,
            domain_id: domainData.id,
            status: 'active'
          });

        if (!error) {
          setShowAccountModal(false);
          setNewAccount({
            platform_id: '',
            account_name: '',
            account_id: '',
            daily_budget: '',
            currency: 'CNY'
          });
          loadAccounts();
        }
      }
    } catch (error) {
      console.error('Error creating account:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleCreateCampaign = async (e) => {
    e.preventDefault();
    setLoading(true);

    try {
      const { data: domainData } = await supabase
        .from('sys_domains')
        .select('id')
        .limit(1)
        .single();

      if (domainData) {
        const { error } = await supabase
          .from('ad_campaigns')
          .insert({
            ...newCampaign,
            domain_id: domainData.id
          });

        if (!error) {
          setShowCreateModal(false);
          setNewCampaign({
            campaign_name: '',
            campaign_objective: 'conversions',
            account_id: '',
            daily_budget: '',
            start_date: '',
            end_date: '',
            status: 'draft'
          });
          loadCampaigns();
        }
      }
    } catch (error) {
      console.error('Error creating campaign:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleToggleCampaignStatus = async (campaignId, currentStatus) => {
    const newStatus = currentStatus === 'active' ? 'paused' : 'active';

    const { error } = await supabase
      .from('ad_campaigns')
      .update({ status: newStatus })
      .eq('id', campaignId);

    if (!error) {
      loadCampaigns();
    }
  };

  const loadAIRecommendations = async () => {
    try {
      const { data: domainData } = await supabase
        .from('sys_domains')
        .select('id')
        .limit(1)
        .maybeSingle();

      if (domainData) {
        const { data, error } = await supabase.rpc('get_ai_recommendations', {
          p_domain_id: domainData.id,
          p_status: 'pending'
        });

        if (!error && data) {
          setAiRecommendations(data);
        }
      }
    } catch (error) {
      console.error('Error loading AI recommendations:', error);
    }
  };

  const generateAIRecommendations = async () => {
    setGeneratingAI(true);
    try {
      const { data: domainData } = await supabase
        .from('sys_domains')
        .select('id')
        .limit(1)
        .maybeSingle();

      if (domainData) {
        const { data, error } = await supabase.rpc('generate_ai_recommendations', {
          p_domain_id: domainData.id
        });

        if (!error && data) {
          await loadAIRecommendations();
        }
      }
    } catch (error) {
      console.error('Error generating AI recommendations:', error);
    } finally {
      setGeneratingAI(false);
    }
  };

  const dismissRecommendation = async (recommendationId) => {
    const { error } = await supabase
      .from('ad_optimization_recommendations')
      .update({ status: 'dismissed' })
      .eq('id', recommendationId);

    if (!error) {
      loadAIRecommendations();
    }
  };

  const getStatusBadge = (status) => {
    const statusConfig = {
      active: { text: '投放中', className: 'bg-green-100 text-green-800', icon: CheckCircle },
      paused: { text: '已暂停', className: 'bg-yellow-100 text-yellow-800', icon: Pause },
      draft: { text: '草稿', className: 'bg-gray-100 text-gray-800', icon: AlertCircle },
      completed: { text: '已完成', className: 'bg-blue-100 text-blue-800', icon: CheckCircle },
      archived: { text: '已归档', className: 'bg-gray-100 text-gray-600', icon: AlertCircle }
    };
    const config = statusConfig[status] || statusConfig.draft;
    const Icon = config.icon;

    return (
      <span className={`inline-flex items-center gap-1 px-2 py-1 rounded-full text-xs font-medium ${config.className}`}>
        <Icon className="w-3 h-3" />
        {config.text}
      </span>
    );
  };

  const formatCurrency = (value) => {
    return new Intl.NumberFormat('zh-CN', {
      style: 'currency',
      currency: 'CNY'
    }).format(value);
  };

  const formatNumber = (value) => {
    return new Intl.NumberFormat('zh-CN').format(value);
  };

  const tabs = [
    { id: 'overview', name: '数据概览', icon: BarChart3 },
    { id: 'campaigns', name: '广告活动', icon: Target },
    { id: 'accounts', name: '广告账户', icon: Settings },
    { id: 'automation', name: '智能优化', icon: Zap }
  ];

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-start">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">广告推广管理</h1>
          <p className="text-gray-600 mt-1">智能化多平台广告投放与优化</p>
        </div>
        <div className="flex gap-3">
          <button
            onClick={() => setShowAccountModal(true)}
            className="flex items-center gap-2 px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50 transition-colors"
          >
            <Plus className="w-5 h-5" />
            添加账户
          </button>
          <button
            onClick={() => setShowCreateModal(true)}
            className="flex items-center gap-2 bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors"
          >
            <Plus className="w-5 h-5" />
            创建广告
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">总花费</p>
              <p className="text-2xl font-bold text-gray-900 mt-1">
                {formatCurrency(stats.totalSpend)}
              </p>
            </div>
            <div className="p-3 bg-red-50 rounded-lg">
              <DollarSign className="w-6 h-6 text-red-600" />
            </div>
          </div>
        </div>

        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">总收入</p>
              <p className="text-2xl font-bold text-gray-900 mt-1">
                {formatCurrency(stats.totalRevenue)}
              </p>
            </div>
            <div className="p-3 bg-green-50 rounded-lg">
              <TrendingUp className="w-6 h-6 text-green-600" />
            </div>
          </div>
        </div>

        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">展示次数</p>
              <p className="text-2xl font-bold text-gray-900 mt-1">
                {formatNumber(stats.totalImpressions)}
              </p>
            </div>
            <div className="p-3 bg-blue-50 rounded-lg">
              <Eye className="w-6 h-6 text-blue-600" />
            </div>
          </div>
        </div>

        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">点击次数</p>
              <p className="text-2xl font-bold text-gray-900 mt-1">
                {formatNumber(stats.totalClicks)}
              </p>
            </div>
            <div className="p-3 bg-purple-50 rounded-lg">
              <MousePointer className="w-6 h-6 text-purple-600" />
            </div>
          </div>
        </div>
      </div>

      <div className="bg-white rounded-lg shadow-sm border border-gray-200">
        <div className="border-b border-gray-200">
          <nav className="flex -mb-px">
            {tabs.map((tab) => {
              const Icon = tab.icon;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`flex items-center gap-2 px-6 py-4 border-b-2 font-medium text-sm transition-colors ${
                    activeTab === tab.id
                      ? 'border-blue-500 text-blue-600'
                      : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                  }`}
                >
                  <Icon className="w-5 h-5" />
                  {tab.name}
                </button>
              );
            })}
          </nav>
        </div>

        <div className="p-6">
          {activeTab === 'overview' && (
            <div className="space-y-6">
              <div className="flex items-center justify-between">
                <h2 className="text-lg font-semibold text-gray-900">性能指标</h2>
                <select
                  value={selectedDateRange}
                  onChange={(e) => setSelectedDateRange(e.target.value)}
                  className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                >
                  <option value="7d">最近7天</option>
                  <option value="30d">最近30天</option>
                  <option value="90d">最近90天</option>
                </select>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="bg-gradient-to-br from-blue-50 to-blue-100 rounded-lg p-6 border border-blue-200">
                  <div className="flex items-center gap-3 mb-2">
                    <Target className="w-5 h-5 text-blue-600" />
                    <span className="text-sm font-medium text-blue-900">点击率 (CTR)</span>
                  </div>
                  <p className="text-3xl font-bold text-blue-900">
                    {stats.avgCTR.toFixed(2)}%
                  </p>
                </div>

                <div className="bg-gradient-to-br from-green-50 to-green-100 rounded-lg p-6 border border-green-200">
                  <div className="flex items-center gap-3 mb-2">
                    <TrendingUp className="w-5 h-5 text-green-600" />
                    <span className="text-sm font-medium text-green-900">投资回报率 (ROAS)</span>
                  </div>
                  <p className="text-3xl font-bold text-green-900">
                    {stats.avgROAS.toFixed(2)}x
                  </p>
                </div>

                <div className="bg-gradient-to-br from-purple-50 to-purple-100 rounded-lg p-6 border border-purple-200">
                  <div className="flex items-center gap-3 mb-2">
                    <DollarSign className="w-5 h-5 text-purple-600" />
                    <span className="text-sm font-medium text-purple-900">平均单次点击成本</span>
                  </div>
                  <p className="text-3xl font-bold text-purple-900">
                    {stats.totalClicks > 0 ? formatCurrency(stats.totalSpend / stats.totalClicks) : '¥0'}
                  </p>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'campaigns' && (
            <div className="space-y-4">
              {loading ? (
                <div className="flex items-center justify-center py-12">
                  <div className="animate-spin rounded-full h-8 w-8 border-2 border-blue-600 border-t-transparent" />
                </div>
              ) : campaigns.length === 0 ? (
                <div className="text-center py-12">
                  <Target className="w-12 h-12 text-gray-400 mx-auto mb-3" />
                  <p className="text-gray-600">还没有广告活动</p>
                  <button
                    onClick={() => setShowCreateModal(true)}
                    className="mt-4 text-blue-600 hover:text-blue-700"
                  >
                    创建第一个广告活动
                  </button>
                </div>
              ) : (
                <div className="overflow-x-auto">
                  <table className="min-w-full divide-y divide-gray-200">
                    <thead className="bg-gray-50">
                      <tr>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                          活动名称
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                          平台
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                          目标
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                          预算
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                          状态
                        </th>
                        <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase">
                          操作
                        </th>
                      </tr>
                    </thead>
                    <tbody className="bg-white divide-y divide-gray-200">
                      {campaigns.map((campaign) => (
                        <tr key={campaign.id}>
                          <td className="px-6 py-4">
                            <div className="text-sm font-medium text-gray-900">
                              {campaign.campaign_name}
                            </div>
                            <div className="text-xs text-gray-500">
                              {campaign.account?.account_name}
                            </div>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                            {campaign.account?.platform?.platform_name_cn}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                            {campaign.campaign_objective}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                            {formatCurrency(campaign.daily_budget)}/天
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap">
                            {getStatusBadge(campaign.status)}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                            <button
                              onClick={() => handleToggleCampaignStatus(campaign.id, campaign.status)}
                              className="text-blue-600 hover:text-blue-900 mr-3"
                            >
                              {campaign.status === 'active' ? (
                                <Pause className="w-5 h-5" />
                              ) : (
                                <Play className="w-5 h-5" />
                              )}
                            </button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          )}

          {activeTab === 'accounts' && (
            <div className="space-y-4">
              {accounts.length === 0 ? (
                <div className="text-center py-12">
                  <Settings className="w-12 h-12 text-gray-400 mx-auto mb-3" />
                  <p className="text-gray-600">还没有广告账户</p>
                  <button
                    onClick={() => setShowAccountModal(true)}
                    className="mt-4 text-blue-600 hover:text-blue-700"
                  >
                    添加第一个广告账户
                  </button>
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {accounts.map((account) => (
                    <div
                      key={account.id}
                      className="bg-white rounded-lg border border-gray-200 p-6 hover:border-blue-300 transition-colors"
                    >
                      <div className="flex items-start justify-between mb-4">
                        <div>
                          <h3 className="font-semibold text-gray-900">{account.account_name}</h3>
                          <p className="text-sm text-gray-600 mt-1">
                            {account.platform?.platform_name_cn}
                          </p>
                        </div>
                        <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                          account.status === 'active'
                            ? 'bg-green-100 text-green-800'
                            : 'bg-gray-100 text-gray-800'
                        }`}>
                          {account.status === 'active' ? '活跃' : '暂停'}
                        </span>
                      </div>
                      <div className="space-y-2 text-sm">
                        <div className="flex justify-between">
                          <span className="text-gray-600">每日预算:</span>
                          <span className="font-medium text-gray-900">
                            {formatCurrency(account.daily_budget)}
                          </span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-600">账户ID:</span>
                          <span className="font-medium text-gray-900 font-mono text-xs">
                            {account.account_id}
                          </span>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {activeTab === 'automation' && (
            <div className="space-y-6">
              <div className="flex items-center justify-between mb-4">
                <div>
                  <h2 className="text-lg font-semibold text-gray-900">AI智能优化建议</h2>
                  <p className="text-sm text-gray-600 mt-1">
                    基于机器学习算法分析您的广告数据，提供实时优化建议
                  </p>
                </div>
                <button
                  onClick={generateAIRecommendations}
                  disabled={generatingAI}
                  className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:bg-gray-400 transition-colors"
                >
                  <Zap className="w-5 h-5" />
                  {generatingAI ? '生成中...' : '生成AI建议'}
                </button>
              </div>

              {aiRecommendations.length === 0 ? (
                <div className="bg-gradient-to-r from-blue-50 to-purple-50 rounded-lg p-12 border border-blue-200 text-center">
                  <Zap className="w-12 h-12 text-blue-600 mx-auto mb-4" />
                  <h3 className="text-lg font-semibold text-gray-900 mb-2">
                    暂无AI优化建议
                  </h3>
                  <p className="text-gray-600 mb-4">
                    点击上方按钮，让AI分析您的广告数据并生成优化建议
                  </p>
                </div>
              ) : (
                <div className="space-y-3">
                  {aiRecommendations.map((rec) => {
                    const priorityConfig = {
                      critical: { color: 'red', icon: AlertCircle },
                      high: { color: 'orange', icon: TrendingUp },
                      medium: { color: 'blue', icon: Target },
                      low: { color: 'gray', icon: CheckCircle }
                    };
                    const config = priorityConfig[rec.priority] || priorityConfig.medium;
                    const Icon = config.icon;

                    return (
                      <div key={rec.id} className="bg-white rounded-lg p-4 border border-gray-200 hover:border-blue-300 transition-colors">
                        <div className="flex items-start justify-between gap-4">
                          <div className="flex items-start gap-3 flex-1">
                            <div className={`p-2 bg-${config.color}-50 rounded-lg`}>
                              <Icon className={`w-5 h-5 text-${config.color}-600`} />
                            </div>
                            <div className="flex-1">
                              <div className="flex items-center gap-2 mb-1">
                                <h4 className="font-medium text-gray-900">{rec.title}</h4>
                                <span className={`px-2 py-0.5 text-xs rounded-full bg-${config.color}-100 text-${config.color}-700`}>
                                  {rec.priority === 'critical' ? '紧急' :
                                   rec.priority === 'high' ? '高' :
                                   rec.priority === 'medium' ? '中' : '低'}
                                </span>
                                {rec.ai_confidence_score && (
                                  <span className="text-xs text-gray-500">
                                    置信度: {rec.ai_confidence_score}%
                                  </span>
                                )}
                              </div>
                              <p className="text-sm text-gray-600 mb-2">{rec.description}</p>

                              {rec.campaign_name && (
                                <p className="text-xs text-gray-500 mb-2">
                                  广告活动: {rec.campaign_name}
                                </p>
                              )}

                              {rec.current_metrics && (
                                <div className="flex gap-4 text-xs text-gray-600 mb-2">
                                  {rec.current_metrics.roas && (
                                    <span>ROAS: {rec.current_metrics.roas}x</span>
                                  )}
                                  {rec.current_metrics.ctr && (
                                    <span>CTR: {rec.current_metrics.ctr}%</span>
                                  )}
                                </div>
                              )}

                              {rec.action_items && rec.action_items.length > 0 && (
                                <div className="mt-2 bg-gray-50 rounded p-2">
                                  <p className="text-xs font-medium text-gray-700 mb-1">建议操作:</p>
                                  <ul className="text-xs text-gray-600 space-y-0.5">
                                    {rec.action_items.map((item, idx) => (
                                      <li key={idx}>• {item}</li>
                                    ))}
                                  </ul>
                                </div>
                              )}
                            </div>
                          </div>
                          <button
                            onClick={() => dismissRecommendation(rec.id)}
                            className="text-gray-400 hover:text-gray-600 transition-colors"
                            title="忽略此建议"
                          >
                            ×
                          </button>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}

              <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mt-6">
                <div className="flex items-start gap-2">
                  <Zap className="w-5 h-5 text-blue-600 mt-0.5" />
                  <div className="text-sm text-blue-800">
                    <p className="font-medium mb-1">AI算法说明：</p>
                    <ul className="list-disc list-inside space-y-1 text-xs">
                      <li>分析最近7天的广告数据，识别表现趋势</li>
                      <li>基于ROAS、CTR等关键指标生成优化建议</li>
                      <li>每个建议都包含AI置信度评分</li>
                      <li>建议会在7天后自动过期</li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>

      {showAccountModal && (
        <Modal
          isOpen={showAccountModal}
          onClose={() => setShowAccountModal(false)}
          title="添加广告账户"
        >
          <form onSubmit={handleCreateAccount} className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                选择平台 *
              </label>
              <select
                value={newAccount.platform_id}
                onChange={(e) => setNewAccount({ ...newAccount, platform_id: e.target.value })}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                required
              >
                <option value="">请选择广告平台</option>
                {platforms.map((platform) => (
                  <option key={platform.id} value={platform.id}>
                    {platform.platform_name_cn}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                账户名称 *
              </label>
              <input
                type="text"
                value={newAccount.account_name}
                onChange={(e) => setNewAccount({ ...newAccount, account_name: e.target.value })}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                placeholder="例如：主推广账户"
                required
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                账户ID *
              </label>
              <input
                type="text"
                value={newAccount.account_id}
                onChange={(e) => setNewAccount({ ...newAccount, account_id: e.target.value })}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                placeholder="从广告平台获取的账户ID"
                required
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                每日预算
              </label>
              <input
                type="number"
                value={newAccount.daily_budget}
                onChange={(e) => setNewAccount({ ...newAccount, daily_budget: e.target.value })}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                placeholder="0"
                min="0"
                step="0.01"
              />
            </div>

            <div className="flex gap-3 pt-4">
              <button
                type="button"
                onClick={() => setShowAccountModal(false)}
                className="flex-1 px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50 transition-colors"
              >
                取消
              </button>
              <button
                type="submit"
                disabled={loading}
                className="flex-1 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors disabled:bg-gray-400"
              >
                {loading ? '添加中...' : '添加'}
              </button>
            </div>
          </form>
        </Modal>
      )}

      {showCreateModal && (
        <Modal
          isOpen={showCreateModal}
          onClose={() => setShowCreateModal(false)}
          title="创建广告活动"
        >
          <form onSubmit={handleCreateCampaign} className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                选择账户 *
              </label>
              <select
                value={newCampaign.account_id}
                onChange={(e) => setNewCampaign({ ...newCampaign, account_id: e.target.value })}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                required
              >
                <option value="">请选择广告账户</option>
                {accounts.map((account) => (
                  <option key={account.id} value={account.id}>
                    {account.account_name} ({account.platform?.platform_name_cn})
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                活动名称 *
              </label>
              <input
                type="text"
                value={newCampaign.campaign_name}
                onChange={(e) => setNewCampaign({ ...newCampaign, campaign_name: e.target.value })}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                placeholder="例如：春季促销活动"
                required
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                营销目标 *
              </label>
              <select
                value={newCampaign.campaign_objective}
                onChange={(e) => setNewCampaign({ ...newCampaign, campaign_objective: e.target.value })}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                required
              >
                <option value="conversions">转化量</option>
                <option value="traffic">网站流量</option>
                <option value="awareness">品牌知名度</option>
                <option value="engagement">互动率</option>
                <option value="app_installs">应用安装</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                每日预算
              </label>
              <input
                type="number"
                value={newCampaign.daily_budget}
                onChange={(e) => setNewCampaign({ ...newCampaign, daily_budget: e.target.value })}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                placeholder="0"
                min="0"
                step="0.01"
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  开始日期
                </label>
                <input
                  type="date"
                  value={newCampaign.start_date}
                  onChange={(e) => setNewCampaign({ ...newCampaign, start_date: e.target.value })}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  结束日期
                </label>
                <input
                  type="date"
                  value={newCampaign.end_date}
                  onChange={(e) => setNewCampaign({ ...newCampaign, end_date: e.target.value })}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
              </div>
            </div>

            <div className="flex gap-3 pt-4">
              <button
                type="button"
                onClick={() => setShowCreateModal(false)}
                className="flex-1 px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50 transition-colors"
              >
                取消
              </button>
              <button
                type="submit"
                disabled={loading}
                className="flex-1 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors disabled:bg-gray-400"
              >
                {loading ? '创建中...' : '创建'}
              </button>
            </div>
          </form>
        </Modal>
      )}
    </div>
  );
}
