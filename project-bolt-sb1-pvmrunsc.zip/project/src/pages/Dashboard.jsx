import React, { useEffect, useState } from 'react';
import { supabase } from '../lib/supabase';
import {
  TrendingUp,
  TrendingDown,
  ShoppingCart,
  Package,
  DollarSign,
  Users,
  AlertCircle,
  Clock,
  Warehouse,
  Truck,
  Gift,
  MessageSquare,
  Activity,
  CheckCircle,
  XCircle,
  ArrowUpRight,
  ArrowDownRight
} from 'lucide-react';

export default function Dashboard() {
  const [stats, setStats] = useState({
    totalOrders: 0,
    totalProducts: 0,
    totalRevenue: 0,
    pendingOrders: 0,
    todayOrders: 0,
    todayRevenue: 0,
    lowStockProducts: 0,
    activeWarehouses: 0,
    pendingShipments: 0,
    activeLottery: 0,
    openTickets: 0
  });
  const [recentOrders, setRecentOrders] = useState([]);
  const [stockAlerts, setStockAlerts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [lastUpdate, setLastUpdate] = useState(new Date());

  useEffect(() => {
    loadDashboardData();

    const interval = setInterval(() => {
      loadDashboardData();
    }, 30000);

    return () => clearInterval(interval);
  }, []);

  const loadDashboardData = async () => {
    try {
      const wasInitialLoad = loading;
      if (wasInitialLoad) {
        setLoading(true);
      }
      setError(null);

      const today = new Date();
      today.setHours(0, 0, 0, 0);

      const results = await Promise.allSettled([
        supabase.from('sys_orders').select('total_amount, order_status, created_at'),
        supabase.from('sys_products').select('id, status'),
        supabase
          .from('sys_orders')
          .select('id, order_number, customer_name, final_amount, order_status, created_at')
          .order('created_at', { ascending: false })
          .limit(5),
        supabase.from('wms_warehouses').select('id, status').eq('status', 'active'),
        supabase.from('lgs_shipments').select('id, status').in('status', ['pending', 'in_transit']),
        supabase.from('lot_campaigns').select('id, status').eq('status', 'active'),
        supabase.from('cs_tickets').select('id, status').in('status', ['open', 'in_progress']),
        supabase.from('wms_stock_alerts').select('id, alert_type, current_quantity').eq('status', 'active').limit(5)
      ]);

      const [
        ordersData,
        productsData,
        recentOrdersData,
        warehousesData,
        shipmentsData,
        lotteryData,
        ticketsData,
        alertsData
      ] = results.map(result =>
        result.status === 'fulfilled' ? result.value : { data: null, error: result.reason }
      );

      if (ordersData.data) {
        const totalOrders = ordersData.data.length;
        const totalRevenue = ordersData.data.reduce((sum, order) => sum + Number(order.total_amount || 0), 0);
        const pendingOrders = ordersData.data.filter(o => o.order_status === 'pending').length;

        const todayOrdersData = ordersData.data.filter(o => new Date(o.created_at) >= today);
        const todayOrders = todayOrdersData.length;
        const todayRevenue = todayOrdersData.reduce((sum, order) => sum + Number(order.total_amount || 0), 0);

        setStats(prev => ({
          ...prev,
          totalOrders,
          totalRevenue,
          pendingOrders,
          todayOrders,
          todayRevenue
        }));
      }

      if (productsData.data) {
        const totalProducts = productsData.data.filter(p => p.status === 'active').length;
        setStats(prev => ({ ...prev, totalProducts }));
      }

      if (recentOrdersData.data) {
        setRecentOrders(recentOrdersData.data);
      }

      if (warehousesData.data) {
        setStats(prev => ({ ...prev, activeWarehouses: warehousesData.data.length }));
      }

      if (shipmentsData.data) {
        setStats(prev => ({ ...prev, pendingShipments: shipmentsData.data.length }));
      }

      if (lotteryData.data) {
        setStats(prev => ({ ...prev, activeLottery: lotteryData.data.length }));
      }

      if (ticketsData.data) {
        setStats(prev => ({ ...prev, openTickets: ticketsData.data.length }));
      }

      if (alertsData.data) {
        setStockAlerts(alertsData.data);
      }

      setLastUpdate(new Date());
    } catch (err) {
      console.error('Error loading dashboard data:', err);
      setError(err.message || '加载数据失败');
    } finally {
      setLoading(false);
    }
  };

  const mainStats = [
    {
      title: '今日订单',
      value: stats.todayOrders,
      subtitle: `总订单: ${stats.totalOrders}`,
      icon: ShoppingCart,
      gradient: 'from-blue-500 to-cyan-600',
      bgGradient: 'from-blue-50 to-cyan-50',
      trend: '+12.5%'
    },
    {
      title: '今日收入',
      value: `¥${stats.todayRevenue.toLocaleString()}`,
      subtitle: `总收入: ¥${stats.totalRevenue.toLocaleString()}`,
      icon: DollarSign,
      gradient: 'from-emerald-500 to-teal-600',
      bgGradient: 'from-emerald-50 to-teal-50',
      trend: '+8.3%'
    },
    {
      title: '在售商品',
      value: stats.totalProducts,
      subtitle: `${stats.pendingOrders} 待处理订单`,
      icon: Package,
      gradient: 'from-amber-500 to-orange-600',
      bgGradient: 'from-amber-50 to-orange-50',
      trend: '+5.2%'
    },
    {
      title: '活跃仓库',
      value: stats.activeWarehouses,
      subtitle: `${stats.pendingShipments} 待发货`,
      icon: Warehouse,
      gradient: 'from-purple-500 to-pink-600',
      bgGradient: 'from-purple-50 to-pink-50',
      trend: 'stable'
    }
  ];

  const systemStatus = [
    {
      name: '物流系统',
      value: stats.pendingShipments,
      label: '运输中',
      icon: Truck,
      color: 'blue',
      status: 'normal'
    },
    {
      name: '一元购',
      value: stats.activeLottery,
      label: '活动进行中',
      icon: Gift,
      color: 'rose',
      status: 'normal'
    },
    {
      name: '客服工单',
      value: stats.openTickets,
      label: '待处理',
      icon: MessageSquare,
      color: 'amber',
      status: stats.openTickets > 10 ? 'warning' : 'normal'
    },
    {
      name: '库存预警',
      value: stockAlerts.length,
      label: '需关注',
      icon: AlertCircle,
      color: 'red',
      status: stockAlerts.length > 0 ? 'warning' : 'normal'
    }
  ];

  const getStatusColor = (status) => {
    const colors = {
      pending: 'bg-amber-100 text-amber-700 border border-amber-200',
      confirmed: 'bg-blue-100 text-blue-700 border border-blue-200',
      shipped: 'bg-cyan-100 text-cyan-700 border border-cyan-200',
      delivered: 'bg-emerald-100 text-emerald-700 border border-emerald-200',
      cancelled: 'bg-rose-100 text-rose-700 border border-rose-200'
    };
    return colors[status] || 'bg-gray-100 text-gray-700 border border-gray-200';
  };

  const getStatusText = (status) => {
    const texts = {
      pending: '待处理',
      confirmed: '已确认',
      shipped: '已发货',
      delivered: '已送达',
      cancelled: '已取消'
    };
    return texts[status] || status;
  };

  const getAlertTypeText = (type) => {
    const texts = {
      low_stock: '库存不足',
      out_of_stock: '已缺货',
      overstock: '库存过多',
      expired: '即将过期'
    };
    return texts[type] || type;
  };

  if (loading) {
    return (
      <div className="flex flex-col items-center justify-center h-64 gap-4">
        <div className="relative">
          <div className="animate-spin rounded-full h-16 w-16 border-4 border-blue-200"></div>
          <div className="animate-spin rounded-full h-16 w-16 border-4 border-blue-600 border-t-transparent absolute top-0 left-0"></div>
        </div>
        <p className="text-gray-600 animate-pulse">加载ERP数据中...</p>
      </div>
    );
  }

  if (error) {
    return (
      <div className="flex flex-col items-center justify-center h-64 gap-4">
        <AlertCircle className="w-16 h-16 text-red-500" />
        <p className="text-gray-900 font-semibold">加载数据失败</p>
        <p className="text-gray-600">{error}</p>
        <button
          onClick={loadDashboardData}
          className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
        >
          重试
        </button>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="animate-slide-up">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-black bg-gradient-to-r from-gray-900 via-blue-800 to-cyan-700 bg-clip-text text-transparent">
              168全球购 ERP控制中心
            </h1>
            <p className="text-gray-600 mt-2 flex items-center gap-2">
              <span className="relative flex h-3 w-3">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-3 w-3 bg-emerald-500"></span>
              </span>
              系统运行正常 · 实时数据监控
            </p>
          </div>
          <div className="text-right">
            <p className="text-xs text-gray-500">上次更新</p>
            <p className="text-sm font-medium text-gray-700">{lastUpdate.toLocaleTimeString('zh-CN')}</p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-6">
        {mainStats.map((stat, index) => {
          const Icon = stat.icon;
          return (
            <div
              key={index}
              className="group relative bg-white rounded-2xl border border-gray-200/50 p-6 shadow-sm hover:shadow-xl transition-all duration-300 overflow-hidden"
            >
              <div className={`absolute inset-0 bg-gradient-to-br ${stat.bgGradient} opacity-0 group-hover:opacity-100 transition-opacity duration-300`}></div>

              <div className="relative">
                <div className="flex items-start justify-between mb-4">
                  <div className={`p-3 rounded-xl bg-gradient-to-br ${stat.gradient} shadow-lg`}>
                    <Icon className="w-6 h-6 text-white" strokeWidth={2.5} />
                  </div>
                  {stat.trend !== 'stable' ? (
                    <div className="flex items-center gap-1 px-2 py-1 rounded-lg bg-emerald-50">
                      <ArrowUpRight className="w-3 h-3 text-emerald-600" />
                      <span className="text-xs font-bold text-emerald-600">{stat.trend}</span>
                    </div>
                  ) : (
                    <div className="w-2 h-2 rounded-full bg-gray-300"></div>
                  )}
                </div>

                <h3 className="text-gray-600 text-sm font-medium mb-2">{stat.title}</h3>
                <p className="text-3xl font-black text-gray-900 mb-1">{stat.value}</p>
                <p className="text-xs text-gray-500">{stat.subtitle}</p>
              </div>
            </div>
          );
        })}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white rounded-2xl border border-gray-200/50 shadow-sm p-6">
          <div className="flex items-center justify-between mb-6">
            <div>
              <h2 className="text-xl font-bold text-gray-900">系统状态</h2>
              <p className="text-sm text-gray-600 mt-1">各模块运行状态</p>
            </div>
            <Activity className="w-6 h-6 text-blue-500" />
          </div>

          <div className="space-y-4">
            {systemStatus.map((item, index) => {
              const Icon = item.icon;
              const colorClasses = {
                blue: 'bg-blue-100 text-blue-700',
                rose: 'bg-rose-100 text-rose-700',
                amber: 'bg-amber-100 text-amber-700',
                red: 'bg-red-100 text-red-700'
              };

              return (
                <div key={index} className="flex items-center justify-between p-4 rounded-xl border border-gray-200 hover:border-gray-300 transition-colors">
                  <div className="flex items-center gap-4">
                    <div className={`p-2.5 rounded-lg ${colorClasses[item.color]}`}>
                      <Icon className="w-5 h-5" />
                    </div>
                    <div>
                      <p className="font-semibold text-gray-900">{item.name}</p>
                      <p className="text-sm text-gray-600">{item.label}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-2xl font-bold text-gray-900">{item.value}</span>
                    {item.status === 'warning' ? (
                      <AlertCircle className="w-5 h-5 text-amber-500" />
                    ) : (
                      <CheckCircle className="w-5 h-5 text-emerald-500" />
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        <div className="bg-white rounded-2xl border border-gray-200/50 shadow-sm p-6">
          <div className="flex items-center justify-between mb-6">
            <div>
              <h2 className="text-xl font-bold text-gray-900">库存预警</h2>
              <p className="text-sm text-gray-600 mt-1">需要关注的库存问题</p>
            </div>
            <AlertCircle className="w-6 h-6 text-amber-500" />
          </div>

          <div className="space-y-3">
            {stockAlerts.length > 0 ? (
              stockAlerts.map((alert, index) => (
                <div key={index} className="flex items-center justify-between p-3 rounded-lg bg-amber-50 border border-amber-200">
                  <div className="flex items-center gap-3">
                    <div className="w-2 h-2 rounded-full bg-amber-500"></div>
                    <div>
                      <p className="font-medium text-gray-900">{getAlertTypeText(alert.alert_type)}</p>
                      <p className="text-sm text-gray-600">当前库存: {alert.current_quantity}</p>
                    </div>
                  </div>
                  <XCircle className="w-5 h-5 text-amber-600" />
                </div>
              ))
            ) : (
              <div className="flex flex-col items-center justify-center py-8 text-center">
                <CheckCircle className="w-12 h-12 text-emerald-500 mb-3" />
                <p className="text-gray-600 font-medium">库存状态良好</p>
                <p className="text-sm text-gray-500">没有需要关注的预警</p>
              </div>
            )}
          </div>
        </div>
      </div>

      <div className="bg-white rounded-2xl border border-gray-200/50 shadow-sm overflow-hidden">
        <div className="p-6 border-b border-gray-200/50 bg-gradient-to-r from-gray-50 to-white">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-xl font-bold text-gray-900">最近订单</h2>
              <p className="text-sm text-gray-600 mt-1">实时订单动态</p>
            </div>
            <div className="flex items-center gap-2 px-3 py-1.5 bg-blue-50 rounded-lg">
              <div className="w-2 h-2 rounded-full bg-blue-600 animate-pulse"></div>
              <span className="text-xs font-medium text-blue-700">Live</span>
            </div>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-4 text-left text-xs font-bold text-gray-700 uppercase">订单号</th>
                <th className="px-6 py-4 text-left text-xs font-bold text-gray-700 uppercase">客户</th>
                <th className="px-6 py-4 text-left text-xs font-bold text-gray-700 uppercase">金额</th>
                <th className="px-6 py-4 text-left text-xs font-bold text-gray-700 uppercase">状态</th>
                <th className="px-6 py-4 text-left text-xs font-bold text-gray-700 uppercase">时间</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {recentOrders.map((order) => (
                <tr key={order.id} className="hover:bg-blue-50/30 transition-colors">
                  <td className="px-6 py-4">
                    <span className="text-sm font-bold text-gray-900">{order.order_number}</span>
                  </td>
                  <td className="px-6 py-4">
                    <span className="text-sm text-gray-700">{order.customer_name}</span>
                  </td>
                  <td className="px-6 py-4">
                    <span className="text-sm font-bold text-emerald-600">
                      ¥{Number(order.final_amount).toLocaleString()}
                    </span>
                  </td>
                  <td className="px-6 py-4">
                    <span className={`inline-flex items-center px-3 py-1 text-xs font-bold rounded-full ${getStatusColor(order.order_status)}`}>
                      {getStatusText(order.order_status)}
                    </span>
                  </td>
                  <td className="px-6 py-4">
                    <span className="text-sm text-gray-600">
                      {new Date(order.created_at).toLocaleString('zh-CN')}
                    </span>
                  </td>
                </tr>
              ))}
              {recentOrders.length === 0 && (
                <tr>
                  <td colSpan="5" className="px-6 py-12 text-center">
                    <div className="flex flex-col items-center gap-3">
                      <Package className="w-12 h-12 text-gray-300" />
                      <p className="text-gray-500 font-medium">暂无订单数据</p>
                    </div>
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
