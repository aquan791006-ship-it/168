import { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';
import { useToast } from '../contexts/ToastContext';
import {
  Link as LinkIcon,
  Plus,
  Copy,
  ExternalLink,
  BarChart3,
  Edit2,
  Trash2,
  Search,
  Filter,
  Download,
  Eye,
  EyeOff,
  Package,
  Globe,
  Tag
} from 'lucide-react';
import Modal from '../components/Modal';

export default function LinkTracker() {
  const { user } = useAuth();
  const { showToast } = useToast();
  const [links, setLinks] = useState([]);
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [hasPermission, setHasPermission] = useState(false);
  const [showAddModal, setShowAddModal] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [filterType, setFilterType] = useState('all');
  const [domain, setDomain] = useState(null);

  const [formData, setFormData] = useState({
    original_url: '',
    link_type: 'external',
    title: '',
    description: '',
    product_id: null,
    campaign_name: '',
    utm_source: '',
    utm_medium: '',
    utm_campaign: '',
    expires_at: null
  });

  useEffect(() => {
    loadDomainAndCheck();
  }, [user]);

  const loadDomainAndCheck = async () => {
    try {
      const { data: domainData, error: domainError } = await supabase
        .from('sys_domains')
        .select('id, domain, display_name')
        .limit(1)
        .single();

      if (domainError) throw domainError;
      setDomain(domainData);

      const { data: permData } = await supabase.rpc('check_analytics_permission', {
        p_domain_id: domainData.id,
        p_admin_id: user.id,
        p_permission_type: 'view'
      });

      if (permData || user?.is_super_admin) {
        setHasPermission(true);
        loadLinks(domainData.id);
        loadProducts(domainData.id);
      } else {
        setHasPermission(false);
      }
    } catch (error) {
      console.error('Error loading data:', error);
      showToast('error', '加载数据失败');
    } finally {
      setLoading(false);
    }
  };

  const loadLinks = async (domainId) => {
    const { data, error } = await supabase
      .from('sys_tracked_links')
      .select(`
        *,
        product:sys_products(id, name, image_url)
      `)
      .eq('domain_id', domainId)
      .order('created_at', { ascending: false });

    if (error) {
      console.error('Error loading links:', error);
      return;
    }

    setLinks(data || []);
  };

  const loadProducts = async (domainId) => {
    const { data, error } = await supabase
      .from('sys_products')
      .select('id, name, price, image_url')
      .eq('domain_id', domainId)
      .eq('status', 'active')
      .order('name');

    if (error) {
      console.error('Error loading products:', error);
      return;
    }

    setProducts(data || []);
  };

  const handleCreateLink = async () => {
    try {
      if (!formData.original_url || !formData.title) {
        showToast('error', '请填写链接和标题');
        return;
      }

      const { data: shortCode } = await supabase.rpc('generate_short_code');

      const { error } = await supabase
        .from('sys_tracked_links')
        .insert([{
          ...formData,
          domain_id: domain.id,
          short_code: shortCode,
          created_by: user.id,
          product_id: formData.product_id || null,
          expires_at: formData.expires_at || null
        }]);

      if (error) throw error;

      showToast('success', '链接创建成功');
      setShowAddModal(false);
      resetForm();
      loadLinks(domain.id);
    } catch (error) {
      console.error('Error creating link:', error);
      showToast('error', '创建失败：' + error.message);
    }
  };

  const handleToggleActive = async (id, currentStatus) => {
    const { error } = await supabase
      .from('sys_tracked_links')
      .update({ is_active: !currentStatus })
      .eq('id', id);

    if (error) {
      showToast('error', '操作失败');
      return;
    }

    showToast('success', !currentStatus ? '链接已激活' : '链接已禁用');
    loadLinks(domain.id);
  };

  const handleDelete = async (id) => {
    if (!confirm('确定要删除此链接吗？所有相关统计数据将被删除。')) return;

    const { error } = await supabase
      .from('sys_tracked_links')
      .delete()
      .eq('id', id);

    if (error) {
      showToast('error', '删除失败');
      return;
    }

    showToast('success', '链接删除成功');
    loadLinks(domain.id);
  };

  const copyToClipboard = (shortCode) => {
    const url = `${window.location.origin}/l/${shortCode}`;
    navigator.clipboard.writeText(url);
    showToast('success', '链接已复制到剪贴板');
  };

  const resetForm = () => {
    setFormData({
      original_url: '',
      link_type: 'external',
      title: '',
      description: '',
      product_id: null,
      campaign_name: '',
      utm_source: '',
      utm_medium: '',
      utm_campaign: '',
      expires_at: null
    });
  };

  const getShortUrl = (shortCode) => {
    return `${window.location.origin}/l/${shortCode}`;
  };

  const filteredLinks = links.filter(link => {
    const matchesSearch = link.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         link.original_url.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesType = filterType === 'all' || link.link_type === filterType;
    return matchesSearch && matchesType;
  });

  if (loading) {
    return <div className="p-6">加载中...</div>;
  }

  if (!hasPermission) {
    return (
      <div className="p-6">
        <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-6 text-center">
          <Eye className="w-12 h-12 text-yellow-600 mx-auto mb-3" />
          <h3 className="text-lg font-semibold text-gray-900 mb-2">无权限访问</h3>
          <p className="text-gray-600">
            您没有权限使用链接追踪功能，请联系超级管理员授予权限。
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="p-6">
      <div className="mb-6 flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900 flex items-center gap-2">
            <LinkIcon className="w-6 h-6" />
            链接追踪管理
          </h1>
          <p className="text-sm text-gray-600 mt-1">
            创建和管理追踪链接，统计访问数据
          </p>
        </div>
        <button
          onClick={() => setShowAddModal(true)}
          className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
        >
          <Plus className="w-4 h-4" />
          创建链接
        </button>
      </div>

      <div className="mb-6 flex gap-4">
        <div className="flex-1 relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="搜索链接标题或URL..."
            className="w-full pl-10 pr-4 py-2 border rounded-lg"
          />
        </div>
        <select
          value={filterType}
          onChange={(e) => setFilterType(e.target.value)}
          className="px-4 py-2 border rounded-lg"
        >
          <option value="all">所有类型</option>
          <option value="product">商品链接</option>
          <option value="category">分类链接</option>
          <option value="page">页面链接</option>
          <option value="external">外部链接</option>
          <option value="campaign">营销活动</option>
        </select>
      </div>

      <div className="grid gap-4">
        {filteredLinks.map((link) => (
          <div key={link.id} className="bg-white rounded-lg shadow-md p-6">
            <div className="flex items-start justify-between">
              <div className="flex-1">
                <div className="flex items-center gap-2 mb-2">
                  <h3 className="text-lg font-semibold text-gray-900">{link.title}</h3>
                  <span className={`px-2 py-0.5 text-xs rounded-full ${
                    link.link_type === 'product' ? 'bg-green-100 text-green-700' :
                    link.link_type === 'external' ? 'bg-blue-100 text-blue-700' :
                    'bg-gray-100 text-gray-700'
                  }`}>
                    {link.link_type === 'product' ? '商品' :
                     link.link_type === 'external' ? '外部' :
                     link.link_type === 'category' ? '分类' :
                     link.link_type === 'page' ? '页面' : '活动'}
                  </span>
                  {!link.is_active && (
                    <span className="px-2 py-0.5 text-xs bg-red-100 text-red-700 rounded-full">
                      已禁用
                    </span>
                  )}
                </div>

                {link.description && (
                  <p className="text-sm text-gray-600 mb-3">{link.description}</p>
                )}

                {link.product && (
                  <div className="flex items-center gap-2 mb-3 p-2 bg-gray-50 rounded">
                    {link.product.image_url && (
                      <img
                        src={link.product.image_url}
                        alt={link.product.name}
                        className="w-10 h-10 rounded object-cover"
                      />
                    )}
                    <div>
                      <div className="text-sm font-medium text-gray-900">{link.product.name}</div>
                      <div className="text-xs text-gray-500">关联商品</div>
                    </div>
                  </div>
                )}

                <div className="flex items-center gap-4 text-sm mb-3">
                  <div className="flex items-center gap-1">
                    <BarChart3 className="w-4 h-4 text-gray-400" />
                    <span className="font-semibold">{link.click_count || 0}</span>
                    <span className="text-gray-500">次点击</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <span className="font-semibold">{link.unique_click_count || 0}</span>
                    <span className="text-gray-500">独立访客</span>
                  </div>
                  {link.last_clicked_at && (
                    <div className="text-gray-500">
                      最后访问：{new Date(link.last_clicked_at).toLocaleString('zh-CN')}
                    </div>
                  )}
                </div>

                <div className="flex items-center gap-2 p-3 bg-gray-50 rounded">
                  <code className="flex-1 text-sm text-gray-700">{getShortUrl(link.short_code)}</code>
                  <button
                    onClick={() => copyToClipboard(link.short_code)}
                    className="p-1 text-gray-600 hover:text-blue-600"
                    title="复制链接"
                  >
                    <Copy className="w-4 h-4" />
                  </button>
                  <a
                    href={link.original_url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="p-1 text-gray-600 hover:text-blue-600"
                    title="打开原始链接"
                  >
                    <ExternalLink className="w-4 h-4" />
                  </a>
                </div>
              </div>

              <div className="flex gap-2 ml-4">
                <button
                  onClick={() => handleToggleActive(link.id, link.is_active)}
                  className={`p-2 rounded-lg ${
                    link.is_active
                      ? 'text-green-600 hover:bg-green-50'
                      : 'text-gray-400 hover:bg-gray-50'
                  }`}
                  title={link.is_active ? '禁用链接' : '启用链接'}
                >
                  {link.is_active ? <Eye className="w-5 h-5" /> : <EyeOff className="w-5 h-5" />}
                </button>
                <button
                  onClick={() => handleDelete(link.id)}
                  className="p-2 text-red-600 hover:bg-red-50 rounded-lg"
                  title="删除链接"
                >
                  <Trash2 className="w-5 h-5" />
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>

      {filteredLinks.length === 0 && (
        <div className="text-center py-12">
          <LinkIcon className="w-16 h-16 text-gray-300 mx-auto mb-4" />
          <p className="text-gray-500">
            {searchQuery || filterType !== 'all' ? '没有找到匹配的链接' : '还没有创建任何追踪链接'}
          </p>
        </div>
      )}

      <Modal
        isOpen={showAddModal}
        onClose={() => {
          setShowAddModal(false);
          resetForm();
        }}
        title="创建追踪链接"
      >
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              链接类型 *
            </label>
            <select
              value={formData.link_type}
              onChange={(e) => setFormData({ ...formData, link_type: e.target.value, product_id: null })}
              className="w-full px-3 py-2 border rounded-lg"
            >
              <option value="product">商品链接</option>
              <option value="category">分类链接</option>
              <option value="page">页面链接</option>
              <option value="external">外部链接</option>
              <option value="campaign">营销活动</option>
            </select>
          </div>

          {formData.link_type === 'product' && (
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                选择商品
              </label>
              <select
                value={formData.product_id || ''}
                onChange={(e) => setFormData({ ...formData, product_id: e.target.value || null })}
                className="w-full px-3 py-2 border rounded-lg"
              >
                <option value="">请选择商品</option>
                {products.map((product) => (
                  <option key={product.id} value={product.id}>
                    {product.name}
                  </option>
                ))}
              </select>
            </div>
          )}

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              原始URL *
            </label>
            <input
              type="url"
              value={formData.original_url}
              onChange={(e) => setFormData({ ...formData, original_url: e.target.value })}
              placeholder="https://example.com/page"
              className="w-full px-3 py-2 border rounded-lg"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              链接标题 *
            </label>
            <input
              type="text"
              value={formData.title}
              onChange={(e) => setFormData({ ...formData, title: e.target.value })}
              placeholder="描述这个链接的用途"
              className="w-full px-3 py-2 border rounded-lg"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              描述
            </label>
            <textarea
              value={formData.description}
              onChange={(e) => setFormData({ ...formData, description: e.target.value })}
              rows={2}
              className="w-full px-3 py-2 border rounded-lg"
            />
          </div>

          <div className="border-t pt-4">
            <h4 className="text-sm font-medium text-gray-700 mb-3">UTM参数（可选）</h4>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <input
                  type="text"
                  value={formData.utm_source}
                  onChange={(e) => setFormData({ ...formData, utm_source: e.target.value })}
                  placeholder="utm_source"
                  className="w-full px-3 py-2 border rounded-lg text-sm"
                />
              </div>
              <div>
                <input
                  type="text"
                  value={formData.utm_medium}
                  onChange={(e) => setFormData({ ...formData, utm_medium: e.target.value })}
                  placeholder="utm_medium"
                  className="w-full px-3 py-2 border rounded-lg text-sm"
                />
              </div>
              <div className="col-span-2">
                <input
                  type="text"
                  value={formData.utm_campaign}
                  onChange={(e) => setFormData({ ...formData, utm_campaign: e.target.value })}
                  placeholder="utm_campaign"
                  className="w-full px-3 py-2 border rounded-lg text-sm"
                />
              </div>
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              过期时间（可选）
            </label>
            <input
              type="datetime-local"
              value={formData.expires_at || ''}
              onChange={(e) => setFormData({ ...formData, expires_at: e.target.value || null })}
              className="w-full px-3 py-2 border rounded-lg"
            />
          </div>

          <div className="flex gap-2 pt-4">
            <button
              onClick={handleCreateLink}
              className="flex-1 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
            >
              创建链接
            </button>
            <button
              onClick={() => {
                setShowAddModal(false);
                resetForm();
              }}
              className="px-4 py-2 bg-gray-200 text-gray-700 rounded-lg hover:bg-gray-300"
            >
              取消
            </button>
          </div>
        </div>
      </Modal>
    </div>
  );
}
