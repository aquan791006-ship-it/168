import React from 'react';
import {
  Package,
  Warehouse,
  Truck,
  DollarSign,
  Gift,
  MessageSquare,
  TrendingUp,
  Megaphone,
  ShoppingBag,
  Users,
  Settings,
  CheckCircle
} from 'lucide-react';

export default function SystemModules() {
  const modules = [
    {
      category: '核心管理',
      items: [
        {
          name: '部门管理',
          icon: Users,
          description: '多级部门架构，支持分层权限管理',
          status: 'active',
          features: ['多级部门', '上下级关系', '权限继承', '内部/商家分类']
        },
        {
          name: '产品管理',
          icon: Package,
          description: '商品信息管理，支持多规格、多语言',
          status: 'active',
          features: ['多SKU', '多语言', '图片管理', '库存追踪']
        }
      ]
    },
    {
      category: '仓储物流',
      items: [
        {
          name: '仓储系统',
          icon: Warehouse,
          description: '完整的WMS系统，库位管理、出入库、库存预警',
          status: 'active',
          features: ['多仓库', '库位管理', '出入库单', '库存预警', '商家入仓']
        },
        {
          name: '物流系统',
          icon: Truck,
          description: '自建物流+第三方物流，路线规划、司机管理',
          status: 'active',
          features: ['自营物流', '司机管理', '车辆管理', '路线规划', '实时追踪']
        }
      ]
    },
    {
      category: '财务结算',
      items: [
        {
          name: '财务系统',
          icon: DollarSign,
          description: '全面的财务管理，账户、交易、结算、税务',
          status: 'active',
          features: ['账户管理', '交易记录', '商家服务费', '员工工资', '税务管理', '奖惩机制']
        }
      ]
    },
    {
      category: '营销推广',
      items: [
        {
          name: '一元购系统',
          icon: Gift,
          description: '抽奖营销系统，号码生成、自动开奖',
          status: 'active',
          features: ['商家申请', '超管审核', '号码分发', '即时开奖', '唯一性保证', '地区控制']
        },
        {
          name: '推广系统',
          icon: Megaphone,
          description: '多渠道推广管理，效果追踪',
          status: 'active',
          features: ['推广渠道', '活动管理', '素材管理', '效果追踪', '转化分析']
        }
      ]
    },
    {
      category: '客户服务',
      items: [
        {
          name: '客服系统',
          icon: MessageSquare,
          description: '在线客服，工单管理，快捷回复',
          status: 'active',
          features: ['实时会话', '工单系统', '快捷回复', '客服评价', '多渠道接入']
        }
      ]
    },
    {
      category: '智能系统',
      items: [
        {
          name: '智能算法',
          icon: TrendingUp,
          description: '商品排名算法，用户推荐系统',
          status: 'active',
          features: ['评分系统', '排名算法', '用户偏好', '智能推荐', '自动排序']
        }
      ]
    },
    {
      category: '采购系统',
      items: [
        {
          name: '采购管理',
          icon: ShoppingBag,
          description: '供应商管理，采购单，自动调价上架',
          status: 'active',
          features: ['供应商管理', '采购单', '1688对接', '自动调价', '自动上架']
        }
      ]
    }
  ];

  return (
    <div className="space-y-6">
      <div className="bg-gradient-to-r from-blue-500 to-cyan-600 rounded-2xl p-8 text-white shadow-xl">
        <h1 className="text-3xl font-black mb-2">168全球购 ERP系统</h1>
        <p className="text-blue-50 text-lg">企业级全功能电商运营管理平台</p>
        <div className="mt-6 grid grid-cols-2 md:grid-cols-4 gap-4">
          <div className="bg-white/10 backdrop-blur-sm rounded-lg p-4">
            <div className="text-3xl font-black">{modules.reduce((acc, cat) => acc + cat.items.length, 0)}</div>
            <div className="text-sm text-blue-100">核心模块</div>
          </div>
          <div className="bg-white/10 backdrop-blur-sm rounded-lg p-4">
            <div className="text-3xl font-black">50+</div>
            <div className="text-sm text-blue-100">数据表</div>
          </div>
          <div className="bg-white/10 backdrop-blur-sm rounded-lg p-4">
            <div className="text-3xl font-black">100+</div>
            <div className="text-sm text-blue-100">功能特性</div>
          </div>
          <div className="bg-white/10 backdrop-blur-sm rounded-lg p-4">
            <div className="text-3xl font-black">∞</div>
            <div className="text-sm text-blue-100">扩展能力</div>
          </div>
        </div>
      </div>

      {modules.map((category, idx) => (
        <div key={idx} className="bg-white rounded-2xl shadow-md p-6">
          <h2 className="text-xl font-bold text-gray-900 mb-4 flex items-center gap-2">
            <div className="w-1 h-6 bg-gradient-to-b from-blue-500 to-cyan-600 rounded-full"></div>
            {category.category}
          </h2>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {category.items.map((module, moduleIdx) => (
              <div
                key={moduleIdx}
                className="border border-gray-200 rounded-xl p-5 hover:shadow-lg hover:border-blue-300 transition-all duration-200 group"
              >
                <div className="flex items-start gap-4">
                  <div className="flex-shrink-0">
                    <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-cyan-600 rounded-xl flex items-center justify-center group-hover:scale-110 transition-transform duration-200">
                      <module.icon className="w-6 h-6 text-white" />
                    </div>
                  </div>

                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-2">
                      <h3 className="font-bold text-gray-900">{module.name}</h3>
                      {module.status === 'active' && (
                        <CheckCircle className="w-4 h-4 text-green-500" />
                      )}
                    </div>

                    <p className="text-sm text-gray-600 mb-3">{module.description}</p>

                    <div className="flex flex-wrap gap-2">
                      {module.features.map((feature, featureIdx) => (
                        <span
                          key={featureIdx}
                          className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-50 text-blue-700 border border-blue-200"
                        >
                          {feature}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      ))}

      <div className="bg-gradient-to-r from-amber-500 to-orange-600 rounded-2xl p-6 text-white">
        <h3 className="text-xl font-bold mb-3">系统特性</h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="bg-white/10 backdrop-blur-sm rounded-lg p-4">
            <Settings className="w-8 h-8 mb-2" />
            <h4 className="font-bold mb-1">高度集成</h4>
            <p className="text-sm text-amber-50">所有模块深度融合，数据实时同步</p>
          </div>
          <div className="bg-white/10 backdrop-blur-sm rounded-lg p-4">
            <TrendingUp className="w-8 h-8 mb-2" />
            <h4 className="font-bold mb-1">智能自动化</h4>
            <p className="text-sm text-amber-50">智能算法驱动，自动化流程优化</p>
          </div>
          <div className="bg-white/10 backdrop-blur-sm rounded-lg p-4">
            <CheckCircle className="w-8 h-8 mb-2" />
            <h4 className="font-bold mb-1">安全可靠</h4>
            <p className="text-sm text-amber-50">完整的权限控制，数据安全保障</p>
          </div>
        </div>
      </div>
    </div>
  );
}
