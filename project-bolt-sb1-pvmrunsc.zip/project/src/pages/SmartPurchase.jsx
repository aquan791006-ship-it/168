import { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import { useToast } from '../contexts/ToastContext';
import { ShoppingCart, Plus, RefreshCw, CheckCircle, XCircle, Clock, Package, TrendingUp } from 'lucide-react';
import Modal from '../components/Modal';

export default function SmartPurchase() {
  const [supplierProducts, setSupplierProducts] = useState([]);
  const [suppliers, setSuppliers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showAddModal, setShowAddModal] = useState(false);
  const [formData, setFormData] = useState({
    supplier_id: '',
    product_link: '',
    cost_price: '',
    markup_percentage: 50
  });
  const { showToast } = useToast();

  useEffect(() => {
    loadData();

    const channel = supabase
      .channel('supplier_products_changes')
      .on('postgres_changes', {
        event: '*',
        schema: 'public',
        table: 'pur_supplier_products'
      }, () => {
        loadSupplierProducts();
      })
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, []);

  const loadData = async () => {
    await Promise.all([loadSuppliers(), loadSupplierProducts()]);
  };

  const loadSuppliers = async () => {
    try {
      const { data, error } = await supabase
        .from('pur_suppliers')
        .select('id, name, code')
        .eq('cooperation_status', 'active')
        .order('name');

      if (error) throw error;
      setSuppliers(data || []);
    } catch (error) {
      showToast('加载供应商失败: ' + error.message, 'error');
    }
  };

  const loadSupplierProducts = async () => {
    try {
      setLoading(true);
      const { data, error } = await supabase
        .from('pur_supplier_products')
        .select(`
          *,
          supplier:pur_suppliers(name, code)
        `)
        .order('created_at', { ascending: false });

      if (error) throw error;
      setSupplierProducts(data || []);
    } catch (error) {
      showToast('加载商品失败: ' + error.message, 'error');
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!formData.supplier_id || !formData.product_link || !formData.cost_price) {
      showToast('请填写所有必填项', 'warning');
      return;
    }

    try {
      const { data: { user } } = await supabase.auth.getUser();

      const { error } = await supabase
        .from('pur_supplier_products')
        .insert({
          supplier_id: formData.supplier_id,
          product_link: formData.product_link,
          cost_price: parseFloat(formData.cost_price),
          markup_percentage: parseFloat(formData.markup_percentage),
          scrape_status: 'pending',
          created_by: user?.id
        });

      if (error) throw error;

      showToast('商品已添加到抓取队列，系统将自动抓取商品信息', 'success');
      setShowAddModal(false);
      setFormData({
        supplier_id: '',
        product_link: '',
        cost_price: '',
        markup_percentage: 50
      });
      loadSupplierProducts();
    } catch (error) {
      showToast('添加失败: ' + error.message, 'error');
    }
  };

  const handleAutoList = async (supplierProduct) => {
    try {
      const { data, error } = await supabase.rpc('auto_list_product', {
        p_supplier_product_id: supplierProduct.id,
        p_initial_stock: 100
      });

      if (error) throw error;

      showToast('商品已自动上架成功', 'success');
      loadSupplierProducts();
    } catch (error) {
      showToast('自动上架失败: ' + error.message, 'error');
    }
  };

  const getStatusIcon = (status) => {
    switch (status) {
      case 'success':
        return <CheckCircle className="w-5 h-5 text-green-500" />;
      case 'failed':
        return <XCircle className="w-5 h-5 text-red-500" />;
      case 'processing':
        return <RefreshCw className="w-5 h-5 text-blue-500 animate-spin" />;
      default:
        return <Clock className="w-5 h-5 text-gray-400" />;
    }
  };

  const getStatusText = (status) => {
    const statusMap = {
      'pending': '等待抓取',
      'processing': '抓取中',
      'success': '抓取成功',
      'failed': '抓取失败'
    };
    return statusMap[status] || status;
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-gray-500">加载中...</div>
      </div>
    );
  }

  return (
    <div className="p-6">
      <div className="mb-6 flex items-center justify-between">
        <div>
          <div className="flex items-center gap-2 mb-2">
            <ShoppingCart className="w-6 h-6 text-blue-600" />
            <h1 className="text-2xl font-bold text-gray-900">智能采购模块管理</h1>
          </div>
          <p className="text-gray-600">
            添加供应商商品链接，系统自动抓取信息、计算售价、采购入库后自动上架
          </p>
        </div>
        <button
          onClick={() => setShowAddModal(true)}
          className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
        >
          <Plus className="w-5 h-5" />
          添加供应商商品
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
        <div className="bg-white rounded-lg shadow p-6">
          <div className="flex items-center justify-between">
            <div>
              <div className="text-gray-500 text-sm">总商品数</div>
              <div className="text-2xl font-bold text-gray-900 mt-1">
                {supplierProducts.length}
              </div>
            </div>
            <Package className="w-10 h-10 text-blue-500 opacity-20" />
          </div>
        </div>
        <div className="bg-white rounded-lg shadow p-6">
          <div className="flex items-center justify-between">
            <div>
              <div className="text-gray-500 text-sm">已上架</div>
              <div className="text-2xl font-bold text-green-600 mt-1">
                {supplierProducts.filter(p => p.is_listed).length}
              </div>
            </div>
            <CheckCircle className="w-10 h-10 text-green-500 opacity-20" />
          </div>
        </div>
        <div className="bg-white rounded-lg shadow p-6">
          <div className="flex items-center justify-between">
            <div>
              <div className="text-gray-500 text-sm">抓取中</div>
              <div className="text-2xl font-bold text-blue-600 mt-1">
                {supplierProducts.filter(p => p.scrape_status === 'processing' || p.scrape_status === 'pending').length}
              </div>
            </div>
            <RefreshCw className="w-10 h-10 text-blue-500 opacity-20" />
          </div>
        </div>
      </div>

      <div className="bg-white rounded-lg shadow overflow-hidden">
        <table className="min-w-full divide-y divide-gray-200">
          <thead className="bg-gray-50">
            <tr>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                供应商
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                商品链接
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                商品信息
              </th>
              <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                成本价
              </th>
              <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                加价%
              </th>
              <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                售价
              </th>
              <th className="px-6 py-3 text-center text-xs font-medium text-gray-500 uppercase tracking-wider">
                抓取状态
              </th>
              <th className="px-6 py-3 text-center text-xs font-medium text-gray-500 uppercase tracking-wider">
                操作
              </th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {supplierProducts.map((product) => (
              <tr key={product.id} className="hover:bg-gray-50">
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="text-sm font-medium text-gray-900">
                    {product.supplier?.name}
                  </div>
                  <div className="text-xs text-gray-500">
                    {product.supplier?.code}
                  </div>
                </td>
                <td className="px-6 py-4">
                  <a
                    href={product.product_link}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-sm text-blue-600 hover:underline max-w-xs truncate block"
                    title={product.product_link}
                  >
                    {product.product_link}
                  </a>
                </td>
                <td className="px-6 py-4">
                  {product.scraped_title ? (
                    <div>
                      <div className="text-sm font-medium text-gray-900 line-clamp-2">
                        {product.scraped_title}
                      </div>
                      {product.scraped_images && product.scraped_images.length > 0 && (
                        <div className="text-xs text-gray-500 mt-1">
                          {product.scraped_images.length} 张图片
                        </div>
                      )}
                    </div>
                  ) : (
                    <div className="text-sm text-gray-400">等待抓取</div>
                  )}
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-right text-sm text-gray-900">
                  ¥{product.cost_price?.toFixed(2)}
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-right">
                  <span className="inline-flex items-center gap-1 text-sm text-gray-900">
                    <TrendingUp className="w-4 h-4 text-green-500" />
                    {product.markup_percentage}%
                  </span>
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium text-blue-600">
                  ¥{product.selling_price?.toFixed(2)}
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-center">
                  <div className="flex items-center justify-center gap-2">
                    {getStatusIcon(product.scrape_status)}
                    <span className="text-sm text-gray-700">
                      {getStatusText(product.scrape_status)}
                    </span>
                  </div>
                  {product.scrape_status === 'failed' && product.scrape_error && (
                    <div className="text-xs text-red-600 mt-1" title={product.scrape_error}>
                      {product.scrape_error.substring(0, 50)}...
                    </div>
                  )}
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-center text-sm">
                  {product.is_listed ? (
                    <span className="inline-flex items-center gap-1 px-3 py-1 rounded-full text-xs font-medium bg-green-100 text-green-800">
                      <CheckCircle className="w-3 h-3" />
                      已上架
                    </span>
                  ) : product.scrape_status === 'success' ? (
                    <button
                      onClick={() => handleAutoList(product)}
                      className="px-3 py-1 bg-blue-600 text-white rounded-lg hover:bg-blue-700 text-xs transition-colors"
                    >
                      一键上架
                    </button>
                  ) : (
                    <span className="text-gray-400 text-xs">-</span>
                  )}
                </td>
              </tr>
            ))}
            {supplierProducts.length === 0 && (
              <tr>
                <td colSpan="8" className="px-6 py-12 text-center text-gray-500">
                  暂无供应商商品，点击右上角"添加供应商商品"开始使用
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      <Modal
        isOpen={showAddModal}
        onClose={() => setShowAddModal(false)}
        title="添加供应商商品"
      >
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              选择供应商 <span className="text-red-500">*</span>
            </label>
            <select
              value={formData.supplier_id}
              onChange={(e) => setFormData({ ...formData, supplier_id: e.target.value })}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              required
            >
              <option value="">请选择供应商</option>
              {suppliers.map((supplier) => (
                <option key={supplier.id} value={supplier.id}>
                  {supplier.name} ({supplier.code})
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              商品链接 <span className="text-red-500">*</span>
            </label>
            <input
              type="url"
              value={formData.product_link}
              onChange={(e) => setFormData({ ...formData, product_link: e.target.value })}
              placeholder="https://detail.1688.com/..."
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              required
            />
            <p className="text-xs text-gray-500 mt-1">
              支持1688、淘宝等供应商平台链接
            </p>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                成本价 (¥) <span className="text-red-500">*</span>
              </label>
              <input
                type="number"
                step="0.01"
                min="0"
                value={formData.cost_price}
                onChange={(e) => setFormData({ ...formData, cost_price: e.target.value })}
                placeholder="0.00"
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                required
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                加价百分比 (%)
              </label>
              <input
                type="number"
                step="0.1"
                min="0"
                value={formData.markup_percentage}
                onChange={(e) => setFormData({ ...formData, markup_percentage: e.target.value })}
                placeholder="50"
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
              <p className="text-xs text-gray-500 mt-1">
                自动计算售价 = 成本价 × (1 + {formData.markup_percentage || 0}%)
              </p>
            </div>
          </div>

          {formData.cost_price && (
            <div className="bg-blue-50 border border-blue-200 rounded-lg p-3">
              <div className="text-sm text-blue-900">
                预计售价: <span className="font-bold text-lg">
                  ¥{(parseFloat(formData.cost_price || 0) * (1 + parseFloat(formData.markup_percentage || 0) / 100)).toFixed(2)}
                </span>
              </div>
            </div>
          )}

          <div className="flex gap-3 pt-4">
            <button
              type="button"
              onClick={() => setShowAddModal(false)}
              className="flex-1 px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors"
            >
              取消
            </button>
            <button
              type="submit"
              className="flex-1 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
            >
              添加并抓取
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
}
