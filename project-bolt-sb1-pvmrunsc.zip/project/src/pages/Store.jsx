import React, { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import { ShoppingCart, Search, Filter, Star, TrendingUp, CheckCircle, Sparkles, Award, ShoppingBag, Package } from 'lucide-react';
import Logo, { LogoBrand } from '../components/Logo';
import CheckoutForm from '../components/CheckoutForm';
import AnnouncementPopup from '../components/AnnouncementPopup';
import { useToast } from '../contexts/ToastContext';

export default function Store() {
  const { success, error: showError } = useToast();
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [categories, setCategories] = useState([]);
  const [storeConfig, setStoreConfig] = useState(null);
  const [showCheckoutForm, setShowCheckoutForm] = useState(false);
  const [selectedProduct, setSelectedProduct] = useState(null);
  const [domainId, setDomainId] = useState(null);

  useEffect(() => {
    fetchStoreConfig();
    fetchProducts();
  }, []);

  const fetchStoreConfig = async () => {
    try {
      const { data: domainData } = await supabase
        .from('sys_domains')
        .select('id')
        .limit(1)
        .maybeSingle();

      if (domainData) {
        setDomainId(domainData.id);

        const { data: configData } = await supabase
          .from('store_configs')
          .select('*')
          .eq('domain_id', domainData.id)
          .maybeSingle();

        if (configData) {
          setStoreConfig(configData);
        }
      }
    } catch (error) {
      console.error('Error fetching store config:', error);
    }
  };

  const fetchProducts = async () => {
    try {
      setLoading(true);

      const { data: productsData, error } = await supabase
        .from('sys_products')
        .select(`
          id,
          title,
          description,
          base_price,
          compare_price,
          currency_code,
          category,
          tags,
          views_count,
          orders_count,
          sys_product_images!inner(
            original_url,
            is_primary
          )
        `)
        .eq('status', 'active')
        .order('created_at', { ascending: false });

      if (error) throw error;

      const processedProducts = productsData.map(product => ({
        ...product,
        primaryImage: product.sys_product_images.find(img => img.is_primary)?.original_url
                      || product.sys_product_images[0]?.original_url
                      || 'https://images.pexels.com/photos/230544/pexels-photo-230544.jpeg',
        titleText: typeof product.title === 'object'
                   ? (product.title.zh || product.title.en || Object.values(product.title)[0])
                   : product.title,
        descriptionText: typeof product.description === 'object'
                        ? (product.description.zh || product.description.en || Object.values(product.description)[0])
                        : product.description
      }));

      setProducts(processedProducts);

      const uniqueCategories = [...new Set(productsData
        .map(p => p.category)
        .filter(Boolean))];
      setCategories(uniqueCategories);

    } catch (error) {
      console.error('Error fetching products:', error);
    } finally {
      setLoading(false);
    }
  };

  const filteredProducts = products.filter(product => {
    const matchesSearch = !searchQuery ||
      product.titleText?.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = selectedCategory === 'all' ||
      product.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  const formatPrice = (price, currency = 'CNY') => {
    const symbols = { CNY: '¥', USD: '$', EUR: '€' };
    return `${symbols[currency] || ''}${parseFloat(price).toFixed(2)}`;
  };

  const handleBuyNow = (product) => {
    setSelectedProduct(product);
    setShowCheckoutForm(true);
  };

  const handleOrderSuccess = (order) => {
    success('订单提交成功！我们会尽快为您处理');
    setShowCheckoutForm(false);
    setSelectedProduct(null);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50/30 to-slate-100">
      <header className="sticky top-0 z-50 frosted-glass border-b border-slate-200/50 shadow-xl">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16 md:h-20">
            <div className="flex items-center gap-4 md:gap-5">
              {storeConfig?.store_logo_url ? (
                <div className="relative group">
                  <div className="absolute inset-0 bg-gradient-to-br from-blue-500/20 to-cyan-500/20 rounded-xl blur-lg opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                  <img
                    src={storeConfig.store_logo_url}
                    alt="Logo"
                    className="relative h-12 md:h-14 object-contain transition-transform duration-300 group-hover:scale-105"
                    onError={(e) => {
                      e.target.style.display = 'none';
                    }}
                  />
                </div>
              ) : (
                <Logo size="md" showText={false} />
              )}
              <div>
                <h1 className="text-xl md:text-2xl font-black tracking-tight">
                  <span className="bg-gradient-to-r from-slate-800 via-blue-900 to-slate-900 bg-clip-text text-transparent">
                    {storeConfig?.store_name?.zh || '168全球购'}
                  </span>
                </h1>
                <p className="text-xs text-slate-600 font-semibold hidden sm:flex items-center gap-1.5 mt-0.5">
                  <Sparkles className="w-3 h-3 text-amber-500" />
                  {storeConfig?.site_subtitle?.zh || '全球精选好物 · 货到付款'}
                </p>
              </div>
            </div>

            <div className="flex items-center gap-3 md:gap-4">
              <div className="relative hidden sm:block group">
                <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400 group-focus-within:text-blue-500 transition-colors" />
                <input
                  type="text"
                  placeholder="搜索商品..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10 pr-4 py-2.5 w-56 md:w-72 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500/30 focus:border-blue-500 focus:bg-white outline-none text-sm transition-all duration-200 hover:border-slate-300"
                />
              </div>
              <button className="sm:hidden p-2.5 rounded-xl hover:bg-blue-50 transition-all duration-200 active:scale-95">
                <Search className="w-5 h-5 text-slate-600" />
              </button>
            </div>
          </div>

          <div className="sm:hidden pb-3">
            <div className="relative group">
              <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400 group-focus-within:text-blue-500 transition-colors" />
              <input
                type="text"
                placeholder="搜索商品..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-10 pr-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500/30 focus:border-blue-500 focus:bg-white outline-none text-sm transition-all"
              />
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 md:py-12">
        {categories.length > 0 && (
          <div className="mb-8 md:mb-12 frosted-glass rounded-2xl p-5 md:p-6 border border-slate-200/50 shadow-lg animate-slide-up">
            <div className="flex items-center gap-3 mb-5">
              <div className="p-2 bg-blue-500/10 rounded-lg">
                <Filter className="w-5 h-5 text-blue-600" />
              </div>
              <span className="text-base font-bold text-slate-800">商品分类</span>
            </div>
            <div className="flex items-center gap-2.5 md:gap-3 flex-wrap">
              <button
                onClick={() => setSelectedCategory('all')}
                className={`px-5 md:px-6 py-2.5 md:py-3 rounded-xl text-sm font-bold transition-all duration-300 button-hover ${
                  selectedCategory === 'all'
                    ? 'bg-gradient-to-r from-blue-600 to-cyan-600 text-white shadow-lg shadow-blue-500/30 scale-105'
                    : 'bg-white text-slate-700 border border-slate-200 hover:border-blue-500 hover:bg-blue-50 active:scale-95'
                }`}
              >
                全部商品
              </button>
              {categories.map(category => (
                <button
                  key={category}
                  onClick={() => setSelectedCategory(category)}
                  className={`px-5 md:px-6 py-2.5 md:py-3 rounded-xl text-sm font-bold transition-all duration-300 button-hover ${
                    selectedCategory === category
                      ? 'bg-gradient-to-r from-blue-600 to-cyan-600 text-white shadow-lg shadow-blue-500/30 scale-105'
                      : 'bg-white text-slate-700 border border-slate-200 hover:border-blue-500 hover:bg-blue-50 active:scale-95'
                  }`}
                >
                  {category}
                </button>
              ))}
            </div>
          </div>
        )}

        {loading ? (
          <div className="flex flex-col items-center justify-center py-24 animate-fade-in">
            <div className="relative">
              <div className="animate-spin rounded-full h-20 w-20 border-4 border-slate-200"></div>
              <div className="animate-spin rounded-full h-20 w-20 border-4 border-blue-600 border-t-transparent absolute top-0"></div>
              <Package className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-8 h-8 text-blue-600 animate-pulse" />
            </div>
            <p className="mt-6 text-slate-600 font-semibold text-lg">正在加载精选商品...</p>
          </div>
        ) : filteredProducts.length === 0 ? (
          <div className="text-center py-24 frosted-glass rounded-2xl border border-slate-200 shadow-lg animate-scale-in">
            <div className="text-slate-300 mb-4">
              <ShoppingCart className="w-20 h-20 mx-auto" strokeWidth={1.5} />
            </div>
            <p className="text-slate-700 text-xl font-bold mb-2">暂无商品</p>
            <p className="text-slate-500 text-sm">请稍后再来查看</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-5 md:gap-6">
            {filteredProducts.map((product, index) => (
              <div
                key={product.id}
                className="group bg-white rounded-2xl shadow-md hover:shadow-2xl transition-all duration-500 overflow-hidden border border-slate-200/60 hover:border-blue-300 card-hover animate-slide-up"
                style={{ animationDelay: `${index * 40}ms` }}
              >
                <div className="relative aspect-square overflow-hidden bg-slate-100">
                  <img
                    src={product.primaryImage}
                    alt={product.titleText}
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
                    onError={(e) => {
                      e.target.src = 'https://images.pexels.com/photos/230544/pexels-photo-230544.jpeg';
                    }}
                  />

                  <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>

                  {product.compare_price && product.compare_price > product.base_price && (
                    <div className="absolute top-3 left-3 bg-gradient-to-r from-red-500 to-rose-600 text-white px-3 py-1.5 rounded-full text-xs font-bold shadow-lg flex items-center gap-1 animate-bounce-subtle">
                      <Sparkles className="w-3 h-3" />
                      省 {formatPrice(product.compare_price - product.base_price, product.currency_code)}
                    </div>
                  )}

                  {product.orders_count > 50 && (
                    <div className="absolute top-3 right-3 bg-gradient-to-r from-amber-500 to-orange-600 text-white px-3 py-1.5 rounded-full text-xs font-bold shadow-lg flex items-center gap-1">
                      <TrendingUp className="w-3.5 h-3.5" />
                      热销
                    </div>
                  )}
                </div>

                <div className="p-5">
                  <h3 className="font-bold text-slate-900 line-clamp-2 mb-2 group-hover:text-blue-600 transition-colors duration-300 leading-snug">
                    {product.titleText}
                  </h3>

                  {product.descriptionText && (
                    <p className="text-sm text-slate-500 line-clamp-2 mb-4 leading-relaxed">
                      {product.descriptionText}
                    </p>
                  )}

                  <div className="flex items-baseline gap-2.5 mb-4">
                    <span className="text-3xl font-black bg-gradient-to-r from-red-600 to-rose-600 bg-clip-text text-transparent">
                      {formatPrice(product.base_price, product.currency_code)}
                    </span>
                    {product.compare_price && product.compare_price > product.base_price && (
                      <span className="text-sm text-slate-400 line-through font-medium">
                        {formatPrice(product.compare_price, product.currency_code)}
                      </span>
                    )}
                  </div>

                  <div className="flex items-center justify-between text-xs text-slate-500 mb-5 pb-4 border-b border-slate-100">
                    <span className="flex items-center gap-1.5 font-medium">
                      <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
                      {product.views_count || 0} 浏览
                    </span>
                    <span className="flex items-center gap-1.5 font-medium">
                      <CheckCircle className="w-3.5 h-3.5 text-green-500" />
                      {product.orders_count || 0} 已售
                    </span>
                  </div>

                  <button
                    onClick={() => handleBuyNow(product)}
                    className="w-full bg-gradient-to-r from-blue-600 via-blue-500 to-cyan-600 text-white py-3.5 rounded-xl font-bold hover:from-blue-700 hover:via-blue-600 hover:to-cyan-700 transition-all shadow-md hover:shadow-xl hover:shadow-blue-500/30 active:scale-95 flex items-center justify-center gap-2.5 group-hover:scale-105 button-hover"
                  >
                    <ShoppingBag className="w-5 h-5" strokeWidth={2.5} />
                    <span className="tracking-tight">立即购买</span>
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      <footer className="relative bg-gradient-to-br from-slate-900 via-slate-900 to-blue-950 text-slate-400 py-12 md:py-16 mt-20 border-t border-slate-800/50 overflow-hidden">
        <div className="absolute inset-0 bg-dots-pattern opacity-5"></div>

        <div className="absolute top-0 left-1/4 w-96 h-96 bg-blue-500/5 rounded-full blur-3xl"></div>
        <div className="absolute bottom-0 right-1/4 w-96 h-96 bg-cyan-500/5 rounded-full blur-3xl"></div>

        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col items-center">
            <div className="mb-8">
              <Logo size="md" showText={true} />
            </div>

            <div className="mt-6 flex flex-wrap items-center justify-center gap-2 text-sm">
              <span className="text-slate-400 font-medium">
                {storeConfig?.footer_text?.zh || '© 2026 168全球购 All rights reserved'}
              </span>
              <span className="text-slate-600">·</span>
              <span className="bg-gradient-to-r from-blue-400 to-cyan-400 bg-clip-text text-transparent font-bold">
                {storeConfig?.site_subtitle?.zh || '全球精选好物'}
              </span>
            </div>

            <div className="mt-5 flex flex-wrap items-center justify-center gap-4 md:gap-6 text-xs">
              <div className="flex items-center gap-2 text-slate-500 font-medium">
                <div className="relative">
                  <div className="w-2 h-2 rounded-full bg-blue-500 animate-pulse"></div>
                  <div className="absolute inset-0 w-2 h-2 rounded-full bg-blue-400 animate-ping"></div>
                </div>
                <span>货到付款</span>
              </div>
              <div className="w-1 h-1 rounded-full bg-slate-600"></div>
              <div className="flex items-center gap-2 text-slate-500 font-medium">
                <CheckCircle className="w-3.5 h-3.5 text-green-500" />
                <span>安全可靠</span>
              </div>
              <div className="w-1 h-1 rounded-full bg-slate-600"></div>
              <div className="flex items-center gap-2 text-slate-500 font-medium">
                <Award className="w-3.5 h-3.5 text-amber-500" />
                <span>品质保证</span>
              </div>
            </div>
          </div>
        </div>
      </footer>

      {showCheckoutForm && selectedProduct && (
        <CheckoutForm
          product={selectedProduct}
          onClose={() => {
            setShowCheckoutForm(false);
            setSelectedProduct(null);
          }}
          onSuccess={handleOrderSuccess}
        />
      )}

      {domainId && (
        <AnnouncementPopup domainId={domainId} viewerType="customer" />
      )}
    </div>
  );
}
