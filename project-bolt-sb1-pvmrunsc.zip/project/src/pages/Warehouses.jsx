import React, { useEffect, useState } from 'react';
import { supabase } from '../lib/supabase';
import {
  Warehouse,
  MapPin,
  Package,
  AlertTriangle,
  TrendingUp,
  RefreshCw,
  CheckCircle,
  XCircle,
  Clock,
  Zap,
  BarChart3,
  Plus,
  Edit,
  Inbox,
  Send
} from 'lucide-react';

export default function Warehouses() {
  const [warehouses, setWarehouses] = useState([]);
  const [inventory, setInventory] = useState([]);
  const [alerts, setAlerts] = useState([]);
  const [inboundOrders, setInboundOrders] = useState([]);
  const [outboundOrders, setOutboundOrders] = useState([]);
  const [loading, setLoading] = useState(true);
  const [autoRefresh, setAutoRefresh] = useState(true);

  useEffect(() => {
    loadAllData();

    if (autoRefresh) {
      const interval = setInterval(loadAllData, 30000);
      return () => clearInterval(interval);
    }
  }, [autoRefresh]);

  const loadAllData = async () => {
    try {
      const [
        warehousesRes,
        inventoryRes,
        alertsRes,
        inboundRes,
        outboundRes
      ] = await Promise.all([
        supabase.from('wms_warehouses').select('*').order('created_at', { ascending: false }),
        supabase.from('wms_inventory').select(`
          *,
          warehouse:wms_warehouses(name),
          product:sys_products(title)
        `).order('created_at', { ascending: false }).limit(20),
        supabase.from('wms_stock_alerts').select(`
          *,
          inventory:wms_inventory(
            id,
            product:sys_products(title)
          )
        `).eq('status', 'active').order('created_at', { ascending: false }).limit(10),
        supabase.from('wms_inbound').select('*').order('created_at', { ascending: false }).limit(5),
        supabase.from('wms_outbound').select('*').order('created_at', { ascending: false}).limit(5)
      ]);

      if (warehousesRes.data) setWarehouses(warehousesRes.data);
      if (inventoryRes.data) setInventory(inventoryRes.data);
      if (alertsRes.data) setAlerts(alertsRes.data);
      if (inboundRes.data) setInboundOrders(inboundRes.data);
      if (outboundRes.data) setOutboundOrders(outboundRes.data);
    } catch (error) {
      console.error('Error loading data:', error);
    } finally {
      setLoading(false);
    }
  };

  const resolveAlert = async (alertId) => {
    try {
      await supabase
        .from('wms_stock_alerts')
        .update({
          status: 'resolved',
          resolved_at: new Date().toISOString()
        })
        .eq('id', alertId);
      await loadAllData();
    } catch (error) {
      console.error('Error resolving alert:', error);
    }
  };

  const getSeverityColor = (priority) => {
    const colors = {
      critical: 'bg-red-100 border-red-300 text-red-800',
      high: 'bg-orange-100 border-orange-300 text-orange-800',
      medium: 'bg-yellow-100 border-yellow-300 text-yellow-800',
      low: 'bg-blue-100 border-blue-300 text-blue-800'
    };
    return colors[priority] || colors.medium;
  };

  const getStatusColor = (status) => {
    const colors = {
      active: 'bg-green-100 text-green-700 border border-green-200',
      inactive: 'bg-gray-100 text-gray-700 border border-gray-200',
      maintenance: 'bg-amber-100 text-amber-700 border border-amber-200',
      pending: 'bg-blue-100 text-blue-700 border border-blue-200',
      in_progress: 'bg-cyan-100 text-cyan-700 border border-cyan-200',
      completed: 'bg-emerald-100 text-emerald-700 border border-emerald-200',
      cancelled: 'bg-rose-100 text-rose-700 border border-rose-200'
    };
    return colors[status] || colors.pending;
  };

  const getStatusText = (status) => {
    const texts = {
      active: '运营中',
      inactive: '未激活',
      maintenance: '维护中',
      pending: '待处理',
      in_progress: '进行中',
      completed: '已完成',
      cancelled: '已取消',
      picking: '拣货中',
      picked: '已拣货',
      packed: '已打包',
      shipped: '已发货'
    };
    return texts[status] || status;
  };

  const getAlertTypeText = (type) => {
    const texts = {
      low_stock: '库存不足',
      out_of_stock: '已缺货',
      overstock: '库存过多',
      expired: '即将过期'
    };
    return texts[type] || type;
  };

  const totalInventory = inventory.reduce((sum, item) => sum + (item.quantity || 0), 0);
  const lowStockCount = inventory.filter(item => item.quantity <= item.alert_threshold).length;
  const totalInbound = inboundOrders.filter(o => o.status === 'pending' || o.status === 'in_progress').length;
  const totalOutbound = outboundOrders.filter(o => o.status === 'pending' || o.status === 'picking').length;

  if (loading) {
    return (
      <div className="flex flex-col items-center justify-center h-96 gap-4">
        <div className="relative">
          <div className="animate-spin rounded-full h-16 w-16 border-4 border-blue-200"></div>
          <div className="animate-spin rounded-full h-16 w-16 border-4 border-blue-600 border-t-transparent absolute top-0 left-0"></div>
        </div>
        <p className="text-gray-600 animate-pulse">加载仓储数据中...</p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-black bg-gradient-to-r from-gray-900 via-blue-800 to-cyan-700 bg-clip-text text-transparent">
            智能仓储管理系统
          </h1>
          <p className="text-gray-600 mt-2 flex items-center gap-2">
            <Zap className="w-4 h-4 text-blue-600" />
            实时库存监控 · 智能预警 · 自动化流程
          </p>
        </div>
        <div className="flex items-center gap-3">
          <button
            onClick={() => setAutoRefresh(!autoRefresh)}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl font-medium transition-all ${
              autoRefresh
                ? 'bg-blue-50 text-blue-600 border-2 border-blue-200 shadow-sm'
                : 'bg-gray-100 text-gray-600 border-2 border-gray-200'
            }`}
          >
            <RefreshCw className={`w-4 h-4 ${autoRefresh ? 'animate-spin' : ''}`} />
            <span className="text-sm">自动刷新</span>
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-6">
        <div className="group bg-white rounded-2xl border-2 border-gray-200 p-6 hover:shadow-xl transition-all duration-300">
          <div className="flex items-center justify-between mb-4">
            <div className="p-3 bg-gradient-to-br from-blue-500 to-cyan-600 rounded-xl shadow-lg">
              <Warehouse className="w-6 h-6 text-white" />
            </div>
            <div className="text-right">
              <p className="text-3xl font-black text-gray-900">{warehouses.length}</p>
              <p className="text-sm text-gray-600 mt-1">活跃仓库</p>
            </div>
          </div>
          <div className="h-1 w-full bg-gradient-to-r from-blue-200 to-cyan-200 rounded-full"></div>
        </div>

        <div className="group bg-white rounded-2xl border-2 border-gray-200 p-6 hover:shadow-xl transition-all duration-300">
          <div className="flex items-center justify-between mb-4">
            <div className="p-3 bg-gradient-to-br from-emerald-500 to-teal-600 rounded-xl shadow-lg">
              <Package className="w-6 h-6 text-white" />
            </div>
            <div className="text-right">
              <p className="text-3xl font-black text-gray-900">{totalInventory.toLocaleString()}</p>
              <p className="text-sm text-gray-600 mt-1">总库存</p>
            </div>
          </div>
          <div className="h-1 w-full bg-gradient-to-r from-emerald-200 to-teal-200 rounded-full"></div>
        </div>

        <div className="group bg-white rounded-2xl border-2 border-gray-200 p-6 hover:shadow-xl transition-all duration-300">
          <div className="flex items-center justify-between mb-4">
            <div className="p-3 bg-gradient-to-br from-amber-500 to-orange-600 rounded-xl shadow-lg">
              <AlertTriangle className="w-6 h-6 text-white" />
            </div>
            <div className="text-right">
              <p className="text-3xl font-black text-gray-900">{alerts.length}</p>
              <p className="text-sm text-gray-600 mt-1">库存预警</p>
            </div>
          </div>
          <div className="h-1 w-full bg-gradient-to-r from-amber-200 to-orange-200 rounded-full"></div>
        </div>

        <div className="group bg-white rounded-2xl border-2 border-gray-200 p-6 hover:shadow-xl transition-all duration-300">
          <div className="flex items-center justify-between mb-4">
            <div className="p-3 bg-gradient-to-br from-purple-500 to-pink-600 rounded-xl shadow-lg">
              <TrendingUp className="w-6 h-6 text-white" />
            </div>
            <div className="text-right">
              <p className="text-3xl font-black text-gray-900">{lowStockCount}</p>
              <p className="text-sm text-gray-600 mt-1">低库存商品</p>
            </div>
          </div>
          <div className="h-1 w-full bg-gradient-to-r from-purple-200 to-pink-200 rounded-full"></div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white rounded-2xl border border-gray-200 p-6 shadow-sm">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-3">
              <Inbox className="w-6 h-6 text-blue-600" />
              <h2 className="text-xl font-bold text-gray-900">入库单</h2>
            </div>
            <span className="px-3 py-1 bg-blue-100 text-blue-700 text-sm font-bold rounded-full">
              {totalInbound} 待处理
            </span>
          </div>

          <div className="space-y-3">
            {inboundOrders.length > 0 ? (
              inboundOrders.map((order) => (
                <div key={order.id} className="p-4 rounded-xl border border-gray-200 hover:border-blue-300 transition-colors">
                  <div className="flex items-center justify-between mb-2">
                    <span className="font-bold text-gray-900">{order.code}</span>
                    <span className={`px-3 py-1 text-xs font-bold rounded-full ${getStatusColor(order.status)}`}>
                      {getStatusText(order.status)}
                    </span>
                  </div>
                  <div className="flex items-center gap-2 text-sm text-gray-600">
                    <Clock className="w-4 h-4" />
                    {new Date(order.created_at).toLocaleString('zh-CN')}
                  </div>
                </div>
              ))
            ) : (
              <div className="text-center py-8">
                <CheckCircle className="w-12 h-12 text-emerald-500 mx-auto mb-3" />
                <p className="text-gray-500 font-medium">暂无入库单</p>
              </div>
            )}
          </div>
        </div>

        <div className="bg-white rounded-2xl border border-gray-200 p-6 shadow-sm">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-3">
              <Send className="w-6 h-6 text-cyan-600" />
              <h2 className="text-xl font-bold text-gray-900">出库单</h2>
            </div>
            <span className="px-3 py-1 bg-cyan-100 text-cyan-700 text-sm font-bold rounded-full">
              {totalOutbound} 待处理
            </span>
          </div>

          <div className="space-y-3">
            {outboundOrders.length > 0 ? (
              outboundOrders.map((order) => (
                <div key={order.id} className="p-4 rounded-xl border border-gray-200 hover:border-cyan-300 transition-colors">
                  <div className="flex items-center justify-between mb-2">
                    <span className="font-bold text-gray-900">{order.code}</span>
                    <span className={`px-3 py-1 text-xs font-bold rounded-full ${getStatusColor(order.status)}`}>
                      {getStatusText(order.status)}
                    </span>
                  </div>
                  <div className="flex items-center gap-2 text-sm text-gray-600">
                    <Clock className="w-4 h-4" />
                    {new Date(order.created_at).toLocaleString('zh-CN')}
                  </div>
                </div>
              ))
            ) : (
              <div className="text-center py-8">
                <CheckCircle className="w-12 h-12 text-emerald-500 mx-auto mb-3" />
                <p className="text-gray-500 font-medium">暂无出库单</p>
              </div>
            )}
          </div>
        </div>
      </div>

      <div className="bg-white rounded-2xl border border-gray-200 p-6 shadow-sm">
        <div className="flex items-center gap-3 mb-6">
          <AlertTriangle className="w-6 h-6 text-amber-600" />
          <h2 className="text-xl font-bold text-gray-900">实时库存预警</h2>
          <span className="px-3 py-1 bg-amber-100 text-amber-700 text-sm font-bold rounded-full">
            {alerts.length} 条待处理
          </span>
        </div>

        <div className="space-y-3">
          {alerts.length > 0 ? (
            alerts.map((alert) => (
              <div
                key={alert.id}
                className={`p-4 rounded-xl border-2 ${getSeverityColor(alert.priority)} flex items-center justify-between`}
              >
                <div className="flex-1">
                  <div className="flex items-center gap-3 mb-2">
                    <AlertTriangle className="w-5 h-5" />
                    <span className="font-bold">{getAlertTypeText(alert.alert_type)}</span>
                    <span className="text-xs px-2 py-1 bg-white/50 rounded-full font-medium">
                      {alert.priority || 'medium'}
                    </span>
                  </div>
                  <p className="text-sm mb-1">
                    <span className="font-medium">当前库存:</span> {alert.current_quantity}
                  </p>
                  {alert.threshold_quantity && (
                    <p className="text-sm mb-1">
                      <span className="font-medium">阈值:</span> {alert.threshold_quantity}
                    </p>
                  )}
                  {alert.notes && (
                    <p className="text-sm mt-2 opacity-90">{alert.notes}</p>
                  )}
                  <div className="flex items-center gap-2 mt-2 text-xs opacity-75">
                    <Clock className="w-3 h-3" />
                    {new Date(alert.created_at).toLocaleString('zh-CN')}
                  </div>
                </div>
                <button
                  onClick={() => resolveAlert(alert.id)}
                  className="ml-4 px-4 py-2 bg-white/80 hover:bg-white rounded-lg text-sm font-bold transition-colors shadow-sm"
                >
                  标记已处理
                </button>
              </div>
            ))
          ) : (
            <div className="text-center py-12">
              <CheckCircle className="w-16 h-16 mx-auto mb-4 text-emerald-500" />
              <p className="text-gray-600 font-bold text-lg">库存状态良好</p>
              <p className="text-gray-500 text-sm">没有需要关注的预警</p>
            </div>
          )}
        </div>
      </div>

      <div className="bg-white rounded-2xl border border-gray-200 p-6 shadow-sm">
        <h2 className="text-xl font-bold text-gray-900 mb-6">仓库列表</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {warehouses.map((warehouse) => {
            const utilization = warehouse.current_usage && warehouse.capacity
              ? (warehouse.current_usage / warehouse.capacity * 100).toFixed(1)
              : 0;

            return (
              <div
                key={warehouse.id}
                className="group bg-gradient-to-br from-gray-50 to-white rounded-2xl border-2 border-gray-200 p-6 hover:border-blue-400 hover:shadow-2xl transition-all cursor-pointer"
              >
                <div className="flex items-start gap-4 mb-4">
                  <div className="p-3 bg-gradient-to-br from-blue-500 to-cyan-600 rounded-xl shadow-lg">
                    <Warehouse className="w-6 h-6 text-white" />
                  </div>
                  <div className="flex-1">
                    <h3 className="font-black text-gray-900 mb-2">{warehouse.name}</h3>
                    <span className={`inline-flex px-3 py-1 text-xs font-bold rounded-full ${getStatusColor(warehouse.status)}`}>
                      {getStatusText(warehouse.status)}
                    </span>
                  </div>
                </div>

                <div className="space-y-3 text-sm">
                  {warehouse.address && (
                    <div className="flex items-start gap-2 text-gray-600">
                      <MapPin className="w-4 h-4 mt-0.5 flex-shrink-0" />
                      <span>{warehouse.address.address || '地址未设置'}</span>
                    </div>
                  )}

                  <div className="pt-3 border-t border-gray-200">
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-gray-600 font-medium">容量使用率</span>
                      <span className={`font-black ${
                        utilization > 90 ? 'text-red-600' : utilization > 70 ? 'text-orange-600' : 'text-green-600'
                      }`}>
                        {utilization}%
                      </span>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-2.5">
                      <div
                        className={`h-2.5 rounded-full transition-all ${
                          utilization > 90 ? 'bg-red-500' : utilization > 70 ? 'bg-orange-500' : 'bg-green-500'
                        }`}
                        style={{ width: `${Math.min(utilization, 100)}%` }}
                      />
                    </div>
                  </div>

                  <div className="flex items-center justify-between pt-2 text-xs text-gray-500 font-medium">
                    <span>容量: {(warehouse.capacity || 0).toLocaleString()}</span>
                    <span>已用: {(warehouse.current_usage || 0).toLocaleString()}</span>
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {warehouses.length === 0 && (
          <div className="text-center py-16">
            <Warehouse className="w-16 h-16 text-gray-300 mx-auto mb-4" />
            <p className="text-gray-500 font-bold text-lg">暂无仓库数据</p>
            <p className="text-gray-400 text-sm mt-2">请添加第一个仓库开始使用</p>
          </div>
        )}
      </div>
    </div>
  );
}
