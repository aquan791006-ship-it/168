import React, { useState, useEffect } from 'react';
import {
  Wallet,
  TrendingUp,
  TrendingDown,
  DollarSign,
  CreditCard,
  FileText,
  PieChart,
  Calendar,
  Filter,
  Plus,
  Download,
  Upload,
  CheckCircle,
  AlertCircle,
  ArrowUpRight,
  ArrowDownRight,
  Receipt,
  BarChart3,
  Activity
} from 'lucide-react';
import { supabase } from '../lib/supabase';
import Modal from '../components/Modal';

export default function Finance() {
  const [activeTab, setActiveTab] = useState('overview');
  const [accounts, setAccounts] = useState([]);
  const [transactions, setTransactions] = useState([]);
  const [invoices, setInvoices] = useState([]);
  const [budgets, setBudgets] = useState([]);
  const [categories, setCategories] = useState([]);
  const [stats, setStats] = useState({
    totalIncome: 0,
    totalExpense: 0,
    netProfit: 0,
    totalBalance: 0
  });
  const [loading, setLoading] = useState(false);
  const [showTransactionModal, setShowTransactionModal] = useState(false);
  const [showAccountModal, setShowAccountModal] = useState(false);
  const [showInvoiceModal, setShowInvoiceModal] = useState(false);
  const [selectedDateRange, setSelectedDateRange] = useState('30d');

  const [newTransaction, setNewTransaction] = useState({
    account_id: '',
    category_id: '',
    transaction_type: 'expense',
    amount: '',
    payer_payee: '',
    description: '',
    transaction_date: new Date().toISOString().split('T')[0]
  });

  const [newAccount, setNewAccount] = useState({
    account_name: '',
    account_type: 'bank',
    account_number: '',
    bank_name: '',
    balance: ''
  });

  const [newInvoice, setNewInvoice] = useState({
    invoice_number: '',
    invoice_type: 'sales',
    invoice_date: new Date().toISOString().split('T')[0],
    customer_supplier: '',
    total_amount: '',
    tax_amount: '',
    status: 'pending'
  });

  useEffect(() => {
    loadData();
  }, [selectedDateRange]);

  const loadData = async () => {
    setLoading(true);
    try {
      await Promise.all([
        loadAccounts(),
        loadCategories(),
        loadTransactions(),
        loadInvoices(),
        loadBudgets(),
        loadStats()
      ]);
    } catch (error) {
      console.error('Error loading data:', error);
    } finally {
      setLoading(false);
    }
  };

  const loadAccounts = async () => {
    const { data: domainData } = await supabase
      .from('sys_domains')
      .select('id')
      .limit(1)
      .single();

    if (domainData) {
      const { data, error } = await supabase
        .from('finance_accounts')
        .select('*')
        .eq('domain_id', domainData.id)
        .order('created_at', { ascending: false });

      if (!error && data) {
        setAccounts(data);
      }
    }
  };

  const loadCategories = async () => {
    const { data: domainData } = await supabase
      .from('sys_domains')
      .select('id')
      .limit(1)
      .single();

    if (domainData) {
      const { data, error } = await supabase
        .from('finance_categories')
        .select('*')
        .eq('domain_id', domainData.id)
        .order('sort_order');

      if (!error && data) {
        setCategories(data);
      }
    }
  };

  const loadTransactions = async () => {
    const { data: domainData } = await supabase
      .from('sys_domains')
      .select('id')
      .limit(1)
      .single();

    if (domainData) {
      const daysMap = { '7d': 7, '30d': 30, '90d': 90 };
      const days = daysMap[selectedDateRange] || 30;
      const startDate = new Date();
      startDate.setDate(startDate.getDate() - days);

      const { data, error } = await supabase
        .from('finance_transactions')
        .select(`
          *,
          account:finance_accounts(account_name),
          category:finance_categories(category_name, color)
        `)
        .eq('domain_id', domainData.id)
        .gte('transaction_date', startDate.toISOString())
        .order('transaction_date', { ascending: false })
        .limit(100);

      if (!error && data) {
        setTransactions(data);
      }
    }
  };

  const loadInvoices = async () => {
    const { data: domainData } = await supabase
      .from('sys_domains')
      .select('id')
      .limit(1)
      .single();

    if (domainData) {
      const { data, error } = await supabase
        .from('finance_invoices')
        .select('*')
        .eq('domain_id', domainData.id)
        .order('invoice_date', { ascending: false })
        .limit(50);

      if (!error && data) {
        setInvoices(data);
      }
    }
  };

  const loadBudgets = async () => {
    const { data: domainData } = await supabase
      .from('sys_domains')
      .select('id')
      .limit(1)
      .single();

    if (domainData) {
      const { data, error } = await supabase
        .from('finance_budgets')
        .select(`
          *,
          category:finance_categories(category_name)
        `)
        .eq('domain_id', domainData.id)
        .eq('is_active', true)
        .order('created_at', { ascending: false });

      if (!error && data) {
        setBudgets(data);
      }
    }
  };

  const loadStats = async () => {
    const { data: domainData } = await supabase
      .from('sys_domains')
      .select('id')
      .limit(1)
      .single();

    if (domainData) {
      const daysMap = { '7d': 7, '30d': 30, '90d': 90 };
      const days = daysMap[selectedDateRange] || 30;
      const startDate = new Date();
      startDate.setDate(startDate.getDate() - days);

      const { data, error } = await supabase
        .from('finance_transactions')
        .select('transaction_type, amount')
        .eq('domain_id', domainData.id)
        .gte('transaction_date', startDate.toISOString());

      if (!error && data) {
        const totalIncome = data
          .filter(t => t.transaction_type === 'income')
          .reduce((sum, t) => sum + parseFloat(t.amount), 0);

        const totalExpense = data
          .filter(t => t.transaction_type === 'expense')
          .reduce((sum, t) => sum + parseFloat(t.amount), 0);

        const { data: accountsData } = await supabase
          .from('finance_accounts')
          .select('balance')
          .eq('domain_id', domainData.id);

        const totalBalance = accountsData
          ? accountsData.reduce((sum, acc) => sum + parseFloat(acc.balance || 0), 0)
          : 0;

        setStats({
          totalIncome,
          totalExpense,
          netProfit: totalIncome - totalExpense,
          totalBalance
        });
      }
    }
  };

  const handleCreateAccount = async (e) => {
    e.preventDefault();
    setLoading(true);

    try {
      const { data: domainData } = await supabase
        .from('sys_domains')
        .select('id')
        .limit(1)
        .single();

      if (domainData) {
        const { error } = await supabase
          .from('finance_accounts')
          .insert({
            ...newAccount,
            domain_id: domainData.id,
            status: 'active'
          });

        if (!error) {
          setShowAccountModal(false);
          setNewAccount({
            account_name: '',
            account_type: 'bank',
            account_number: '',
            bank_name: '',
            balance: ''
          });
          loadAccounts();
          loadStats();
        }
      }
    } catch (error) {
      console.error('Error creating account:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleCreateTransaction = async (e) => {
    e.preventDefault();
    setLoading(true);

    try {
      const { data: domainData } = await supabase
        .from('sys_domains')
        .select('id')
        .limit(1)
        .single();

      if (domainData) {
        const { error } = await supabase
          .from('finance_transactions')
          .insert({
            ...newTransaction,
            domain_id: domainData.id
          });

        if (!error) {
          const account = accounts.find(a => a.id === newTransaction.account_id);
          if (account) {
            const newBalance = newTransaction.transaction_type === 'income'
              ? parseFloat(account.balance) + parseFloat(newTransaction.amount)
              : parseFloat(account.balance) - parseFloat(newTransaction.amount);

            await supabase
              .from('finance_accounts')
              .update({ balance: newBalance })
              .eq('id', newTransaction.account_id);
          }

          setShowTransactionModal(false);
          setNewTransaction({
            account_id: '',
            category_id: '',
            transaction_type: 'expense',
            amount: '',
            payer_payee: '',
            description: '',
            transaction_date: new Date().toISOString().split('T')[0]
          });
          loadTransactions();
          loadAccounts();
          loadStats();
        }
      }
    } catch (error) {
      console.error('Error creating transaction:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleCreateInvoice = async (e) => {
    e.preventDefault();
    setLoading(true);

    try {
      const { data: domainData } = await supabase
        .from('sys_domains')
        .select('id')
        .limit(1)
        .single();

      if (domainData) {
        const { error } = await supabase
          .from('finance_invoices')
          .insert({
            ...newInvoice,
            domain_id: domainData.id
          });

        if (!error) {
          setShowInvoiceModal(false);
          setNewInvoice({
            invoice_number: '',
            invoice_type: 'sales',
            invoice_date: new Date().toISOString().split('T')[0],
            customer_supplier: '',
            total_amount: '',
            tax_amount: '',
            status: 'pending'
          });
          loadInvoices();
        }
      }
    } catch (error) {
      console.error('Error creating invoice:', error);
    } finally {
      setLoading(false);
    }
  };

  const formatCurrency = (value) => {
    return new Intl.NumberFormat('zh-CN', {
      style: 'currency',
      currency: 'CNY'
    }).format(value);
  };

  const getAccountTypeLabel = (type) => {
    const types = {
      bank: '银行账户',
      alipay: '支付宝',
      wechat: '微信支付',
      cash: '现金',
      credit_card: '信用卡',
      other: '其他'
    };
    return types[type] || type;
  };

  const getInvoiceStatusBadge = (status) => {
    const statusConfig = {
      pending: { text: '待支付', className: 'bg-yellow-100 text-yellow-800' },
      paid: { text: '已支付', className: 'bg-green-100 text-green-800' },
      partial: { text: '部分支付', className: 'bg-blue-100 text-blue-800' },
      overdue: { text: '已逾期', className: 'bg-red-100 text-red-800' },
      cancelled: { text: '已取消', className: 'bg-gray-100 text-gray-800' }
    };
    const config = statusConfig[status] || statusConfig.pending;
    return (
      <span className={`px-2 py-1 rounded-full text-xs font-medium ${config.className}`}>
        {config.text}
      </span>
    );
  };

  const tabs = [
    { id: 'overview', name: '财务概览', icon: BarChart3 },
    { id: 'accounts', name: '账户管理', icon: Wallet },
    { id: 'transactions', name: '交易记录', icon: Activity },
    { id: 'invoices', name: '发票管理', icon: FileText },
    { id: 'budgets', name: '预算管理', icon: PieChart }
  ];

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-start">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">财务管理</h1>
          <p className="text-gray-600 mt-1">安全智能的财务数据管理与分析</p>
        </div>
        <div className="flex gap-3">
          <button
            onClick={() => setShowAccountModal(true)}
            className="flex items-center gap-2 px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50 transition-colors"
          >
            <Plus className="w-5 h-5" />
            添加账户
          </button>
          <button
            onClick={() => setShowTransactionModal(true)}
            className="flex items-center gap-2 bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors"
          >
            <Plus className="w-5 h-5" />
            记账
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-gradient-to-br from-blue-50 to-blue-100 rounded-lg shadow-sm border border-blue-200 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-blue-700 font-medium">总余额</p>
              <p className="text-2xl font-bold text-blue-900 mt-1">
                {formatCurrency(stats.totalBalance)}
              </p>
            </div>
            <div className="p-3 bg-blue-500 rounded-lg">
              <Wallet className="w-6 h-6 text-white" />
            </div>
          </div>
        </div>

        <div className="bg-gradient-to-br from-green-50 to-green-100 rounded-lg shadow-sm border border-green-200 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-green-700 font-medium">总收入</p>
              <p className="text-2xl font-bold text-green-900 mt-1">
                {formatCurrency(stats.totalIncome)}
              </p>
            </div>
            <div className="p-3 bg-green-500 rounded-lg">
              <TrendingUp className="w-6 h-6 text-white" />
            </div>
          </div>
        </div>

        <div className="bg-gradient-to-br from-red-50 to-red-100 rounded-lg shadow-sm border border-red-200 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-red-700 font-medium">总支出</p>
              <p className="text-2xl font-bold text-red-900 mt-1">
                {formatCurrency(stats.totalExpense)}
              </p>
            </div>
            <div className="p-3 bg-red-500 rounded-lg">
              <TrendingDown className="w-6 h-6 text-white" />
            </div>
          </div>
        </div>

        <div className={`bg-gradient-to-br rounded-lg shadow-sm border p-6 ${
          stats.netProfit >= 0
            ? 'from-emerald-50 to-emerald-100 border-emerald-200'
            : 'from-orange-50 to-orange-100 border-orange-200'
        }`}>
          <div className="flex items-center justify-between">
            <div>
              <p className={`text-sm font-medium ${
                stats.netProfit >= 0 ? 'text-emerald-700' : 'text-orange-700'
              }`}>
                净利润
              </p>
              <p className={`text-2xl font-bold mt-1 ${
                stats.netProfit >= 0 ? 'text-emerald-900' : 'text-orange-900'
              }`}>
                {formatCurrency(stats.netProfit)}
              </p>
            </div>
            <div className={`p-3 rounded-lg ${
              stats.netProfit >= 0 ? 'bg-emerald-500' : 'bg-orange-500'
            }`}>
              <DollarSign className="w-6 h-6 text-white" />
            </div>
          </div>
        </div>
      </div>

      <div className="bg-white rounded-lg shadow-sm border border-gray-200">
        <div className="border-b border-gray-200">
          <nav className="flex -mb-px">
            {tabs.map((tab) => {
              const Icon = tab.icon;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`flex items-center gap-2 px-6 py-4 border-b-2 font-medium text-sm transition-colors ${
                    activeTab === tab.id
                      ? 'border-blue-500 text-blue-600'
                      : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                  }`}
                >
                  <Icon className="w-5 h-5" />
                  {tab.name}
                </button>
              );
            })}
          </nav>
        </div>

        <div className="p-6">
          {activeTab === 'overview' && (
            <div className="space-y-6">
              <div className="flex items-center justify-between">
                <h2 className="text-lg font-semibold text-gray-900">财务趋势</h2>
                <select
                  value={selectedDateRange}
                  onChange={(e) => setSelectedDateRange(e.target.value)}
                  className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                >
                  <option value="7d">最近7天</option>
                  <option value="30d">最近30天</option>
                  <option value="90d">最近90天</option>
                </select>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="bg-gradient-to-br from-blue-50 to-indigo-50 rounded-lg p-6 border border-blue-200">
                  <h3 className="text-sm font-medium text-blue-900 mb-4">收入构成</h3>
                  <div className="space-y-3">
                    {categories.filter(c => c.category_type === 'income').map((category) => {
                      const categoryTotal = transactions
                        .filter(t => t.transaction_type === 'income' && t.category_id === category.id)
                        .reduce((sum, t) => sum + parseFloat(t.amount), 0);
                      const percentage = stats.totalIncome > 0 ? (categoryTotal / stats.totalIncome * 100) : 0;

                      return categoryTotal > 0 ? (
                        <div key={category.id}>
                          <div className="flex justify-between text-sm mb-1">
                            <span className="text-gray-700">{category.category_name}</span>
                            <span className="font-medium text-gray-900">{formatCurrency(categoryTotal)}</span>
                          </div>
                          <div className="w-full bg-blue-200 rounded-full h-2">
                            <div
                              className="bg-blue-600 h-2 rounded-full transition-all"
                              style={{ width: `${percentage}%` }}
                            />
                          </div>
                        </div>
                      ) : null;
                    })}
                  </div>
                </div>

                <div className="bg-gradient-to-br from-red-50 to-pink-50 rounded-lg p-6 border border-red-200">
                  <h3 className="text-sm font-medium text-red-900 mb-4">支出构成</h3>
                  <div className="space-y-3">
                    {categories.filter(c => c.category_type === 'expense').map((category) => {
                      const categoryTotal = transactions
                        .filter(t => t.transaction_type === 'expense' && t.category_id === category.id)
                        .reduce((sum, t) => sum + parseFloat(t.amount), 0);
                      const percentage = stats.totalExpense > 0 ? (categoryTotal / stats.totalExpense * 100) : 0;

                      return categoryTotal > 0 ? (
                        <div key={category.id}>
                          <div className="flex justify-between text-sm mb-1">
                            <span className="text-gray-700">{category.category_name}</span>
                            <span className="font-medium text-gray-900">{formatCurrency(categoryTotal)}</span>
                          </div>
                          <div className="w-full bg-red-200 rounded-full h-2">
                            <div
                              className="bg-red-600 h-2 rounded-full transition-all"
                              style={{ width: `${percentage}%` }}
                            />
                          </div>
                        </div>
                      ) : null;
                    })}
                  </div>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'accounts' && (
            <div className="space-y-4">
              {accounts.length === 0 ? (
                <div className="text-center py-12">
                  <Wallet className="w-12 h-12 text-gray-400 mx-auto mb-3" />
                  <p className="text-gray-600">还没有财务账户</p>
                  <button
                    onClick={() => setShowAccountModal(true)}
                    className="mt-4 text-blue-600 hover:text-blue-700"
                  >
                    添加第一个账户
                  </button>
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {accounts.map((account) => (
                    <div
                      key={account.id}
                      className="bg-gradient-to-br from-gray-50 to-gray-100 rounded-lg p-6 border border-gray-200 hover:border-blue-300 transition-colors"
                    >
                      <div className="flex items-start justify-between mb-4">
                        <div>
                          <h3 className="font-semibold text-gray-900">{account.account_name}</h3>
                          <p className="text-sm text-gray-600 mt-1">
                            {getAccountTypeLabel(account.account_type)}
                          </p>
                        </div>
                        <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                          account.status === 'active'
                            ? 'bg-green-100 text-green-800'
                            : 'bg-gray-100 text-gray-800'
                        }`}>
                          {account.status === 'active' ? '活跃' : '冻结'}
                        </span>
                      </div>
                      <div className="space-y-2">
                        <div>
                          <p className="text-xs text-gray-600">账户余额</p>
                          <p className="text-2xl font-bold text-gray-900">
                            {formatCurrency(account.balance)}
                          </p>
                        </div>
                        {account.account_number && (
                          <p className="text-xs text-gray-600 font-mono">
                            {account.account_number}
                          </p>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {activeTab === 'transactions' && (
            <div className="space-y-4">
              {transactions.length === 0 ? (
                <div className="text-center py-12">
                  <Activity className="w-12 h-12 text-gray-400 mx-auto mb-3" />
                  <p className="text-gray-600">还没有交易记录</p>
                  <button
                    onClick={() => setShowTransactionModal(true)}
                    className="mt-4 text-blue-600 hover:text-blue-700"
                  >
                    添加第一笔交易
                  </button>
                </div>
              ) : (
                <div className="overflow-x-auto">
                  <table className="min-w-full divide-y divide-gray-200">
                    <thead className="bg-gray-50">
                      <tr>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                          日期
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                          类型
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                          分类
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                          账户
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                          说明
                        </th>
                        <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase">
                          金额
                        </th>
                      </tr>
                    </thead>
                    <tbody className="bg-white divide-y divide-gray-200">
                      {transactions.map((transaction) => (
                        <tr key={transaction.id}>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                            {new Date(transaction.transaction_date).toLocaleDateString('zh-CN')}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap">
                            <div className="flex items-center gap-2">
                              {transaction.transaction_type === 'income' ? (
                                <>
                                  <ArrowUpRight className="w-4 h-4 text-green-600" />
                                  <span className="text-sm font-medium text-green-600">收入</span>
                                </>
                              ) : (
                                <>
                                  <ArrowDownRight className="w-4 h-4 text-red-600" />
                                  <span className="text-sm font-medium text-red-600">支出</span>
                                </>
                              )}
                            </div>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                            {transaction.category?.category_name || '-'}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-600">
                            {transaction.account?.account_name}
                          </td>
                          <td className="px-6 py-4 text-sm text-gray-600">
                            {transaction.description || '-'}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-right">
                            <span className={`text-sm font-semibold ${
                              transaction.transaction_type === 'income'
                                ? 'text-green-600'
                                : 'text-red-600'
                            }`}>
                              {transaction.transaction_type === 'income' ? '+' : '-'}
                              {formatCurrency(transaction.amount)}
                            </span>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          )}

          {activeTab === 'invoices' && (
            <div className="space-y-4">
              <div className="flex justify-end">
                <button
                  onClick={() => setShowInvoiceModal(true)}
                  className="flex items-center gap-2 bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors"
                >
                  <Plus className="w-5 h-5" />
                  创建发票
                </button>
              </div>

              {invoices.length === 0 ? (
                <div className="text-center py-12">
                  <FileText className="w-12 h-12 text-gray-400 mx-auto mb-3" />
                  <p className="text-gray-600">还没有发票记录</p>
                </div>
              ) : (
                <div className="overflow-x-auto">
                  <table className="min-w-full divide-y divide-gray-200">
                    <thead className="bg-gray-50">
                      <tr>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                          发票号
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                          类型
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                          客户/供应商
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                          日期
                        </th>
                        <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase">
                          金额
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                          状态
                        </th>
                      </tr>
                    </thead>
                    <tbody className="bg-white divide-y divide-gray-200">
                      {invoices.map((invoice) => (
                        <tr key={invoice.id}>
                          <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                            {invoice.invoice_number}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-600">
                            {invoice.invoice_type === 'sales' ? '销售' : invoice.invoice_type === 'purchase' ? '采购' : '费用'}
                          </td>
                          <td className="px-6 py-4 text-sm text-gray-900">
                            {invoice.customer_supplier}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-600">
                            {new Date(invoice.invoice_date).toLocaleDateString('zh-CN')}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-semibold text-gray-900">
                            {formatCurrency(invoice.total_amount)}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap">
                            {getInvoiceStatusBadge(invoice.status)}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          )}

          {activeTab === 'budgets' && (
            <div className="space-y-4">
              {budgets.length === 0 ? (
                <div className="text-center py-12">
                  <PieChart className="w-12 h-12 text-gray-400 mx-auto mb-3" />
                  <p className="text-gray-600">还没有预算设置</p>
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {budgets.map((budget) => {
                    const usedPercentage = (parseFloat(budget.spent_amount) / parseFloat(budget.budget_amount)) * 100;
                    const isOverBudget = usedPercentage > 100;
                    const isNearLimit = usedPercentage >= parseFloat(budget.alert_threshold);

                    return (
                      <div
                        key={budget.id}
                        className={`bg-white rounded-lg p-6 border-2 ${
                          isOverBudget
                            ? 'border-red-300 bg-red-50'
                            : isNearLimit
                            ? 'border-yellow-300 bg-yellow-50'
                            : 'border-gray-200'
                        }`}
                      >
                        <div className="flex items-start justify-between mb-4">
                          <div>
                            <h3 className="font-semibold text-gray-900">{budget.budget_name}</h3>
                            <p className="text-sm text-gray-600 mt-1">
                              {budget.category?.category_name}
                            </p>
                          </div>
                          {isOverBudget ? (
                            <AlertCircle className="w-5 h-5 text-red-600" />
                          ) : isNearLimit ? (
                            <AlertCircle className="w-5 h-5 text-yellow-600" />
                          ) : (
                            <CheckCircle className="w-5 h-5 text-green-600" />
                          )}
                        </div>

                        <div className="space-y-2">
                          <div className="flex justify-between text-sm">
                            <span className="text-gray-600">已使用</span>
                            <span className="font-medium text-gray-900">
                              {formatCurrency(budget.spent_amount)} / {formatCurrency(budget.budget_amount)}
                            </span>
                          </div>
                          <div className="w-full bg-gray-200 rounded-full h-3">
                            <div
                              className={`h-3 rounded-full transition-all ${
                                isOverBudget
                                  ? 'bg-red-600'
                                  : isNearLimit
                                  ? 'bg-yellow-500'
                                  : 'bg-green-500'
                              }`}
                              style={{ width: `${Math.min(usedPercentage, 100)}%` }}
                            />
                          </div>
                          <div className="flex justify-between text-xs text-gray-600">
                            <span>{usedPercentage.toFixed(1)}% 已使用</span>
                            <span>
                              {new Date(budget.period_start).toLocaleDateString('zh-CN')} - {new Date(budget.period_end).toLocaleDateString('zh-CN')}
                            </span>
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          )}
        </div>
      </div>

      {showAccountModal && (
        <Modal
          isOpen={showAccountModal}
          onClose={() => setShowAccountModal(false)}
          title="添加财务账户"
        >
          <form onSubmit={handleCreateAccount} className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                账户名称 *
              </label>
              <input
                type="text"
                value={newAccount.account_name}
                onChange={(e) => setNewAccount({ ...newAccount, account_name: e.target.value })}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                placeholder="例如：招商银行储蓄卡"
                required
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                账户类型 *
              </label>
              <select
                value={newAccount.account_type}
                onChange={(e) => setNewAccount({ ...newAccount, account_type: e.target.value })}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                required
              >
                <option value="bank">银行账户</option>
                <option value="alipay">支付宝</option>
                <option value="wechat">微信支付</option>
                <option value="cash">现金</option>
                <option value="credit_card">信用卡</option>
                <option value="other">其他</option>
              </select>
            </div>

            {newAccount.account_type === 'bank' && (
              <>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    银行名称
                  </label>
                  <input
                    type="text"
                    value={newAccount.bank_name}
                    onChange={(e) => setNewAccount({ ...newAccount, bank_name: e.target.value })}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    placeholder="例如：招商银行"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    账号
                  </label>
                  <input
                    type="text"
                    value={newAccount.account_number}
                    onChange={(e) => setNewAccount({ ...newAccount, account_number: e.target.value })}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    placeholder="银行卡号"
                  />
                </div>
              </>
            )}

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                初始余额
              </label>
              <input
                type="number"
                value={newAccount.balance}
                onChange={(e) => setNewAccount({ ...newAccount, balance: e.target.value })}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                placeholder="0.00"
                step="0.01"
                min="0"
              />
            </div>

            <div className="flex gap-3 pt-4">
              <button
                type="button"
                onClick={() => setShowAccountModal(false)}
                className="flex-1 px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50 transition-colors"
              >
                取消
              </button>
              <button
                type="submit"
                disabled={loading}
                className="flex-1 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors disabled:bg-gray-400"
              >
                {loading ? '添加中...' : '添加'}
              </button>
            </div>
          </form>
        </Modal>
      )}

      {showTransactionModal && (
        <Modal
          isOpen={showTransactionModal}
          onClose={() => setShowTransactionModal(false)}
          title="添加交易记录"
        >
          <form onSubmit={handleCreateTransaction} className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                交易类型 *
              </label>
              <div className="grid grid-cols-2 gap-3">
                <button
                  type="button"
                  onClick={() => setNewTransaction({ ...newTransaction, transaction_type: 'income' })}
                  className={`px-4 py-2 rounded-lg border-2 transition-colors ${
                    newTransaction.transaction_type === 'income'
                      ? 'border-green-500 bg-green-50 text-green-700'
                      : 'border-gray-300 hover:border-gray-400'
                  }`}
                >
                  收入
                </button>
                <button
                  type="button"
                  onClick={() => setNewTransaction({ ...newTransaction, transaction_type: 'expense' })}
                  className={`px-4 py-2 rounded-lg border-2 transition-colors ${
                    newTransaction.transaction_type === 'expense'
                      ? 'border-red-500 bg-red-50 text-red-700'
                      : 'border-gray-300 hover:border-gray-400'
                  }`}
                >
                  支出
                </button>
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                账户 *
              </label>
              <select
                value={newTransaction.account_id}
                onChange={(e) => setNewTransaction({ ...newTransaction, account_id: e.target.value })}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                required
              >
                <option value="">选择账户</option>
                {accounts.map((account) => (
                  <option key={account.id} value={account.id}>
                    {account.account_name} ({formatCurrency(account.balance)})
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                分类 *
              </label>
              <select
                value={newTransaction.category_id}
                onChange={(e) => setNewTransaction({ ...newTransaction, category_id: e.target.value })}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                required
              >
                <option value="">选择分类</option>
                {categories
                  .filter(c => c.category_type === newTransaction.transaction_type)
                  .map((category) => (
                    <option key={category.id} value={category.id}>
                      {category.category_name}
                    </option>
                  ))}
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                金额 *
              </label>
              <input
                type="number"
                value={newTransaction.amount}
                onChange={(e) => setNewTransaction({ ...newTransaction, amount: e.target.value })}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                placeholder="0.00"
                step="0.01"
                min="0.01"
                required
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                交易日期 *
              </label>
              <input
                type="date"
                value={newTransaction.transaction_date}
                onChange={(e) => setNewTransaction({ ...newTransaction, transaction_date: e.target.value })}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                required
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                {newTransaction.transaction_type === 'income' ? '付款方' : '收款方'}
              </label>
              <input
                type="text"
                value={newTransaction.payer_payee}
                onChange={(e) => setNewTransaction({ ...newTransaction, payer_payee: e.target.value })}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                placeholder={newTransaction.transaction_type === 'income' ? '客户名称' : '供应商名称'}
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                备注说明
              </label>
              <textarea
                value={newTransaction.description}
                onChange={(e) => setNewTransaction({ ...newTransaction, description: e.target.value })}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                rows="3"
                placeholder="交易说明..."
              />
            </div>

            <div className="flex gap-3 pt-4">
              <button
                type="button"
                onClick={() => setShowTransactionModal(false)}
                className="flex-1 px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50 transition-colors"
              >
                取消
              </button>
              <button
                type="submit"
                disabled={loading}
                className="flex-1 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors disabled:bg-gray-400"
              >
                {loading ? '添加中...' : '添加'}
              </button>
            </div>
          </form>
        </Modal>
      )}

      {showInvoiceModal && (
        <Modal
          isOpen={showInvoiceModal}
          onClose={() => setShowInvoiceModal(false)}
          title="创建发票"
        >
          <form onSubmit={handleCreateInvoice} className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                发票类型 *
              </label>
              <select
                value={newInvoice.invoice_type}
                onChange={(e) => setNewInvoice({ ...newInvoice, invoice_type: e.target.value })}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                required
              >
                <option value="sales">销售发票</option>
                <option value="purchase">采购发票</option>
                <option value="expense">费用发票</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                发票号 *
              </label>
              <input
                type="text"
                value={newInvoice.invoice_number}
                onChange={(e) => setNewInvoice({ ...newInvoice, invoice_number: e.target.value })}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                placeholder="INV-20260108-001"
                required
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                {newInvoice.invoice_type === 'sales' ? '客户名称' : '供应商名称'} *
              </label>
              <input
                type="text"
                value={newInvoice.customer_supplier}
                onChange={(e) => setNewInvoice({ ...newInvoice, customer_supplier: e.target.value })}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                placeholder="公司或个人名称"
                required
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  发票金额 *
                </label>
                <input
                  type="number"
                  value={newInvoice.total_amount}
                  onChange={(e) => setNewInvoice({ ...newInvoice, total_amount: e.target.value })}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  placeholder="0.00"
                  step="0.01"
                  min="0.01"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  税额
                </label>
                <input
                  type="number"
                  value={newInvoice.tax_amount}
                  onChange={(e) => setNewInvoice({ ...newInvoice, tax_amount: e.target.value })}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  placeholder="0.00"
                  step="0.01"
                  min="0"
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                开票日期 *
              </label>
              <input
                type="date"
                value={newInvoice.invoice_date}
                onChange={(e) => setNewInvoice({ ...newInvoice, invoice_date: e.target.value })}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                required
              />
            </div>

            <div className="flex gap-3 pt-4">
              <button
                type="button"
                onClick={() => setShowInvoiceModal(false)}
                className="flex-1 px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50 transition-colors"
              >
                取消
              </button>
              <button
                type="submit"
                disabled={loading}
                className="flex-1 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors disabled:bg-gray-400"
              >
                {loading ? '创建中...' : '创建'}
              </button>
            </div>
          </form>
        </Modal>
      )}
    </div>
  );
}
