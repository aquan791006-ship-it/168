import { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';
import { useToast } from '../contexts/ToastContext';
import {
  BarChart3,
  TrendingUp,
  Users,
  Globe,
  Monitor,
  Smartphone,
  Calendar,
  Download,
  Eye
} from 'lucide-react';
import { LineChart, Line, BarChart, Bar, PieChart, Pie, Cell, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';

export default function LinkAnalytics() {
  const { user } = useAuth();
  const { showToast } = useToast();
  const [loading, setLoading] = useState(true);
  const [hasPermission, setHasPermission] = useState(false);
  const [domain, setDomain] = useState(null);
  const [dateRange, setDateRange] = useState('7d');
  const [selectedLink, setSelectedLink] = useState(null);

  const [links, setLinks] = useState([]);
  const [stats, setStats] = useState({
    totalClicks: 0,
    uniqueVisitors: 0,
    conversionRate: 0,
    avgDuration: 0
  });
  const [clicksTrend, setClicksTrend] = useState([]);
  const [deviceData, setDeviceData] = useState([]);
  const [countryData, setCountryData] = useState([]);
  const [browserData, setBrowserData] = useState([]);
  const [topLinks, setTopLinks] = useState([]);

  const COLORS = ['#3b82f6', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6', '#ec4899'];

  useEffect(() => {
    loadDomainAndCheck();
  }, [user]);

  useEffect(() => {
    if (hasPermission && domain) {
      loadAnalytics();
    }
  }, [hasPermission, domain, dateRange, selectedLink]);

  const loadDomainAndCheck = async () => {
    try {
      const { data: domainData, error } = await supabase
        .from('sys_domains')
        .select('id, domain, display_name')
        .limit(1)
        .single();

      if (error) throw error;
      setDomain(domainData);

      const { data: permData } = await supabase.rpc('check_analytics_permission', {
        p_domain_id: domainData.id,
        p_admin_id: user.id,
        p_permission_type: 'view'
      });

      setHasPermission(permData || user?.is_super_admin);
    } catch (error) {
      console.error('Error:', error);
    } finally {
      setLoading(false);
    }
  };

  const loadAnalytics = async () => {
    try {
      await Promise.all([
        loadLinks(),
        loadStats(),
        loadClicksTrend(),
        loadDeviceStats(),
        loadCountryStats(),
        loadBrowserStats(),
        loadTopLinks()
      ]);
    } catch (error) {
      console.error('Error loading analytics:', error);
      showToast('error', '加载统计数据失败');
    }
  };

  const loadLinks = async () => {
    const { data, error } = await supabase
      .from('sys_tracked_links')
      .select('id, title, short_code, click_count')
      .eq('domain_id', domain.id)
      .eq('is_active', true)
      .order('click_count', { ascending: false });

    if (!error && data) {
      setLinks(data);
    }
  };

  const loadStats = async () => {
    const daysAgo = parseInt(dateRange.replace('d', ''));
    const startDate = new Date();
    startDate.setDate(startDate.getDate() - daysAgo);

    let query = supabase
      .from('sys_link_visits')
      .select('id, is_unique_visit, visit_duration_seconds, converted', { count: 'exact' })
      .eq('domain_id', domain.id)
      .gte('visited_at', startDate.toISOString());

    if (selectedLink) {
      query = query.eq('link_id', selectedLink);
    }

    const { data, count, error } = await query;

    if (!error && data) {
      const uniqueCount = data.filter(v => v.is_unique_visit).length;
      const conversions = data.filter(v => v.converted).length;
      const totalDuration = data.reduce((sum, v) => sum + (v.visit_duration_seconds || 0), 0);

      setStats({
        totalClicks: count || 0,
        uniqueVisitors: uniqueCount,
        conversionRate: count > 0 ? ((conversions / count) * 100).toFixed(2) : 0,
        avgDuration: count > 0 ? Math.round(totalDuration / count) : 0
      });
    }
  };

  const loadClicksTrend = async () => {
    const daysAgo = parseInt(dateRange.replace('d', ''));
    const startDate = new Date();
    startDate.setDate(startDate.setDate() - daysAgo);

    let query = supabase
      .from('sys_link_visits')
      .select('visited_at, is_unique_visit')
      .eq('domain_id', domain.id)
      .gte('visited_at', startDate.toISOString())
      .order('visited_at');

    if (selectedLink) {
      query = query.eq('link_id', selectedLink);
    }

    const { data, error } = await query;

    if (!error && data) {
      const groupedByDate = data.reduce((acc, visit) => {
        const date = new Date(visit.visited_at).toLocaleDateString('zh-CN');
        if (!acc[date]) {
          acc[date] = { date, clicks: 0, unique: 0 };
        }
        acc[date].clicks++;
        if (visit.is_unique_visit) acc[date].unique++;
        return acc;
      }, {});

      setClicksTrend(Object.values(groupedByDate));
    }
  };

  const loadDeviceStats = async () => {
    const daysAgo = parseInt(dateRange.replace('d', ''));
    const startDate = new Date();
    startDate.setDate(startDate.getDate() - daysAgo);

    let query = supabase
      .from('sys_link_visits')
      .select('device_type')
      .eq('domain_id', domain.id)
      .gte('visited_at', startDate.toISOString());

    if (selectedLink) {
      query = query.eq('link_id', selectedLink);
    }

    const { data, error } = await query;

    if (!error && data) {
      const deviceCounts = data.reduce((acc, visit) => {
        const device = visit.device_type || 'unknown';
        acc[device] = (acc[device] || 0) + 1;
        return acc;
      }, {});

      const deviceNames = {
        desktop: '桌面',
        mobile: '手机',
        tablet: '平板',
        bot: '机器人',
        other: '其他'
      };

      setDeviceData(
        Object.entries(deviceCounts).map(([name, value]) => ({
          name: deviceNames[name] || name,
          value
        }))
      );
    }
  };

  const loadCountryStats = async () => {
    const daysAgo = parseInt(dateRange.replace('d', ''));
    const startDate = new Date();
    startDate.setDate(startDate.getDate() - daysAgo);

    let query = supabase
      .from('sys_link_visits')
      .select('visitor_country')
      .eq('domain_id', domain.id)
      .gte('visited_at', startDate.toISOString())
      .not('visitor_country', 'is', null);

    if (selectedLink) {
      query = query.eq('link_id', selectedLink);
    }

    const { data, error } = await query;

    if (!error && data) {
      const countryCounts = data.reduce((acc, visit) => {
        const country = visit.visitor_country || 'Unknown';
        acc[country] = (acc[country] || 0) + 1;
        return acc;
      }, {});

      setCountryData(
        Object.entries(countryCounts)
          .map(([name, value]) => ({ name, value }))
          .sort((a, b) => b.value - a.value)
          .slice(0, 10)
      );
    }
  };

  const loadBrowserStats = async () => {
    const daysAgo = parseInt(dateRange.replace('d', ''));
    const startDate = new Date();
    startDate.setDate(startDate.getDate() - daysAgo);

    let query = supabase
      .from('sys_link_visits')
      .select('browser')
      .eq('domain_id', domain.id)
      .gte('visited_at', startDate.toISOString())
      .not('browser', 'is', null);

    if (selectedLink) {
      query = query.eq('link_id', selectedLink);
    }

    const { data, error } = await query;

    if (!error && data) {
      const browserCounts = data.reduce((acc, visit) => {
        const browser = visit.browser || 'Other';
        acc[browser] = (acc[browser] || 0) + 1;
        return acc;
      }, {});

      setBrowserData(
        Object.entries(browserCounts)
          .map(([name, value]) => ({ name, value }))
          .sort((a, b) => b.value - a.value)
          .slice(0, 5)
      );
    }
  };

  const loadTopLinks = async () => {
    const daysAgo = parseInt(dateRange.replace('d', ''));
    const startDate = new Date();
    startDate.setDate(startDate.getDate() - daysAgo);

    const { data: visits, error } = await supabase
      .from('sys_link_visits')
      .select('link_id')
      .eq('domain_id', domain.id)
      .gte('visited_at', startDate.toISOString());

    if (error || !visits) return;

    const linkCounts = visits.reduce((acc, visit) => {
      acc[visit.link_id] = (acc[visit.link_id] || 0) + 1;
      return acc;
    }, {});

    const { data: linksData } = await supabase
      .from('sys_tracked_links')
      .select('id, title, short_code')
      .in('id', Object.keys(linkCounts));

    if (linksData) {
      const topLinksData = linksData
        .map(link => ({
          ...link,
          clicks: linkCounts[link.id] || 0
        }))
        .sort((a, b) => b.clicks - a.clicks)
        .slice(0, 5);

      setTopLinks(topLinksData);
    }
  };

  if (loading) {
    return <div className="p-6">加载中...</div>;
  }

  if (!hasPermission) {
    return (
      <div className="p-6">
        <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-6 text-center">
          <Eye className="w-12 h-12 text-yellow-600 mx-auto mb-3" />
          <h3 className="text-lg font-semibold text-gray-900 mb-2">无权限访问</h3>
          <p className="text-gray-600">
            您没有权限查看统计分析数据，请联系超级管理员授予权限。
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="p-6">
      <div className="mb-6 flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900 flex items-center gap-2">
            <BarChart3 className="w-6 h-6" />
            链接统计分析
          </h1>
          <p className="text-sm text-gray-600 mt-1">
            查看链接访问数据和用户行为分析
          </p>
        </div>
        <div className="flex gap-3">
          <select
            value={selectedLink || ''}
            onChange={(e) => setSelectedLink(e.target.value || null)}
            className="px-4 py-2 border rounded-lg"
          >
            <option value="">所有链接</option>
            {links.map((link) => (
              <option key={link.id} value={link.id}>
                {link.title}
              </option>
            ))}
          </select>
          <select
            value={dateRange}
            onChange={(e) => setDateRange(e.target.value)}
            className="px-4 py-2 border rounded-lg"
          >
            <option value="7d">最近7天</option>
            <option value="30d">最近30天</option>
            <option value="90d">最近90天</option>
          </select>
        </div>
      </div>

      <div className="grid grid-cols-4 gap-4 mb-6">
        <div className="bg-white rounded-lg shadow-md p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">总点击数</p>
              <p className="text-2xl font-bold text-gray-900 mt-1">{stats.totalClicks.toLocaleString()}</p>
            </div>
            <div className="p-3 bg-blue-100 rounded-lg">
              <TrendingUp className="w-6 h-6 text-blue-600" />
            </div>
          </div>
        </div>

        <div className="bg-white rounded-lg shadow-md p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">独立访客</p>
              <p className="text-2xl font-bold text-gray-900 mt-1">{stats.uniqueVisitors.toLocaleString()}</p>
            </div>
            <div className="p-3 bg-green-100 rounded-lg">
              <Users className="w-6 h-6 text-green-600" />
            </div>
          </div>
        </div>

        <div className="bg-white rounded-lg shadow-md p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">转化率</p>
              <p className="text-2xl font-bold text-gray-900 mt-1">{stats.conversionRate}%</p>
            </div>
            <div className="p-3 bg-purple-100 rounded-lg">
              <BarChart3 className="w-6 h-6 text-purple-600" />
            </div>
          </div>
        </div>

        <div className="bg-white rounded-lg shadow-md p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">平均停留</p>
              <p className="text-2xl font-bold text-gray-900 mt-1">{stats.avgDuration}s</p>
            </div>
            <div className="p-3 bg-orange-100 rounded-lg">
              <Calendar className="w-6 h-6 text-orange-600" />
            </div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-6 mb-6">
        <div className="bg-white rounded-lg shadow-md p-6">
          <h3 className="text-lg font-semibold mb-4">点击趋势</h3>
          <ResponsiveContainer width="100%" height={300}>
            <LineChart data={clicksTrend}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="date" />
              <YAxis />
              <Tooltip />
              <Legend />
              <Line type="monotone" dataKey="clicks" stroke="#3b82f6" name="总点击" />
              <Line type="monotone" dataKey="unique" stroke="#10b981" name="独立访客" />
            </LineChart>
          </ResponsiveContainer>
        </div>

        <div className="bg-white rounded-lg shadow-md p-6">
          <h3 className="text-lg font-semibold mb-4">设备分布</h3>
          <ResponsiveContainer width="100%" height={300}>
            <PieChart>
              <Pie
                data={deviceData}
                cx="50%"
                cy="50%"
                labelLine={false}
                label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                outerRadius={80}
                fill="#8884d8"
                dataKey="value"
              >
                {deviceData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                ))}
              </Pie>
              <Tooltip />
            </PieChart>
          </ResponsiveContainer>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-6 mb-6">
        <div className="bg-white rounded-lg shadow-md p-6">
          <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
            <Globe className="w-5 h-5" />
            访客地区 Top 10
          </h3>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={countryData} layout="horizontal">
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis type="number" />
              <YAxis dataKey="name" type="category" width={80} />
              <Tooltip />
              <Bar dataKey="value" fill="#3b82f6" />
            </BarChart>
          </ResponsiveContainer>
        </div>

        <div className="bg-white rounded-lg shadow-md p-6">
          <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
            <Monitor className="w-5 h-5" />
            浏览器分布
          </h3>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={browserData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="name" />
              <YAxis />
              <Tooltip />
              <Bar dataKey="value" fill="#10b981" />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      <div className="bg-white rounded-lg shadow-md p-6">
        <h3 className="text-lg font-semibold mb-4">热门链接 Top 5</h3>
        <div className="space-y-3">
          {topLinks.map((link, index) => (
            <div key={link.id} className="flex items-center gap-4 p-3 bg-gray-50 rounded-lg">
              <div className="flex-shrink-0 w-8 h-8 flex items-center justify-center bg-blue-100 text-blue-600 rounded-full font-semibold">
                {index + 1}
              </div>
              <div className="flex-1">
                <div className="font-medium text-gray-900">{link.title}</div>
                <div className="text-xs text-gray-500">{link.short_code}</div>
              </div>
              <div className="text-right">
                <div className="text-lg font-semibold text-gray-900">{link.clicks.toLocaleString()}</div>
                <div className="text-xs text-gray-500">点击</div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
