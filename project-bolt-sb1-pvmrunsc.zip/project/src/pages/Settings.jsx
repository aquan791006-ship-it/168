import React, { useState, useEffect } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { Lock, User, Save, Check, Users, Plus, Trash2, Shield, Mail, Phone, UserCog, AlertCircle, Bell, CreditCard, Wallet } from 'lucide-react';
import { supabase } from '../lib/supabase';
import Modal from '../components/Modal';
import ConfirmDialog from '../components/ConfirmDialog';
import AnnouncementManager from '../components/AnnouncementManager';
import PaymentMethodsManager from '../components/PaymentMethodsManager';
import PaymentAccountsManager from '../components/PaymentAccountsManager';

export default function Settings() {
  const { admin } = useAuth();
  const [activeTab, setActiveTab] = useState('profile');
  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState({ type: '', text: '' });

  const [admins, setAdmins] = useState([]);
  const [roles, setRoles] = useState([]);
  const [loadingAdmins, setLoadingAdmins] = useState(false);
  const [showAddModal, setShowAddModal] = useState(false);
  const [deleteConfirm, setDeleteConfirm] = useState({ show: false, adminId: null, adminName: '' });

  const [newAdmin, setNewAdmin] = useState({
    email: '',
    password: '',
    full_name: '',
    phone: '',
    role_id: '',
    is_super_admin: false
  });

  useEffect(() => {
    if (activeTab === 'admins' && admin?.is_super_admin) {
      loadAdmins();
      loadRoles();
    }
  }, [activeTab, admin]);

  const loadAdmins = async () => {
    setLoadingAdmins(true);
    try {
      const { data, error } = await supabase.rpc('get_all_admins');
      if (error) throw error;
      setAdmins(data || []);
    } catch (error) {
      console.error('Error loading admins:', error);
    } finally {
      setLoadingAdmins(false);
    }
  };

  const loadRoles = async () => {
    try {
      const { data, error } = await supabase.rpc('get_all_roles');
      if (error) throw error;
      setRoles(data || []);
    } catch (error) {
      console.error('Error loading roles:', error);
    }
  };

  const handlePasswordChange = async (e) => {
    e.preventDefault();
    setMessage({ type: '', text: '' });

    if (newPassword !== confirmPassword) {
      setMessage({ type: 'error', text: '两次输入的新密码不一致' });
      return;
    }

    if (newPassword.length < 6) {
      setMessage({ type: 'error', text: '新密码长度至少为6位' });
      return;
    }

    setLoading(true);

    try {
      const apiUrl = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/change-password`;
      const response = await fetch(apiUrl, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${import.meta.env.VITE_SUPABASE_ANON_KEY}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          email: admin.email,
          currentPassword,
          newPassword
        })
      });

      const data = await response.json();

      if (response.ok) {
        setMessage({ type: 'success', text: '密码修改成功' });
        setCurrentPassword('');
        setNewPassword('');
        setConfirmPassword('');
      } else {
        setMessage({ type: 'error', text: data.error || '密码修改失败' });
      }
    } catch (error) {
      setMessage({ type: 'error', text: '网络错误，请稍后重试' });
    } finally {
      setLoading(false);
    }
  };

  const handleAddAdmin = async (e) => {
    e.preventDefault();
    setLoading(true);

    try {
      const { data, error } = await supabase.rpc('add_new_admin', {
        p_email: newAdmin.email,
        p_password: newAdmin.password,
        p_full_name: newAdmin.full_name,
        p_phone: newAdmin.phone || null,
        p_role_id: newAdmin.role_id || null,
        p_is_super_admin: newAdmin.is_super_admin
      });

      if (error) throw error;

      if (data.success) {
        setMessage({ type: 'success', text: '管理员添加成功' });
        setShowAddModal(false);
        setNewAdmin({
          email: '',
          password: '',
          full_name: '',
          phone: '',
          role_id: '',
          is_super_admin: false
        });
        loadAdmins();
      } else {
        setMessage({ type: 'error', text: data.error || '添加失败' });
      }
    } catch (error) {
      setMessage({ type: 'error', text: '添加失败：' + error.message });
    } finally {
      setLoading(false);
    }
  };

  const handleDeleteAdmin = async () => {
    setLoading(true);
    try {
      const { data, error } = await supabase.rpc('delete_admin', {
        p_admin_id: deleteConfirm.adminId,
        p_operator_email: admin.email
      });

      if (error) throw error;

      if (data.success) {
        setMessage({ type: 'success', text: '管理员删除成功' });
        setDeleteConfirm({ show: false, adminId: null, adminName: '' });
        loadAdmins();
      } else {
        setMessage({ type: 'error', text: data.error || '删除失败' });
      }
    } catch (error) {
      setMessage({ type: 'error', text: '删除失败：' + error.message });
    } finally {
      setLoading(false);
    }
  };

  const handleStatusChange = async (adminId, newStatus) => {
    try {
      const { data, error } = await supabase.rpc('update_admin_status', {
        p_admin_id: adminId,
        p_status: newStatus,
        p_operator_email: admin.email
      });

      if (error) throw error;

      if (data.success) {
        setMessage({ type: 'success', text: '状态更新成功' });
        loadAdmins();
      } else {
        setMessage({ type: 'error', text: data.error || '更新失败' });
      }
    } catch (error) {
      setMessage({ type: 'error', text: '更新失败：' + error.message });
    }
  };

  const tabs = [
    { id: 'profile', name: '基本信息', icon: User },
    { id: 'password', name: '修改密码', icon: Lock },
    ...(admin?.is_super_admin ? [
      { id: 'admins', name: '管理员管理', icon: Users },
      { id: 'payment_methods', name: '付款方式', icon: CreditCard },
      { id: 'payment_accounts', name: '收款账号', icon: Wallet },
      { id: 'announcements', name: '弹窗公告', icon: Bell }
    ] : [])
  ];

  const getStatusBadge = (status) => {
    const statusConfig = {
      active: { text: '正常', className: 'bg-green-100 text-green-800' },
      suspended: { text: '暂停', className: 'bg-yellow-100 text-yellow-800' },
      inactive: { text: '停用', className: 'bg-gray-100 text-gray-800' }
    };
    const config = statusConfig[status] || statusConfig.inactive;
    return (
      <span className={`px-2 py-1 rounded-full text-xs font-medium ${config.className}`}>
        {config.text}
      </span>
    );
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-gray-900">系统设置</h1>
        <p className="text-gray-600 mt-1">管理您的账户信息和安全设置</p>
      </div>

      {message.text && (
        <div
          className={`p-4 rounded-lg flex items-center gap-2 ${
            message.type === 'success'
              ? 'bg-green-50 text-green-800 border border-green-200'
              : 'bg-red-50 text-red-800 border border-red-200'
          }`}
        >
          {message.type === 'success' ? <Check className="w-5 h-5" /> : <AlertCircle className="w-5 h-5" />}
          <span>{message.text}</span>
        </div>
      )}

      <div className="bg-white rounded-lg shadow-sm border border-gray-200">
        <div className="border-b border-gray-200">
          <nav className="flex -mb-px">
            {tabs.map((tab) => {
              const Icon = tab.icon;
              return (
                <button
                  key={tab.id}
                  onClick={() => {
                    setActiveTab(tab.id);
                    setMessage({ type: '', text: '' });
                  }}
                  className={`flex items-center gap-2 px-6 py-4 border-b-2 font-medium text-sm transition-colors ${
                    activeTab === tab.id
                      ? 'border-blue-500 text-blue-600'
                      : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                  }`}
                >
                  <Icon className="w-5 h-5" />
                  {tab.name}
                </button>
              );
            })}
          </nav>
        </div>

        <div className="p-6">
          {activeTab === 'profile' && (
            <div className="max-w-2xl space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  姓名
                </label>
                <input
                  type="text"
                  value={admin?.full_name || ''}
                  disabled
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg bg-gray-50 text-gray-500 cursor-not-allowed"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  邮箱
                </label>
                <input
                  type="email"
                  value={admin?.email || ''}
                  disabled
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg bg-gray-50 text-gray-500 cursor-not-allowed"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  权限级别
                </label>
                <div className="flex items-center gap-2">
                  <input
                    type="text"
                    value={admin?.role || 'admin'}
                    disabled
                    className="flex-1 px-4 py-2 border border-gray-300 rounded-lg bg-gray-50 text-gray-500 cursor-not-allowed"
                  />
                  {admin?.is_super_admin && (
                    <span className="flex items-center gap-1 px-3 py-2 bg-purple-100 text-purple-800 rounded-lg text-sm font-medium">
                      <Shield className="w-4 h-4" />
                      超级管理员
                    </span>
                  )}
                </div>
              </div>
            </div>
          )}

          {activeTab === 'password' && (
            <div className="max-w-2xl">
              <form onSubmit={handlePasswordChange} className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    当前密码
                  </label>
                  <input
                    type="password"
                    value={currentPassword}
                    onChange={(e) => setCurrentPassword(e.target.value)}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    placeholder="请输入当前密码"
                    required
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    新密码
                  </label>
                  <input
                    type="password"
                    value={newPassword}
                    onChange={(e) => setNewPassword(e.target.value)}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    placeholder="请输入新密码（至少6位）"
                    required
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    确认新密码
                  </label>
                  <input
                    type="password"
                    value={confirmPassword}
                    onChange={(e) => setConfirmPassword(e.target.value)}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    placeholder="请再次输入新密码"
                    required
                  />
                </div>

                <div className="bg-blue-50 rounded-lg border border-blue-200 p-4">
                  <h3 className="font-semibold text-blue-900 mb-2">密码安全提示</h3>
                  <ul className="text-sm text-blue-800 space-y-1">
                    <li>• 密码长度至少6位字符</li>
                    <li>• 建议包含字母和数字</li>
                    <li>• 定期更换密码</li>
                    <li>• 不要使用简单密码</li>
                  </ul>
                </div>

                <button
                  type="submit"
                  disabled={loading}
                  className="w-full flex items-center justify-center gap-2 bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors disabled:bg-gray-400 disabled:cursor-not-allowed"
                >
                  {loading ? (
                    <>
                      <div className="animate-spin rounded-full h-5 w-5 border-2 border-white border-t-transparent" />
                      <span>保存中...</span>
                    </>
                  ) : (
                    <>
                      <Save className="w-5 h-5" />
                      <span>保存密码</span>
                    </>
                  )}
                </button>
              </form>
            </div>
          )}

          {activeTab === 'admins' && admin?.is_super_admin && (
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <div>
                  <h2 className="text-lg font-semibold text-gray-900">管理员列表</h2>
                  <p className="text-sm text-gray-600">管理系统的所有管理员账户</p>
                </div>
                <button
                  onClick={() => setShowAddModal(true)}
                  className="flex items-center gap-2 bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors"
                >
                  <Plus className="w-5 h-5" />
                  添加管理员
                </button>
              </div>

              {loadingAdmins ? (
                <div className="flex items-center justify-center py-12">
                  <div className="animate-spin rounded-full h-8 w-8 border-2 border-blue-600 border-t-transparent" />
                </div>
              ) : (
                <div className="overflow-x-auto">
                  <table className="min-w-full divide-y divide-gray-200">
                    <thead className="bg-gray-50">
                      <tr>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          姓名/邮箱
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          联系方式
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          角色
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          状态
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          最后登录
                        </th>
                        <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                          操作
                        </th>
                      </tr>
                    </thead>
                    <tbody className="bg-white divide-y divide-gray-200">
                      {admins.map((adminUser) => (
                        <tr key={adminUser.id}>
                          <td className="px-6 py-4 whitespace-nowrap">
                            <div className="flex items-center">
                              <div>
                                <div className="text-sm font-medium text-gray-900 flex items-center gap-2">
                                  {adminUser.full_name}
                                  {adminUser.is_super_admin && (
                                    <Shield className="w-4 h-4 text-purple-600" />
                                  )}
                                </div>
                                <div className="text-sm text-gray-500">{adminUser.email}</div>
                              </div>
                            </div>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                            {adminUser.phone || '-'}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                            {adminUser.role_name || '-'}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap">
                            {getStatusBadge(adminUser.status)}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                            {adminUser.last_login_at
                              ? new Date(adminUser.last_login_at).toLocaleDateString('zh-CN')
                              : '-'}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                            {adminUser.id !== admin.id && (
                              <button
                                onClick={() =>
                                  setDeleteConfirm({
                                    show: true,
                                    adminId: adminUser.id,
                                    adminName: adminUser.full_name
                                  })
                                }
                                className="text-red-600 hover:text-red-900 transition-colors"
                              >
                                <Trash2 className="w-5 h-5" />
                              </button>
                            )}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          )}

          {activeTab === 'payment_methods' && admin?.is_super_admin && (
            <PaymentMethodsManager domainId={admin.domain_id} />
          )}

          {activeTab === 'payment_accounts' && admin?.is_super_admin && (
            <PaymentAccountsManager domainId={admin.domain_id} />
          )}

          {activeTab === 'announcements' && admin?.is_super_admin && (
            <AnnouncementManager domainId={admin.domain_id} />
          )}
        </div>
      </div>

      {showAddModal && (
        <Modal
          isOpen={showAddModal}
          onClose={() => setShowAddModal(false)}
          title="添加管理员"
        >
          <form onSubmit={handleAddAdmin} className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                姓名 *
              </label>
              <input
                type="text"
                value={newAdmin.full_name}
                onChange={(e) => setNewAdmin({ ...newAdmin, full_name: e.target.value })}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                placeholder="请输入姓名"
                required
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                邮箱 *
              </label>
              <input
                type="email"
                value={newAdmin.email}
                onChange={(e) => setNewAdmin({ ...newAdmin, email: e.target.value })}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                placeholder="请输入邮箱"
                required
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                密码 *
              </label>
              <input
                type="password"
                value={newAdmin.password}
                onChange={(e) => setNewAdmin({ ...newAdmin, password: e.target.value })}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                placeholder="请输入密码（至少6位）"
                required
                minLength={6}
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                手机号
              </label>
              <input
                type="tel"
                value={newAdmin.phone}
                onChange={(e) => setNewAdmin({ ...newAdmin, phone: e.target.value })}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                placeholder="请输入手机号"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                角色
              </label>
              <select
                value={newAdmin.role_id}
                onChange={(e) => setNewAdmin({ ...newAdmin, role_id: e.target.value })}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              >
                <option value="">选择角色</option>
                {roles.map((role) => (
                  <option key={role.id} value={role.id}>
                    {role.display_name || role.name}
                  </option>
                ))}
              </select>
            </div>

            <div className="flex items-center gap-2">
              <input
                type="checkbox"
                id="is_super_admin"
                checked={newAdmin.is_super_admin}
                onChange={(e) => setNewAdmin({ ...newAdmin, is_super_admin: e.target.checked })}
                className="w-4 h-4 text-blue-600 border-gray-300 rounded focus:ring-blue-500"
              />
              <label htmlFor="is_super_admin" className="text-sm font-medium text-gray-700">
                设为超级管理员
              </label>
            </div>

            <div className="flex gap-3 pt-4">
              <button
                type="button"
                onClick={() => setShowAddModal(false)}
                className="flex-1 px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50 transition-colors"
              >
                取消
              </button>
              <button
                type="submit"
                disabled={loading}
                className="flex-1 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors disabled:bg-gray-400 disabled:cursor-not-allowed"
              >
                {loading ? '添加中...' : '添加'}
              </button>
            </div>
          </form>
        </Modal>
      )}

      {deleteConfirm.show && (
        <ConfirmDialog
          isOpen={deleteConfirm.show}
          onClose={() => setDeleteConfirm({ show: false, adminId: null, adminName: '' })}
          onConfirm={handleDeleteAdmin}
          title="删除管理员"
          message={`确定要删除管理员"${deleteConfirm.adminName}"吗？此操作无法撤销。`}
          confirmText="删除"
          type="danger"
        />
      )}
    </div>
  );
}
