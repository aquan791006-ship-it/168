import React from 'react';
import { Gift } from 'lucide-react';

export default function Promotions() {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-gray-900">促销活动模块管理</h1>
        <p className="text-gray-500 mt-1">管理促销活动和优惠券</p>
      </div>

      <div className="bg-white rounded-xl border border-gray-200 p-12 text-center">
        <Gift className="w-12 h-12 text-gray-400 mx-auto mb-3" />
        <p className="text-gray-500">营销活动功能开发中</p>
      </div>
    </div>
  );
}
