import { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import { useToast } from '../contexts/ToastContext';
import { AlertTriangle, CheckCircle, ShoppingCart, X, TrendingDown, Package } from 'lucide-react';

export default function StockAlerts() {
  const [alerts, setAlerts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [stats, setStats] = useState({ total: 0, critical: 0, high: 0, medium: 0 });
  const { showToast } = useToast();

  useEffect(() => {
    loadAlerts();
  }, []);

  const loadAlerts = async () => {
    try {
      setLoading(true);
      const { data, error } = await supabase
        .from('wms_stock_alerts')
        .select(`
          *,
          inventory:wms_inventory(
            id,
            quantity,
            available_quantity,
            locked_quantity,
            alert_threshold,
            warehouse:wms_warehouses(name, code),
            product:sys_products(
              id,
              title,
              base_price,
              metadata
            )
          ),
          triggered_purchase_order:pur_purchase_orders(
            id,
            po_number,
            status,
            total_amount
          )
        `)
        .eq('status', 'active')
        .order('priority', { ascending: false })
        .order('created_at', { ascending: false });

      if (error) throw error;

      setAlerts(data || []);

      const stats = {
        total: data?.length || 0,
        critical: data?.filter(a => a.priority === 'critical').length || 0,
        high: data?.filter(a => a.priority === 'high').length || 0,
        medium: data?.filter(a => a.priority === 'medium').length || 0
      };
      setStats(stats);
    } catch (error) {
      showToast('加载预警失败: ' + error.message, 'error');
    } finally {
      setLoading(false);
    }
  };

  const handleAutoReplenish = async (alert) => {
    try {
      const { data, error } = await supabase.rpc('trigger_auto_replenishment', {
        p_alert_id: alert.id
      });

      if (error) throw error;

      showToast('自动补货采购单已创建: PO-' + data?.substring(0, 8), 'success');
      loadAlerts();
    } catch (error) {
      showToast('自动补货失败: ' + error.message, 'error');
    }
  };

  const handleResolveAlert = async (alertId) => {
    try {
      const { error } = await supabase
        .from('wms_stock_alerts')
        .update({
          status: 'resolved',
          resolved_at: new Date().toISOString()
        })
        .eq('id', alertId);

      if (error) throw error;

      showToast('预警已标记为已解决', 'success');
      loadAlerts();
    } catch (error) {
      showToast('操作失败: ' + error.message, 'error');
    }
  };

  const getPriorityColor = (priority) => {
    switch (priority) {
      case 'critical':
        return 'border-red-500 bg-red-50';
      case 'high':
        return 'border-orange-500 bg-orange-50';
      case 'medium':
        return 'border-yellow-500 bg-yellow-50';
      default:
        return 'border-gray-300 bg-gray-50';
    }
  };

  const getPriorityBadge = (priority) => {
    const badges = {
      critical: { text: '紧急', className: 'bg-red-100 text-red-800' },
      high: { text: '高', className: 'bg-orange-100 text-orange-800' },
      medium: { text: '中', className: 'bg-yellow-100 text-yellow-800' },
      low: { text: '低', className: 'bg-gray-100 text-gray-800' }
    };
    const badge = badges[priority] || badges.low;
    return (
      <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${badge.className}`}>
        {badge.text}
      </span>
    );
  };

  const getAlertTypeText = (type) => {
    return type === 'out_of_stock' ? '缺货' : '库存不足';
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-gray-500">加载中...</div>
      </div>
    );
  }

  return (
    <div className="p-6">
      <div className="mb-6">
        <div className="flex items-center gap-2 mb-2">
          <AlertTriangle className="w-6 h-6 text-orange-600" />
          <h1 className="text-2xl font-bold text-gray-900">库存预警模块管理</h1>
        </div>
        <p className="text-gray-600">
          实时监控库存情况，当库存低于阈值时自动预警并支持一键补货
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
        <div className="bg-white rounded-lg shadow p-6">
          <div className="flex items-center justify-between">
            <div>
              <div className="text-gray-500 text-sm">总预警数</div>
              <div className="text-2xl font-bold text-gray-900 mt-1">{stats.total}</div>
            </div>
            <AlertTriangle className="w-10 h-10 text-gray-400 opacity-20" />
          </div>
        </div>
        <div className="bg-white rounded-lg shadow p-6">
          <div className="flex items-center justify-between">
            <div>
              <div className="text-gray-500 text-sm">紧急</div>
              <div className="text-2xl font-bold text-red-600 mt-1">{stats.critical}</div>
            </div>
            <TrendingDown className="w-10 h-10 text-red-500 opacity-20" />
          </div>
        </div>
        <div className="bg-white rounded-lg shadow p-6">
          <div className="flex items-center justify-between">
            <div>
              <div className="text-gray-500 text-sm">高优先级</div>
              <div className="text-2xl font-bold text-orange-600 mt-1">{stats.high}</div>
            </div>
            <AlertTriangle className="w-10 h-10 text-orange-500 opacity-20" />
          </div>
        </div>
        <div className="bg-white rounded-lg shadow p-6">
          <div className="flex items-center justify-between">
            <div>
              <div className="text-gray-500 text-sm">中优先级</div>
              <div className="text-2xl font-bold text-yellow-600 mt-1">{stats.medium}</div>
            </div>
            <Package className="w-10 h-10 text-yellow-500 opacity-20" />
          </div>
        </div>
      </div>

      <div className="space-y-4">
        {alerts.map((alert) => (
          <div
            key={alert.id}
            className={`border-l-4 rounded-lg p-6 shadow ${getPriorityColor(alert.priority)}`}
          >
            <div className="flex items-start justify-between">
              <div className="flex-1">
                <div className="flex items-center gap-3 mb-3">
                  <AlertTriangle className={`w-6 h-6 ${
                    alert.priority === 'critical' ? 'text-red-600' :
                    alert.priority === 'high' ? 'text-orange-600' : 'text-yellow-600'
                  }`} />
                  <div>
                    <h3 className="text-lg font-semibold text-gray-900">
                      {alert.inventory?.product?.title?.zh || '未知商品'}
                    </h3>
                    <div className="flex items-center gap-2 mt-1">
                      {getPriorityBadge(alert.priority)}
                      <span className="text-sm text-gray-600">
                        {getAlertTypeText(alert.alert_type)}
                      </span>
                      <span className="text-xs text-gray-500">
                        • {alert.inventory?.warehouse?.name}
                      </span>
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-4">
                  <div className="bg-white rounded-lg p-3 shadow-sm">
                    <div className="text-xs text-gray-500 mb-1">当前库存</div>
                    <div className="text-lg font-bold text-red-600">
                      {alert.current_quantity}
                    </div>
                  </div>
                  <div className="bg-white rounded-lg p-3 shadow-sm">
                    <div className="text-xs text-gray-500 mb-1">可用库存</div>
                    <div className="text-lg font-bold text-orange-600">
                      {alert.inventory?.available_quantity}
                    </div>
                  </div>
                  <div className="bg-white rounded-lg p-3 shadow-sm">
                    <div className="text-xs text-gray-500 mb-1">预警阈值</div>
                    <div className="text-lg font-bold text-gray-900">
                      {alert.threshold_quantity}
                    </div>
                  </div>
                  <div className="bg-white rounded-lg p-3 shadow-sm">
                    <div className="text-xs text-gray-500 mb-1">锁定库存</div>
                    <div className="text-lg font-bold text-blue-600">
                      {alert.inventory?.locked_quantity}
                    </div>
                  </div>
                </div>

                {alert.replenish_triggered && alert.triggered_purchase_order && (
                  <div className="bg-blue-50 border border-blue-200 rounded-lg p-3 mb-3">
                    <div className="flex items-center gap-2 text-sm text-blue-900">
                      <CheckCircle className="w-4 h-4" />
                      <span>
                        已触发自动补货 - 采购单号: {alert.triggered_purchase_order.po_number}
                        (状态: {alert.triggered_purchase_order.status})
                      </span>
                    </div>
                    <div className="text-xs text-blue-700 mt-1">
                      建议补货数量: {alert.replenish_quantity} •
                      采购金额: ¥{alert.triggered_purchase_order.total_amount?.toFixed(2)}
                    </div>
                  </div>
                )}

                <div className="text-xs text-gray-500">
                  预警时间: {new Date(alert.created_at).toLocaleString('zh-CN')}
                </div>
              </div>

              <div className="flex flex-col gap-2 ml-4">
                {!alert.replenish_triggered && (
                  <button
                    onClick={() => handleAutoReplenish(alert)}
                    className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors text-sm whitespace-nowrap"
                  >
                    <ShoppingCart className="w-4 h-4" />
                    自动补货
                  </button>
                )}
                <button
                  onClick={() => handleResolveAlert(alert.id)}
                  className="flex items-center gap-2 px-4 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 transition-colors text-sm whitespace-nowrap"
                >
                  <CheckCircle className="w-4 h-4" />
                  标记已解决
                </button>
              </div>
            </div>
          </div>
        ))}

        {alerts.length === 0 && (
          <div className="bg-white rounded-lg shadow p-12 text-center">
            <CheckCircle className="w-16 h-16 text-green-500 mx-auto mb-4" />
            <h3 className="text-lg font-semibold text-gray-900 mb-2">暂无库存预警</h3>
            <p className="text-gray-600">所有商品库存充足，系统运行正常</p>
          </div>
        )}
      </div>

      <div className="mt-6 bg-blue-50 border border-blue-200 rounded-lg p-4">
        <h3 className="text-sm font-medium text-blue-900 mb-2">功能说明</h3>
        <ul className="text-sm text-blue-700 space-y-1">
          <li>• 系统自动检测库存低于阈值的商品并生成预警</li>
          <li>• 点击"自动补货"将根据建议数量自动创建采购单</li>
          <li>• 紧急预警（红色）表示商品已缺货，需立即处理</li>
          <li>• 高优先级预警（橙色）表示库存低于阈值50%</li>
          <li>• 中优先级预警（黄色）表示库存低于阈值但高于50%</li>
          <li>• 建议补货数量默认为阈值的3倍，确保库存充足</li>
        </ul>
      </div>
    </div>
  );
}
