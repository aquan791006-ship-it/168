import { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import { useToast } from '../contexts/ToastContext';
import { Settings, Eye, EyeOff, Lock, Unlock } from 'lucide-react';

export default function ProductFieldConfig() {
  const [fieldConfigs, setFieldConfigs] = useState([]);
  const [loading, setLoading] = useState(true);
  const { showToast } = useToast();

  useEffect(() => {
    loadFieldConfigs();
  }, []);

  const loadFieldConfigs = async () => {
    try {
      setLoading(true);
      const { data, error } = await supabase
        .from('sys_product_field_config')
        .select('*')
        .order('sort_order', { ascending: true });

      if (error) throw error;
      setFieldConfigs(data || []);
    } catch (error) {
      showToast('加载字段配置失败: ' + error.message, 'error');
    } finally {
      setLoading(false);
    }
  };

  const handleToggleVisible = async (fieldName, currentValue) => {
    try {
      const { error } = await supabase
        .from('sys_product_field_config')
        .update({ is_visible: !currentValue, updated_at: new Date().toISOString() })
        .eq('field_name', fieldName);

      if (error) throw error;

      showToast('字段显示状态已更新', 'success');
      loadFieldConfigs();
    } catch (error) {
      showToast('更新失败: ' + error.message, 'error');
    }
  };

  const handleToggleRequired = async (fieldName, currentValue, isLocked) => {
    if (isLocked) {
      showToast('该字段为必填项，无法修改', 'warning');
      return;
    }

    try {
      const { error } = await supabase
        .from('sys_product_field_config')
        .update({ is_required: !currentValue, updated_at: new Date().toISOString() })
        .eq('field_name', fieldName);

      if (error) throw error;

      showToast('字段必填状态已更新', 'success');
      loadFieldConfigs();
    } catch (error) {
      showToast('更新失败: ' + error.message, 'error');
    }
  };

  const isLockedField = (fieldName) => {
    return ['main_image', 'price', 'quantity', 'sku'].includes(fieldName);
  };

  const getFieldTypeLabel = (type) => {
    const types = {
      'text': '文本',
      'number': '数字',
      'textarea': '多行文本',
      'select': '下拉选择',
      'image_multi': '多图上传',
      'address': '地址选择'
    };
    return types[type] || type;
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-gray-500">加载中...</div>
      </div>
    );
  }

  return (
    <div className="p-6">
      <div className="mb-6">
        <div className="flex items-center gap-2 mb-2">
          <Settings className="w-6 h-6 text-blue-600" />
          <h1 className="text-2xl font-bold text-gray-900">字段配置模块管理</h1>
        </div>
        <p className="text-gray-600">
          控制商品表单中哪些字段显示/隐藏、必填/选填。主图、价格、数量、SKU为系统锁定的必填项。
        </p>
      </div>

      <div className="bg-white rounded-lg shadow overflow-hidden">
        <table className="min-w-full divide-y divide-gray-200">
          <thead className="bg-gray-50">
            <tr>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                字段名称
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                字段类型
              </th>
              <th className="px-6 py-3 text-center text-xs font-medium text-gray-500 uppercase tracking-wider">
                显示
              </th>
              <th className="px-6 py-3 text-center text-xs font-medium text-gray-500 uppercase tracking-wider">
                必填
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                提示文本
              </th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {fieldConfigs.map((field) => {
              const isLocked = isLockedField(field.field_name);
              return (
                <tr key={field.id} className="hover:bg-gray-50">
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="flex items-center gap-2">
                      <div className="text-sm font-medium text-gray-900">
                        {field.display_name?.zh || field.field_name}
                      </div>
                      {isLocked && (
                        <Lock className="w-4 h-4 text-amber-500" title="系统锁定字段" />
                      )}
                    </div>
                    <div className="text-xs text-gray-500">{field.field_name}</div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className="px-2 py-1 text-xs font-medium bg-blue-100 text-blue-800 rounded">
                      {getFieldTypeLabel(field.field_type)}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-center">
                    <button
                      onClick={() => handleToggleVisible(field.field_name, field.is_visible)}
                      className={`p-2 rounded-lg transition-colors ${
                        field.is_visible
                          ? 'bg-green-100 text-green-600 hover:bg-green-200'
                          : 'bg-gray-100 text-gray-400 hover:bg-gray-200'
                      }`}
                      title={field.is_visible ? '点击隐藏' : '点击显示'}
                    >
                      {field.is_visible ? (
                        <Eye className="w-5 h-5" />
                      ) : (
                        <EyeOff className="w-5 h-5" />
                      )}
                    </button>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-center">
                    <button
                      onClick={() => handleToggleRequired(field.field_name, field.is_required, isLocked)}
                      disabled={isLocked}
                      className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
                        field.is_required
                          ? 'bg-red-100 text-red-700 hover:bg-red-200'
                          : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                      } ${isLocked ? 'opacity-50 cursor-not-allowed' : 'cursor-pointer'}`}
                      title={isLocked ? '系统锁定字段，无法修改' : (field.is_required ? '点击设为选填' : '点击设为必填')}
                    >
                      {field.is_required ? '必填' : '选填'}
                    </button>
                  </td>
                  <td className="px-6 py-4">
                    <div className="text-sm text-gray-900">{field.help_text?.zh || '-'}</div>
                    <div className="text-xs text-gray-500 mt-1">
                      占位符: {field.placeholder?.zh || '-'}
                    </div>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      <div className="mt-6 bg-blue-50 border border-blue-200 rounded-lg p-4">
        <h3 className="text-sm font-medium text-blue-900 mb-2">使用说明</h3>
        <ul className="text-sm text-blue-700 space-y-1">
          <li>• 点击"显示"图标控制字段在表单中是否显示</li>
          <li>• 点击"必填/选填"按钮控制字段是否为必填项</li>
          <li>• 主图、价格、数量、SKU为系统核心字段，始终为必填项</li>
          <li>• 隐藏的字段不会在商品表单中显示，但数据仍然保存</li>
          <li>• 配置修改后立即生效，无需重启系统</li>
        </ul>
      </div>
    </div>
  );
}
