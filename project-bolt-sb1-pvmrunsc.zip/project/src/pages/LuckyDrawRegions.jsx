import { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';
import { Globe, Shield, AlertTriangle, Plus, Edit2, Save, X } from 'lucide-react';
import { useToast } from '../contexts/ToastContext';

export default function LuckyDrawRegions() {
  const { user } = useAuth();
  const { showToast } = useToast();
  const [regions, setRegions] = useState([]);
  const [loading, setLoading] = useState(true);
  const [editingId, setEditingId] = useState(null);
  const [showAddForm, setShowAddForm] = useState(false);
  const [formData, setFormData] = useState({
    country_code: '',
    country_name: '',
    region_code: '',
    region_name: '',
    is_active: false,
    risk_level: 'low',
    max_product_shares: 50000,
    max_user_shares_per_product: 1000,
    daily_user_limit: 10000,
    require_id_verification: false,
    notes: ''
  });

  useEffect(() => {
    if (!user?.is_super_admin) {
      showToast('error', '仅超级管理员可访问此页面');
      return;
    }
    loadRegions();
  }, [user]);

  const loadRegions = async () => {
    try {
      setLoading(true);
      const { data, error } = await supabase
        .from('sys_lucky_draw_allowed_regions')
        .select('*')
        .order('country_name');

      if (error) throw error;
      setRegions(data || []);
    } catch (error) {
      showToast('error', '加载地区列表失败');
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  const handleToggleActive = async (id, currentStatus) => {
    try {
      const { error } = await supabase
        .from('sys_lucky_draw_allowed_regions')
        .update({ is_active: !currentStatus })
        .eq('id', id);

      if (error) throw error;
      showToast('success', !currentStatus ? '地区已启用' : '地区已禁用');
      loadRegions();
    } catch (error) {
      showToast('error', '操作失败');
      console.error(error);
    }
  };

  const handleSave = async (id) => {
    try {
      const regionToUpdate = regions.find(r => r.id === id);
      const { error } = await supabase
        .from('sys_lucky_draw_allowed_regions')
        .update(regionToUpdate)
        .eq('id', id);

      if (error) throw error;
      showToast('success', '保存成功');
      setEditingId(null);
    } catch (error) {
      showToast('error', '保存失败');
      console.error(error);
    }
  };

  const handleAdd = async () => {
    try {
      const { error } = await supabase
        .from('sys_lucky_draw_allowed_regions')
        .insert([{ ...formData, created_by: user.id }]);

      if (error) throw error;
      showToast('success', '地区添加成功');
      setShowAddForm(false);
      setFormData({
        country_code: '',
        country_name: '',
        region_code: '',
        region_name: '',
        is_active: false,
        risk_level: 'low',
        max_product_shares: 50000,
        max_user_shares_per_product: 1000,
        daily_user_limit: 10000,
        require_id_verification: false,
        notes: ''
      });
      loadRegions();
    } catch (error) {
      showToast('error', '添加失败');
      console.error(error);
    }
  };

  const getRiskLevelColor = (level) => {
    switch (level) {
      case 'low': return 'bg-green-100 text-green-800';
      case 'medium': return 'bg-yellow-100 text-yellow-800';
      case 'high': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getRiskLevelText = (level) => {
    switch (level) {
      case 'low': return '低风险';
      case 'medium': return '中等风险';
      case 'high': return '高风险';
      default: return level;
    }
  };

  if (!user?.is_super_admin) {
    return (
      <div className="p-6">
        <div className="bg-red-50 border border-red-200 rounded-lg p-4 text-red-800">
          仅超级管理员可访问此页面
        </div>
      </div>
    );
  }

  if (loading) {
    return <div className="p-6">加载中...</div>;
  }

  return (
    <div className="p-6">
      <div className="mb-6 flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900 flex items-center gap-2">
            <Globe className="w-6 h-6" />
            一元购地区管理
          </h1>
          <p className="text-sm text-gray-600 mt-1">
            配置允许开启一元购功能的国家和地区
          </p>
        </div>
        <button
          onClick={() => setShowAddForm(true)}
          className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
        >
          <Plus className="w-4 h-4" />
          添加地区
        </button>
      </div>

      {showAddForm && (
        <div className="mb-6 bg-white rounded-lg shadow-md p-6">
          <h3 className="text-lg font-semibold mb-4">添加新地区</h3>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                国家代码 *
              </label>
              <input
                type="text"
                value={formData.country_code}
                onChange={(e) => setFormData({ ...formData, country_code: e.target.value.toUpperCase() })}
                className="w-full px-3 py-2 border rounded-lg"
                placeholder="如: MY, TH, VN"
                maxLength={2}
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                国家名称 *
              </label>
              <input
                type="text"
                value={formData.country_name}
                onChange={(e) => setFormData({ ...formData, country_name: e.target.value })}
                className="w-full px-3 py-2 border rounded-lg"
                placeholder="如: 马来西亚"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                风险等级
              </label>
              <select
                value={formData.risk_level}
                onChange={(e) => setFormData({ ...formData, risk_level: e.target.value })}
                className="w-full px-3 py-2 border rounded-lg"
              >
                <option value="low">低风险</option>
                <option value="medium">中等风险</option>
                <option value="high">高风险</option>
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                最大产品份数
              </label>
              <input
                type="number"
                value={formData.max_product_shares}
                onChange={(e) => setFormData({ ...formData, max_product_shares: parseInt(e.target.value) })}
                className="w-full px-3 py-2 border rounded-lg"
              />
            </div>
            <div className="col-span-2">
              <label className="block text-sm font-medium text-gray-700 mb-1">
                备注
              </label>
              <textarea
                value={formData.notes}
                onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                className="w-full px-3 py-2 border rounded-lg"
                rows={2}
              />
            </div>
            <div className="col-span-2 flex items-center gap-4">
              <label className="flex items-center gap-2">
                <input
                  type="checkbox"
                  checked={formData.is_active}
                  onChange={(e) => setFormData({ ...formData, is_active: e.target.checked })}
                  className="rounded"
                />
                <span className="text-sm">启用该地区</span>
              </label>
              <label className="flex items-center gap-2">
                <input
                  type="checkbox"
                  checked={formData.require_id_verification}
                  onChange={(e) => setFormData({ ...formData, require_id_verification: e.target.checked })}
                  className="rounded"
                />
                <span className="text-sm">需要身份验证</span>
              </label>
            </div>
          </div>
          <div className="mt-4 flex gap-2">
            <button
              onClick={handleAdd}
              className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
            >
              添加
            </button>
            <button
              onClick={() => setShowAddForm(false)}
              className="px-4 py-2 bg-gray-200 text-gray-700 rounded-lg hover:bg-gray-300"
            >
              取消
            </button>
          </div>
        </div>
      )}

      <div className="bg-white rounded-lg shadow-md overflow-hidden">
        <table className="w-full">
          <thead className="bg-gray-50 border-b">
            <tr>
              <th className="px-4 py-3 text-left text-sm font-semibold text-gray-900">国家/地区</th>
              <th className="px-4 py-3 text-left text-sm font-semibold text-gray-900">状态</th>
              <th className="px-4 py-3 text-left text-sm font-semibold text-gray-900">风险等级</th>
              <th className="px-4 py-3 text-left text-sm font-semibold text-gray-900">限制参数</th>
              <th className="px-4 py-3 text-left text-sm font-semibold text-gray-900">备注</th>
              <th className="px-4 py-3 text-right text-sm font-semibold text-gray-900">操作</th>
            </tr>
          </thead>
          <tbody className="divide-y">
            {regions.map((region) => (
              <tr key={region.id} className="hover:bg-gray-50">
                <td className="px-4 py-3">
                  <div className="flex items-center gap-2">
                    <Globe className="w-4 h-4 text-gray-400" />
                    <div>
                      <div className="font-medium text-gray-900">
                        {region.country_name}
                      </div>
                      <div className="text-xs text-gray-500">
                        代码: {region.country_code}
                      </div>
                    </div>
                  </div>
                </td>
                <td className="px-4 py-3">
                  <button
                    onClick={() => handleToggleActive(region.id, region.is_active)}
                    className={`px-3 py-1 rounded-full text-xs font-medium ${
                      region.is_active
                        ? 'bg-green-100 text-green-800'
                        : 'bg-gray-100 text-gray-800'
                    }`}
                  >
                    {region.is_active ? '已启用' : '已禁用'}
                  </button>
                </td>
                <td className="px-4 py-3">
                  {editingId === region.id ? (
                    <select
                      value={region.risk_level}
                      onChange={(e) => {
                        const updated = regions.map(r =>
                          r.id === region.id ? { ...r, risk_level: e.target.value } : r
                        );
                        setRegions(updated);
                      }}
                      className="px-2 py-1 border rounded text-sm"
                    >
                      <option value="low">低风险</option>
                      <option value="medium">中等风险</option>
                      <option value="high">高风险</option>
                    </select>
                  ) : (
                    <span className={`inline-flex items-center gap-1 px-3 py-1 rounded-full text-xs font-medium ${getRiskLevelColor(region.risk_level)}`}>
                      <Shield className="w-3 h-3" />
                      {getRiskLevelText(region.risk_level)}
                    </span>
                  )}
                </td>
                <td className="px-4 py-3">
                  {editingId === region.id ? (
                    <div className="space-y-1">
                      <input
                        type="number"
                        value={region.max_product_shares}
                        onChange={(e) => {
                          const updated = regions.map(r =>
                            r.id === region.id ? { ...r, max_product_shares: parseInt(e.target.value) } : r
                          );
                          setRegions(updated);
                        }}
                        className="w-full px-2 py-1 border rounded text-sm"
                        placeholder="最大份数"
                      />
                    </div>
                  ) : (
                    <div className="text-sm text-gray-600">
                      <div>最大份数: {region.max_product_shares?.toLocaleString()}</div>
                      <div>用户限制: {region.max_user_shares_per_product}</div>
                    </div>
                  )}
                </td>
                <td className="px-4 py-3">
                  {editingId === region.id ? (
                    <textarea
                      value={region.notes || ''}
                      onChange={(e) => {
                        const updated = regions.map(r =>
                          r.id === region.id ? { ...r, notes: e.target.value } : r
                        );
                        setRegions(updated);
                      }}
                      className="w-full px-2 py-1 border rounded text-sm"
                      rows={2}
                    />
                  ) : (
                    <div className="text-sm text-gray-600 max-w-xs truncate">
                      {region.notes || '-'}
                    </div>
                  )}
                </td>
                <td className="px-4 py-3 text-right">
                  {editingId === region.id ? (
                    <div className="flex items-center justify-end gap-2">
                      <button
                        onClick={() => handleSave(region.id)}
                        className="p-1 text-green-600 hover:bg-green-50 rounded"
                      >
                        <Save className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => {
                          setEditingId(null);
                          loadRegions();
                        }}
                        className="p-1 text-gray-600 hover:bg-gray-50 rounded"
                      >
                        <X className="w-4 h-4" />
                      </button>
                    </div>
                  ) : (
                    <button
                      onClick={() => setEditingId(region.id)}
                      className="p-1 text-blue-600 hover:bg-blue-50 rounded"
                    >
                      <Edit2 className="w-4 h-4" />
                    </button>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>

        {regions.length === 0 && (
          <div className="p-8 text-center text-gray-500">
            暂无地区配置，请添加允许开启一元购的地区
          </div>
        )}
      </div>

      <div className="mt-6 bg-yellow-50 border border-yellow-200 rounded-lg p-4">
        <div className="flex items-start gap-2">
          <AlertTriangle className="w-5 h-5 text-yellow-600 mt-0.5" />
          <div className="text-sm text-yellow-800">
            <p className="font-medium mb-1">法律合规提醒：</p>
            <ul className="list-disc list-inside space-y-1 text-xs">
              <li>启用新地区前，请确保已获得当地相关许可和资质</li>
              <li>高风险地区需特别审批和更严格的风控措施</li>
              <li>定期审查各地区的法律法规变化</li>
              <li>建议咨询当地法律顾问</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
}
