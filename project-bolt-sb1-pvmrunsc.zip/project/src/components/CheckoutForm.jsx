import React, { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import { X, User, Phone, MessageCircle, MapPin, ChevronDown, ShoppingCart, Send } from 'lucide-react';

const CONTACT_TYPES = [
  { value: 'phone', label: '电话', icon: Phone },
  { value: 'telegram', label: 'Telegram', icon: MessageCircle },
  { value: 'whatsapp', label: 'WhatsApp', icon: MessageCircle },
  { value: 'wechat', label: '微信', icon: MessageCircle }
];

const COUNTRIES = [
  { code: 'CN', name: '中国', nameEn: 'China' },
  { code: 'US', name: '美国', nameEn: 'United States' },
  { code: 'UK', name: '英国', nameEn: 'United Kingdom' },
  { code: 'JP', name: '日本', nameEn: 'Japan' },
  { code: 'KR', name: '韩国', nameEn: 'South Korea' },
  { code: 'SG', name: '新加坡', nameEn: 'Singapore' },
  { code: 'MY', name: '马来西亚', nameEn: 'Malaysia' },
  { code: 'TH', name: '泰国', nameEn: 'Thailand' },
  { code: 'VN', name: '越南', nameEn: 'Vietnam' },
  { code: 'ID', name: '印度尼西亚', nameEn: 'Indonesia' }
];

export default function CheckoutForm({ product, onClose, onSuccess }) {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [ipCountry, setIpCountry] = useState(null);

  const [formData, setFormData] = useState({
    customerName: '',
    contactType: 'phone',
    contactValue: '',
    country: 'CN',
    province: '',
    city: '',
    district: '',
    street: '',
    detailAddress: '',
    notes: ''
  });

  const [provinces, setProvinces] = useState([]);
  const [cities, setCities] = useState([]);
  const [districts, setDistricts] = useState([]);
  const [streets, setStreets] = useState([]);

  useEffect(() => {
    detectCountryByIP();
    loadProvinces();
  }, []);

  const detectCountryByIP = async () => {
    try {
      const response = await fetch('https://ipapi.co/json/');
      const data = await response.json();
      if (data.country_code) {
        setIpCountry(data.country_code);
        const matchedCountry = COUNTRIES.find(c => c.code === data.country_code);
        if (matchedCountry) {
          setFormData(prev => ({ ...prev, country: matchedCountry.code }));
        }
      }
    } catch (error) {
      console.log('IP detection failed, using default country');
    }
  };

  const loadProvinces = async () => {
    try {
      const { data, error } = await supabase
        .from('china_addresses')
        .select('*')
        .eq('level', 'province')
        .eq('is_active', true)
        .order('sort_order');

      if (error) throw error;
      setProvinces(data || []);
    } catch (error) {
      console.error('Error loading provinces:', error);
    }
  };

  const loadCities = async (provinceCode) => {
    try {
      const { data, error } = await supabase
        .from('china_addresses')
        .select('*')
        .eq('level', 'city')
        .eq('parent_code', provinceCode)
        .eq('is_active', true)
        .order('sort_order');

      if (error) throw error;
      setCities(data || []);
    } catch (error) {
      console.error('Error loading cities:', error);
    }
  };

  const loadDistricts = async (cityCode) => {
    try {
      const { data, error } = await supabase
        .from('china_addresses')
        .select('*')
        .eq('level', 'district')
        .eq('parent_code', cityCode)
        .eq('is_active', true)
        .order('sort_order');

      if (error) throw error;
      setDistricts(data || []);
    } catch (error) {
      console.error('Error loading districts:', error);
    }
  };

  const loadStreets = async (districtCode) => {
    try {
      const { data, error } = await supabase
        .from('china_addresses')
        .select('*')
        .eq('level', 'street')
        .eq('parent_code', districtCode)
        .eq('is_active', true)
        .order('sort_order');

      if (error) throw error;
      setStreets(data || []);
    } catch (error) {
      console.error('Error loading streets:', error);
    }
  };

  const handleProvinceChange = (e) => {
    const code = e.target.value;
    const province = provinces.find(p => p.code === code);

    setFormData(prev => ({
      ...prev,
      province: province?.name || '',
      city: '',
      district: '',
      street: ''
    }));

    setCities([]);
    setDistricts([]);
    setStreets([]);

    if (code) loadCities(code);
  };

  const handleCityChange = (e) => {
    const code = e.target.value;
    const city = cities.find(c => c.code === code);

    setFormData(prev => ({
      ...prev,
      city: city?.name || '',
      district: '',
      street: ''
    }));

    setDistricts([]);
    setStreets([]);

    if (code) loadDistricts(code);
  };

  const handleDistrictChange = (e) => {
    const code = e.target.value;
    const district = districts.find(d => d.code === code);

    setFormData(prev => ({
      ...prev,
      district: district?.name || '',
      street: ''
    }));

    setStreets([]);

    if (code) loadStreets(code);
  };

  const handleStreetChange = (e) => {
    const code = e.target.value;
    const street = streets.find(s => s.code === code);

    setFormData(prev => ({
      ...prev,
      street: street?.name || ''
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    try {
      if (!formData.customerName || !formData.contactValue) {
        throw new Error('请填写完整的客户信息');
      }

      if (formData.country === 'CN' && (!formData.province || !formData.city || !formData.district)) {
        throw new Error('请选择完整的配送地址');
      }

      if (!formData.detailAddress) {
        throw new Error('请填写详细地址');
      }

      const country = COUNTRIES.find(c => c.code === formData.country);
      const fullAddress = formData.country === 'CN'
        ? `${country?.name} ${formData.province}${formData.city}${formData.district}${formData.street} ${formData.detailAddress}`
        : `${country?.name} ${formData.detailAddress}`;

      const orderData = {
        order_number: `ORD${Date.now()}`,
        customer_name: formData.customerName,
        customer_phone: formData.contactValue,
        contact_type: formData.contactType,
        shipping_address: fullAddress,
        shipping_country: formData.country,
        shipping_province: formData.province,
        shipping_city: formData.city,
        shipping_district: formData.district,
        shipping_street: formData.street,
        shipping_detail: formData.detailAddress,
        total_amount: product.base_price,
        payment_method: 'cod',
        status: 'pending',
        notes: formData.notes,
        metadata: {
          product_id: product.id,
          product_title: typeof product.title === 'object'
            ? (product.title.zh || product.title.en)
            : product.title,
          product_price: product.base_price,
          detected_ip_country: ipCountry
        }
      };

      const { data, error: insertError } = await supabase
        .from('orders')
        .insert([orderData])
        .select()
        .single();

      if (insertError) throw insertError;

      if (onSuccess) onSuccess(data);
      if (onClose) onClose();

    } catch (err) {
      console.error('Error creating order:', err);
      setError(err.message || '提交订单失败');
    } finally {
      setLoading(false);
    }
  };

  const getTitle = (titleObj) => {
    if (typeof titleObj === 'string') return titleObj;
    return titleObj?.zh || titleObj?.en || '';
  };

  const formatPrice = (price, currency = 'CNY') => {
    const symbols = { CNY: '¥', USD: '$', EUR: '€' };
    return `${symbols[currency] || ''}${parseFloat(price).toFixed(2)}`;
  };

  const SelectedIcon = CONTACT_TYPES.find(t => t.value === formData.contactType)?.icon || Phone;

  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-start justify-center overflow-y-auto p-4">
      <div className="w-full max-w-3xl bg-white rounded-2xl shadow-2xl my-8 animate-scale-in">
        <div className="sticky top-0 bg-gradient-to-r from-teal-500 via-emerald-500 to-cyan-600 text-white px-6 py-4 rounded-t-2xl flex items-center justify-between z-10">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-white/20 rounded-xl flex items-center justify-center">
              <ShoppingCart className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-xl font-bold">确认订单</h2>
              <p className="text-sm text-white/80">填写收货信息</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 hover:bg-white/20 rounded-lg transition-colors"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-6 max-h-[calc(100vh-12rem)] overflow-y-auto custom-scrollbar">
          {error && (
            <div className="bg-red-50 border-2 border-red-200 rounded-xl p-4 flex items-start gap-3">
              <div>
                <p className="font-semibold text-red-700">错误</p>
                <p className="text-sm text-red-600">{error}</p>
              </div>
            </div>
          )}

          {product && (
            <div className="bg-gradient-to-br from-teal-50 to-emerald-50 border-2 border-teal-200 rounded-xl p-4">
              <div className="flex items-center gap-4">
                {product.primaryImage && (
                  <img
                    src={product.primaryImage}
                    alt={getTitle(product.title)}
                    className="w-20 h-20 object-cover rounded-lg"
                  />
                )}
                <div className="flex-1">
                  <h3 className="font-semibold text-gray-900 mb-1">{getTitle(product.title)}</h3>
                  <p className="text-2xl font-black text-teal-600">
                    {formatPrice(product.base_price, product.currency_code)}
                  </p>
                </div>
              </div>
            </div>
          )}

          <div className="bg-gray-50 border-2 border-gray-200 rounded-xl p-5 space-y-4">
            <h3 className="font-semibold text-gray-900 flex items-center gap-2">
              <User className="w-5 h-5 text-teal-600" />
              客户信息
            </h3>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">
                  姓名 <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  value={formData.customerName}
                  onChange={(e) => setFormData({ ...formData, customerName: e.target.value })}
                  placeholder="请输入您的姓名"
                  required
                  className="w-full px-4 py-2.5 border-2 border-gray-200 rounded-lg focus:ring-2 focus:ring-teal-500/20 focus:border-teal-500 transition-all outline-none"
                />
              </div>

              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">
                  联系方式 <span className="text-red-500">*</span>
                </label>
                <div className="flex gap-2">
                  <div className="relative w-32">
                    <select
                      value={formData.contactType}
                      onChange={(e) => setFormData({ ...formData, contactType: e.target.value })}
                      className="w-full px-3 py-2.5 border-2 border-gray-200 rounded-lg focus:ring-2 focus:ring-teal-500/20 focus:border-teal-500 transition-all outline-none appearance-none bg-white pr-8"
                    >
                      {CONTACT_TYPES.map(type => (
                        <option key={type.value} value={type.value}>
                          {type.label}
                        </option>
                      ))}
                    </select>
                    <ChevronDown className="absolute right-2 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400 pointer-events-none" />
                  </div>
                  <div className="flex-1 relative">
                    <SelectedIcon className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                    <input
                      type="text"
                      value={formData.contactValue}
                      onChange={(e) => setFormData({ ...formData, contactValue: e.target.value })}
                      placeholder={`请输入${CONTACT_TYPES.find(t => t.value === formData.contactType)?.label}`}
                      required
                      className="w-full pl-10 pr-4 py-2.5 border-2 border-gray-200 rounded-lg focus:ring-2 focus:ring-teal-500/20 focus:border-teal-500 transition-all outline-none"
                    />
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div className="bg-gray-50 border-2 border-gray-200 rounded-xl p-5 space-y-4">
            <h3 className="font-semibold text-gray-900 flex items-center gap-2">
              <MapPin className="w-5 h-5 text-teal-600" />
              配送地址
            </h3>

            <div className="grid grid-cols-1 md:grid-cols-5 gap-3">
              <div className="relative">
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  国家 <span className="text-red-500">*</span>
                </label>
                <select
                  value={formData.country}
                  onChange={(e) => setFormData({ ...formData, country: e.target.value })}
                  required
                  className="w-full px-3 py-2.5 border-2 border-gray-200 rounded-lg focus:ring-2 focus:ring-teal-500/20 focus:border-teal-500 transition-all outline-none appearance-none bg-white"
                >
                  {COUNTRIES.map(country => (
                    <option key={country.code} value={country.code}>
                      {country.name}
                    </option>
                  ))}
                </select>
                <ChevronDown className="absolute right-2 bottom-3 w-4 h-4 text-gray-400 pointer-events-none" />
              </div>

              {formData.country === 'CN' && (
                <>
                  <div className="relative">
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      省/州 <span className="text-red-500">*</span>
                    </label>
                    <select
                      value={provinces.find(p => p.name === formData.province)?.code || ''}
                      onChange={handleProvinceChange}
                      required
                      className="w-full px-3 py-2.5 border-2 border-gray-200 rounded-lg focus:ring-2 focus:ring-teal-500/20 focus:border-teal-500 transition-all outline-none appearance-none bg-white"
                    >
                      <option value="">选择省份</option>
                      {provinces.map(province => (
                        <option key={province.code} value={province.code}>
                          {province.name}
                        </option>
                      ))}
                    </select>
                    <ChevronDown className="absolute right-2 bottom-3 w-4 h-4 text-gray-400 pointer-events-none" />
                  </div>

                  <div className="relative">
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      市 <span className="text-red-500">*</span>
                    </label>
                    <select
                      value={cities.find(c => c.name === formData.city)?.code || ''}
                      onChange={handleCityChange}
                      disabled={!formData.province}
                      required
                      className="w-full px-3 py-2.5 border-2 border-gray-200 rounded-lg focus:ring-2 focus:ring-teal-500/20 focus:border-teal-500 transition-all outline-none appearance-none bg-white disabled:bg-gray-100"
                    >
                      <option value="">选择城市</option>
                      {cities.map(city => (
                        <option key={city.code} value={city.code}>
                          {city.name}
                        </option>
                      ))}
                    </select>
                    <ChevronDown className="absolute right-2 bottom-3 w-4 h-4 text-gray-400 pointer-events-none" />
                  </div>

                  <div className="relative">
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      县/区 <span className="text-red-500">*</span>
                    </label>
                    <select
                      value={districts.find(d => d.name === formData.district)?.code || ''}
                      onChange={handleDistrictChange}
                      disabled={!formData.city}
                      required
                      className="w-full px-3 py-2.5 border-2 border-gray-200 rounded-lg focus:ring-2 focus:ring-teal-500/20 focus:border-teal-500 transition-all outline-none appearance-none bg-white disabled:bg-gray-100"
                    >
                      <option value="">选择区/县</option>
                      {districts.map(district => (
                        <option key={district.code} value={district.code}>
                          {district.name}
                        </option>
                      ))}
                    </select>
                    <ChevronDown className="absolute right-2 bottom-3 w-4 h-4 text-gray-400 pointer-events-none" />
                  </div>

                  <div className="relative">
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      镇/街道
                    </label>
                    <select
                      value={streets.find(s => s.name === formData.street)?.code || ''}
                      onChange={handleStreetChange}
                      disabled={!formData.district}
                      className="w-full px-3 py-2.5 border-2 border-gray-200 rounded-lg focus:ring-2 focus:ring-teal-500/20 focus:border-teal-500 transition-all outline-none appearance-none bg-white disabled:bg-gray-100"
                    >
                      <option value="">选择街道</option>
                      {streets.map(street => (
                        <option key={street.code} value={street.code}>
                          {street.name}
                        </option>
                      ))}
                    </select>
                    <ChevronDown className="absolute right-2 bottom-3 w-4 h-4 text-gray-400 pointer-events-none" />
                  </div>
                </>
              )}
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                详细地址 <span className="text-red-500">*</span>
              </label>
              <input
                type="text"
                value={formData.detailAddress}
                onChange={(e) => setFormData({ ...formData, detailAddress: e.target.value })}
                placeholder="请输入街道门牌号、楼栋单元等详细地址"
                required
                className="w-full px-4 py-2.5 border-2 border-gray-200 rounded-lg focus:ring-2 focus:ring-teal-500/20 focus:border-teal-500 transition-all outline-none"
              />
            </div>

            {(formData.province || formData.city || formData.detailAddress) && (
              <div className="text-sm text-gray-600 bg-teal-50 border border-teal-200 rounded-lg p-3">
                <span className="font-medium text-teal-700">完整地址：</span>
                {COUNTRIES.find(c => c.code === formData.country)?.name}{' '}
                {formData.province}{formData.city}{formData.district}{formData.street}{' '}
                {formData.detailAddress}
              </div>
            )}
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              备注信息
            </label>
            <textarea
              value={formData.notes}
              onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
              placeholder="如有其他要求或备注，请在此填写"
              rows={3}
              className="w-full px-4 py-2.5 border-2 border-gray-200 rounded-lg focus:ring-2 focus:ring-teal-500/20 focus:border-teal-500 transition-all outline-none resize-none"
            />
          </div>

          <div className="sticky bottom-0 bg-white border-t-2 border-gray-200 pt-6 flex gap-3">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 px-6 py-3 border-2 border-gray-300 text-gray-700 rounded-xl font-semibold hover:bg-gray-50 transition-all"
            >
              取消
            </button>
            <button
              type="submit"
              disabled={loading}
              className="flex-1 px-6 py-3 bg-gradient-to-r from-teal-500 via-emerald-500 to-cyan-600 text-white rounded-xl font-semibold hover:shadow-xl transition-all disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
            >
              {loading ? (
                <>
                  <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                  提交中...
                </>
              ) : (
                <>
                  <Send className="w-5 h-5" />
                  提交订单
                </>
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
