import React, { useState, useEffect } from 'react';
import {
  Bell,
  Plus,
  Edit2,
  Trash2,
  Eye,
  EyeOff,
  Image as ImageIcon,
  Link as LinkIcon,
  Calendar,
  Target,
  BarChart3,
  Save,
  X
} from 'lucide-react';
import { supabase } from '../lib/supabase';
import Modal from './Modal';
import ImageUploader from './ImageUploader';
import { useToast } from '../contexts/ToastContext';

export default function AnnouncementManager({ domainId }) {
  const [announcements, setAnnouncements] = useState([]);
  const [loading, setLoading] = useState(false);
  const [showModal, setShowModal] = useState(false);
  const [editingItem, setEditingItem] = useState(null);
  const [statistics, setStatistics] = useState(null);
  const { showToast } = useToast();

  const [formData, setFormData] = useState({
    title: '',
    content: '',
    announcement_type: 'text',
    image_url: '',
    link_url: '',
    link_text: '',
    button_text: '我知道了',
    button_color: 'blue',
    display_position: 'center',
    display_frequency: 'once',
    priority: 0,
    target_audience: 'all',
    start_date: new Date().toISOString().slice(0, 16),
    end_date: '',
    max_display_count: ''
  });

  useEffect(() => {
    loadAnnouncements();
    loadStatistics();
  }, [domainId]);

  const loadAnnouncements = async () => {
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from('sys_announcements')
        .select('*')
        .eq('domain_id', domainId)
        .order('priority', { ascending: false })
        .order('created_at', { ascending: false });

      if (error) throw error;
      setAnnouncements(data || []);
    } catch (error) {
      console.error('Error loading announcements:', error);
      showToast('加载公告失败', 'error');
    } finally {
      setLoading(false);
    }
  };

  const loadStatistics = async () => {
    try {
      const { data, error } = await supabase.rpc('get_announcement_statistics', {
        p_domain_id: domainId
      });

      if (!error && data) {
        setStatistics(data);
      }
    } catch (error) {
      console.error('Error loading statistics:', error);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);

    try {
      const payload = {
        ...formData,
        domain_id: domainId,
        max_display_count: formData.max_display_count ? parseInt(formData.max_display_count) : null,
        start_date: formData.start_date || new Date().toISOString(),
        end_date: formData.end_date || null
      };

      if (editingItem) {
        const { error } = await supabase
          .from('sys_announcements')
          .update(payload)
          .eq('id', editingItem.id);

        if (error) throw error;
        showToast('公告已更新', 'success');
      } else {
        const { error } = await supabase
          .from('sys_announcements')
          .insert([payload]);

        if (error) throw error;
        showToast('公告已创建', 'success');
      }

      setShowModal(false);
      resetForm();
      loadAnnouncements();
      loadStatistics();
    } catch (error) {
      console.error('Error saving announcement:', error);
      showToast('保存失败', 'error');
    } finally {
      setLoading(false);
    }
  };

  const handleEdit = (item) => {
    setEditingItem(item);
    setFormData({
      title: item.title,
      content: item.content || '',
      announcement_type: item.announcement_type,
      image_url: item.image_url || '',
      link_url: item.link_url || '',
      link_text: item.link_text || '',
      button_text: item.button_text,
      button_color: item.button_color,
      display_position: item.display_position,
      display_frequency: item.display_frequency,
      priority: item.priority,
      target_audience: item.target_audience,
      start_date: item.start_date ? new Date(item.start_date).toISOString().slice(0, 16) : '',
      end_date: item.end_date ? new Date(item.end_date).toISOString().slice(0, 16) : '',
      max_display_count: item.max_display_count || ''
    });
    setShowModal(true);
  };

  const handleDelete = async (id) => {
    if (!window.confirm('确定要删除这个公告吗？')) return;

    try {
      const { error } = await supabase
        .from('sys_announcements')
        .delete()
        .eq('id', id);

      if (error) throw error;
      showToast('公告已删除', 'success');
      loadAnnouncements();
      loadStatistics();
    } catch (error) {
      console.error('Error deleting announcement:', error);
      showToast('删除失败', 'error');
    }
  };

  const toggleActive = async (id, currentStatus) => {
    try {
      const { error } = await supabase
        .from('sys_announcements')
        .update({ is_active: !currentStatus })
        .eq('id', id);

      if (error) throw error;
      showToast(currentStatus ? '已禁用' : '已启用', 'success');
      loadAnnouncements();
    } catch (error) {
      console.error('Error toggling status:', error);
      showToast('操作失败', 'error');
    }
  };

  const resetForm = () => {
    setEditingItem(null);
    setFormData({
      title: '',
      content: '',
      announcement_type: 'text',
      image_url: '',
      link_url: '',
      link_text: '',
      button_text: '我知道了',
      button_color: 'blue',
      display_position: 'center',
      display_frequency: 'once',
      priority: 0,
      target_audience: 'all',
      start_date: new Date().toISOString().slice(0, 16),
      end_date: '',
      max_display_count: ''
    });
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-start">
        <div>
          <h2 className="text-xl font-semibold text-gray-900">弹窗公告管理</h2>
          <p className="text-sm text-gray-600 mt-1">发布文字、图片或链接公告</p>
        </div>
        <button
          onClick={() => {
            resetForm();
            setShowModal(true);
          }}
          className="flex items-center gap-2 bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700"
        >
          <Plus className="w-4 h-4" />
          创建公告
        </button>
      </div>

      {statistics && (
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
            <div className="flex items-center gap-2 mb-1">
              <Bell className="w-4 h-4 text-blue-600" />
              <p className="text-sm font-medium text-blue-900">活跃公告</p>
            </div>
            <p className="text-2xl font-bold text-blue-600">
              {statistics.total_active_announcements}
            </p>
          </div>

          <div className="bg-green-50 border border-green-200 rounded-lg p-4">
            <div className="flex items-center gap-2 mb-1">
              <Eye className="w-4 h-4 text-green-600" />
              <p className="text-sm font-medium text-green-900">总浏览量</p>
            </div>
            <p className="text-2xl font-bold text-green-600">
              {statistics.total_views}
            </p>
          </div>

          <div className="bg-purple-50 border border-purple-200 rounded-lg p-4">
            <div className="flex items-center gap-2 mb-1">
              <LinkIcon className="w-4 h-4 text-purple-600" />
              <p className="text-sm font-medium text-purple-900">总点击数</p>
            </div>
            <p className="text-2xl font-bold text-purple-600">
              {statistics.total_clicks}
            </p>
          </div>

          <div className="bg-orange-50 border border-orange-200 rounded-lg p-4">
            <div className="flex items-center gap-2 mb-1">
              <BarChart3 className="w-4 h-4 text-orange-600" />
              <p className="text-sm font-medium text-orange-900">点击率</p>
            </div>
            <p className="text-2xl font-bold text-orange-600">
              {statistics.click_through_rate}%
            </p>
          </div>
        </div>
      )}

      <div className="bg-white rounded-lg border border-gray-200">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50 border-b border-gray-200">
              <tr>
                <th className="px-4 py-3 text-left text-xs font-medium text-gray-600 uppercase">标题</th>
                <th className="px-4 py-3 text-left text-xs font-medium text-gray-600 uppercase">类型</th>
                <th className="px-4 py-3 text-left text-xs font-medium text-gray-600 uppercase">显示频率</th>
                <th className="px-4 py-3 text-left text-xs font-medium text-gray-600 uppercase">目标受众</th>
                <th className="px-4 py-3 text-left text-xs font-medium text-gray-600 uppercase">统计</th>
                <th className="px-4 py-3 text-left text-xs font-medium text-gray-600 uppercase">状态</th>
                <th className="px-4 py-3 text-left text-xs font-medium text-gray-600 uppercase">操作</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200">
              {announcements.map((item) => (
                <tr key={item.id} className="hover:bg-gray-50">
                  <td className="px-4 py-3">
                    <div>
                      <p className="font-medium text-gray-900">{item.title}</p>
                      {item.content && (
                        <p className="text-sm text-gray-600 line-clamp-1">{item.content}</p>
                      )}
                    </div>
                  </td>
                  <td className="px-4 py-3">
                    <span className={`inline-flex items-center gap-1 px-2 py-1 text-xs rounded-full ${
                      item.announcement_type === 'image' ? 'bg-purple-100 text-purple-700' :
                      item.announcement_type === 'text_with_image' ? 'bg-blue-100 text-blue-700' :
                      'bg-gray-100 text-gray-700'
                    }`}>
                      {item.announcement_type === 'image' && <ImageIcon className="w-3 h-3" />}
                      {item.announcement_type === 'text' ? '文字' :
                       item.announcement_type === 'image' ? '图片' : '图文'}
                    </span>
                  </td>
                  <td className="px-4 py-3">
                    <span className="text-sm text-gray-700">
                      {item.display_frequency === 'once' ? '仅一次' :
                       item.display_frequency === 'daily' ? '每日' : '总是显示'}
                    </span>
                  </td>
                  <td className="px-4 py-3">
                    <span className="text-sm text-gray-700">
                      {item.target_audience === 'all' ? '所有人' :
                       item.target_audience === 'admin_only' ? '仅管理员' :
                       item.target_audience === 'customer_only' ? '仅客户' : '新用户'}
                    </span>
                  </td>
                  <td className="px-4 py-3">
                    <div className="text-sm">
                      <p className="text-gray-700">浏览: {item.current_display_count}</p>
                      <p className="text-gray-700">点击: {item.click_count}</p>
                    </div>
                  </td>
                  <td className="px-4 py-3">
                    <button
                      onClick={() => toggleActive(item.id, item.is_active)}
                      className={`inline-flex items-center gap-1 px-2 py-1 text-xs rounded-full ${
                        item.is_active
                          ? 'bg-green-100 text-green-700'
                          : 'bg-gray-100 text-gray-700'
                      }`}
                    >
                      {item.is_active ? <Eye className="w-3 h-3" /> : <EyeOff className="w-3 h-3" />}
                      {item.is_active ? '启用中' : '已禁用'}
                    </button>
                  </td>
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => handleEdit(item)}
                        className="text-blue-600 hover:text-blue-800"
                        title="编辑"
                      >
                        <Edit2 className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => handleDelete(item.id)}
                        className="text-red-600 hover:text-red-800"
                        title="删除"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
              {announcements.length === 0 && (
                <tr>
                  <td colSpan="7" className="px-4 py-8 text-center text-gray-500">
                    暂无公告，点击"创建公告"开始添加
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {showModal && (
        <Modal
          isOpen={showModal}
          onClose={() => {
            setShowModal(false);
            resetForm();
          }}
          title={editingItem ? '编辑公告' : '创建公告'}
        >
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                标题 *
              </label>
              <input
                type="text"
                value={formData.title}
                onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                required
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                公告类型
              </label>
              <select
                value={formData.announcement_type}
                onChange={(e) => setFormData({ ...formData, announcement_type: e.target.value })}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
              >
                <option value="text">纯文字</option>
                <option value="image">纯图片</option>
                <option value="text_with_image">图文结合</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                内容
              </label>
              <textarea
                value={formData.content}
                onChange={(e) => setFormData({ ...formData, content: e.target.value })}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                rows="4"
                placeholder="输入公告内容..."
              />
            </div>

            {(formData.announcement_type === 'image' || formData.announcement_type === 'text_with_image') && (
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  图片
                </label>
                <ImageUploader
                  value={formData.image_url}
                  onChange={(url) => setFormData({ ...formData, image_url: url })}
                  folder="announcements"
                />
              </div>
            )}

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  链接地址
                </label>
                <input
                  type="url"
                  value={formData.link_url}
                  onChange={(e) => setFormData({ ...formData, link_url: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                  placeholder="https://..."
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  链接文字
                </label>
                <input
                  type="text"
                  value={formData.link_text}
                  onChange={(e) => setFormData({ ...formData, link_text: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                  placeholder="了解更多"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  按钮文字
                </label>
                <input
                  type="text"
                  value={formData.button_text}
                  onChange={(e) => setFormData({ ...formData, button_text: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  按钮颜色
                </label>
                <select
                  value={formData.button_color}
                  onChange={(e) => setFormData({ ...formData, button_color: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                >
                  <option value="blue">蓝色</option>
                  <option value="green">绿色</option>
                  <option value="red">红色</option>
                  <option value="gray">灰色</option>
                </select>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  显示位置
                </label>
                <select
                  value={formData.display_position}
                  onChange={(e) => setFormData({ ...formData, display_position: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                >
                  <option value="center">居中</option>
                  <option value="top">顶部</option>
                  <option value="bottom">底部</option>
                  <option value="top-right">右上角</option>
                  <option value="top-left">左上角</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  显示频率
                </label>
                <select
                  value={formData.display_frequency}
                  onChange={(e) => setFormData({ ...formData, display_frequency: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                >
                  <option value="once">仅显示一次</option>
                  <option value="daily">每日显示</option>
                  <option value="always">总是显示</option>
                  <option value="session">每次会话</option>
                </select>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  目标受众
                </label>
                <select
                  value={formData.target_audience}
                  onChange={(e) => setFormData({ ...formData, target_audience: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                >
                  <option value="all">所有人</option>
                  <option value="customer_only">仅客户</option>
                  <option value="admin_only">仅管理员</option>
                  <option value="new_users">新用户</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  优先级
                </label>
                <input
                  type="number"
                  value={formData.priority}
                  onChange={(e) => setFormData({ ...formData, priority: parseInt(e.target.value) || 0 })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                  min="0"
                  max="100"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  开始时间
                </label>
                <input
                  type="datetime-local"
                  value={formData.start_date}
                  onChange={(e) => setFormData({ ...formData, start_date: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  结束时间（可选）
                </label>
                <input
                  type="datetime-local"
                  value={formData.end_date}
                  onChange={(e) => setFormData({ ...formData, end_date: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                最大显示次数（可选）
              </label>
              <input
                type="number"
                value={formData.max_display_count}
                onChange={(e) => setFormData({ ...formData, max_display_count: e.target.value })}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                min="1"
                placeholder="不限制"
              />
            </div>

            <div className="flex gap-3 pt-4">
              <button
                type="submit"
                disabled={loading}
                className="flex-1 flex items-center justify-center gap-2 bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 disabled:bg-gray-400"
              >
                <Save className="w-4 h-4" />
                {loading ? '保存中...' : '保存'}
              </button>
              <button
                type="button"
                onClick={() => {
                  setShowModal(false);
                  resetForm();
                }}
                className="px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50"
              >
                取消
              </button>
            </div>
          </form>
        </Modal>
      )}
    </div>
  );
}
