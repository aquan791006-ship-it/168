import React, { useState, useEffect } from 'react';
import { Download, X, Smartphone } from 'lucide-react';

export default function PWAInstallPrompt() {
  const [deferredPrompt, setDeferredPrompt] = useState(null);
  const [showPrompt, setShowPrompt] = useState(false);
  const [isIOS, setIsIOS] = useState(false);
  const [isStandalone, setIsStandalone] = useState(false);

  useEffect(() => {
    const isIOSDevice = /iPad|iPhone|iPod/.test(navigator.userAgent) && !window.MSStream;
    const isInStandaloneMode = window.matchMedia('(display-mode: standalone)').matches ||
                               window.navigator.standalone === true;

    setIsIOS(isIOSDevice);
    setIsStandalone(isInStandaloneMode);

    const dismissed = localStorage.getItem('pwa-install-dismissed');
    const dismissedTime = dismissed ? parseInt(dismissed, 10) : 0;
    const sevenDaysInMs = 7 * 24 * 60 * 60 * 1000;

    if (isInStandaloneMode || (dismissedTime && Date.now() - dismissedTime < sevenDaysInMs)) {
      return;
    }

    const handleBeforeInstallPrompt = (e) => {
      e.preventDefault();
      setDeferredPrompt(e);

      setTimeout(() => {
        setShowPrompt(true);
      }, 3000);
    };

    window.addEventListener('beforeinstallprompt', handleBeforeInstallPrompt);

    if (isIOSDevice && !isInStandaloneMode) {
      setTimeout(() => {
        setShowPrompt(true);
      }, 3000);
    }

    return () => {
      window.removeEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
    };
  }, []);

  const handleInstallClick = async () => {
    if (!deferredPrompt) {
      return;
    }

    deferredPrompt.prompt();
    const { outcome } = await deferredPrompt.userChoice;

    if (outcome === 'accepted') {
      console.log('PWA安装已接受');
    }

    setDeferredPrompt(null);
    setShowPrompt(false);
  };

  const handleDismiss = () => {
    setShowPrompt(false);
    localStorage.setItem('pwa-install-dismissed', Date.now().toString());
  };

  if (!showPrompt || isStandalone) {
    return null;
  }

  if (isIOS && !deferredPrompt) {
    return (
      <div className="fixed bottom-4 left-4 right-4 md:left-auto md:right-4 md:w-96 z-50 animate-slide-up">
        <div className="bg-white rounded-2xl shadow-2xl border border-teal-200 overflow-hidden">
          <div className="bg-gradient-to-r from-teal-500 via-emerald-500 to-cyan-600 p-4 relative">
            <button
              onClick={handleDismiss}
              className="absolute top-2 right-2 p-1 rounded-full bg-white/20 hover:bg-white/30 transition-colors"
            >
              <X className="w-4 h-4 text-white" />
            </button>
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 bg-white rounded-xl flex items-center justify-center shadow-lg">
                <Smartphone className="w-6 h-6 text-teal-600" />
              </div>
              <div className="flex-1">
                <h3 className="text-white font-bold text-lg">安装到主屏幕</h3>
                <p className="text-white/90 text-sm">获得更好的体验</p>
              </div>
            </div>
          </div>

          <div className="p-4 space-y-3">
            <p className="text-gray-700 text-sm leading-relaxed">
              将168全球购添加到您的主屏幕，享受类似原生应用的体验：
            </p>

            <div className="space-y-2 text-sm text-gray-600">
              <div className="flex items-start gap-2">
                <span className="inline-block w-5 h-5 rounded-full bg-teal-100 text-teal-600 font-bold text-xs flex items-center justify-center mt-0.5">1</span>
                <p>点击底部的分享按钮 <span className="inline-block px-2 py-0.5 bg-gray-100 rounded">⬆️</span></p>
              </div>
              <div className="flex items-start gap-2">
                <span className="inline-block w-5 h-5 rounded-full bg-teal-100 text-teal-600 font-bold text-xs flex items-center justify-center mt-0.5">2</span>
                <p>选择 "添加到主屏幕"</p>
              </div>
              <div className="flex items-start gap-2">
                <span className="inline-block w-5 h-5 rounded-full bg-teal-100 text-teal-600 font-bold text-xs flex items-center justify-center mt-0.5">3</span>
                <p>点击 "添加" 完成安装</p>
              </div>
            </div>

            <button
              onClick={handleDismiss}
              className="w-full py-2 px-4 text-gray-600 hover:bg-gray-100 rounded-lg transition-colors text-sm font-medium"
            >
              稍后再说
            </button>
          </div>
        </div>
      </div>
    );
  }

  if (deferredPrompt) {
    return (
      <div className="fixed bottom-4 left-4 right-4 md:left-auto md:right-4 md:w-96 z-50 animate-slide-up">
        <div className="bg-white rounded-2xl shadow-2xl border border-teal-200 overflow-hidden">
          <div className="bg-gradient-to-r from-teal-500 via-emerald-500 to-cyan-600 p-4 relative">
            <button
              onClick={handleDismiss}
              className="absolute top-2 right-2 p-1 rounded-full bg-white/20 hover:bg-white/30 transition-colors"
            >
              <X className="w-4 h-4 text-white" />
            </button>
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 bg-white rounded-xl flex items-center justify-center shadow-lg">
                <Download className="w-6 h-6 text-teal-600" />
              </div>
              <div className="flex-1">
                <h3 className="text-white font-bold text-lg">安装应用</h3>
                <p className="text-white/90 text-sm">快速访问，离线可用</p>
              </div>
            </div>
          </div>

          <div className="p-4 space-y-3">
            <p className="text-gray-700 text-sm leading-relaxed">
              安装168全球购应用到您的设备，享受：
            </p>

            <ul className="space-y-2 text-sm text-gray-600">
              <li className="flex items-center gap-2">
                <span className="w-1.5 h-1.5 rounded-full bg-teal-500"></span>
                <span>快速启动，无需浏览器</span>
              </li>
              <li className="flex items-center gap-2">
                <span className="w-1.5 h-1.5 rounded-full bg-teal-500"></span>
                <span>离线访问部分功能</span>
              </li>
              <li className="flex items-center gap-2">
                <span className="w-1.5 h-1.5 rounded-full bg-teal-500"></span>
                <span>获得原生应用体验</span>
              </li>
            </ul>

            <div className="flex gap-2 pt-2">
              <button
                onClick={handleDismiss}
                className="flex-1 py-2.5 px-4 text-gray-600 hover:bg-gray-100 rounded-xl transition-colors font-medium"
              >
                稍后
              </button>
              <button
                onClick={handleInstallClick}
                className="flex-1 py-2.5 px-4 bg-gradient-to-r from-teal-500 via-emerald-500 to-cyan-600 text-white rounded-xl font-bold hover:from-teal-600 hover:via-emerald-600 hover:to-cyan-700 transition-all shadow-md hover:shadow-lg flex items-center justify-center gap-2"
              >
                <Download className="w-4 h-4" />
                <span>安装</span>
              </button>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return null;
}
