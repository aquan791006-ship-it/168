import React from 'react';
import {
  ComposedChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Cell
} from 'recharts';

const CandlestickChart = ({ data, height = 400 }) => {
  const CustomCandlestick = (props) => {
    const { x, y, width, height, payload } = props;
    const { open, close, high, low } = payload;

    if (!open || !close || !high || !low) return null;

    const isPositive = close >= open;
    const color = isPositive ? '#10b981' : '#ef4444';
    const fillColor = isPositive ? '#10b981' : '#ef4444';

    const maxPrice = Math.max(open, close, high, low);
    const minPrice = Math.min(open, close, high, low);
    const range = maxPrice - minPrice || 1;

    const chartHeight = height;
    const wickX = x + width / 2;

    const highY = y;
    const lowY = y + chartHeight;

    const bodyTop = y + ((maxPrice - Math.max(open, close)) / range) * chartHeight;
    const bodyHeight = (Math.abs(close - open) / range) * chartHeight || 2;

    return (
      <g>
        <line
          x1={wickX}
          y1={highY}
          x2={wickX}
          y2={lowY}
          stroke={color}
          strokeWidth={1.5}
        />
        <rect
          x={x + width * 0.2}
          y={bodyTop}
          width={width * 0.6}
          height={Math.max(bodyHeight, 2)}
          fill={fillColor}
          stroke={color}
          strokeWidth={1.5}
          rx={2}
        />
      </g>
    );
  };

  const CustomTooltip = ({ active, payload }) => {
    if (active && payload && payload.length) {
      const data = payload[0].payload;
      const isPositive = data.close >= data.open;
      const change = data.close - data.open;
      const changePercent = ((change / data.open) * 100).toFixed(2);

      return (
        <div className="bg-white/95 backdrop-blur-sm p-4 rounded-xl shadow-xl border border-gray-200">
          <p className="font-bold text-gray-900 mb-3 text-base">{data.date}</p>
          <div className="space-y-2 text-sm">
            <div className="flex items-center justify-between gap-8">
              <span className="text-gray-600">开盘:</span>
              <span className="font-semibold text-gray-900">¥{data.open?.toLocaleString()}</span>
            </div>
            <div className="flex items-center justify-between gap-8">
              <span className="text-gray-600">收盘:</span>
              <span className={`font-semibold ${isPositive ? 'text-emerald-600' : 'text-rose-600'}`}>
                ¥{data.close?.toLocaleString()}
              </span>
            </div>
            <div className="flex items-center justify-between gap-8">
              <span className="text-gray-600">最高:</span>
              <span className="font-semibold text-emerald-600">¥{data.high?.toLocaleString()}</span>
            </div>
            <div className="flex items-center justify-between gap-8">
              <span className="text-gray-600">最低:</span>
              <span className="font-semibold text-rose-600">¥{data.low?.toLocaleString()}</span>
            </div>
            <div className="pt-2 border-t border-gray-200">
              <div className="flex items-center justify-between gap-8">
                <span className="text-gray-600">涨跌:</span>
                <span className={`font-bold ${isPositive ? 'text-emerald-600' : 'text-rose-600'}`}>
                  {isPositive ? '+' : ''}{change.toLocaleString()} ({isPositive ? '+' : ''}{changePercent}%)
                </span>
              </div>
              <div className="flex items-center justify-between gap-8 mt-2">
                <span className="text-gray-600">成交量:</span>
                <span className="font-semibold text-blue-600">{data.volume?.toLocaleString()}</span>
              </div>
            </div>
          </div>
        </div>
      );
    }
    return null;
  };

  const chartData = data.map(item => ({
    ...item,
    candlestick: item.high
  }));

  return (
    <ResponsiveContainer width="100%" height={height}>
      <ComposedChart data={chartData} margin={{ top: 10, right: 30, left: 10, bottom: 0 }}>
        <defs>
          <linearGradient id="volumeGradient" x1="0" y1="0" x2="0" y2="1">
            <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.4} />
            <stop offset="95%" stopColor="#3b82f6" stopOpacity={0.05} />
          </linearGradient>
        </defs>
        <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" vertical={false} />
        <XAxis
          dataKey="date"
          stroke="#9ca3af"
          style={{ fontSize: '12px', fontWeight: '500' }}
          tickLine={false}
        />
        <YAxis
          yAxisId="left"
          stroke="#9ca3af"
          style={{ fontSize: '12px', fontWeight: '500' }}
          tickLine={false}
          domain={['dataMin - 1000', 'dataMax + 1000']}
        />
        <YAxis
          yAxisId="right"
          orientation="right"
          stroke="#9ca3af"
          style={{ fontSize: '12px', fontWeight: '500' }}
          tickLine={false}
        />
        <Tooltip content={<CustomTooltip />} cursor={{ fill: 'rgba(59, 130, 246, 0.05)' }} />
        <Bar
          yAxisId="right"
          dataKey="volume"
          fill="url(#volumeGradient)"
          radius={[4, 4, 0, 0]}
          maxBarSize={40}
        />
        <Bar
          yAxisId="left"
          dataKey="high"
          shape={<CustomCandlestick />}
          maxBarSize={30}
        />
      </ComposedChart>
    </ResponsiveContainer>
  );
};

export default CandlestickChart;
