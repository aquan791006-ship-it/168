import React, { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import { MapPin, ChevronDown } from 'lucide-react';

export default function AddressSelector({ value, onChange, required = false }) {
  const [provinces, setProvinces] = useState([]);
  const [cities, setCities] = useState([]);
  const [districts, setDistricts] = useState([]);
  const [streets, setStreets] = useState([]);

  const [selectedProvince, setSelectedProvince] = useState('');
  const [selectedCity, setSelectedCity] = useState('');
  const [selectedDistrict, setSelectedDistrict] = useState('');
  const [selectedStreet, setSelectedStreet] = useState('');
  const [detailAddress, setDetailAddress] = useState('');

  const [loading, setLoading] = useState({
    provinces: false,
    cities: false,
    districts: false,
    streets: false
  });

  useEffect(() => {
    loadProvinces();
  }, []);

  useEffect(() => {
    if (value) {
      setSelectedProvince(value.province || '');
      setSelectedCity(value.city || '');
      setSelectedDistrict(value.district || '');
      setSelectedStreet(value.street || '');
      setDetailAddress(value.detail || '');
    }
  }, [value]);

  const loadProvinces = async () => {
    setLoading(prev => ({ ...prev, provinces: true }));
    try {
      const { data, error } = await supabase
        .from('china_addresses')
        .select('*')
        .eq('level', 'province')
        .eq('is_active', true)
        .order('sort_order');

      if (error) throw error;
      setProvinces(data || []);
    } catch (error) {
      console.error('Error loading provinces:', error);
    } finally {
      setLoading(prev => ({ ...prev, provinces: false }));
    }
  };

  const loadCities = async (provinceCode) => {
    if (!provinceCode) {
      setCities([]);
      return;
    }

    setLoading(prev => ({ ...prev, cities: true }));
    try {
      const { data, error } = await supabase
        .from('china_addresses')
        .select('*')
        .eq('level', 'city')
        .eq('parent_code', provinceCode)
        .eq('is_active', true)
        .order('sort_order');

      if (error) throw error;
      setCities(data || []);
    } catch (error) {
      console.error('Error loading cities:', error);
    } finally {
      setLoading(prev => ({ ...prev, cities: false }));
    }
  };

  const loadDistricts = async (cityCode) => {
    if (!cityCode) {
      setDistricts([]);
      return;
    }

    setLoading(prev => ({ ...prev, districts: true }));
    try {
      const { data, error } = await supabase
        .from('china_addresses')
        .select('*')
        .eq('level', 'district')
        .eq('parent_code', cityCode)
        .eq('is_active', true)
        .order('sort_order');

      if (error) throw error;
      setDistricts(data || []);
    } catch (error) {
      console.error('Error loading districts:', error);
    } finally {
      setLoading(prev => ({ ...prev, districts: false }));
    }
  };

  const loadStreets = async (districtCode) => {
    if (!districtCode) {
      setStreets([]);
      return;
    }

    setLoading(prev => ({ ...prev, streets: true }));
    try {
      const { data, error } = await supabase
        .from('china_addresses')
        .select('*')
        .eq('level', 'street')
        .eq('parent_code', districtCode)
        .eq('is_active', true)
        .order('sort_order');

      if (error) throw error;
      setStreets(data || []);
    } catch (error) {
      console.error('Error loading streets:', error);
    } finally {
      setLoading(prev => ({ ...prev, streets: false }));
    }
  };

  const handleProvinceChange = (e) => {
    const province = provinces.find(p => p.code === e.target.value);
    setSelectedProvince(province?.name || '');
    setSelectedCity('');
    setSelectedDistrict('');
    setSelectedStreet('');
    setCities([]);
    setDistricts([]);
    setStreets([]);

    if (province) {
      loadCities(province.code);
      updateValue(province.name, '', '', '', detailAddress);
    }
  };

  const handleCityChange = (e) => {
    const city = cities.find(c => c.code === e.target.value);
    setSelectedCity(city?.name || '');
    setSelectedDistrict('');
    setSelectedStreet('');
    setDistricts([]);
    setStreets([]);

    if (city) {
      loadDistricts(city.code);
      updateValue(selectedProvince, city.name, '', '', detailAddress);
    }
  };

  const handleDistrictChange = (e) => {
    const district = districts.find(d => d.code === e.target.value);
    setSelectedDistrict(district?.name || '');
    setSelectedStreet('');
    setStreets([]);

    if (district) {
      loadStreets(district.code);
      updateValue(selectedProvince, selectedCity, district.name, '', detailAddress);
    }
  };

  const handleStreetChange = (e) => {
    const street = streets.find(s => s.code === e.target.value);
    setSelectedStreet(street?.name || '');
    updateValue(selectedProvince, selectedCity, selectedDistrict, street?.name || '', detailAddress);
  };

  const handleDetailChange = (e) => {
    const detail = e.target.value;
    setDetailAddress(detail);
    updateValue(selectedProvince, selectedCity, selectedDistrict, selectedStreet, detail);
  };

  const updateValue = (province, city, district, street, detail) => {
    if (onChange) {
      onChange({
        province,
        city,
        district,
        street,
        detail,
        fullAddress: `${province}${city}${district}${street}${detail}`
      });
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-2 mb-2">
        <MapPin className="w-5 h-5 text-orange-600" />
        <label className="block text-sm font-semibold text-gray-700">
          配送地址 {required && <span className="text-red-500">*</span>}
        </label>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-3">
        <div className="relative">
          <select
            value={provinces.find(p => p.name === selectedProvince)?.code || ''}
            onChange={handleProvinceChange}
            required={required}
            className="w-full px-4 py-2.5 border-2 border-gray-200 rounded-lg focus:ring-2 focus:ring-orange-500/20 focus:border-orange-500 transition-all outline-none appearance-none bg-white"
          >
            <option value="">选择省份</option>
            {provinces.map(province => (
              <option key={province.code} value={province.code}>
                {province.name}
              </option>
            ))}
          </select>
          <ChevronDown className="absolute right-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400 pointer-events-none" />
        </div>

        <div className="relative">
          <select
            value={cities.find(c => c.name === selectedCity)?.code || ''}
            onChange={handleCityChange}
            disabled={!selectedProvince}
            required={required && selectedProvince}
            className="w-full px-4 py-2.5 border-2 border-gray-200 rounded-lg focus:ring-2 focus:ring-orange-500/20 focus:border-orange-500 transition-all outline-none appearance-none bg-white disabled:bg-gray-50 disabled:cursor-not-allowed"
          >
            <option value="">选择城市</option>
            {cities.map(city => (
              <option key={city.code} value={city.code}>
                {city.name}
              </option>
            ))}
          </select>
          <ChevronDown className="absolute right-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400 pointer-events-none" />
        </div>

        <div className="relative">
          <select
            value={districts.find(d => d.name === selectedDistrict)?.code || ''}
            onChange={handleDistrictChange}
            disabled={!selectedCity}
            required={required && selectedCity}
            className="w-full px-4 py-2.5 border-2 border-gray-200 rounded-lg focus:ring-2 focus:ring-orange-500/20 focus:border-orange-500 transition-all outline-none appearance-none bg-white disabled:bg-gray-50 disabled:cursor-not-allowed"
          >
            <option value="">选择区/县</option>
            {districts.map(district => (
              <option key={district.code} value={district.code}>
                {district.name}
              </option>
            ))}
          </select>
          <ChevronDown className="absolute right-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400 pointer-events-none" />
        </div>

        <div className="relative">
          <select
            value={streets.find(s => s.name === selectedStreet)?.code || ''}
            onChange={handleStreetChange}
            disabled={!selectedDistrict}
            className="w-full px-4 py-2.5 border-2 border-gray-200 rounded-lg focus:ring-2 focus:ring-orange-500/20 focus:border-orange-500 transition-all outline-none appearance-none bg-white disabled:bg-gray-50 disabled:cursor-not-allowed"
          >
            <option value="">选择街道</option>
            {streets.map(street => (
              <option key={street.code} value={street.code}>
                {street.name}
              </option>
            ))}
          </select>
          <ChevronDown className="absolute right-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400 pointer-events-none" />
        </div>
      </div>

      <div>
        <input
          type="text"
          value={detailAddress}
          onChange={handleDetailChange}
          placeholder="请输入详细地址（街道门牌号、楼栋单元等）"
          required={required}
          className="w-full px-4 py-2.5 border-2 border-gray-200 rounded-lg focus:ring-2 focus:ring-orange-500/20 focus:border-orange-500 transition-all outline-none"
        />
      </div>

      {(selectedProvince || selectedCity || selectedDistrict) && (
        <div className="text-sm text-gray-600 bg-orange-50 border border-orange-100 rounded-lg p-3">
          <span className="font-medium text-orange-700">完整地址：</span>
          {selectedProvince}{selectedCity}{selectedDistrict}{selectedStreet}{detailAddress}
        </div>
      )}
    </div>
  );
}
