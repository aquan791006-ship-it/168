import React from 'react';
import { Globe, ShoppingBag, Sparkles, Star } from 'lucide-react';

export default function Logo({ size = 'md', showText = true, variant = 'default' }) {
  const sizes = {
    sm: {
      container: 'w-10 h-10',
      icon: 'w-3.5 h-3.5',
      text: 'text-sm',
      number: 'text-lg',
      badge: 'w-5 h-5',
      starSize: 'w-2 h-2'
    },
    md: {
      container: 'w-14 h-14',
      icon: 'w-4 h-4',
      text: 'text-base',
      number: 'text-2xl',
      badge: 'w-6 h-6',
      starSize: 'w-2.5 h-2.5'
    },
    lg: {
      container: 'w-20 h-20',
      icon: 'w-5 h-5',
      text: 'text-xl',
      number: 'text-3xl',
      badge: 'w-8 h-8',
      starSize: 'w-3 h-3'
    }
  };

  const currentSize = sizes[size] || sizes.md;

  return (
    <div className="flex items-center gap-3.5 animate-fade-in">
      <div className="relative group">
        <div className="absolute inset-0 bg-gradient-to-br from-blue-500 via-blue-600 to-blue-700 rounded-2xl blur-lg opacity-30 group-hover:opacity-50 transition-opacity duration-500"></div>

        <div className={`relative ${currentSize.container} rounded-2xl overflow-hidden shadow-2xl transform group-hover:scale-105 transition-all duration-300`}>
          <div className="absolute inset-0 bg-gradient-to-br from-slate-900 via-blue-900 to-slate-900"></div>

          <div className="absolute inset-0 bg-gradient-to-tr from-transparent via-blue-500/10 to-blue-400/20"></div>

          <div className="absolute top-0 right-0 w-16 h-16 bg-gradient-to-br from-blue-400/20 to-transparent rounded-full blur-2xl"></div>
          <div className="absolute bottom-0 left-0 w-16 h-16 bg-gradient-to-tr from-amber-400/10 to-transparent rounded-full blur-2xl"></div>

          <div className="relative flex items-center justify-center h-full z-10">
            <span className={`${currentSize.number} font-black text-transparent bg-clip-text bg-gradient-to-br from-white via-blue-100 to-blue-200 tracking-tighter drop-shadow-2xl`}>
              168
            </span>
          </div>

          <div className={`absolute -right-1 -top-1 ${currentSize.badge} bg-gradient-to-br from-amber-400 via-amber-500 to-orange-500 rounded-full flex items-center justify-center shadow-xl ring-2 ring-white/30 group-hover:rotate-12 transition-transform duration-300`}>
            <ShoppingBag className={`${currentSize.icon} text-white drop-shadow-md`} strokeWidth={2.5} />
          </div>

          <div className={`absolute -left-1 -bottom-1 ${currentSize.badge} bg-gradient-to-br from-blue-400 via-blue-500 to-cyan-500 rounded-full flex items-center justify-center shadow-xl ring-2 ring-white/30 group-hover:-rotate-12 transition-transform duration-300`}>
            <Globe className={`${currentSize.icon} text-white drop-shadow-md`} strokeWidth={2.5} />
          </div>

          <div className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-700">
            <Sparkles className={`absolute top-2 right-2 ${currentSize.starSize} text-amber-300/60 animate-pulse`} />
            <Sparkles className={`absolute bottom-2 left-2 ${currentSize.starSize} text-blue-300/60 animate-pulse`} style={{animationDelay: '0.5s'}} />
            <Star className={`absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 ${currentSize.starSize} text-white/20 animate-ping`} />
          </div>

          <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent"></div>
        </div>
      </div>

      {showText && (
        <div className="flex flex-col leading-tight">
          <div className="flex items-center gap-2.5">
            <span className={`${currentSize.text} font-black tracking-tight`}>
              <span className="bg-gradient-to-r from-slate-800 via-blue-900 to-slate-900 bg-clip-text text-transparent drop-shadow-sm">
                168全球购
              </span>
            </span>
            <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-[10px] font-bold tracking-wide bg-gradient-to-r from-amber-100 to-orange-100 text-orange-700 border border-orange-200/50 shadow-sm">
              COD
            </span>
          </div>
          <div className="flex items-center gap-2 mt-1">
            <div className="flex items-center gap-1.5">
              <div className="relative">
                <div className="w-1.5 h-1.5 rounded-full bg-gradient-to-r from-blue-500 to-cyan-500 animate-pulse"></div>
                <div className="absolute inset-0 w-1.5 h-1.5 rounded-full bg-blue-400 animate-ping"></div>
              </div>
              <span className="text-[11px] font-semibold text-slate-600 tracking-wide">
                智能电商管理平台
              </span>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export function LogoCompact({ animated = false }) {
  return (
    <div className="relative group">
      <div className={`absolute inset-0 bg-gradient-to-br from-blue-500 to-blue-700 rounded-xl blur-md opacity-40 group-hover:opacity-60 transition-opacity duration-300 ${animated ? 'animate-pulse' : ''}`}></div>

      <div className="relative w-11 h-11 rounded-xl overflow-hidden shadow-xl transform group-hover:scale-110 transition-transform duration-300">
        <div className="absolute inset-0 bg-gradient-to-br from-slate-900 via-blue-900 to-slate-900"></div>
        <div className="absolute inset-0 bg-gradient-to-tr from-transparent via-blue-500/10 to-blue-400/20"></div>

        <div className="relative flex items-center justify-center h-full">
          <span className="text-xl font-black text-transparent bg-clip-text bg-gradient-to-br from-white via-blue-100 to-blue-200 drop-shadow-lg">
            168
          </span>
        </div>

        <div className="absolute -right-0.5 -top-0.5 w-5 h-5 bg-gradient-to-br from-amber-400 to-orange-500 rounded-full flex items-center justify-center shadow-lg ring-1 ring-white/30">
          <ShoppingBag className="w-2.5 h-2.5 text-white" strokeWidth={2.5} />
        </div>
      </div>
    </div>
  );
}

export function LogoIcon({ className = "w-9 h-9" }) {
  return (
    <div className={`relative ${className} group`}>
      <div className="absolute inset-0 bg-gradient-to-br from-blue-500 to-blue-700 rounded-lg blur opacity-50"></div>

      <div className="relative w-full h-full rounded-lg overflow-hidden shadow-lg">
        <div className="absolute inset-0 bg-gradient-to-br from-slate-900 via-blue-900 to-slate-900"></div>
        <div className="absolute inset-0 bg-gradient-to-tr from-transparent via-blue-500/10 to-blue-400/20"></div>

        <div className="relative flex items-center justify-center h-full">
          <span className="text-sm font-black text-transparent bg-clip-text bg-gradient-to-br from-white to-blue-200">
            168
          </span>
        </div>
      </div>
    </div>
  );
}

export function LogoBrand({ size = 'lg', theme = 'dark' }) {
  const isLight = theme === 'light';

  return (
    <div className="flex flex-col items-center gap-4 animate-fade-in">
      <div className="relative group">
        <div className="absolute inset-0 bg-gradient-to-br from-blue-500 via-blue-600 to-blue-700 rounded-3xl blur-2xl opacity-30 group-hover:opacity-50 transition-opacity duration-500"></div>

        <div className="relative w-24 h-24 rounded-3xl overflow-hidden shadow-2xl transform group-hover:scale-105 transition-transform duration-500">
          <div className={`absolute inset-0 ${isLight ? 'bg-gradient-to-br from-slate-50 via-blue-50 to-slate-100' : 'bg-gradient-to-br from-slate-900 via-blue-900 to-slate-900'}`}></div>

          <div className="absolute inset-0 bg-gradient-to-tr from-transparent via-blue-500/10 to-blue-400/20"></div>

          <div className="absolute top-0 right-0 w-20 h-20 bg-gradient-to-br from-blue-400/20 to-transparent rounded-full blur-3xl"></div>
          <div className="absolute bottom-0 left-0 w-20 h-20 bg-gradient-to-tr from-amber-400/10 to-transparent rounded-full blur-3xl"></div>

          <div className="relative flex items-center justify-center h-full z-10">
            <span className={`text-4xl font-black tracking-tighter ${isLight ? 'text-transparent bg-clip-text bg-gradient-to-br from-slate-800 via-blue-900 to-slate-900' : 'text-transparent bg-clip-text bg-gradient-to-br from-white via-blue-100 to-blue-200'} drop-shadow-2xl`}>
              168
            </span>
          </div>

          <div className="absolute -right-1.5 -top-1.5 w-9 h-9 bg-gradient-to-br from-amber-400 via-amber-500 to-orange-500 rounded-full flex items-center justify-center shadow-xl ring-2 ring-white/30 group-hover:rotate-12 transition-transform duration-300">
            <ShoppingBag className="w-5 h-5 text-white drop-shadow-md" strokeWidth={2.5} />
          </div>

          <div className="absolute -left-1.5 -bottom-1.5 w-9 h-9 bg-gradient-to-br from-blue-400 via-blue-500 to-cyan-500 rounded-full flex items-center justify-center shadow-xl ring-2 ring-white/30 group-hover:-rotate-12 transition-transform duration-300">
            <Globe className="w-5 h-5 text-white drop-shadow-md" strokeWidth={2.5} />
          </div>
        </div>
      </div>

      <div className="text-center space-y-2">
        <h1 className={`text-3xl font-black tracking-tight ${isLight ? 'text-transparent bg-clip-text bg-gradient-to-r from-slate-800 via-blue-900 to-slate-900' : 'text-white'}`}>
          168全球购
        </h1>
        <div className="flex items-center justify-center gap-2">
          <span className="inline-flex items-center px-3 py-1 rounded-full text-xs font-bold tracking-wide bg-gradient-to-r from-amber-100 to-orange-100 text-orange-700 border border-orange-200/50 shadow-sm">
            COD
          </span>
          <span className={`text-sm font-semibold ${isLight ? 'text-slate-600' : 'text-slate-300'}`}>
            智能电商管理平台
          </span>
        </div>
      </div>
    </div>
  );
}
