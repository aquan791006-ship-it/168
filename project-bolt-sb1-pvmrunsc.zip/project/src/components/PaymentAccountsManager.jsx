import React, { useState, useEffect } from 'react';
import {
  Wallet,
  Plus,
  Edit2,
  Trash2,
  Eye,
  EyeOff,
  Save,
  Star,
  QrCode,
  User,
  Building2,
  AlertCircle
} from 'lucide-react';
import { supabase } from '../lib/supabase';
import Modal from './Modal';
import ImageUploader from './ImageUploader';
import { useToast } from '../contexts/ToastContext';

export default function PaymentAccountsManager({ domainId }) {
  const [accounts, setAccounts] = useState([]);
  const [methods, setMethods] = useState([]);
  const [loading, setLoading] = useState(false);
  const [showModal, setShowModal] = useState(false);
  const [editingItem, setEditingItem] = useState(null);
  const { showToast } = useToast();

  const [formData, setFormData] = useState({
    payment_method_id: '',
    account_name: '',
    account_type: 'personal',
    account_info: {},
    qr_code_url: '',
    notes: ''
  });

  const [accountFields, setAccountFields] = useState({
    account_holder: '',
    account_number: '',
    bank_name: '',
    bank_branch: '',
    phone_number: '',
    email: '',
    address: ''
  });

  useEffect(() => {
    loadMethods();
    loadAccounts();
  }, [domainId]);

  const loadMethods = async () => {
    try {
      const { data, error } = await supabase
        .from('sys_payment_methods')
        .select('*')
        .eq('domain_id', domainId)
        .eq('require_account', true)
        .eq('is_enabled', true)
        .order('display_order', { ascending: true });

      if (error) throw error;
      setMethods(data || []);
    } catch (error) {
      console.error('Error loading payment methods:', error);
    }
  };

  const loadAccounts = async () => {
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from('sys_payment_accounts')
        .select(`
          *,
          payment_method:sys_payment_methods(method_code, method_name, method_type)
        `)
        .eq('domain_id', domainId)
        .order('is_primary', { ascending: false })
        .order('created_at', { ascending: false });

      if (error) throw error;
      setAccounts(data || []);
    } catch (error) {
      console.error('Error loading payment accounts:', error);
      showToast('加载收款账号失败', 'error');
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);

    try {
      const payload = {
        ...formData,
        domain_id: domainId,
        account_info: accountFields
      };

      if (editingItem) {
        const { error } = await supabase
          .from('sys_payment_accounts')
          .update(payload)
          .eq('id', editingItem.id);

        if (error) throw error;
        showToast('收款账号已更新', 'success');
      } else {
        const { error } = await supabase
          .from('sys_payment_accounts')
          .insert([payload]);

        if (error) throw error;
        showToast('收款账号已添加', 'success');
      }

      setShowModal(false);
      resetForm();
      loadAccounts();
    } catch (error) {
      console.error('Error saving payment account:', error);
      showToast(error.message || '保存失败', 'error');
    } finally {
      setLoading(false);
    }
  };

  const handleEdit = (item) => {
    setEditingItem(item);
    setFormData({
      payment_method_id: item.payment_method_id,
      account_name: item.account_name,
      account_type: item.account_type,
      account_info: item.account_info,
      qr_code_url: item.qr_code_url || '',
      notes: item.notes || ''
    });
    setAccountFields(item.account_info || {
      account_holder: '',
      account_number: '',
      bank_name: '',
      bank_branch: '',
      phone_number: '',
      email: '',
      address: ''
    });
    setShowModal(true);
  };

  const handleDelete = async (id) => {
    if (!window.confirm('确定要删除这个收款账号吗？')) return;

    try {
      const { error } = await supabase
        .from('sys_payment_accounts')
        .delete()
        .eq('id', id);

      if (error) throw error;
      showToast('收款账号已删除', 'success');
      loadAccounts();
    } catch (error) {
      console.error('Error deleting payment account:', error);
      showToast('删除失败', 'error');
    }
  };

  const toggleActive = async (id, currentStatus) => {
    try {
      const { error } = await supabase
        .from('sys_payment_accounts')
        .update({ is_active: !currentStatus })
        .eq('id', id);

      if (error) throw error;
      showToast(currentStatus ? '已禁用' : '已启用', 'success');
      loadAccounts();
    } catch (error) {
      console.error('Error toggling status:', error);
      showToast('操作失败', 'error');
    }
  };

  const setPrimary = async (id) => {
    try {
      const { data, error } = await supabase.rpc('set_primary_payment_account', {
        p_account_id: id,
        p_domain_id: domainId
      });

      if (error) throw error;

      if (data.success) {
        showToast('已设为主账号', 'success');
        loadAccounts();
      } else {
        showToast(data.error || '设置失败', 'error');
      }
    } catch (error) {
      console.error('Error setting primary:', error);
      showToast('设置失败', 'error');
    }
  };

  const resetForm = () => {
    setEditingItem(null);
    setFormData({
      payment_method_id: '',
      account_name: '',
      account_type: 'personal',
      account_info: {},
      qr_code_url: '',
      notes: ''
    });
    setAccountFields({
      account_holder: '',
      account_number: '',
      bank_name: '',
      bank_branch: '',
      phone_number: '',
      email: '',
      address: ''
    });
  };

  const getAccountTypeIcon = (type) => {
    if (type === 'business' || type === 'merchant') {
      return <Building2 className="w-4 h-4" />;
    }
    return <User className="w-4 h-4" />;
  };

  const getAccountTypeName = (type) => {
    const types = {
      personal: '个人',
      business: '企业',
      merchant: '商户'
    };
    return types[type] || type;
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-start">
        <div>
          <h2 className="text-xl font-semibold text-gray-900">在线支付收款账号</h2>
          <p className="text-sm text-gray-600 mt-1">配置各种支付方式的收款账号信息</p>
        </div>
        <button
          onClick={() => {
            resetForm();
            setShowModal(true);
          }}
          disabled={methods.length === 0}
          className="flex items-center gap-2 bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 disabled:bg-gray-400 disabled:cursor-not-allowed"
        >
          <Plus className="w-4 h-4" />
          添加收款账号
        </button>
      </div>

      {methods.length === 0 && (
        <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4 flex items-start gap-3">
          <AlertCircle className="w-5 h-5 text-yellow-600 flex-shrink-0 mt-0.5" />
          <div>
            <p className="text-sm font-medium text-yellow-900">尚未配置需要账号的付款方式</p>
            <p className="text-sm text-yellow-700 mt-1">
              请先在"全局付款方式"中添加并启用需要配置账号的支付方式（如支付宝、微信、银行转账等）
            </p>
          </div>
        </div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {accounts.map((item) => (
          <div
            key={item.id}
            className="bg-white rounded-lg border border-gray-200 p-4 hover:shadow-md transition-shadow"
          >
            <div className="flex justify-between items-start mb-3">
              <div className="flex items-center gap-2">
                {item.payment_method?.method_name && (
                  <span className="text-sm font-medium text-gray-900">
                    {item.payment_method.method_name}
                  </span>
                )}
                {item.is_primary && (
                  <Star className="w-4 h-4 text-yellow-500 fill-yellow-500" title="主账号" />
                )}
              </div>
              <div className="flex items-center gap-1">
                <button
                  onClick={() => toggleActive(item.id, item.is_active)}
                  className="p-1 text-gray-500 hover:text-gray-700"
                  title={item.is_active ? '禁用' : '启用'}
                >
                  {item.is_active ? <Eye className="w-4 h-4" /> : <EyeOff className="w-4 h-4" />}
                </button>
                <button
                  onClick={() => handleEdit(item)}
                  className="p-1 text-blue-600 hover:text-blue-800"
                  title="编辑"
                >
                  <Edit2 className="w-4 h-4" />
                </button>
                <button
                  onClick={() => handleDelete(item.id)}
                  className="p-1 text-red-600 hover:text-red-800"
                  title="删除"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>

            <div className="space-y-2">
              <div>
                <p className="text-lg font-semibold text-gray-900">{item.account_name}</p>
                <div className="flex items-center gap-1 mt-1">
                  {getAccountTypeIcon(item.account_type)}
                  <span className="text-xs text-gray-600">
                    {getAccountTypeName(item.account_type)}账号
                  </span>
                </div>
              </div>

              {item.qr_code_url && (
                <div className="flex items-center justify-center p-2 bg-gray-50 rounded">
                  <img
                    src={item.qr_code_url}
                    alt="收款码"
                    className="w-32 h-32 object-contain"
                  />
                </div>
              )}

              {item.account_info && Object.keys(item.account_info).length > 0 && (
                <div className="text-xs text-gray-600 space-y-1 pt-2 border-t border-gray-100">
                  {item.account_info.account_holder && (
                    <p>持有人: {item.account_info.account_holder}</p>
                  )}
                  {item.account_info.account_number && (
                    <p>账号: {item.account_info.account_number}</p>
                  )}
                  {item.account_info.bank_name && (
                    <p>银行: {item.account_info.bank_name}</p>
                  )}
                  {item.account_info.phone_number && (
                    <p>电话: {item.account_info.phone_number}</p>
                  )}
                </div>
              )}

              {item.notes && (
                <p className="text-xs text-gray-500 italic">{item.notes}</p>
              )}

              {!item.is_primary && item.is_active && (
                <button
                  onClick={() => setPrimary(item.id)}
                  className="w-full mt-2 text-xs text-blue-600 hover:text-blue-800 font-medium py-1"
                >
                  设为主账号
                </button>
              )}
            </div>

            <div className="mt-3 pt-3 border-t border-gray-100">
              <span className={`inline-flex items-center gap-1 px-2 py-1 text-xs rounded-full ${
                item.is_active
                  ? 'bg-green-100 text-green-700'
                  : 'bg-gray-100 text-gray-600'
              }`}>
                {item.is_active ? '使用中' : '已禁用'}
              </span>
            </div>
          </div>
        ))}

        {accounts.length === 0 && methods.length > 0 && (
          <div className="col-span-full text-center py-12 text-gray-500">
            暂无收款账号，点击"添加收款账号"开始配置
          </div>
        )}
      </div>

      {showModal && (
        <Modal
          isOpen={showModal}
          onClose={() => {
            setShowModal(false);
            resetForm();
          }}
          title={editingItem ? '编辑收款账号' : '添加收款账号'}
        >
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                付款方式 *
              </label>
              <select
                value={formData.payment_method_id}
                onChange={(e) => setFormData({ ...formData, payment_method_id: e.target.value })}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                required
                disabled={!!editingItem}
              >
                <option value="">选择付款方式</option>
                {methods.map((method) => (
                  <option key={method.id} value={method.id}>
                    {method.method_name}
                  </option>
                ))}
              </select>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  账号名称 *
                </label>
                <input
                  type="text"
                  value={formData.account_name}
                  onChange={(e) => setFormData({ ...formData, account_name: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                  placeholder="如: 主账号、备用账号"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  账号类型
                </label>
                <select
                  value={formData.account_type}
                  onChange={(e) => setFormData({ ...formData, account_type: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                >
                  <option value="personal">个人账号</option>
                  <option value="business">企业账号</option>
                  <option value="merchant">商户账号</option>
                </select>
              </div>
            </div>

            <div className="border border-gray-200 rounded-lg p-4 space-y-3">
              <h3 className="text-sm font-semibold text-gray-900">账号详细信息</h3>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-medium text-gray-700 mb-1">
                    持有人姓名
                  </label>
                  <input
                    type="text"
                    value={accountFields.account_holder}
                    onChange={(e) => setAccountFields({ ...accountFields, account_holder: e.target.value })}
                    className="w-full px-2 py-1.5 text-sm border border-gray-300 rounded focus:ring-2 focus:ring-blue-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-medium text-gray-700 mb-1">
                    账号/卡号
                  </label>
                  <input
                    type="text"
                    value={accountFields.account_number}
                    onChange={(e) => setAccountFields({ ...accountFields, account_number: e.target.value })}
                    className="w-full px-2 py-1.5 text-sm border border-gray-300 rounded focus:ring-2 focus:ring-blue-500"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-medium text-gray-700 mb-1">
                    银行名称
                  </label>
                  <input
                    type="text"
                    value={accountFields.bank_name}
                    onChange={(e) => setAccountFields({ ...accountFields, bank_name: e.target.value })}
                    className="w-full px-2 py-1.5 text-sm border border-gray-300 rounded focus:ring-2 focus:ring-blue-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-medium text-gray-700 mb-1">
                    开户行/支行
                  </label>
                  <input
                    type="text"
                    value={accountFields.bank_branch}
                    onChange={(e) => setAccountFields({ ...accountFields, bank_branch: e.target.value })}
                    className="w-full px-2 py-1.5 text-sm border border-gray-300 rounded focus:ring-2 focus:ring-blue-500"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-medium text-gray-700 mb-1">
                    联系电话
                  </label>
                  <input
                    type="tel"
                    value={accountFields.phone_number}
                    onChange={(e) => setAccountFields({ ...accountFields, phone_number: e.target.value })}
                    className="w-full px-2 py-1.5 text-sm border border-gray-300 rounded focus:ring-2 focus:ring-blue-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-medium text-gray-700 mb-1">
                    邮箱
                  </label>
                  <input
                    type="email"
                    value={accountFields.email}
                    onChange={(e) => setAccountFields({ ...accountFields, email: e.target.value })}
                    className="w-full px-2 py-1.5 text-sm border border-gray-300 rounded focus:ring-2 focus:ring-blue-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-medium text-gray-700 mb-1">
                  地址
                </label>
                <input
                  type="text"
                  value={accountFields.address}
                  onChange={(e) => setAccountFields({ ...accountFields, address: e.target.value })}
                  className="w-full px-2 py-1.5 text-sm border border-gray-300 rounded focus:ring-2 focus:ring-blue-500"
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                收款二维码
              </label>
              <ImageUploader
                value={formData.qr_code_url}
                onChange={(url) => setFormData({ ...formData, qr_code_url: url })}
                folder="payment-qrcodes"
              />
              <p className="text-xs text-gray-500 mt-1">上传支付宝/微信等收款二维码</p>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                备注说明
              </label>
              <textarea
                value={formData.notes}
                onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                rows="2"
                placeholder="其他说明信息..."
              />
            </div>

            <div className="flex gap-3 pt-4">
              <button
                type="submit"
                disabled={loading}
                className="flex-1 flex items-center justify-center gap-2 bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 disabled:bg-gray-400"
              >
                <Save className="w-4 h-4" />
                {loading ? '保存中...' : '保存'}
              </button>
              <button
                type="button"
                onClick={() => {
                  setShowModal(false);
                  resetForm();
                }}
                className="px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50"
              >
                取消
              </button>
            </div>
          </form>
        </Modal>
      )}
    </div>
  );
}
