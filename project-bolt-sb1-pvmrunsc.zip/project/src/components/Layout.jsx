import React, { useState } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { useModules } from '../contexts/ModuleContext';
import Logo, { LogoCompact } from './Logo';
import * as Icons from 'lucide-react';

const {
  LogOut,
  Menu,
  X,
  ChevronDown,
  Puzzle,
  ...AllIcons
} = Icons;

export default function Layout({ children }) {
  const { admin, logout } = useAuth();
  const { routes } = useModules();
  const location = useLocation();
  const navigate = useNavigate();
  const [sidebarOpen, setSidebarOpen] = useState(false);

  const handleLogout = () => {
    logout();
    navigate('/admin/login');
  };

  const navigation = routes
    .filter(route => route.is_menu_item)
    .sort((a, b) => a.menu_order - b.menu_order)
    .map(route => {
      const IconComponent = AllIcons[route.menu_icon] || AllIcons.Circle;
      return {
        name: route.menu_label?.zh || route.component_name,
        href: route.route_path,
        icon: IconComponent,
        moduleKey: route.module_key
      };
    });

  const moduleManagerItem = {
    name: '模块管理',
    href: '/admin/modules',
    icon: Puzzle
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50/30 to-slate-100">
      <div className="lg:hidden fixed top-0 left-0 right-0 z-50 px-4 py-3 flex items-center justify-between shadow-xl frosted-glass border-b border-slate-200/50">
        <Logo size="sm" showText={true} />
        <button
          onClick={() => setSidebarOpen(!sidebarOpen)}
          className="p-2.5 rounded-xl hover:bg-slate-100 transition-all duration-200 hover:scale-105 active:scale-95 button-hover"
        >
          {sidebarOpen ? <X className="w-6 h-6 text-slate-700" /> : <Menu className="w-6 h-6 text-slate-700" />}
        </button>
      </div>

      <div
        className={`fixed inset-0 bg-slate-900/70 backdrop-blur-sm z-40 lg:hidden transition-opacity duration-300 ${
          sidebarOpen ? 'opacity-100' : 'opacity-0 pointer-events-none'
        }`}
        onClick={() => setSidebarOpen(false)}
      />

      <aside
        className={`fixed top-0 left-0 bottom-0 w-72 z-40 transform transition-all duration-300 ease-out lg:translate-x-0 shadow-2xl ${
          sidebarOpen ? 'translate-x-0' : '-translate-x-full'
        }`}
      >
        <div className="h-full flex flex-col bg-gradient-to-b from-slate-900 via-slate-900 to-slate-950 border-r border-slate-800/50">
          <div className="absolute inset-0 bg-grid-pattern opacity-5 pointer-events-none"></div>

          <div className="relative p-6 border-b border-slate-800/80 bg-gradient-to-br from-slate-800/30 to-transparent">
            <div className="mb-6">
              <Logo size="md" showText={true} />
            </div>

            <div className="relative group">
              <div className="absolute inset-0 bg-gradient-to-br from-blue-500/10 to-cyan-500/10 rounded-2xl blur-xl opacity-50 group-hover:opacity-75 transition-opacity duration-300"></div>

              <div className="relative flex items-center gap-3 px-4 py-3.5 bg-gradient-to-br from-slate-800/80 to-slate-900/80 rounded-2xl border border-slate-700/50 shadow-xl backdrop-blur-xl hover:shadow-2xl hover:border-slate-600/50 transition-all duration-300 hover:transform hover:scale-[1.02]">
                <div className="relative">
                  <div className="w-11 h-11 bg-gradient-to-br from-blue-500 via-blue-600 to-cyan-600 rounded-full flex items-center justify-center text-white text-base font-black shadow-lg ring-2 ring-blue-400/30">
                    {admin?.full_name?.[0] || 'A'}
                  </div>
                  <div className="absolute -bottom-0.5 -right-0.5 w-3.5 h-3.5 bg-green-500 rounded-full border-2 border-slate-900 animate-pulse"></div>
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-bold text-white truncate tracking-tight">{admin?.full_name || '管理员'}</p>
                  <p className="text-xs font-semibold bg-gradient-to-r from-blue-400 to-cyan-400 bg-clip-text text-transparent">
                    {admin?.admin_type === 'super_admin' ? '超级管理员' : '管理员'}
                  </p>
                </div>
                <div className="w-2 h-2 rounded-full bg-blue-400 animate-pulse shadow-lg shadow-blue-500/50"></div>
              </div>
            </div>
          </div>

          <nav className="flex-1 overflow-y-auto p-4 custom-scrollbar space-y-1.5">
            {[moduleManagerItem, ...navigation].map((item, index) => {
              const isActive = location.pathname === item.href;
              const Icon = item.icon;
              return (
                <Link
                  key={item.name}
                  to={item.href}
                  onClick={() => setSidebarOpen(false)}
                  className={`relative group flex items-center gap-3.5 px-4 py-3.5 rounded-xl transition-all duration-300 overflow-hidden ${
                    isActive
                      ? 'bg-gradient-to-r from-blue-600 via-blue-500 to-cyan-500 text-white shadow-xl shadow-blue-500/30 scale-[1.02]'
                      : 'text-slate-300 hover:text-white hover:bg-slate-800/60 hover:shadow-lg hover:scale-[1.01]'
                  }`}
                  style={{
                    animationDelay: `${index * 20}ms`,
                    animation: 'slideRight 0.4s cubic-bezier(0.16, 1, 0.3, 1) backwards'
                  }}
                >
                  {isActive && (
                    <>
                      <div className="absolute inset-0 bg-gradient-to-r from-white/0 via-white/10 to-white/0 animate-shimmer"></div>
                      <div className="absolute left-0 top-1/2 -translate-y-1/2 w-1 h-10 bg-white rounded-r-full shadow-lg"></div>
                    </>
                  )}

                  <div className={`relative z-10 p-2 rounded-lg transition-all duration-300 ${
                    isActive ? 'bg-white/10 shadow-inner' : 'group-hover:bg-slate-700/50'
                  }`}>
                    <Icon
                      className={`w-5 h-5 transition-all duration-300 ${
                        isActive ? 'drop-shadow-md scale-110' : 'group-hover:scale-110'
                      }`}
                      strokeWidth={isActive ? 2.5 : 2}
                    />
                  </div>

                  <span className={`font-semibold relative z-10 tracking-tight text-sm ${
                    isActive ? 'text-shadow-sm' : ''
                  }`}>
                    {item.name}
                  </span>

                  {isActive && (
                    <div className="ml-auto relative z-10">
                      <div className="w-2 h-2 rounded-full bg-white animate-pulse shadow-lg"></div>
                    </div>
                  )}

                  {!isActive && (
                    <div className="ml-auto opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                      <Icons.ChevronRight className="w-4 h-4" />
                    </div>
                  )}
                </Link>
              );
            })}
          </nav>

          <div className="relative p-4 border-t border-slate-800/80 bg-gradient-to-t from-slate-950/50 to-transparent">
            <button
              onClick={handleLogout}
              className="w-full flex items-center gap-3.5 px-4 py-3.5 text-red-400 hover:text-red-300 bg-red-500/10 hover:bg-red-500/20 rounded-xl transition-all duration-300 hover:shadow-lg hover:shadow-red-500/20 group active:scale-95 border border-red-500/20 hover:border-red-500/30 button-hover"
            >
              <div className="p-2 bg-red-500/10 group-hover:bg-red-500/20 rounded-lg transition-colors duration-300">
                <LogOut className="w-5 h-5 group-hover:scale-110 group-hover:-rotate-6 transition-all duration-300" strokeWidth={2} />
              </div>
              <span className="font-semibold tracking-tight text-sm">退出登录</span>
            </button>
          </div>
        </div>
      </aside>

      <main className="lg:ml-72 min-h-screen pt-16 lg:pt-0">
        <div className="p-6 lg:p-8 xl:p-10 animate-fade-in">
          <div className="max-w-screen-2xl mx-auto">
            {children}
          </div>
        </div>
      </main>
    </div>
  );
}
