import { useState, useEffect } from 'react';
import { supabase } from '../../lib/supabase';
import { useToast } from '../../contexts/ToastContext';
import ImageUploader from '../ImageUploader';
import {
  Settings,
  Store,
  Type,
  Image as ImageIcon,
  Palette,
  Save,
  RefreshCw,
  Eye,
  Link as LinkIcon
} from 'lucide-react';

export default function StoreSettings() {
  const [config, setConfig] = useState(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [storeName, setStoreName] = useState({ zh: '', en: '' });
  const [siteTitle, setSiteTitle] = useState({ zh: '', en: '' });
  const [siteSubtitle, setSiteSubtitle] = useState({ zh: '', en: '' });
  const [logoUrl, setLogoUrl] = useState('');
  const [primaryColor, setPrimaryColor] = useState('#14b8a6');
  const [secondaryColor, setSecondaryColor] = useState('#10b981');
  const { showToast } = useToast();

  useEffect(() => {
    loadStoreConfig();
  }, []);

  const loadStoreConfig = async () => {
    try {
      setLoading(true);

      const { data: domainData } = await supabase
        .from('sys_domains')
        .select('id')
        .limit(1)
        .single();

      if (!domainData) {
        showToast('未找到域配置', 'error');
        return;
      }

      let { data: configData, error } = await supabase
        .from('store_configs')
        .select('*')
        .eq('domain_id', domainData.id)
        .maybeSingle();

      if (error && error.code !== 'PGRST116') {
        throw error;
      }

      if (!configData) {
        const { data: userData } = await supabase.auth.getUser();

        const { data: newConfig, error: insertError } = await supabase
          .from('store_configs')
          .insert({
            domain_id: domainData.id,
            created_by: userData.user?.id
          })
          .select()
          .single();

        if (insertError) throw insertError;
        configData = newConfig;
      }

      setConfig(configData);
      setStoreName(configData.store_name || { zh: '168全球购', en: '168 Global Shop' });
      setSiteTitle(configData.site_title || { zh: '168全球购 - 全球精选好物', en: '168 Global Shop' });
      setSiteSubtitle(configData.site_subtitle || { zh: '全球精选好物 · 货到付款', en: 'Selected Products' });
      setLogoUrl(configData.store_logo_url || '');
      setPrimaryColor(configData.primary_color || '#14b8a6');
      setSecondaryColor(configData.secondary_color || '#10b981');

    } catch (error) {
      console.error('Error loading store config:', error);
      showToast('加载配置失败', 'error');
    } finally {
      setLoading(false);
    }
  };

  const handleSave = async () => {
    if (!config) return;

    try {
      setSaving(true);

      const { error } = await supabase
        .from('store_configs')
        .update({
          store_name: storeName,
          site_title: siteTitle,
          site_subtitle: siteSubtitle,
          store_logo_url: logoUrl,
          primary_color: primaryColor,
          secondary_color: secondaryColor,
          updated_at: new Date().toISOString()
        })
        .eq('id', config.id);

      if (error) throw error;

      showToast('保存成功！', 'success');
      await loadStoreConfig();

    } catch (error) {
      console.error('Error saving config:', error);
      showToast('保存失败', 'error');
    } finally {
      setSaving(false);
    }
  };

  const handlePreview = () => {
    window.open('/', '_blank');
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center py-12">
        <div className="animate-spin rounded-full h-12 w-12 border-4 border-teal-500 border-t-transparent"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-gradient-to-br from-teal-500 to-cyan-600 rounded-lg flex items-center justify-center">
            <Settings className="w-6 h-6 text-white" />
          </div>
          <div>
            <h2 className="text-xl font-bold text-gray-900">商城配置</h2>
            <p className="text-sm text-gray-600">自定义商城名称、LOGO和外观</p>
          </div>
        </div>
        <div className="flex items-center gap-3">
          <button
            onClick={handlePreview}
            className="flex items-center gap-2 px-4 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 transition-colors"
          >
            <Eye className="w-4 h-4" />
            预览商城
          </button>
          <button
            onClick={handleSave}
            disabled={saving}
            className="flex items-center gap-2 px-6 py-2 bg-gradient-to-r from-teal-500 to-cyan-600 text-white rounded-lg hover:from-teal-600 hover:to-cyan-700 disabled:opacity-50 disabled:cursor-not-allowed transition-all shadow-lg hover:shadow-xl"
          >
            {saving ? (
              <>
                <RefreshCw className="w-4 h-4 animate-spin" />
                保存中...
              </>
            ) : (
              <>
                <Save className="w-4 h-4" />
                保存配置
              </>
            )}
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white rounded-lg border-2 border-gray-200 p-6 space-y-6">
          <div className="flex items-center gap-2 pb-4 border-b border-gray-200">
            <Store className="w-5 h-5 text-teal-600" />
            <h3 className="font-semibold text-gray-900">基本信息</h3>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              商城名称（中文）
            </label>
            <input
              type="text"
              value={storeName.zh}
              onChange={(e) => setStoreName({ ...storeName, zh: e.target.value })}
              placeholder="例如：168全球购"
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-teal-500 focus:border-transparent"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              商城名称（英文）
            </label>
            <input
              type="text"
              value={storeName.en}
              onChange={(e) => setStoreName({ ...storeName, en: e.target.value })}
              placeholder="例如：168 Global Shop"
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-teal-500 focus:border-transparent"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              网站标题（中文）
            </label>
            <input
              type="text"
              value={siteTitle.zh}
              onChange={(e) => setSiteTitle({ ...siteTitle, zh: e.target.value })}
              placeholder="例如：168全球购 - 全球精选好物"
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-teal-500 focus:border-transparent"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              网站标题（英文）
            </label>
            <input
              type="text"
              value={siteTitle.en}
              onChange={(e) => setSiteTitle({ ...siteTitle, en: e.target.value })}
              placeholder="例如：168 Global Shop - Selected Products"
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-teal-500 focus:border-transparent"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              副标题（中文）
            </label>
            <input
              type="text"
              value={siteSubtitle.zh}
              onChange={(e) => setSiteSubtitle({ ...siteSubtitle, zh: e.target.value })}
              placeholder="例如：全球精选好物 · 货到付款"
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-teal-500 focus:border-transparent"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              副标题（英文）
            </label>
            <input
              type="text"
              value={siteSubtitle.en}
              onChange={(e) => setSiteSubtitle({ ...siteSubtitle, en: e.target.value })}
              placeholder="例如：Selected Products · Cash on Delivery"
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-teal-500 focus:border-transparent"
            />
          </div>
        </div>

        <div className="space-y-6">
          <div className="bg-white rounded-lg border-2 border-gray-200 p-6">
            <div className="flex items-center gap-2 pb-4 border-b border-gray-200 mb-4">
              <ImageIcon className="w-5 h-5 text-teal-600" />
              <h3 className="font-semibold text-gray-900">商城LOGO</h3>
            </div>

            <div className="space-y-4">
              <ImageUploader
                currentImage={logoUrl}
                onImageChange={setLogoUrl}
                label="上传LOGO"
              />

              {logoUrl && (
                <div className="mt-4 p-4 bg-gray-50 rounded-lg">
                  <p className="text-sm text-gray-600 mb-2">LOGO预览：</p>
                  <img
                    src={logoUrl}
                    alt="Logo"
                    className="h-16 object-contain"
                    onError={(e) => {
                      e.target.style.display = 'none';
                    }}
                  />
                  <div className="mt-2">
                    <p className="text-xs text-gray-500 break-all">{logoUrl}</p>
                  </div>
                </div>
              )}
            </div>
          </div>

          <div className="bg-white rounded-lg border-2 border-gray-200 p-6">
            <div className="flex items-center gap-2 pb-4 border-b border-gray-200 mb-4">
              <Palette className="w-5 h-5 text-teal-600" />
              <h3 className="font-semibold text-gray-900">主题颜色</h3>
            </div>

            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  主色调
                </label>
                <div className="flex items-center gap-3">
                  <input
                    type="color"
                    value={primaryColor}
                    onChange={(e) => setPrimaryColor(e.target.value)}
                    className="w-16 h-10 rounded-lg border border-gray-300 cursor-pointer"
                  />
                  <input
                    type="text"
                    value={primaryColor}
                    onChange={(e) => setPrimaryColor(e.target.value)}
                    className="flex-1 px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-teal-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  辅助色
                </label>
                <div className="flex items-center gap-3">
                  <input
                    type="color"
                    value={secondaryColor}
                    onChange={(e) => setSecondaryColor(e.target.value)}
                    className="w-16 h-10 rounded-lg border border-gray-300 cursor-pointer"
                  />
                  <input
                    type="text"
                    value={secondaryColor}
                    onChange={(e) => setSecondaryColor(e.target.value)}
                    className="flex-1 px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-teal-500"
                  />
                </div>
              </div>

              <div className="mt-4 p-4 bg-gray-50 rounded-lg">
                <p className="text-sm font-medium text-gray-700 mb-3">颜色预览：</p>
                <div className="flex items-center gap-3">
                  <div
                    className="flex-1 h-12 rounded-lg shadow-md"
                    style={{ backgroundColor: primaryColor }}
                  ></div>
                  <div
                    className="flex-1 h-12 rounded-lg shadow-md"
                    style={{ backgroundColor: secondaryColor }}
                  ></div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="bg-gradient-to-br from-teal-50 to-cyan-50 rounded-lg border-2 border-teal-200 p-6">
        <div className="flex items-start gap-3">
          <div className="w-10 h-10 bg-teal-500 rounded-lg flex items-center justify-center flex-shrink-0">
            <LinkIcon className="w-5 h-5 text-white" />
          </div>
          <div className="flex-1">
            <h4 className="font-semibold text-gray-900 mb-2">配置说明</h4>
            <ul className="text-sm text-gray-700 space-y-1">
              <li>• 商城名称将显示在网站头部和页面标题中</li>
              <li>• LOGO建议使用透明背景的PNG格式，尺寸200x200像素</li>
              <li>• 主色调用于按钮和重要元素，辅助色用于渐变效果</li>
              <li>• 修改配置后点击"预览商城"查看效果</li>
              <li>• 所有更改保存后立即生效</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
}
