import React, { useEffect, useState } from 'react';
import { supabase } from '../../lib/supabase';
import ProductForm from '../ProductForm';
import Modal from '../Modal';
import ConfirmDialog from '../ConfirmDialog';
import Pagination from '../Pagination';
import { useToast } from '../../contexts/ToastContext';
import { Package, Plus, Search, Edit, Trash2, Eye, DollarSign, Link as LinkIcon, Copy, ExternalLink, CheckCircle, XCircle, FileText } from 'lucide-react';

export default function ProductsManager() {
  const { success, error: showError } = useToast();
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [showAddForm, setShowAddForm] = useState(false);
  const [showEditForm, setShowEditForm] = useState(false);
  const [showDetailModal, setShowDetailModal] = useState(false);
  const [selectedProduct, setSelectedProduct] = useState(null);
  const [showDeleteDialog, setShowDeleteDialog] = useState(false);
  const [productToDelete, setProductToDelete] = useState(null);
  const [currentPage, setCurrentPage] = useState(1);
  const [itemsPerPage] = useState(10);

  useEffect(() => {
    loadProducts();
  }, []);

  const loadProducts = async () => {
    try {
      const { data, error } = await supabase
        .from('sys_products')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) throw error;
      setProducts(data || []);
    } catch (error) {
      console.error('Error loading products:', error);
      showError('加载产品列表失败');
    } finally {
      setLoading(false);
    }
  };

  const handleProductAdded = () => {
    loadProducts();
    success('产品添加成功');
  };

  const handleProductUpdated = () => {
    loadProducts();
    success('产品更新成功');
  };

  const handleViewProduct = (product) => {
    setSelectedProduct(product);
    setShowDetailModal(true);
  };

  const handleEditProduct = (product) => {
    setSelectedProduct(product);
    setShowEditForm(true);
  };

  const handleDeleteClick = (product) => {
    setProductToDelete(product);
    setShowDeleteDialog(true);
  };

  const handleDeleteConfirm = async () => {
    if (!productToDelete) return;

    try {
      const { error } = await supabase
        .from('sys_products')
        .delete()
        .eq('id', productToDelete.id);

      if (error) throw error;

      loadProducts();
      success('产品删除成功');
      setProductToDelete(null);
    } catch (error) {
      console.error('Error deleting product:', error);
      showError('删除产品失败');
    }
  };

  const handleCopyProductCode = (productCode) => {
    navigator.clipboard.writeText(productCode);
    success('商品ID已复制');
  };

  const handleCopyProductUrl = (productUrl) => {
    const fullUrl = window.location.origin + productUrl;
    navigator.clipboard.writeText(fullUrl);
    success('商品链接已复制');
  };

  const handleUpdateProductUrl = async (product, newUrl) => {
    try {
      const { error } = await supabase
        .from('sys_products')
        .update({ product_url: newUrl })
        .eq('id', product.id);

      if (error) throw error;

      loadProducts();
      success('商品链接已更新');
    } catch (error) {
      console.error('Error updating product URL:', error);
      showError('更新商品链接失败');
    }
  };

  const handleUpdateStatus = async (productId, newStatus) => {
    try {
      const { error } = await supabase
        .from('sys_products')
        .update({ status: newStatus })
        .eq('id', productId);

      if (error) throw error;

      loadProducts();
      success(`商品已${getStatusText(newStatus)}`);
    } catch (error) {
      console.error('Error updating product status:', error);
      showError('更新商品状态失败');
    }
  };

  const getTitle = (titleObj) => {
    if (typeof titleObj === 'string') return titleObj;
    return titleObj?.zh || titleObj?.en || '未命名产品';
  };

  const getStatusColor = (status) => {
    switch(status) {
      case 'active':
        return 'bg-green-100 text-green-700';
      case 'inactive':
        return 'bg-gray-100 text-gray-700';
      case 'draft':
        return 'bg-yellow-100 text-yellow-700';
      default:
        return 'bg-gray-100 text-gray-700';
    }
  };

  const getStatusText = (status) => {
    switch(status) {
      case 'active':
        return '在售';
      case 'inactive':
        return '下架';
      case 'draft':
        return '草稿';
      default:
        return '未知';
    }
  };

  const filteredProducts = products.filter(product => {
    const title = getTitle(product.title).toLowerCase();
    const serial = (product.serial_number || '').toLowerCase();
    const search = searchTerm.toLowerCase();
    return title.includes(search) || serial.includes(search);
  });

  const totalPages = Math.ceil(filteredProducts.length / itemsPerPage);
  const paginatedProducts = filteredProducts.slice(
    (currentPage - 1) * itemsPerPage,
    currentPage * itemsPerPage
  );

  const handlePageChange = (page) => {
    setCurrentPage(page);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  useEffect(() => {
    setCurrentPage(1);
  }, [searchTerm]);

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-4 border-blue-500 border-t-transparent"></div>
      </div>
    );
  }

  return (
    <>
      {showAddForm && (
        <ProductForm
          onClose={() => setShowAddForm(false)}
          onSuccess={handleProductAdded}
        />
      )}

      {showEditForm && selectedProduct && (
        <ProductForm
          product={selectedProduct}
          onClose={() => {
            setShowEditForm(false);
            setSelectedProduct(null);
          }}
          onSuccess={handleProductUpdated}
        />
      )}

      <Modal
        isOpen={showDetailModal}
        onClose={() => {
          setShowDetailModal(false);
          setSelectedProduct(null);
        }}
        title="产品详情"
        size="lg"
      >
        {selectedProduct && (
          <div className="space-y-4">
            <div>
              <label className="text-sm font-medium text-gray-500">产品名称</label>
              <p className="text-lg font-semibold text-gray-900">{getTitle(selectedProduct.title)}</p>
            </div>
            <div>
              <label className="text-sm font-medium text-gray-500">商品ID</label>
              <div className="flex items-center gap-2 mt-1">
                <code className="text-sm font-mono bg-gray-100 px-3 py-1.5 rounded text-gray-900 flex-1">
                  {selectedProduct.product_code || '-'}
                </code>
                {selectedProduct.product_code && (
                  <button
                    onClick={() => handleCopyProductCode(selectedProduct.product_code)}
                    className="p-2 hover:bg-blue-50 rounded-lg transition-colors"
                    title="复制商品ID"
                  >
                    <Copy className="w-4 h-4 text-blue-600" />
                  </button>
                )}
              </div>
            </div>
            <div>
              <label className="text-sm font-medium text-gray-500">网站头部标题（单品页面）</label>
              <p className="text-gray-900 mt-1">{selectedProduct.page_title || '-'}</p>
              <p className="text-xs text-gray-500 mt-1">此标题仅在单品页面显示</p>
            </div>
            <div>
              <label className="text-sm font-medium text-gray-500">商品链接</label>
              <div className="flex items-center gap-2 mt-1">
                <code className="text-sm font-mono bg-gray-100 px-3 py-1.5 rounded text-gray-900 flex-1 truncate">
                  {selectedProduct.product_url || '-'}
                </code>
                {selectedProduct.product_url && (
                  <>
                    <button
                      onClick={() => handleCopyProductUrl(selectedProduct.product_url)}
                      className="p-2 hover:bg-blue-50 rounded-lg transition-colors"
                      title="复制完整链接"
                    >
                      <Copy className="w-4 h-4 text-blue-600" />
                    </button>
                    <button
                      onClick={() => window.open(selectedProduct.product_url, '_blank')}
                      className="p-2 hover:bg-green-50 rounded-lg transition-colors"
                      title="在新标签页打开"
                    >
                      <ExternalLink className="w-4 h-4 text-green-600" />
                    </button>
                  </>
                )}
              </div>
            </div>
            <div>
              <label className="text-sm font-medium text-gray-500">商品状态</label>
              <div className="mt-2">
                <span className={`inline-flex px-3 py-1.5 text-sm font-medium rounded-lg ${getStatusColor(selectedProduct.status)}`}>
                  {getStatusText(selectedProduct.status)}
                </span>
              </div>
            </div>
            <div>
              <label className="text-sm font-medium text-gray-500">产品编号</label>
              <p className="text-gray-900">{selectedProduct.serial_number || '-'}</p>
            </div>
            <div>
              <label className="text-sm font-medium text-gray-500">价格</label>
              <p className="text-2xl font-bold text-emerald-600">¥{Number(selectedProduct.base_price).toLocaleString()}</p>
            </div>
            <div>
              <label className="text-sm font-medium text-gray-500">分类</label>
              <p className="text-gray-900">{selectedProduct.category || '未分类'}</p>
            </div>
            <div>
              <label className="text-sm font-medium text-gray-500">创建时间</label>
              <p className="text-gray-900">{new Date(selectedProduct.created_at).toLocaleString('zh-CN')}</p>
            </div>
          </div>
        )}
      </Modal>

      <ConfirmDialog
        isOpen={showDeleteDialog}
        onClose={() => {
          setShowDeleteDialog(false);
          setProductToDelete(null);
        }}
        onConfirm={handleDeleteConfirm}
        title="删除产品"
        message={`确定要删除产品"${productToDelete ? getTitle(productToDelete.title) : ''}"吗？此操作无法撤销。`}
        type="danger"
      />

      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-xl font-semibold text-gray-900">商品库存</h2>
            <p className="text-sm text-gray-500 mt-1">共 {filteredProducts.length} 件商品</p>
          </div>
          <button
            onClick={() => setShowAddForm(true)}
            className="flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-orange-500 to-amber-600 text-white rounded-lg hover:shadow-lg transition-all hover:scale-105"
          >
            <Plus className="w-5 h-5" />
            <span>添加商品</span>
          </button>
        </div>

        <div className="bg-white rounded-xl border border-gray-200">
          <div className="p-6 border-b border-gray-200">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
              <input
                type="text"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder="搜索商品名称或编号..."
                className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">商品ID</th>
                  <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">网站头部标题</th>
                  <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">商品名称</th>
                  <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">商品链接</th>
                  <th className="px-4 py-3 text-center text-xs font-medium text-gray-500 uppercase">操作</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-200">
                {paginatedProducts.map((product) => (
                  <tr key={product.id} className="hover:bg-gray-50 transition-colors">
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-2">
                        <code className="text-sm font-mono font-bold bg-blue-50 px-3 py-1.5 rounded-lg text-blue-700">
                          {product.product_code || '-'}
                        </code>
                      </div>
                    </td>
                    <td className="px-4 py-3">
                      <div className="text-sm text-gray-900">
                        {product.page_title || '-'}
                      </div>
                      <div className="text-xs text-gray-500 mt-0.5">单品页面标题</div>
                    </td>
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded-lg bg-blue-50 flex items-center justify-center flex-shrink-0">
                          <Package className="w-5 h-5 text-blue-600" />
                        </div>
                        <div className="min-w-0">
                          <p className="text-sm font-medium text-gray-900 truncate">{getTitle(product.title)}</p>
                          <p className="text-xs text-gray-500">{product.category || '未分类'} · ¥{Number(product.base_price).toLocaleString()}</p>
                        </div>
                      </div>
                    </td>
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-2">
                        <code className="text-xs font-mono text-gray-600 truncate max-w-[120px]">
                          {product.product_url || '-'}
                        </code>
                      </div>
                    </td>
                    <td className="px-4 py-3">
                      <div className="flex items-center justify-center gap-1.5 flex-wrap">
                        <button
                          onClick={() => handleCopyProductCode(product.product_code)}
                          className="px-3 py-1.5 text-xs bg-blue-50 text-blue-700 rounded-lg hover:bg-blue-100 transition-colors flex items-center gap-1.5"
                          title="复制商品ID"
                        >
                          <Copy className="w-3.5 h-3.5" />
                          复制
                        </button>
                        <button
                          onClick={() => handleDeleteClick(product)}
                          className="px-3 py-1.5 text-xs bg-red-50 text-red-700 rounded-lg hover:bg-red-100 transition-colors flex items-center gap-1.5"
                          title="删除"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                          删除
                        </button>
                        {product.status === 'active' ? (
                          <button
                            onClick={() => handleUpdateStatus(product.id, 'inactive')}
                            className="px-3 py-1.5 text-xs bg-gray-50 text-gray-700 rounded-lg hover:bg-gray-100 transition-colors flex items-center gap-1.5"
                            title="下架商品"
                          >
                            <XCircle className="w-3.5 h-3.5" />
                            下架
                          </button>
                        ) : product.status === 'inactive' ? (
                          <button
                            onClick={() => handleUpdateStatus(product.id, 'active')}
                            className="px-3 py-1.5 text-xs bg-green-50 text-green-700 rounded-lg hover:bg-green-100 transition-colors flex items-center gap-1.5"
                            title="上架商品"
                          >
                            <CheckCircle className="w-3.5 h-3.5" />
                            上架
                          </button>
                        ) : (
                          <button
                            onClick={() => handleUpdateStatus(product.id, 'active')}
                            className="px-3 py-1.5 text-xs bg-green-50 text-green-700 rounded-lg hover:bg-green-100 transition-colors flex items-center gap-1.5"
                            title="发布草稿"
                          >
                            <CheckCircle className="w-3.5 h-3.5" />
                            发布
                          </button>
                        )}
                        <button
                          onClick={() => handleUpdateStatus(product.id, 'draft')}
                          className="px-3 py-1.5 text-xs bg-yellow-50 text-yellow-700 rounded-lg hover:bg-yellow-100 transition-colors flex items-center gap-1.5"
                          title="转为草稿"
                        >
                          <FileText className="w-3.5 h-3.5" />
                          草稿
                        </button>
                        <button
                          onClick={() => handleEditProduct(product)}
                          className="px-3 py-1.5 text-xs bg-purple-50 text-purple-700 rounded-lg hover:bg-purple-100 transition-colors flex items-center gap-1.5"
                          title="编辑商品"
                        >
                          <Edit className="w-3.5 h-3.5" />
                          编辑
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {filteredProducts.length === 0 && (
            <div className="text-center py-12">
              <Package className="w-12 h-12 text-gray-400 mx-auto mb-3" />
              <p className="text-gray-500">暂无产品数据</p>
            </div>
          )}

          {filteredProducts.length > 0 && (
            <Pagination
              currentPage={currentPage}
              totalPages={totalPages}
              onPageChange={handlePageChange}
              itemsPerPage={itemsPerPage}
              totalItems={filteredProducts.length}
            />
          )}
        </div>
      </div>
    </>
  );
}
