import React, { useState, useEffect } from 'react';
import { supabase } from '../../lib/supabase';
import { ShoppingCart, Search, Filter, Star, TrendingUp, ExternalLink } from 'lucide-react';

export default function StoreDisplay() {
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [categories, setCategories] = useState([]);

  useEffect(() => {
    fetchProducts();
  }, []);

  const fetchProducts = async () => {
    try {
      setLoading(true);

      const { data: productsData, error } = await supabase
        .from('sys_products')
        .select(`
          id,
          title,
          description,
          base_price,
          compare_price,
          currency_code,
          category,
          tags,
          views_count,
          orders_count,
          sys_product_images!inner(
            original_url,
            is_primary
          )
        `)
        .eq('status', 'active')
        .order('created_at', { ascending: false });

      if (error) throw error;

      const processedProducts = productsData.map(product => ({
        ...product,
        primaryImage: product.sys_product_images.find(img => img.is_primary)?.original_url
                      || product.sys_product_images[0]?.original_url
                      || 'https://images.pexels.com/photos/230544/pexels-photo-230544.jpeg',
        titleText: typeof product.title === 'object'
                   ? (product.title.zh || product.title.en || Object.values(product.title)[0])
                   : product.title,
        descriptionText: typeof product.description === 'object'
                        ? (product.description.zh || product.description.en || Object.values(product.description)[0])
                        : product.description
      }));

      setProducts(processedProducts);

      const uniqueCategories = [...new Set(productsData
        .map(p => p.category)
        .filter(Boolean))];
      setCategories(uniqueCategories);

    } catch (error) {
      console.error('Error fetching products:', error);
    } finally {
      setLoading(false);
    }
  };

  const filteredProducts = products.filter(product => {
    const matchesSearch = !searchQuery ||
      product.titleText?.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = selectedCategory === 'all' ||
      product.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  const formatPrice = (price, currency = 'CNY') => {
    const symbols = { CNY: '¥', USD: '$', EUR: '€' };
    return `${symbols[currency] || ''}${parseFloat(price).toFixed(2)}`;
  };

  return (
    <div className="space-y-6">
      <div className="bg-gradient-to-r from-teal-500 via-emerald-500 to-cyan-600 rounded-2xl p-6 text-white">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-2xl font-bold mb-2">168全球购商城预览</h2>
            <p className="text-teal-50">这是顾客看到的店铺前台展示效果</p>
          </div>
          <a
            href="/"
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center gap-2 px-4 py-2 bg-white text-teal-600 rounded-lg hover:bg-teal-50 transition-colors font-medium"
          >
            <ExternalLink className="w-4 h-4" />
            访问店铺
          </a>
        </div>
      </div>

      <div className="bg-white rounded-xl border border-gray-200 p-6">
        <div className="space-y-4 mb-6">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
            <input
              type="text"
              placeholder="搜索商品..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-10 pr-4 py-2.5 border-2 border-gray-200 rounded-xl focus:ring-2 focus:ring-teal-500/30 focus:border-teal-500 outline-none"
            />
          </div>

          {categories.length > 0 && (
            <div className="space-y-3">
              <div className="flex items-center gap-2">
                <Filter className="w-4 h-4 text-gray-500" />
                <span className="text-sm font-medium text-gray-700">商品分类</span>
              </div>
              <div className="flex items-center gap-2 flex-wrap">
                <button
                  onClick={() => setSelectedCategory('all')}
                  className={`px-4 py-2 rounded-lg text-sm font-medium transition-all ${
                    selectedCategory === 'all'
                      ? 'bg-teal-600 text-white shadow-md'
                      : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                  }`}
                >
                  全部
                </button>
                {categories.map(category => (
                  <button
                    key={category}
                    onClick={() => setSelectedCategory(category)}
                    className={`px-4 py-2 rounded-lg text-sm font-medium transition-all ${
                      selectedCategory === category
                        ? 'bg-teal-600 text-white shadow-md'
                        : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                    }`}
                  >
                    {category}
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>

        {loading ? (
          <div className="flex flex-col items-center justify-center py-12">
            <div className="animate-spin rounded-full h-12 w-12 border-4 border-teal-200 border-t-teal-600"></div>
            <p className="mt-4 text-gray-600">加载中...</p>
          </div>
        ) : filteredProducts.length === 0 ? (
          <div className="text-center py-12 bg-gray-50 rounded-xl">
            <ShoppingCart className="w-12 h-12 text-gray-400 mx-auto mb-3" />
            <p className="text-gray-600">暂无商品</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
            {filteredProducts.map((product) => (
              <div
                key={product.id}
                className="group bg-white rounded-xl shadow-md hover:shadow-xl transition-all duration-300 overflow-hidden border border-gray-200 hover:border-teal-300"
              >
                <div className="relative aspect-square overflow-hidden bg-gray-100">
                  <img
                    src={product.primaryImage}
                    alt={product.titleText}
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                    onError={(e) => {
                      e.target.src = 'https://images.pexels.com/photos/230544/pexels-photo-230544.jpeg';
                    }}
                  />
                  {product.compare_price && product.compare_price > product.base_price && (
                    <div className="absolute top-2 left-2 bg-red-500 text-white px-2 py-1 rounded-lg text-xs font-bold">
                      省 {formatPrice(product.compare_price - product.base_price, product.currency_code)}
                    </div>
                  )}
                  {product.orders_count > 50 && (
                    <div className="absolute top-2 right-2 bg-gradient-to-r from-orange-500 to-red-500 text-white px-2 py-1 rounded-lg text-xs font-bold flex items-center gap-1">
                      <TrendingUp className="w-3 h-3" />
                      热销
                    </div>
                  )}
                </div>

                <div className="p-3">
                  <h3 className="font-semibold text-gray-900 line-clamp-2 mb-2 text-sm">
                    {product.titleText}
                  </h3>

                  <div className="flex items-baseline gap-2 mb-2">
                    <span className="text-xl font-bold text-red-600">
                      {formatPrice(product.base_price, product.currency_code)}
                    </span>
                    {product.compare_price && product.compare_price > product.base_price && (
                      <span className="text-xs text-gray-400 line-through">
                        {formatPrice(product.compare_price, product.currency_code)}
                      </span>
                    )}
                  </div>

                  <div className="flex items-center justify-between text-xs text-gray-400 mb-2">
                    <span className="flex items-center gap-1">
                      <Star className="w-3 h-3 fill-yellow-400 text-yellow-400" />
                      {product.views_count || 0}
                    </span>
                    <span>{product.orders_count || 0} 已售</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
