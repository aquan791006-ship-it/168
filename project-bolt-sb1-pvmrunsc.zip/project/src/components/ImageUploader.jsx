import React, { useState } from 'react';
import { Upload, X, Link as LinkIcon, Image as ImageIcon, Trash2 } from 'lucide-react';

export default function ImageUploader({
  images = [],
  onChange,
  type = 'main',
  allowLink = false,
  maxImages = 10,
  title,
  productType = 'single'
}) {
  const [draggedIndex, setDraggedIndex] = useState(null);

  const handleFileSelect = (e) => {
    const files = Array.from(e.target.files);
    if (files.length + images.length > maxImages) {
      alert(`最多只能上传${maxImages}张图片`);
      return;
    }

    files.forEach(file => {
      if (!file.type.startsWith('image/')) {
        alert('只能上传图片文件');
        return;
      }

      const reader = new FileReader();
      reader.onload = (event) => {
        const newImage = {
          id: Date.now() + Math.random(),
          url: event.target.result,
          file: file,
          linkUrl: '',
          sortOrder: images.length
        };
        onChange([...images, newImage]);
      };
      reader.readAsDataURL(file);
    });

    e.target.value = '';
  };

  const handleUrlAdd = () => {
    const url = prompt('请输入图片URL地址：');
    if (!url) return;

    if (images.length >= maxImages) {
      alert(`最多只能上传${maxImages}张图片`);
      return;
    }

    const newImage = {
      id: Date.now(),
      url: url,
      linkUrl: '',
      sortOrder: images.length
    };
    onChange([...images, newImage]);
  };

  const handleRemove = (id) => {
    onChange(images.filter(img => img.id !== id));
  };

  const handleLinkChange = (id, linkUrl) => {
    onChange(images.map(img =>
      img.id === id ? { ...img, linkUrl } : img
    ));
  };

  const handleDragStart = (index) => {
    setDraggedIndex(index);
  };

  const handleDragOver = (e, index) => {
    e.preventDefault();
    if (draggedIndex === null || draggedIndex === index) return;

    const newImages = [...images];
    const draggedItem = newImages[draggedIndex];
    newImages.splice(draggedIndex, 1);
    newImages.splice(index, 0, draggedItem);

    onChange(newImages.map((img, idx) => ({ ...img, sortOrder: idx })));
    setDraggedIndex(index);
  };

  const handleDragEnd = () => {
    setDraggedIndex(null);
  };

  const getTypeLabel = () => {
    switch(type) {
      case 'main': return '主图';
      case 'module': return '模块图';
      case 'detail': return '详情图';
      default: return '图片';
    }
  };

  const getColorClasses = () => {
    switch(type) {
      case 'main':
        return {
          title: 'text-orange-700',
          uploadBtn: 'bg-gradient-to-r from-orange-500 to-orange-600',
          urlBtn: 'border-orange-500 text-orange-600 hover:bg-orange-50',
          emptyBorder: 'border-orange-200 bg-orange-50/30',
          emptyIcon: 'text-orange-300',
          border: 'border-orange-200',
          badge: 'bg-orange-500'
        };
      case 'module':
        return {
          title: 'text-blue-700',
          uploadBtn: 'bg-gradient-to-r from-blue-500 to-blue-600',
          urlBtn: 'border-blue-500 text-blue-600 hover:bg-blue-50',
          emptyBorder: 'border-blue-200 bg-blue-50/30',
          emptyIcon: 'text-blue-300',
          border: 'border-blue-200',
          badge: 'bg-blue-500'
        };
      case 'detail':
        return {
          title: 'text-green-700',
          uploadBtn: 'bg-gradient-to-r from-green-500 to-green-600',
          urlBtn: 'border-green-500 text-green-600 hover:bg-green-50',
          emptyBorder: 'border-green-200 bg-green-50/30',
          emptyIcon: 'text-green-300',
          border: 'border-green-200',
          badge: 'bg-green-500'
        };
      default:
        return {
          title: 'text-gray-700',
          uploadBtn: 'bg-gradient-to-r from-gray-500 to-gray-600',
          urlBtn: 'border-gray-500 text-gray-600 hover:bg-gray-50',
          emptyBorder: 'border-gray-200 bg-gray-50/30',
          emptyIcon: 'text-gray-300',
          border: 'border-gray-200',
          badge: 'bg-gray-500'
        };
    }
  };

  const colors = getColorClasses();

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h3 className={`text-base font-semibold ${colors.title} flex items-center gap-2`}>
            <ImageIcon className="w-5 h-5" />
            {title || getTypeLabel()}
          </h3>
          <p className="text-sm text-gray-500 mt-1">
            {type === 'main' && '产品主图，用于列表展示和首页展示'}
            {type === 'module' && '中间模块图，可添加跳转链接'}
            {type === 'detail' && '产品详情图，详细介绍产品特性'}
          </p>
        </div>
        <div className="flex gap-2">
          <label className={`px-4 py-2 ${colors.uploadBtn} text-white rounded-lg hover:shadow-lg transition-all cursor-pointer flex items-center gap-2`}>
            <Upload className="w-4 h-4" />
            上传图片
            <input
              type="file"
              multiple
              accept="image/*"
              onChange={handleFileSelect}
              className="hidden"
            />
          </label>
          <button
            type="button"
            onClick={handleUrlAdd}
            className={`px-4 py-2 border-2 ${colors.urlBtn} rounded-lg transition-all flex items-center gap-2`}
          >
            <LinkIcon className="w-4 h-4" />
            URL添加
          </button>
        </div>
      </div>

      {images.length === 0 ? (
        <div className={`border-2 border-dashed ${colors.emptyBorder} rounded-xl p-12 text-center`}>
          <ImageIcon className={`w-12 h-12 ${colors.emptyIcon} mx-auto mb-3`} />
          <p className="text-gray-500 mb-1">暂无{getTypeLabel()}</p>
          <p className="text-sm text-gray-400">点击上方按钮添加图片</p>
        </div>
      ) : (
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
          {images.map((image, index) => (
            <div
              key={image.id}
              draggable
              onDragStart={() => handleDragStart(index)}
              onDragOver={(e) => handleDragOver(e, index)}
              onDragEnd={handleDragEnd}
              className={`relative group border-2 rounded-xl overflow-hidden transition-all ${
                draggedIndex === index ? 'opacity-50 scale-95' : 'hover:shadow-lg'
              } ${colors.border} bg-white`}
            >
              <div className="absolute top-2 right-2 z-10 opacity-0 group-hover:opacity-100 transition-opacity">
                <button
                  type="button"
                  onClick={() => handleRemove(image.id)}
                  className="bg-red-500 hover:bg-red-600 text-white rounded-lg p-2 shadow-lg transition-colors"
                  title="删除图片"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>

              <div className="aspect-square bg-gray-100">
                <img
                  src={image.url}
                  alt={`图片 ${index + 1}`}
                  className="w-full h-full object-cover"
                />
              </div>

              {(allowLink || (productType === 'single' && type === 'main')) && (
                <div className="p-2 bg-gray-50 border-t border-gray-200">
                  <div className="relative">
                    <LinkIcon className="absolute left-2 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                    <input
                      type="url"
                      value={image.linkUrl || ''}
                      onChange={(e) => handleLinkChange(image.id, e.target.value)}
                      placeholder={productType === 'single' ? "单品链接" : "跳转链接"}
                      className="w-full pl-8 pr-2 py-1.5 text-xs border border-gray-300 rounded focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 outline-none"
                      title={productType === 'single' ? "设置单品链接（仅单品模式生效）" : "设置跳转链接"}
                    />
                  </div>
                </div>
              )}

              <div className={`absolute bottom-2 right-2 ${colors.badge} text-white text-xs px-2 py-1 rounded-lg shadow-lg`}>
                #{index + 1}
              </div>
            </div>
          ))}
        </div>
      )}

      <div className="flex items-center justify-between text-sm text-gray-500">
        <span>已上传 {images.length} / {maxImages} 张</span>
        {images.length > 0 && (
          <span className="text-xs">拖拽图片可调整顺序</span>
        )}
      </div>
    </div>
  );
}
