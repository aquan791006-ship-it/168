import React, { useState, useEffect } from 'react';
import { X, ExternalLink } from 'lucide-react';
import { supabase } from '../lib/supabase';

export default function AnnouncementPopup({ domainId, viewerType = 'customer' }) {
  const [announcement, setAnnouncement] = useState(null);
  const [show, setShow] = useState(false);

  useEffect(() => {
    loadAnnouncement();
  }, [domainId]);

  const loadAnnouncement = async () => {
    try {
      const viewerId = localStorage.getItem('announcement_viewer_id') || generateViewerId();
      localStorage.setItem('announcement_viewer_id', viewerId);

      const { data, error } = await supabase.rpc('get_active_announcements', {
        p_domain_id: domainId,
        p_viewer_id: viewerId,
        p_viewer_type: viewerType
      });

      if (!error && data && data.length > 0) {
        const activeAnnouncement = data[0];
        setAnnouncement(activeAnnouncement);
        setShow(true);

        await recordAction(activeAnnouncement.id, 'view');
      }
    } catch (error) {
      console.error('Error loading announcement:', error);
    }
  };

  const generateViewerId = () => {
    return 'viewer_' + Math.random().toString(36).substr(2, 9) + Date.now();
  };

  const recordAction = async (announcementId, actionType) => {
    try {
      const viewerId = localStorage.getItem('announcement_viewer_id');

      await supabase.rpc('record_announcement_action', {
        p_announcement_id: announcementId,
        p_viewer_id: viewerId,
        p_viewer_ip: null,
        p_viewer_type: viewerType,
        p_action_type: actionType
      });
    } catch (error) {
      console.error('Error recording action:', error);
    }
  };

  const handleClose = () => {
    if (announcement) {
      recordAction(announcement.id, 'close');
    }
    setShow(false);
  };

  const handleLinkClick = () => {
    if (announcement) {
      recordAction(announcement.id, 'click');
    }
  };

  if (!show || !announcement) {
    return null;
  }

  const getPositionClasses = () => {
    const positions = {
      'center': 'items-center justify-center',
      'top': 'items-start justify-center pt-20',
      'bottom': 'items-end justify-center pb-20',
      'top-right': 'items-start justify-end pt-4 pr-4',
      'top-left': 'items-start justify-start pt-4 pl-4'
    };
    return positions[announcement.display_position] || positions.center;
  };

  const getButtonColorClasses = () => {
    const colors = {
      'blue': 'bg-blue-600 hover:bg-blue-700 text-white',
      'green': 'bg-green-600 hover:bg-green-700 text-white',
      'red': 'bg-red-600 hover:bg-red-700 text-white',
      'gray': 'bg-gray-600 hover:bg-gray-700 text-white'
    };
    return colors[announcement.button_color] || colors.blue;
  };

  return (
    <div
      className={`fixed inset-0 z-50 flex ${getPositionClasses()}`}
      style={{ backgroundColor: 'rgba(0, 0, 0, 0.5)' }}
      onClick={handleClose}
    >
      <div
        className="bg-white rounded-lg shadow-2xl max-w-md w-full mx-4 relative animate-fadeIn"
        onClick={(e) => e.stopPropagation()}
      >
        <button
          onClick={handleClose}
          className="absolute top-3 right-3 text-gray-400 hover:text-gray-600 transition-colors z-10"
          aria-label="关闭"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="p-6 space-y-4">
          {announcement.title && (
            <h2 className="text-xl font-bold text-gray-900 pr-8">
              {announcement.title}
            </h2>
          )}

          {announcement.image_url && (
            <div className="rounded-lg overflow-hidden">
              <img
                src={announcement.image_url}
                alt={announcement.title}
                className="w-full h-auto object-cover"
                style={{ maxHeight: '300px' }}
              />
            </div>
          )}

          {announcement.content && (
            <div className="text-gray-700 leading-relaxed whitespace-pre-wrap">
              {announcement.content}
            </div>
          )}

          {announcement.link_url && announcement.link_text && (
            <a
              href={announcement.link_url}
              target="_blank"
              rel="noopener noreferrer"
              onClick={handleLinkClick}
              className="inline-flex items-center gap-2 text-blue-600 hover:text-blue-800 font-medium"
            >
              <ExternalLink className="w-4 h-4" />
              {announcement.link_text}
            </a>
          )}

          <div className="flex gap-3 pt-2">
            <button
              onClick={handleClose}
              className={`flex-1 px-4 py-2 rounded-lg font-medium transition-colors ${getButtonColorClasses()}`}
            >
              {announcement.button_text || '我知道了'}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
