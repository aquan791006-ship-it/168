import React, { useState, useEffect } from 'react';
import {
  CreditCard,
  Plus,
  Edit2,
  Trash2,
  Eye,
  EyeOff,
  Save,
  ArrowUp,
  ArrowDown,
  RefreshCw,
  DollarSign,
  Smartphone
} from 'lucide-react';
import { supabase } from '../lib/supabase';
import Modal from './Modal';
import ImageUploader from './ImageUploader';
import { useToast } from '../contexts/ToastContext';

export default function PaymentMethodsManager({ domainId }) {
  const [methods, setMethods] = useState([]);
  const [loading, setLoading] = useState(false);
  const [showModal, setShowModal] = useState(false);
  const [editingItem, setEditingItem] = useState(null);
  const { showToast } = useToast();

  const [formData, setFormData] = useState({
    method_code: '',
    method_name: '',
    method_type: 'offline',
    description: '',
    icon_url: '',
    display_order: 0,
    require_account: false
  });

  useEffect(() => {
    loadMethods();
  }, [domainId]);

  const loadMethods = async () => {
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from('sys_payment_methods')
        .select('*')
        .eq('domain_id', domainId)
        .order('display_order', { ascending: true })
        .order('created_at', { ascending: true });

      if (error) throw error;
      setMethods(data || []);
    } catch (error) {
      console.error('Error loading payment methods:', error);
      showToast('加载付款方式失败', 'error');
    } finally {
      setLoading(false);
    }
  };

  const initializeDefaults = async () => {
    if (!window.confirm('确定要初始化默认付款方式吗？这将添加常用的付款方式。')) return;

    setLoading(true);
    try {
      const { data, error } = await supabase.rpc('initialize_default_payment_methods', {
        p_domain_id: domainId
      });

      if (error) throw error;

      if (data.success) {
        showToast('默认付款方式已初始化', 'success');
        loadMethods();
      } else {
        showToast(data.message || '初始化失败', 'error');
      }
    } catch (error) {
      console.error('Error initializing defaults:', error);
      showToast('初始化失败', 'error');
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);

    try {
      const payload = {
        ...formData,
        domain_id: domainId
      };

      if (editingItem) {
        const { error } = await supabase
          .from('sys_payment_methods')
          .update(payload)
          .eq('id', editingItem.id);

        if (error) throw error;
        showToast('付款方式已更新', 'success');
      } else {
        const { error } = await supabase
          .from('sys_payment_methods')
          .insert([payload]);

        if (error) throw error;
        showToast('付款方式已添加', 'success');
      }

      setShowModal(false);
      resetForm();
      loadMethods();
    } catch (error) {
      console.error('Error saving payment method:', error);
      showToast(error.message || '保存失败', 'error');
    } finally {
      setLoading(false);
    }
  };

  const handleEdit = (item) => {
    setEditingItem(item);
    setFormData({
      method_code: item.method_code,
      method_name: item.method_name,
      method_type: item.method_type,
      description: item.description || '',
      icon_url: item.icon_url || '',
      display_order: item.display_order,
      require_account: item.require_account
    });
    setShowModal(true);
  };

  const handleDelete = async (id) => {
    if (!window.confirm('确定要删除这个付款方式吗？')) return;

    try {
      const { error } = await supabase
        .from('sys_payment_methods')
        .delete()
        .eq('id', id);

      if (error) throw error;
      showToast('付款方式已删除', 'success');
      loadMethods();
    } catch (error) {
      console.error('Error deleting payment method:', error);
      showToast('删除失败', 'error');
    }
  };

  const toggleEnabled = async (id, currentStatus) => {
    try {
      const { error } = await supabase
        .from('sys_payment_methods')
        .update({ is_enabled: !currentStatus })
        .eq('id', id);

      if (error) throw error;
      showToast(currentStatus ? '已禁用' : '已启用', 'success');
      loadMethods();
    } catch (error) {
      console.error('Error toggling status:', error);
      showToast('操作失败', 'error');
    }
  };

  const moveMethod = async (id, direction) => {
    const index = methods.findIndex(m => m.id === id);
    if (
      (direction === 'up' && index === 0) ||
      (direction === 'down' && index === methods.length - 1)
    ) {
      return;
    }

    const targetIndex = direction === 'up' ? index - 1 : index + 1;
    const currentOrder = methods[index].display_order;
    const targetOrder = methods[targetIndex].display_order;

    try {
      await supabase
        .from('sys_payment_methods')
        .update({ display_order: targetOrder })
        .eq('id', methods[index].id);

      await supabase
        .from('sys_payment_methods')
        .update({ display_order: currentOrder })
        .eq('id', methods[targetIndex].id);

      loadMethods();
    } catch (error) {
      console.error('Error moving method:', error);
      showToast('移动失败', 'error');
    }
  };

  const resetForm = () => {
    setEditingItem(null);
    setFormData({
      method_code: '',
      method_name: '',
      method_type: 'offline',
      description: '',
      icon_url: '',
      display_order: methods.length,
      require_account: false
    });
  };

  const getMethodTypeIcon = (type) => {
    return type === 'online' ? <Smartphone className="w-4 h-4" /> : <DollarSign className="w-4 h-4" />;
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-start">
        <div>
          <h2 className="text-xl font-semibold text-gray-900">全局付款方式</h2>
          <p className="text-sm text-gray-600 mt-1">配置系统支持的所有付款方式</p>
        </div>
        <div className="flex gap-3">
          {methods.length === 0 && (
            <button
              onClick={initializeDefaults}
              disabled={loading}
              className="flex items-center gap-2 bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700"
            >
              <RefreshCw className="w-4 h-4" />
              初始化默认方式
            </button>
          )}
          <button
            onClick={() => {
              resetForm();
              setShowModal(true);
            }}
            className="flex items-center gap-2 bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700"
          >
            <Plus className="w-4 h-4" />
            添加付款方式
          </button>
        </div>
      </div>

      <div className="bg-white rounded-lg border border-gray-200">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50 border-b border-gray-200">
              <tr>
                <th className="px-4 py-3 text-left text-xs font-medium text-gray-600 uppercase">代码</th>
                <th className="px-4 py-3 text-left text-xs font-medium text-gray-600 uppercase">名称</th>
                <th className="px-4 py-3 text-left text-xs font-medium text-gray-600 uppercase">类型</th>
                <th className="px-4 py-3 text-left text-xs font-medium text-gray-600 uppercase">描述</th>
                <th className="px-4 py-3 text-left text-xs font-medium text-gray-600 uppercase">需要账号</th>
                <th className="px-4 py-3 text-left text-xs font-medium text-gray-600 uppercase">状态</th>
                <th className="px-4 py-3 text-left text-xs font-medium text-gray-600 uppercase">顺序</th>
                <th className="px-4 py-3 text-left text-xs font-medium text-gray-600 uppercase">操作</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200">
              {methods.map((item, index) => (
                <tr key={item.id} className="hover:bg-gray-50">
                  <td className="px-4 py-3">
                    <span className="font-mono text-sm text-gray-700">{item.method_code}</span>
                  </td>
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-2">
                      {item.icon_url && (
                        <img src={item.icon_url} alt="" className="w-6 h-6 object-contain" />
                      )}
                      <span className="font-medium text-gray-900">{item.method_name}</span>
                    </div>
                  </td>
                  <td className="px-4 py-3">
                    <span className={`inline-flex items-center gap-1 px-2 py-1 text-xs rounded-full ${
                      item.method_type === 'online'
                        ? 'bg-blue-100 text-blue-700'
                        : 'bg-gray-100 text-gray-700'
                    }`}>
                      {getMethodTypeIcon(item.method_type)}
                      {item.method_type === 'online' ? '在线支付' : '线下支付'}
                    </span>
                  </td>
                  <td className="px-4 py-3">
                    <span className="text-sm text-gray-600 line-clamp-1">
                      {item.description || '-'}
                    </span>
                  </td>
                  <td className="px-4 py-3">
                    <span className={`inline-flex items-center px-2 py-1 text-xs rounded-full ${
                      item.require_account
                        ? 'bg-orange-100 text-orange-700'
                        : 'bg-gray-100 text-gray-600'
                    }`}>
                      {item.require_account ? '需要' : '不需要'}
                    </span>
                  </td>
                  <td className="px-4 py-3">
                    <button
                      onClick={() => toggleEnabled(item.id, item.is_enabled)}
                      className={`inline-flex items-center gap-1 px-2 py-1 text-xs rounded-full ${
                        item.is_enabled
                          ? 'bg-green-100 text-green-700'
                          : 'bg-gray-100 text-gray-700'
                      }`}
                    >
                      {item.is_enabled ? <Eye className="w-3 h-3" /> : <EyeOff className="w-3 h-3" />}
                      {item.is_enabled ? '启用中' : '已禁用'}
                    </button>
                  </td>
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-1">
                      <button
                        onClick={() => moveMethod(item.id, 'up')}
                        disabled={index === 0}
                        className="p-1 text-gray-500 hover:text-gray-700 disabled:opacity-30 disabled:cursor-not-allowed"
                        title="上移"
                      >
                        <ArrowUp className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => moveMethod(item.id, 'down')}
                        disabled={index === methods.length - 1}
                        className="p-1 text-gray-500 hover:text-gray-700 disabled:opacity-30 disabled:cursor-not-allowed"
                        title="下移"
                      >
                        <ArrowDown className="w-4 h-4" />
                      </button>
                      <span className="text-sm text-gray-600 ml-1">{item.display_order}</span>
                    </div>
                  </td>
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => handleEdit(item)}
                        className="text-blue-600 hover:text-blue-800"
                        title="编辑"
                      >
                        <Edit2 className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => handleDelete(item.id)}
                        className="text-red-600 hover:text-red-800"
                        title="删除"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
              {methods.length === 0 && (
                <tr>
                  <td colSpan="8" className="px-4 py-8 text-center text-gray-500">
                    暂无付款方式，点击"初始化默认方式"或"添加付款方式"开始配置
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {showModal && (
        <Modal
          isOpen={showModal}
          onClose={() => {
            setShowModal(false);
            resetForm();
          }}
          title={editingItem ? '编辑付款方式' : '添加付款方式'}
        >
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  代码 *
                </label>
                <input
                  type="text"
                  value={formData.method_code}
                  onChange={(e) => setFormData({ ...formData, method_code: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                  placeholder="如: alipay, wechat"
                  required
                  disabled={!!editingItem}
                />
                <p className="text-xs text-gray-500 mt-1">唯一标识，仅小写字母和下划线</p>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  显示名称 *
                </label>
                <input
                  type="text"
                  value={formData.method_name}
                  onChange={(e) => setFormData({ ...formData, method_name: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                  placeholder="如: 支付宝"
                  required
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  类型
                </label>
                <select
                  value={formData.method_type}
                  onChange={(e) => setFormData({ ...formData, method_type: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                >
                  <option value="offline">线下支付</option>
                  <option value="online">在线支付</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  显示顺序
                </label>
                <input
                  type="number"
                  value={formData.display_order}
                  onChange={(e) => setFormData({ ...formData, display_order: parseInt(e.target.value) || 0 })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                  min="0"
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                描述说明
              </label>
              <textarea
                value={formData.description}
                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                rows="2"
                placeholder="简要说明这个付款方式..."
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                图标
              </label>
              <ImageUploader
                value={formData.icon_url}
                onChange={(url) => setFormData({ ...formData, icon_url: url })}
                folder="payment-icons"
              />
            </div>

            <div className="flex items-center gap-2">
              <input
                type="checkbox"
                id="require_account"
                checked={formData.require_account}
                onChange={(e) => setFormData({ ...formData, require_account: e.target.checked })}
                className="w-4 h-4 text-blue-600 border-gray-300 rounded focus:ring-blue-500"
              />
              <label htmlFor="require_account" className="text-sm font-medium text-gray-700">
                需要配置收款账号
              </label>
            </div>

            <div className="flex gap-3 pt-4">
              <button
                type="submit"
                disabled={loading}
                className="flex-1 flex items-center justify-center gap-2 bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 disabled:bg-gray-400"
              >
                <Save className="w-4 h-4" />
                {loading ? '保存中...' : '保存'}
              </button>
              <button
                type="button"
                onClick={() => {
                  setShowModal(false);
                  resetForm();
                }}
                className="px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50"
              >
                取消
              </button>
            </div>
          </form>
        </Modal>
      )}
    </div>
  );
}
