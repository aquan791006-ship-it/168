import React, { useState } from 'react';
import { supabase } from '../lib/supabase';
import ImageUploader from './ImageUploader';
import AddressSelector from './AddressSelector';
import { X, Save, Package, ShoppingCart, Tag, DollarSign, FileText, AlertCircle } from 'lucide-react';

export default function ProductForm({ product = null, onClose, onSuccess }) {
  const isEditMode = !!product;
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const getTitle = (titleObj) => {
    if (typeof titleObj === 'string') return titleObj;
    return titleObj?.zh || titleObj?.en || '';
  };

  const getDescription = (descObj) => {
    if (typeof descObj === 'string') return descObj;
    return descObj?.zh || descObj?.en || '';
  };

  const [productType, setProductType] = useState(product?.product_type || 'single');
  const [formData, setFormData] = useState({
    serialNumber: product?.serial_number || '',
    title: product ? getTitle(product.title) : '',
    description: product ? getDescription(product.description) : '',
    category: product?.category || '',
    basePrice: product?.base_price || '',
    currency: product?.currency || 'CNY',
    status: product?.status || 'active',
    sku: product?.metadata?.sku || '',
    quantity: product?.metadata?.quantity || ''
  });

  const [mainImages, setMainImages] = useState([]);
  const [address, setAddress] = useState(product?.metadata?.shipping_address || null);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    try {
      if (!formData.title || !formData.basePrice) {
        throw new Error('请填写必填项');
      }

      if (!isEditMode && mainImages.length === 0) {
        throw new Error('请至少上传一张主图');
      }

      const productData = {
        serial_number: formData.serialNumber,
        title: { zh: formData.title },
        description: { zh: formData.description },
        category: formData.category,
        base_price: parseFloat(formData.basePrice),
        currency: formData.currency,
        status: formData.status,
        product_type: productType,
        metadata: {
          shipping_address: address,
          sku: formData.sku,
          quantity: formData.quantity ? parseInt(formData.quantity) : null
        }
      };

      let resultProduct;

      if (isEditMode) {
        const { data, error: updateError } = await supabase
          .from('products')
          .update(productData)
          .eq('id', product.id)
          .select()
          .single();

        if (updateError) throw updateError;
        resultProduct = data;
      } else {
        const { data, error: insertError } = await supabase
          .from('products')
          .insert([productData])
          .select()
          .single();

        if (insertError) throw insertError;
        resultProduct = data;
      }

      const imageInserts = [];

      mainImages.forEach((img, index) => {
        imageInserts.push({
          product_id: resultProduct.id,
          image_type: 'main',
          original_url: img.url,
          link_url: img.linkUrl || null,
          is_primary: index === 0,
          sort_order: index
        });
      });

      if (imageInserts.length > 0) {
        const { error: imageError } = await supabase
          .from('product_images')
          .insert(imageInserts);

        if (imageError) throw imageError;
      }

      if (onSuccess) onSuccess(resultProduct);
      if (onClose) onClose();

    } catch (err) {
      console.error(`Error ${isEditMode ? 'updating' : 'creating'} product:`, err);
      setError(err.message || `${isEditMode ? '更新' : '创建'}产品失败`);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-start justify-center overflow-y-auto p-4">
      <div className="w-full max-w-6xl bg-white rounded-2xl shadow-2xl my-8 animate-scale-in">
        <div className="sticky top-0 bg-gradient-to-r from-orange-500 via-red-500 to-amber-600 text-white px-6 py-4 rounded-t-2xl flex items-center justify-between z-10">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-white/20 rounded-xl flex items-center justify-center">
              <Package className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-xl font-bold">{isEditMode ? '编辑产品' : '添加产品'}</h2>
              <p className="text-sm text-white/80">填写产品信息并上传图片</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 hover:bg-white/20 rounded-lg transition-colors"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-6 max-h-[calc(100vh-12rem)] overflow-y-auto custom-scrollbar">
          {error && (
            <div className="bg-red-50 border-2 border-red-200 rounded-xl p-4 flex items-start gap-3 animate-slide-up">
              <AlertCircle className="w-5 h-5 text-red-500 flex-shrink-0 mt-0.5" />
              <div>
                <p className="font-semibold text-red-700">错误</p>
                <p className="text-sm text-red-600">{error}</p>
              </div>
            </div>
          )}

          <div className="bg-gradient-to-r from-orange-50 to-amber-50 border-2 border-orange-200 rounded-xl p-5">
            <label className="block text-sm font-semibold text-gray-700 mb-3">
              产品类型 <span className="text-red-500">*</span>
            </label>
            <div className="grid grid-cols-2 gap-4">
              <button
                type="button"
                onClick={() => setProductType('single')}
                className={`p-4 rounded-xl border-2 transition-all ${
                  productType === 'single'
                    ? 'border-orange-500 bg-white shadow-lg scale-105'
                    : 'border-gray-200 bg-white hover:border-orange-300'
                }`}
              >
                <Package className={`w-8 h-8 mx-auto mb-2 ${
                  productType === 'single' ? 'text-orange-500' : 'text-gray-400'
                }`} />
                <p className={`font-semibold ${
                  productType === 'single' ? 'text-orange-600' : 'text-gray-600'
                }`}>单品模式</p>
                <p className="text-xs text-gray-500 mt-1">单页直接下单</p>
              </button>

              <button
                type="button"
                onClick={() => setProductType('multi')}
                className={`p-4 rounded-xl border-2 transition-all ${
                  productType === 'multi'
                    ? 'border-orange-500 bg-white shadow-lg scale-105'
                    : 'border-gray-200 bg-white hover:border-orange-300'
                }`}
              >
                <ShoppingCart className={`w-8 h-8 mx-auto mb-2 ${
                  productType === 'multi' ? 'text-orange-500' : 'text-gray-400'
                }`} />
                <p className={`font-semibold ${
                  productType === 'multi' ? 'text-orange-600' : 'text-gray-600'
                }`}>多品模式</p>
                <p className="text-xs text-gray-500 mt-1">购物车模式</p>
              </button>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-2">
                <Tag className="w-4 h-4 inline mr-1" />
                产品编号
              </label>
              <input
                type="text"
                value={formData.serialNumber}
                onChange={(e) => setFormData({ ...formData, serialNumber: e.target.value })}
                placeholder="例如：P001"
                className="w-full px-4 py-2.5 border-2 border-gray-200 rounded-lg focus:ring-2 focus:ring-orange-500/20 focus:border-orange-500 transition-all outline-none"
              />
              <p className="text-xs text-gray-500 mt-1">用于仓库拣货识别</p>
            </div>

            {productType === 'multi' && (
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">
                  <Tag className="w-4 h-4 inline mr-1" />
                  SKU编码
                </label>
                <input
                  type="text"
                  value={formData.sku}
                  onChange={(e) => setFormData({ ...formData, sku: e.target.value })}
                  placeholder="例如：SKU-001"
                  className="w-full px-4 py-2.5 border-2 border-gray-200 rounded-lg focus:ring-2 focus:ring-orange-500/20 focus:border-orange-500 transition-all outline-none"
                />
                <p className="text-xs text-gray-500 mt-1">库存单位标识</p>
              </div>
            )}
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-2">
                <DollarSign className="w-4 h-4 inline mr-1" />
                产品价格 <span className="text-red-500">*</span>
              </label>
              <div className="flex gap-2">
                <input
                  type="number"
                  value={formData.basePrice}
                  onChange={(e) => setFormData({ ...formData, basePrice: e.target.value })}
                  placeholder="0.00"
                  step="0.01"
                  required
                  className="flex-1 px-4 py-2.5 border-2 border-gray-200 rounded-lg focus:ring-2 focus:ring-orange-500/20 focus:border-orange-500 transition-all outline-none"
                />
                <select
                  value={formData.currency}
                  onChange={(e) => setFormData({ ...formData, currency: e.target.value })}
                  className="px-4 py-2.5 border-2 border-gray-200 rounded-lg focus:ring-2 focus:ring-orange-500/20 focus:border-orange-500 transition-all outline-none"
                >
                  <option value="CNY">CNY ¥</option>
                  <option value="USD">USD $</option>
                  <option value="USDT">USDT</option>
                </select>
              </div>
            </div>

            {productType === 'multi' && (
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">
                  <Package className="w-4 h-4 inline mr-1" />
                  库存数量
                </label>
                <input
                  type="number"
                  value={formData.quantity}
                  onChange={(e) => setFormData({ ...formData, quantity: e.target.value })}
                  placeholder="0"
                  min="0"
                  className="w-full px-4 py-2.5 border-2 border-gray-200 rounded-lg focus:ring-2 focus:ring-orange-500/20 focus:border-orange-500 transition-all outline-none"
                />
                <p className="text-xs text-gray-500 mt-1">可售库存数量</p>
              </div>
            )}
          </div>

          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-2">
              <Package className="w-4 h-4 inline mr-1" />
              产品名称 <span className="text-red-500">*</span>
            </label>
            <input
              type="text"
              value={formData.title}
              onChange={(e) => setFormData({ ...formData, title: e.target.value })}
              placeholder="请输入产品名称"
              required
              className="w-full px-4 py-2.5 border-2 border-gray-200 rounded-lg focus:ring-2 focus:ring-orange-500/20 focus:border-orange-500 transition-all outline-none"
            />
          </div>

          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-2">
              <FileText className="w-4 h-4 inline mr-1" />
              产品描述
            </label>
            <textarea
              value={formData.description}
              onChange={(e) => setFormData({ ...formData, description: e.target.value })}
              placeholder="请输入产品描述"
              rows={4}
              className="w-full px-4 py-2.5 border-2 border-gray-200 rounded-lg focus:ring-2 focus:ring-orange-500/20 focus:border-orange-500 transition-all outline-none resize-none"
            />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-2">
                产品分类
              </label>
              <input
                type="text"
                value={formData.category}
                onChange={(e) => setFormData({ ...formData, category: e.target.value })}
                placeholder="例如：电子产品"
                className="w-full px-4 py-2.5 border-2 border-gray-200 rounded-lg focus:ring-2 focus:ring-orange-500/20 focus:border-orange-500 transition-all outline-none"
              />
            </div>

            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-2">
                产品状态
              </label>
              <select
                value={formData.status}
                onChange={(e) => setFormData({ ...formData, status: e.target.value })}
                className="w-full px-4 py-2.5 border-2 border-gray-200 rounded-lg focus:ring-2 focus:ring-orange-500/20 focus:border-orange-500 transition-all outline-none"
              >
                <option value="active">在售</option>
                <option value="inactive">下架</option>
                <option value="draft">草稿</option>
              </select>
            </div>
          </div>

          <div className="border-t-2 border-gray-200 pt-6">
            <ImageUploader
              images={mainImages}
              onChange={setMainImages}
              type="main"
              maxImages={10}
              title="产品主图 *"
              productType={productType}
              allowLink={productType === 'single'}
            />
            <p className="text-sm text-gray-500 mt-2">
              上传产品展示图片，第一张为主图
              {productType === 'single' && <span className="text-orange-600 ml-2">· 单品模式可为图片添加超链接</span>}
            </p>
          </div>

          <div className="border-t-2 border-gray-200 pt-6">
            <AddressSelector
              value={address}
              onChange={setAddress}
              required={false}
            />
          </div>

          <div className="sticky bottom-0 bg-white border-t-2 border-gray-200 pt-6 flex gap-3">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 px-6 py-3 border-2 border-gray-300 text-gray-700 rounded-xl font-semibold hover:bg-gray-50 transition-all"
            >
              取消
            </button>
            <button
              type="submit"
              disabled={loading}
              className="flex-1 px-6 py-3 bg-gradient-to-r from-orange-500 to-amber-600 text-white rounded-xl font-semibold hover:shadow-xl transition-all disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
            >
              {loading ? (
                <>
                  <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                  保存中...
                </>
              ) : (
                <>
                  <Save className="w-5 h-5" />
                  {isEditMode ? '更新产品' : '保存产品'}
                </>
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
