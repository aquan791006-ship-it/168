# ygou88.com 部署指南

## 🎯 概述

本指南将帮助您将 SmartInsight AI ERP 系统部署到您的服务器 (159.198.44.80)。

- **域名**: ygou88.com
- **服务器 IP**: 159.198.44.80
- **部署模式**: 一体化部署 (前后端在同一服务器)
- **域名解析**: ✅ 已完成

---

## 📋 部署前准备

### 1. 本地环境要求

- Node.js 18.x 或 20.x
- npm 9.x+
- SSH 访问服务器的权限

### 2. 服务器要求

- **系统**: Linux (Ubuntu 20.04+ / CentOS 7+ / Debian 10+)
- **CPU**: 1核+ (推荐 2核)
- **内存**: 1GB+ (推荐 2GB)
- **硬盘**: 10GB+
- **端口**: 22 (SSH), 80 (HTTP), 443 (HTTPS)

### 3. 需要的密钥信息

从 Supabase 控制台获取:
- SUPABASE_SERVICE_KEY (service_role 密钥)
- DATABASE_URL 中的数据库密码

生成一个随机的 JWT_SECRET (至少32位字符串)

---

## 🚀 方式一: 一键自动部署 (推荐)

### 步骤 1: 准备本地环境

在您的本地电脑上:

```bash
# 1. 确保已安装 Node.js
node -v  # 应该显示 v18.x.x 或 v20.x.x

# 2. 进入项目目录
cd /path/to/smartinsight-erp

# 3. 给部署脚本添加执行权限
chmod +x deploy-to-server.sh
```

### 步骤 2: 配置 SSH 访问

```bash
# 测试 SSH 连接
ssh root@159.198.44.80

# 如果需要配置 SSH 密钥（推荐，避免每次输入密码）
ssh-copy-id root@159.198.44.80
```

### 步骤 3: 运行一键部署脚本

```bash
./deploy-to-server.sh
```

脚本会自动完成:
- ✅ 构建前端项目
- ✅ 打包部署文件
- ✅ 上传到服务器
- ✅ 安装依赖
- ✅ 配置 Nginx
- ✅ 启动应用

### 步骤 4: 配置环境变量

部署完成后,登录服务器配置环境变量:

```bash
ssh root@159.198.44.80
nano /var/www/smartinsight/server/.env
```

修改以下重要配置:

```env
# JWT 密钥（必须修改！）
JWT_SECRET=你的超级安全的32位随机字符串

# Supabase Service Key（从 Supabase 控制台获取）
SUPABASE_SERVICE_KEY=你的service_role密钥

# 数据库密码（从 Supabase 控制台获取）
DATABASE_URL=postgresql://postgres.0ec90b57d6e95fcbda19832f:你的数据库密码@aws-0-ap-southeast-1.pooler.supabase.com:6543/postgres
```

保存后重启应用:

```bash
pm2 restart smartinsight
```

### 步骤 5: 申请 SSL 证书

```bash
# 安装 Certbot
sudo apt update
sudo apt install certbot python3-certbot-nginx -y

# 申请证书
sudo certbot --nginx -d ygou88.com -d www.ygou88.com

# 测试自动续期
sudo certbot renew --dry-run
```

### 步骤 6: 验证部署

在浏览器访问:
- HTTP: http://ygou88.com
- HTTPS: https://ygou88.com (申请证书后)

默认登录信息:
- 用户名: `admin`
- 密码: `admin123`

---

## 🔧 方式二: 手动部署

如果自动脚本遇到问题,可以按以下步骤手动部署:

### 步骤 1: 构建项目

在本地电脑:

```bash
# 构建前端
npm run build

# 打包文件
tar -czf smartinsight-deploy.tar.gz dist/ server/ package.json nginx.ygou88.conf
```

### 步骤 2: 上传文件

```bash
# 上传到服务器
scp smartinsight-deploy.tar.gz root@159.198.44.80:/tmp/
```

### 步骤 3: 在服务器上解压

```bash
# 登录服务器
ssh root@159.198.44.80

# 创建目录
sudo mkdir -p /var/www/smartinsight
cd /var/www/smartinsight

# 解压文件
tar -xzf /tmp/smartinsight-deploy.tar.gz
```

### 步骤 4: 安装软件

```bash
# 更新系统
sudo apt update && sudo apt upgrade -y

# 安装 Node.js 18
curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
sudo apt-get install -y nodejs

# 验证安装
node -v  # 应该显示 v18.x.x
npm -v   # 应该显示 9.x.x

# 安装 PM2
sudo npm install -g pm2

# 安装 Nginx
sudo apt install nginx -y
```

### 步骤 5: 安装后端依赖

```bash
cd /var/www/smartinsight/server
npm install --production
```

### 步骤 6: 配置环境变量

```bash
cd /var/www/smartinsight/server
cp .env.production .env
nano .env
```

修改必要的配置项 (同方式一的步骤4)。

### 步骤 7: 配置 Nginx

```bash
# 复制配置文件
sudo cp /var/www/smartinsight/nginx.ygou88.conf /etc/nginx/sites-available/ygou88.com

# 创建符号链接
sudo ln -s /etc/nginx/sites-available/ygou88.com /etc/nginx/sites-enabled/

# 删除默认配置
sudo rm -f /etc/nginx/sites-enabled/default

# 测试配置
sudo nginx -t

# 重启 Nginx
sudo systemctl restart nginx
sudo systemctl enable nginx
```

### 步骤 8: 启动应用

```bash
cd /var/www/smartinsight/server

# 启动应用
pm2 start src/index.js --name smartinsight

# 设置开机自启
pm2 startup
pm2 save
```

### 步骤 9: 配置防火墙

```bash
# 允许 HTTP/HTTPS
sudo ufw allow 80/tcp
sudo ufw allow 443/tcp
sudo ufw allow 22/tcp  # SSH

# 启用防火墙
sudo ufw enable

# 查看状态
sudo ufw status
```

### 步骤 10: 申请 SSL 证书

同方式一的步骤5。

---

## 📊 部署验证

### 1. 检查服务状态

```bash
# 检查 PM2 状态
pm2 status

# 查看应用日志
pm2 logs smartinsight --lines 50

# 检查 Nginx 状态
sudo systemctl status nginx

# 检查端口监听
sudo netstat -tlnp | grep -E "80|3000"
```

### 2. 测试 HTTP 访问

```bash
# 在服务器上测试
curl http://localhost:3000
curl http://localhost

# 在本地电脑上测试
curl http://ygou88.com
```

### 3. 浏览器测试

访问 http://ygou88.com,应该能看到登录页面。

---

## 🔍 常见问题排查

### 问题 1: 网站无法访问

**检查步骤:**

```bash
# 1. 确认域名解析
nslookup ygou88.com  # 应该返回 159.198.44.80

# 2. 检查防火墙
sudo ufw status
sudo ufw allow 80/tcp

# 3. 检查 Nginx 是否运行
sudo systemctl status nginx
sudo nginx -t  # 测试配置

# 4. 检查 Node.js 应用是否运行
pm2 status
pm2 logs smartinsight

# 5. 检查端口占用
sudo netstat -tlnp | grep :80
sudo netstat -tlnp | grep :3000
```

### 问题 2: 502 Bad Gateway

这通常表示 Nginx 无法连接到后端 Node.js 服务。

```bash
# 检查 Node.js 是否运行
pm2 status

# 查看日志
pm2 logs smartinsight --lines 100

# 重启应用
pm2 restart smartinsight

# 检查端口 3000 是否监听
sudo netstat -tlnp | grep :3000
```

### 问题 3: 环境变量未生效

```bash
# 确认环境变量文件存在
cat /var/www/smartinsight/server/.env

# 确认 NODE_ENV 设置为 production
grep NODE_ENV /var/www/smartinsight/server/.env

# 重启应用使配置生效
pm2 restart smartinsight
```

### 问题 4: 数据库连接失败

```bash
# 测试数据库连接
cd /var/www/smartinsight/server
node -e "
const { createClient } = require('@supabase/supabase-js');
require('dotenv').config();
const supabase = createClient(
  process.env.SUPABASE_URL,
  process.env.SUPABASE_ANON_KEY
);
supabase.from('products').select('count').then(console.log).catch(console.error);
"
```

### 问题 5: 权限问题

```bash
# 修改文件所有者
sudo chown -R $USER:$USER /var/www/smartinsight

# 修改文件权限
sudo chmod -R 755 /var/www/smartinsight
```

---

## 🛠️ 日常维护

### 查看日志

```bash
# 实时查看日志
pm2 logs smartinsight

# 查看最近 100 行日志
pm2 logs smartinsight --lines 100

# 查看错误日志
pm2 logs smartinsight --err

# 查看 Nginx 日志
tail -f /var/log/nginx/ygou88_access.log
tail -f /var/log/nginx/ygou88_error.log
```

### 重启服务

```bash
# 重启应用
pm2 restart smartinsight

# 重启 Nginx
sudo systemctl restart nginx

# 重启整个服务器
sudo reboot
```

### 更新应用

```bash
# 在本地构建新版本
npm run build
tar -czf smartinsight-update.tar.gz dist/ server/

# 上传到服务器
scp smartinsight-update.tar.gz root@159.198.44.80:/tmp/

# 在服务器上
cd /var/www/smartinsight
tar -xzf /tmp/smartinsight-update.tar.gz
cd server
npm install --production
pm2 restart smartinsight
```

### 备份

```bash
# 备份应用文件
cd /var/www
tar -czf smartinsight-backup-$(date +%Y%m%d).tar.gz smartinsight/

# 如果使用自建数据库，备份数据库
# (如果使用 Supabase，在 Supabase Dashboard 中备份)
```

### 监控资源

```bash
# 查看系统资源
htop
# 或
top

# 查看磁盘使用
df -h

# 查看内存使用
free -h

# PM2 监控
pm2 monit
```

---

## 🔒 安全建议

### 1. 修改 SSH 端口 (可选)

```bash
sudo nano /etc/ssh/sshd_config
# 修改: Port 22 改为其他端口如 2222
sudo systemctl restart sshd
```

### 2. 禁用 root SSH 登录

```bash
sudo nano /etc/ssh/sshd_config
# 设置: PermitRootLogin no
sudo systemctl restart sshd
```

### 3. 安装 fail2ban

```bash
sudo apt install fail2ban -y
sudo systemctl enable fail2ban
sudo systemctl start fail2ban
```

### 4. 定期更新系统

```bash
sudo apt update && sudo apt upgrade -y
```

### 5. 使用强密码

- JWT_SECRET 至少 32 位随机字符串
- 数据库密码使用强密码
- 修改默认管理员密码

---

## ✅ 部署检查清单

部署完成后,请确认:

- [ ] 域名解析正确 (159.198.44.80)
- [ ] HTTP 访问正常 (http://ygou88.com)
- [ ] HTTPS 证书已申请并生效
- [ ] 应用正常运行 (`pm2 status` 显示 online)
- [ ] 环境变量已正确配置
- [ ] 数据库连接正常
- [ ] 能够登录系统
- [ ] 防火墙已配置 (80, 443 端口开放)
- [ ] PM2 开机自启已设置
- [ ] SSL 证书自动续期已配置

---

## 📞 获取帮助

如果遇到问题:

1. 查看应用日志: `pm2 logs smartinsight`
2. 查看 Nginx 日志: `tail -f /var/log/nginx/ygou88_error.log`
3. 检查服务状态: `pm2 status` 和 `sudo systemctl status nginx`
4. 确认环境变量配置正确
5. 确认防火墙端口已开放

---

## 🎉 部署完成

恭喜!您的 SmartInsight AI ERP 系统现在应该已经在 ygou88.com 上运行了!

**默认登录信息:**
- URL: https://ygou88.com
- 用户名: `admin`
- 密码: `admin123`

**重要提醒:**
- ⚠️ 请立即修改默认管理员密码
- ⚠️ 确保 JWT_SECRET 是安全的随机字符串
- ⚠️ 定期备份数据和配置文件
- ⚠️ 监控服务器资源使用情况

祝您使用愉快! 🚀
