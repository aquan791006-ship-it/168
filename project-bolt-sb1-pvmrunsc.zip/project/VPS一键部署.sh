#!/bin/bash

# ===================================
# VPS 一键部署脚本
# 适用于任何 Linux VPS (Ubuntu/Debian/CentOS)
# ===================================

set -e

# 颜色定义
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m'

echo "======================================"
echo "  SmartInsight AI ERP - VPS一键部署"
echo "======================================"
echo ""

# 获取用户输入
read -p "请输入您的服务器IP地址: " SERVER_IP
read -p "请输入SSH用户名 (默认: root): " SERVER_USER
SERVER_USER=${SERVER_USER:-root}

read -p "请输入域名 (可选，直接回车跳过): " DOMAIN

echo ""
echo -e "${YELLOW}开始部署...${NC}"
echo ""

# 步骤 1: 构建项目
echo -e "${YELLOW}[1/5] 构建项目...${NC}"
npm run build

if [ ! -d "dist" ]; then
    echo -e "${RED}构建失败！${NC}"
    exit 1
fi

echo -e "${GREEN}✓ 构建完成${NC}"
echo ""

# 步骤 2: 打包
echo -e "${YELLOW}[2/5] 打包文件...${NC}"
DEPLOY_FILE="vps-deploy-$(date +%Y%m%d-%H%M%S).tar.gz"
tar -czf ${DEPLOY_FILE} \
    dist/ \
    server/ \
    nginx.conf.example

echo -e "${GREEN}✓ 打包完成: ${DEPLOY_FILE}${NC}"
echo ""

# 步骤 3: 上传
echo -e "${YELLOW}[3/5] 上传到服务器...${NC}"
scp ${DEPLOY_FILE} ${SERVER_USER}@${SERVER_IP}:/tmp/

echo -e "${GREEN}✓ 上传完成${NC}"
echo ""

# 步骤 4: 服务器端安装
echo -e "${YELLOW}[4/5] 服务器端部署...${NC}"

ssh ${SERVER_USER}@${SERVER_IP} << ENDSSH
set -e

# 检测系统类型
if [ -f /etc/debian_version ]; then
    PKG_MANAGER="apt"
    sudo apt update -y
elif [ -f /etc/redhat-release ]; then
    PKG_MANAGER="yum"
    sudo yum update -y
else
    echo "不支持的系统类型"
    exit 1
fi

# 安装 Node.js (如果未安装)
if ! command -v node &> /dev/null; then
    echo "安装 Node.js..."
    curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
    sudo \${PKG_MANAGER} install -y nodejs
fi

echo "Node.js 版本: \$(node -v)"

# 安装 Nginx (如果未安装)
if ! command -v nginx &> /dev/null; then
    echo "安装 Nginx..."
    sudo \${PKG_MANAGER} install -y nginx
fi

# 安装 PM2
if ! command -v pm2 &> /dev/null; then
    echo "安装 PM2..."
    sudo npm install -g pm2
fi

# 创建部署目录
sudo mkdir -p /var/www/smartinsight
cd /var/www/smartinsight

# 备份旧版本
if [ -d "dist" ]; then
    echo "备份旧版本..."
    sudo tar -czf backup-\$(date +%Y%m%d-%H%M%S).tar.gz dist/ server/ 2>/dev/null || true
fi

# 解压新版本
echo "解压文件..."
DEPLOY_FILE=\$(ls -t /tmp/vps-deploy-*.tar.gz | head -1)
sudo tar -xzf \${DEPLOY_FILE}

# 安装后端依赖
echo "安装后端依赖..."
cd server
sudo npm install --production

# 创建环境变量文件
if [ ! -f ".env" ]; then
    echo "创建环境变量文件..."
    cat > .env << 'EOF'
# Supabase 配置
SUPABASE_URL=https://your-project.supabase.co
SUPABASE_ANON_KEY=your-anon-key
SUPABASE_SERVICE_KEY=your-service-key

# JWT 配置
JWT_SECRET=\$(openssl rand -base64 32)

# 服务器配置
PORT=3000
NODE_ENV=production
EOF

    echo ""
    echo "⚠️  重要: 请编辑 /var/www/smartinsight/server/.env 配置正确的环境变量"
    echo "   命令: sudo nano /var/www/smartinsight/server/.env"
fi

cd /var/www/smartinsight

# 配置 Nginx
echo "配置 Nginx..."
sudo tee /etc/nginx/sites-available/smartinsight > /dev/null << 'NGINXCONF'
server {
    listen 80;
    server_name _;

    # 前端静态文件
    root /var/www/smartinsight/dist;
    index index.html;

    # 前端路由
    location / {
        try_files \$uri \$uri/ /index.html;
    }

    # 后端 API
    location /api {
        proxy_pass http://localhost:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade \$http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_cache_bypass \$http_upgrade;
    }

    # 静态资源缓存
    location ~* \.(js|css|png|jpg|jpeg|gif|ico|svg|woff|woff2|ttf|eot)$ {
        expires 1y;
        add_header Cache-Control "public, immutable";
    }
}
NGINXCONF

# 启用站点
sudo ln -sf /etc/nginx/sites-available/smartinsight /etc/nginx/sites-enabled/
sudo rm -f /etc/nginx/sites-enabled/default

# 测试并重启 Nginx
sudo nginx -t
sudo systemctl restart nginx
sudo systemctl enable nginx

echo "✓ Nginx 配置完成"

# 启动应用
echo "启动应用..."
cd /var/www/smartinsight/server

# 停止旧进程
pm2 stop smartinsight 2>/dev/null || true
pm2 delete smartinsight 2>/dev/null || true

# 启动新进程
pm2 start src/index.js --name smartinsight
pm2 save

# 设置开机自启
sudo env PATH=\$PATH:/usr/bin pm2 startup systemd -u \$(whoami) --hp \$(eval echo ~\$(whoami)) | tail -n 1 | sudo bash

echo "✓ 应用启动完成"

# 配置防火墙
if command -v ufw &> /dev/null; then
    sudo ufw allow 80/tcp
    sudo ufw allow 443/tcp
    sudo ufw allow 22/tcp
    echo "✓ 防火墙规则已配置"
fi

# 清理
rm -f \${DEPLOY_FILE}

echo ""
echo "======================================"
echo "  ✓ 部署完成！"
echo "======================================"

ENDSSH

echo -e "${GREEN}✓ 服务器部署完成${NC}"
echo ""

# 步骤 5: 显示结果
echo -e "${YELLOW}[5/5] 部署信息${NC}"
echo ""
echo "======================================"
echo "  🎉 部署成功！"
echo "======================================"
echo ""

if [ -n "$DOMAIN" ]; then
    echo "🌐 访问地址: http://${DOMAIN}"
    echo ""
    echo "📝 配置域名DNS："
    echo "   类型: A"
    echo "   主机: @"
    echo "   值: ${SERVER_IP}"
    echo ""
    echo "🔒 配置 HTTPS (可选):"
    echo "   ssh ${SERVER_USER}@${SERVER_IP}"
    echo "   sudo apt install certbot python3-certbot-nginx -y"
    echo "   sudo certbot --nginx -d ${DOMAIN}"
else
    echo "🌐 访问地址: http://${SERVER_IP}"
fi

echo ""
echo "👤 默认登录:"
echo "   用户名: admin"
echo "   密码: admin123"
echo ""
echo "⚠️  重要提醒:"
echo "   1. 立即修改默认密码"
echo "   2. 配置环境变量:"
echo "      ssh ${SERVER_USER}@${SERVER_IP}"
echo "      sudo nano /var/www/smartinsight/server/.env"
echo "   3. 重启应用: ssh ${SERVER_USER}@${SERVER_IP} 'pm2 restart smartinsight'"
echo ""
echo "🔧 常用命令:"
echo "   查看日志: ssh ${SERVER_USER}@${SERVER_IP} 'pm2 logs smartinsight'"
echo "   重启应用: ssh ${SERVER_USER}@${SERVER_IP} 'pm2 restart smartinsight'"
echo "   查看状态: ssh ${SERVER_USER}@${SERVER_IP} 'pm2 status'"
echo ""

# 清理本地文件
rm -f ${DEPLOY_FILE}
echo -e "${GREEN}✓ 本地临时文件已清理${NC}"
echo ""
