import "jsr:@supabase/functions-js/edge-runtime.d.ts";
import { createClient } from 'npm:@supabase/supabase-js@2';

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, {
      status: 200,
      headers: corsHeaders,
    });
  }

  try {
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const supabase = createClient(supabaseUrl, supabaseKey);

    const { data: jobs, error: fetchError } = await supabase
      .from('sys_async_jobs')
      .select('*')
      .eq('status', 'pending')
      .lte('scheduled_at', new Date().toISOString())
      .order('priority', { ascending: false })
      .order('scheduled_at', { ascending: true })
      .limit(5);

    if (fetchError) {
      throw fetchError;
    }

    const results = [];

    for (const job of jobs || []) {
      try {
        await supabase
          .from('sys_async_jobs')
          .update({
            status: 'processing',
            started_at: new Date().toISOString()
          })
          .eq('id', job.id);

        let result = null;

        switch (job.job_type) {
          case 'scrape_product':
            result = await handleScrapeProduct(supabase, job);
            break;

          case 'auto_listing':
            result = await handleAutoListing(supabase, job);
            break;

          case 'assign_picker':
            result = await handleAssignPicker(supabase, job);
            break;

          default:
            throw new Error(`Unknown job type: ${job.job_type}`);
        }

        await supabase
          .from('sys_async_jobs')
          .update({
            status: 'completed',
            result: result,
            completed_at: new Date().toISOString()
          })
          .eq('id', job.id);

        results.push({ job_id: job.id, status: 'completed', result });
      } catch (error) {
        const errorMessage = error instanceof Error ? error.message : String(error);

        const { data: jobData } = await supabase
          .from('sys_async_jobs')
          .select('retry_count, max_retries')
          .eq('id', job.id)
          .single();

        const newRetryCount = (jobData?.retry_count || 0) + 1;
        const maxRetries = jobData?.max_retries || 3;

        if (newRetryCount < maxRetries) {
          await supabase
            .from('sys_async_jobs')
            .update({
              status: 'pending',
              retry_count: newRetryCount,
              error_message: errorMessage,
              last_error_at: new Date().toISOString(),
              next_retry_at: new Date(Date.now() + newRetryCount * 5 * 60 * 1000).toISOString()
            })
            .eq('id', job.id);
        } else {
          await supabase
            .from('sys_async_jobs')
            .update({
              status: 'failed',
              retry_count: newRetryCount,
              error_message: errorMessage,
              last_error_at: new Date().toISOString(),
              completed_at: new Date().toISOString()
            })
            .eq('id', job.id);
        }

        results.push({ job_id: job.id, status: 'failed', error: errorMessage });
      }
    }

    return new Response(
      JSON.stringify({
        success: true,
        processed: results.length,
        results
      }),
      {
        headers: {
          ...corsHeaders,
          'Content-Type': 'application/json',
        },
      }
    );
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : String(error);
    return new Response(
      JSON.stringify({ error: errorMessage }),
      {
        status: 500,
        headers: {
          ...corsHeaders,
          'Content-Type': 'application/json',
        },
      }
    );
  }
});

async function handleScrapeProduct(supabase: any, job: any) {
  const { supplier_product_id, product_link } = job.payload;

  await supabase
    .from('pur_supplier_products')
    .update({
      scrape_status: 'processing'
    })
    .eq('id', supplier_product_id);

  const mockScrapedData = {
    title: '示例商品 - ' + product_link.substring(0, 20),
    description: '这是一个模拟抓取的商品描述。在生产环境中，这里会调用真实的商品信息抓取API。',
    images: [
      { url: 'https://via.placeholder.com/400' },
      { url: 'https://via.placeholder.com/400' },
      { url: 'https://via.placeholder.com/400' }
    ],
    price: Math.floor(Math.random() * 900) + 100,
    specs: { weight: '1kg', color: '白色', material: '塑料' }
  };

  await supabase
    .from('pur_supplier_products')
    .update({
      scraped_title: mockScrapedData.title,
      scraped_description: mockScrapedData.description,
      scraped_images: mockScrapedData.images,
      scraped_specs: mockScrapedData.specs,
      scraped_price: mockScrapedData.price,
      scrape_status: 'success',
      last_scraped_at: new Date().toISOString()
    })
    .eq('id', supplier_product_id);

  return { scraped: true, title: mockScrapedData.title };
}

async function handleAutoListing(supabase: any, job: any) {
  const { supplier_product_id, initial_stock } = job.payload;

  const { data: productId, error } = await supabase.rpc('auto_list_product', {
    p_supplier_product_id: supplier_product_id,
    p_initial_stock: initial_stock || 100
  });

  if (error) throw error;

  return { listed: true, product_id: productId };
}

async function handleAssignPicker(supabase: any, job: any) {
  const { outbound_id } = job.payload;

  const { data: warehouses, error: whError } = await supabase
    .from('wms_outbound')
    .select('warehouse_id')
    .eq('id', outbound_id)
    .single();

  if (whError) throw whError;

  const { data: pickers, error: pickerError } = await supabase
    .from('sys_admins')
    .select('id')
    .eq('status', 'active')
    .limit(1);

  if (pickerError || !pickers || pickers.length === 0) {
    throw new Error('No available picker found');
  }

  const pickerId = pickers[0].id;

  await supabase
    .from('wms_outbound')
    .update({
      picker_id: pickerId,
      picker_assigned_at: new Date().toISOString(),
      status: 'picking'
    })
    .eq('id', outbound_id);

  return { assigned: true, picker_id: pickerId };
}
