import "jsr:@supabase/functions-js/edge-runtime.d.ts";
import { createClient } from "npm:@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, {
      status: 200,
      headers: corsHeaders,
    });
  }

  try {
    const url = new URL(req.url);
    const shortCode = url.searchParams.get("code") || url.pathname.split("/").pop();

    if (!shortCode) {
      return new Response(JSON.stringify({ error: "Missing short code" }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    const visitorIP = req.headers.get("x-forwarded-for") || 
                      req.headers.get("x-real-ip") || 
                      "unknown";
    const userAgent = req.headers.get("user-agent") || "";
    const referrer = req.headers.get("referer") || null;

    const deviceType = detectDeviceType(userAgent);
    const browserInfo = detectBrowser(userAgent);
    const osInfo = detectOS(userAgent);

    const { data, error } = await supabase.rpc("record_link_visit", {
      p_short_code: shortCode,
      p_visitor_ip: visitorIP,
      p_user_agent: userAgent,
      p_referrer: referrer,
      p_custom_data: {
        device_type: deviceType,
        browser: browserInfo.name,
        browser_version: browserInfo.version,
        os: osInfo.name,
        os_version: osInfo.version,
      },
    });

    if (error || !data?.success) {
      return new Response(
        JSON.stringify({ error: data?.error || "Link not found" }),
        {
          status: 404,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        }
      );
    }

    return new Response(null, {
      status: 302,
      headers: {
        ...corsHeaders,
        "Location": data.redirect_url,
      },
    });
  } catch (error) {
    console.error("Error:", error);
    return new Response(
      JSON.stringify({ error: error.message }),
      {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      }
    );
  }
});

function detectDeviceType(userAgent: string): string {
  const ua = userAgent.toLowerCase();
  if (/(bot|crawler|spider)/i.test(ua)) return "bot";
  if (/(tablet|ipad|playbook|silk)/i.test(ua)) return "tablet";
  if (/(mobile|phone|android|iphone|ipod|blackberry|windows phone)/i.test(ua)) return "mobile";
  return "desktop";
}

function detectBrowser(userAgent: string): { name: string; version: string } {
  const ua = userAgent.toLowerCase();
  
  if (ua.includes("edg")) {
    const version = ua.match(/edg\/(\d+\.\d+)/);
    return { name: "Edge", version: version ? version[1] : "unknown" };
  }
  if (ua.includes("chrome")) {
    const version = ua.match(/chrome\/(\d+\.\d+)/);
    return { name: "Chrome", version: version ? version[1] : "unknown" };
  }
  if (ua.includes("firefox")) {
    const version = ua.match(/firefox\/(\d+\.\d+)/);
    return { name: "Firefox", version: version ? version[1] : "unknown" };
  }
  if (ua.includes("safari") && !ua.includes("chrome")) {
    const version = ua.match(/version\/(\d+\.\d+)/);
    return { name: "Safari", version: version ? version[1] : "unknown" };
  }
  
  return { name: "Other", version: "unknown" };
}

function detectOS(userAgent: string): { name: string; version: string } {
  const ua = userAgent.toLowerCase();
  
  if (ua.includes("windows nt 10")) return { name: "Windows", version: "10" };
  if (ua.includes("windows nt 11")) return { name: "Windows", version: "11" };
  if (ua.includes("mac os x")) {
    const version = ua.match(/mac os x (\d+[._]\d+)/);
    return { name: "macOS", version: version ? version[1].replace("_", ".") : "unknown" };
  }
  if (ua.includes("android")) {
    const version = ua.match(/android (\d+\.\d+)/);
    return { name: "Android", version: version ? version[1] : "unknown" };
  }
  if (ua.includes("iphone") || ua.includes("ipad")) {
    const version = ua.match(/os (\d+[._]\d+)/);
    return { name: "iOS", version: version ? version[1].replace("_", ".") : "unknown" };
  }
  if (ua.includes("linux")) return { name: "Linux", version: "unknown" };
  
  return { name: "Other", version: "unknown" };
}
