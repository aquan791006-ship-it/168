/*
  # 创建AI作图系统

  ## 功能说明
  为168全球购ERP系统添加AI作图模块，支持：
  1. 对话式图片生成
  2. 图片格式转换（GIF、WebP、APNG、Lottie等）
  3. 图片编辑和修改
  4. 图片库管理
  5. 下载和导出

  ## 新增表
  1. `ai_image_conversations` - AI作图对话记录
  2. `ai_image_generations` - 图片生成记录
  3. `ai_image_library` - 图片库
  4. `ai_image_templates` - 图片模板
  5. `ai_image_styles` - 预设样式

  ## 安全性
  - 严格的权限控制
  - 完整的操作日志
  - 图片内容审核
*/

-- 1. AI作图对话记录表
CREATE TABLE IF NOT EXISTS ai_image_conversations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  domain_id uuid REFERENCES sys_domains(id) ON DELETE CASCADE,
  title text NOT NULL DEFAULT '新对话',
  created_by uuid REFERENCES sys_admins(id) ON DELETE SET NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  is_archived boolean DEFAULT false,
  metadata jsonb DEFAULT '{}'
);

-- 2. AI作图消息记录表
CREATE TABLE IF NOT EXISTS ai_image_messages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  conversation_id uuid REFERENCES ai_image_conversations(id) ON DELETE CASCADE,
  role text NOT NULL CHECK (role IN ('user', 'assistant', 'system')),
  content text NOT NULL,
  image_ids uuid[] DEFAULT '{}',
  created_at timestamptz DEFAULT now(),
  metadata jsonb DEFAULT '{}'
);

-- 3. 图片生成记录表
CREATE TABLE IF NOT EXISTS ai_image_generations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  domain_id uuid REFERENCES sys_domains(id) ON DELETE CASCADE,
  conversation_id uuid REFERENCES ai_image_conversations(id) ON DELETE SET NULL,
  message_id uuid REFERENCES ai_image_messages(id) ON DELETE SET NULL,
  prompt text NOT NULL,
  negative_prompt text,
  style text DEFAULT 'realistic',
  size text DEFAULT '1024x1024',
  format text DEFAULT 'png' CHECK (format IN ('png', 'jpg', 'webp', 'gif', 'apng', 'svg')),
  quality text DEFAULT 'standard' CHECK (quality IN ('draft', 'standard', 'hd', 'ultra')),
  image_url text,
  thumbnail_url text,
  file_path text,
  file_size integer,
  width integer,
  height integer,
  generation_time_ms integer,
  status text DEFAULT 'pending' CHECK (status IN ('pending', 'generating', 'completed', 'failed', 'cancelled')),
  error_message text,
  ai_provider text DEFAULT 'internal',
  provider_data jsonb DEFAULT '{}',
  created_by uuid REFERENCES sys_admins(id) ON DELETE SET NULL,
  created_at timestamptz DEFAULT now(),
  is_public boolean DEFAULT false,
  download_count integer DEFAULT 0,
  metadata jsonb DEFAULT '{}'
);

-- 4. 图片库表
CREATE TABLE IF NOT EXISTS ai_image_library (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  domain_id uuid REFERENCES sys_domains(id) ON DELETE CASCADE,
  generation_id uuid REFERENCES ai_image_generations(id) ON DELETE SET NULL,
  title text NOT NULL,
  description text,
  image_url text NOT NULL,
  thumbnail_url text,
  file_path text,
  file_size integer,
  width integer,
  height integer,
  format text NOT NULL,
  tags text[] DEFAULT '{}',
  category text DEFAULT 'general',
  is_favorite boolean DEFAULT false,
  view_count integer DEFAULT 0,
  download_count integer DEFAULT 0,
  created_by uuid REFERENCES sys_admins(id) ON DELETE SET NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  metadata jsonb DEFAULT '{}'
);

-- 5. 图片模板表
CREATE TABLE IF NOT EXISTS ai_image_templates (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  template_key text UNIQUE NOT NULL,
  template_name jsonb NOT NULL,
  description jsonb,
  category text NOT NULL,
  preview_url text,
  prompt_template text NOT NULL,
  default_style text DEFAULT 'realistic',
  default_size text DEFAULT '1024x1024',
  default_format text DEFAULT 'png',
  parameters jsonb DEFAULT '{}',
  is_active boolean DEFAULT true,
  usage_count integer DEFAULT 0,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- 6. 预设样式表
CREATE TABLE IF NOT EXISTS ai_image_styles (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  style_key text UNIQUE NOT NULL,
  style_name jsonb NOT NULL,
  description jsonb,
  preview_url text,
  prompt_suffix text NOT NULL,
  negative_prompt text,
  recommended_settings jsonb DEFAULT '{}',
  is_active boolean DEFAULT true,
  usage_count integer DEFAULT 0,
  created_at timestamptz DEFAULT now()
);

-- 7. 图片格式转换记录表
CREATE TABLE IF NOT EXISTS ai_image_conversions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  domain_id uuid REFERENCES sys_domains(id) ON DELETE CASCADE,
  source_image_id uuid REFERENCES ai_image_library(id) ON DELETE SET NULL,
  source_format text NOT NULL,
  target_format text NOT NULL,
  source_url text NOT NULL,
  target_url text,
  file_path text,
  file_size integer,
  conversion_options jsonb DEFAULT '{}',
  status text DEFAULT 'pending' CHECK (status IN ('pending', 'processing', 'completed', 'failed')),
  error_message text,
  processing_time_ms integer,
  created_by uuid REFERENCES sys_admins(id) ON DELETE SET NULL,
  created_at timestamptz DEFAULT now()
);

-- 启用RLS
ALTER TABLE ai_image_conversations ENABLE ROW LEVEL SECURITY;
ALTER TABLE ai_image_messages ENABLE ROW LEVEL SECURITY;
ALTER TABLE ai_image_generations ENABLE ROW LEVEL SECURITY;
ALTER TABLE ai_image_library ENABLE ROW LEVEL SECURITY;
ALTER TABLE ai_image_templates ENABLE ROW LEVEL SECURITY;
ALTER TABLE ai_image_styles ENABLE ROW LEVEL SECURITY;
ALTER TABLE ai_image_conversions ENABLE ROW LEVEL SECURITY;

-- 创建索引
CREATE INDEX IF NOT EXISTS idx_ai_image_conversations_domain ON ai_image_conversations(domain_id);
CREATE INDEX IF NOT EXISTS idx_ai_image_conversations_created_by ON ai_image_conversations(created_by);
CREATE INDEX IF NOT EXISTS idx_ai_image_messages_conversation ON ai_image_messages(conversation_id);
CREATE INDEX IF NOT EXISTS idx_ai_image_generations_domain ON ai_image_generations(domain_id);
CREATE INDEX IF NOT EXISTS idx_ai_image_generations_status ON ai_image_generations(status);
CREATE INDEX IF NOT EXISTS idx_ai_image_generations_conversation ON ai_image_generations(conversation_id);
CREATE INDEX IF NOT EXISTS idx_ai_image_library_domain ON ai_image_library(domain_id);
CREATE INDEX IF NOT EXISTS idx_ai_image_library_category ON ai_image_library(category);
CREATE INDEX IF NOT EXISTS idx_ai_image_library_tags ON ai_image_library USING gin(tags);
CREATE INDEX IF NOT EXISTS idx_ai_image_templates_category ON ai_image_templates(category);
CREATE INDEX IF NOT EXISTS idx_ai_image_conversions_domain ON ai_image_conversions(domain_id);

-- RLS策略

-- ai_image_conversations
CREATE POLICY "Users can view own domain conversations"
  ON ai_image_conversations FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM sys_admin_domains ad
      WHERE ad.admin_id = auth.uid()
      AND ad.domain_id = ai_image_conversations.domain_id
    )
  );

CREATE POLICY "Users can create conversations in own domain"
  ON ai_image_conversations FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM sys_admin_domains ad
      WHERE ad.admin_id = auth.uid()
      AND ad.domain_id = ai_image_conversations.domain_id
    )
  );

CREATE POLICY "Users can update own conversations"
  ON ai_image_conversations FOR UPDATE
  TO authenticated
  USING (created_by = auth.uid());

-- ai_image_messages
CREATE POLICY "Users can view messages in accessible conversations"
  ON ai_image_messages FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM ai_image_conversations c
      JOIN sys_admin_domains ad ON ad.domain_id = c.domain_id
      WHERE c.id = ai_image_messages.conversation_id
      AND ad.admin_id = auth.uid()
    )
  );

CREATE POLICY "Users can create messages in accessible conversations"
  ON ai_image_messages FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM ai_image_conversations c
      JOIN sys_admin_domains ad ON ad.domain_id = c.domain_id
      WHERE c.id = ai_image_messages.conversation_id
      AND ad.admin_id = auth.uid()
    )
  );

-- ai_image_generations
CREATE POLICY "Users can view own domain generations"
  ON ai_image_generations FOR SELECT
  TO authenticated
  USING (
    is_public = true OR
    EXISTS (
      SELECT 1 FROM sys_admin_domains ad
      WHERE ad.admin_id = auth.uid()
      AND ad.domain_id = ai_image_generations.domain_id
    )
  );

CREATE POLICY "Users can create generations in own domain"
  ON ai_image_generations FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM sys_admin_domains ad
      WHERE ad.admin_id = auth.uid()
      AND ad.domain_id = ai_image_generations.domain_id
    )
  );

CREATE POLICY "Users can update own generations"
  ON ai_image_generations FOR UPDATE
  TO authenticated
  USING (created_by = auth.uid());

-- ai_image_library
CREATE POLICY "Users can view own domain library"
  ON ai_image_library FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM sys_admin_domains ad
      WHERE ad.admin_id = auth.uid()
      AND ad.domain_id = ai_image_library.domain_id
    )
  );

CREATE POLICY "Users can manage own domain library"
  ON ai_image_library FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM sys_admin_domains ad
      WHERE ad.admin_id = auth.uid()
      AND ad.domain_id = ai_image_library.domain_id
    )
  );

-- ai_image_templates
CREATE POLICY "Anyone can view active templates"
  ON ai_image_templates FOR SELECT
  TO authenticated
  USING (is_active = true);

CREATE POLICY "Only super admin can manage templates"
  ON ai_image_templates FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM sys_admins
      WHERE id = auth.uid()
      AND is_super_admin = true
    )
  );

-- ai_image_styles
CREATE POLICY "Anyone can view active styles"
  ON ai_image_styles FOR SELECT
  TO authenticated
  USING (is_active = true);

CREATE POLICY "Only super admin can manage styles"
  ON ai_image_styles FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM sys_admins
      WHERE id = auth.uid()
      AND is_super_admin = true
    )
  );

-- ai_image_conversions
CREATE POLICY "Users can view own domain conversions"
  ON ai_image_conversions FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM sys_admin_domains ad
      WHERE ad.admin_id = auth.uid()
      AND ad.domain_id = ai_image_conversions.domain_id
    )
  );

CREATE POLICY "Users can create conversions in own domain"
  ON ai_image_conversions FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM sys_admin_domains ad
      WHERE ad.admin_id = auth.uid()
      AND ad.domain_id = ai_image_conversions.domain_id
    )
  );

-- 插入预设模板
INSERT INTO ai_image_templates (template_key, template_name, description, category, prompt_template, default_style, default_size) VALUES
  ('product_photo', '{"zh": "商品照片", "en": "Product Photo"}', '{"zh": "生成专业的商品展示照片", "en": "Generate professional product photos"}', 'ecommerce', 'A professional product photo of {product}, clean white background, studio lighting, high resolution, commercial photography', 'realistic', '1024x1024'),
  ('banner_design', '{"zh": "横幅设计", "en": "Banner Design"}', '{"zh": "创建营销横幅和广告图", "en": "Create marketing banners and ads"}', 'marketing', 'A modern banner design for {theme}, vibrant colors, clean layout, professional design', 'modern', '1920x1080'),
  ('logo_design', '{"zh": "Logo设计", "en": "Logo Design"}', '{"zh": "设计品牌Logo", "en": "Design brand logos"}', 'branding', 'A minimalist logo design for {brand}, {style} style, simple and memorable, vector style', 'minimalist', '512x512'),
  ('social_media', '{"zh": "社交媒体", "en": "Social Media"}', '{"zh": "社交媒体配图", "en": "Social media graphics"}', 'marketing', 'An eye-catching social media post about {topic}, vibrant colors, engaging design', 'modern', '1080x1080'),
  ('illustration', '{"zh": "插画", "en": "Illustration"}', '{"zh": "创意插画和艺术作品", "en": "Creative illustrations and artworks"}', 'art', 'An artistic illustration of {subject}, {style} style, detailed and colorful', 'artistic', '1024x1024'),
  ('icon_set', '{"zh": "图标集", "en": "Icon Set"}', '{"zh": "UI图标设计", "en": "UI icon design"}', 'ui', 'A set of {theme} icons, minimal design, consistent style, modern UI', 'flat', '512x512')
ON CONFLICT (template_key) DO UPDATE SET
  template_name = EXCLUDED.template_name,
  description = EXCLUDED.description,
  is_active = true;

-- 插入预设样式
INSERT INTO ai_image_styles (style_key, style_name, description, prompt_suffix, negative_prompt) VALUES
  ('realistic', '{"zh": "写实风格", "en": "Realistic"}', '{"zh": "照片级真实感", "en": "Photorealistic quality"}', 'photorealistic, highly detailed, 8k uhd, professional photography', 'blurry, low quality, distorted, cartoon, anime'),
  ('minimalist', '{"zh": "极简风格", "en": "Minimalist"}', '{"zh": "简洁现代设计", "en": "Clean modern design"}', 'minimalist design, clean lines, simple, modern, elegant', 'cluttered, complex, busy, ornate'),
  ('artistic', '{"zh": "艺术风格", "en": "Artistic"}', '{"zh": "艺术绘画感", "en": "Artistic painting style"}', 'artistic, painterly, expressive, creative, beautiful artwork', 'photorealistic, plain, simple'),
  ('modern', '{"zh": "现代风格", "en": "Modern"}', '{"zh": "现代设计感", "en": "Modern design aesthetic"}', 'modern design, contemporary, sleek, professional', 'vintage, old-fashioned, dated'),
  ('flat', '{"zh": "扁平风格", "en": "Flat Design"}', '{"zh": "扁平化设计", "en": "Flat design style"}', 'flat design, 2d, vector style, clean, simple colors', '3d, realistic, textured, gradient'),
  ('3d', '{"zh": "3D风格", "en": "3D Style"}', '{"zh": "三维立体效果", "en": "3D rendered style"}', '3d render, volumetric lighting, octane render, highly detailed 3d', '2d, flat, sketch'),
  ('watercolor', '{"zh": "水彩风格", "en": "Watercolor"}', '{"zh": "水彩画效果", "en": "Watercolor painting effect"}', 'watercolor painting, soft colors, artistic, flowing', 'sharp, digital, photographic'),
  ('cartoon', '{"zh": "卡通风格", "en": "Cartoon"}', '{"zh": "卡通动漫风格", "en": "Cartoon animation style"}', 'cartoon style, animated, colorful, fun, playful', 'realistic, photographic, serious')
ON CONFLICT (style_key) DO UPDATE SET
  style_name = EXCLUDED.style_name,
  description = EXCLUDED.description,
  is_active = true;

-- 自动注册AI作图模块到AI模块注册表
INSERT INTO ai_module_registry (module_key, module_name, table_names, allowed_operations, data_sensitivity, requires_masking) VALUES
  ('ai_image_studio', '{"zh": "AI作图工作室", "en": "AI Image Studio"}', 
   ARRAY['ai_image_conversations', 'ai_image_generations', 'ai_image_library', 'ai_image_templates', 'ai_image_styles'], 
   ARRAY['read', 'create', 'update'], 
   'low', 
   false)
ON CONFLICT (module_key) DO UPDATE SET
  table_names = EXCLUDED.table_names,
  allowed_operations = EXCLUDED.allowed_operations,
  is_active = true;