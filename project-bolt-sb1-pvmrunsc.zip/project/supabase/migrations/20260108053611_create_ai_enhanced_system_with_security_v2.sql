/*
  # 创建AI增强系统 - 智能模块访问与自学习（修正版）

  ## 功能说明
  为SmartInsight AI模块添加：
  1. 对所有ERP模块的智能访问权限
  2. AI自学习能力
  3. 数据脱敏保护
  4. 人工审核机制(Human-in-the-loop)
  5. 只有超级管理员才能使用AI高级功能

  ## 新增表
  1. `ai_module_registry` - AI可访问的模块注册表
  2. `ai_learning_data` - AI自学习数据存储
  3. `ai_operation_queue` - AI操作待审核队列
  4. `ai_data_masking_rules` - 数据脱敏规则
  5. `ai_execution_logs` - AI操作执行日志
  6. `ai_training_samples` - AI训练样本（脱敏后）

  ## 安全性
  - 严格的超级管理员权限验证（使用is_super_admin字段）
  - 完整的数据脱敏机制
  - 强制人工审核流程
  - 完整的操作审计日志
*/

-- 1. AI模块注册表 - 记录AI可以访问的所有模块
CREATE TABLE IF NOT EXISTS ai_module_registry (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  module_key text UNIQUE NOT NULL,
  module_name jsonb NOT NULL,
  table_names text[] DEFAULT '{}',
  allowed_operations text[] DEFAULT ARRAY['read'],
  data_sensitivity text DEFAULT 'normal' CHECK (data_sensitivity IN ('low', 'normal', 'high', 'critical')),
  requires_masking boolean DEFAULT false,
  masking_fields jsonb DEFAULT '[]',
  is_active boolean DEFAULT true,
  registered_at timestamptz DEFAULT now(),
  last_accessed timestamptz,
  access_count integer DEFAULT 0,
  metadata jsonb DEFAULT '{}'
);

-- 2. AI学习数据表 - 存储AI从用户交互中学习的知识
CREATE TABLE IF NOT EXISTS ai_learning_data (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  domain_id uuid REFERENCES sys_domains(id) ON DELETE CASCADE,
  learning_type text NOT NULL CHECK (learning_type IN ('user_query', 'operation_pattern', 'optimization_suggestion', 'error_correction', 'best_practice')),
  context jsonb NOT NULL,
  user_input text NOT NULL,
  ai_response text NOT NULL,
  is_successful boolean DEFAULT true,
  user_feedback text,
  feedback_score integer CHECK (feedback_score BETWEEN 1 AND 5),
  is_masked boolean DEFAULT true,
  original_data_hash text,
  learned_patterns jsonb DEFAULT '{}',
  confidence_score numeric(5,2) DEFAULT 0,
  created_by uuid REFERENCES sys_admins(id) ON DELETE SET NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- 3. AI操作待审核队列 - 实现Human-in-the-loop
CREATE TABLE IF NOT EXISTS ai_operation_queue (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  domain_id uuid REFERENCES sys_domains(id) ON DELETE CASCADE,
  operation_type text NOT NULL CHECK (operation_type IN ('create', 'update', 'delete', 'bulk_update', 'module_modification')),
  target_module text NOT NULL,
  target_table text NOT NULL,
  operation_data jsonb NOT NULL,
  ai_reasoning text NOT NULL,
  risk_level text DEFAULT 'medium' CHECK (risk_level IN ('low', 'medium', 'high', 'critical')),
  estimated_impact text,
  status text DEFAULT 'pending' CHECK (status IN ('pending', 'approved', 'rejected', 'executed', 'failed', 'cancelled')),
  requested_by uuid REFERENCES sys_admins(id) ON DELETE SET NULL,
  reviewed_by uuid REFERENCES sys_admins(id) ON DELETE SET NULL,
  review_notes text,
  execution_result jsonb,
  created_at timestamptz DEFAULT now(),
  reviewed_at timestamptz,
  executed_at timestamptz,
  expires_at timestamptz DEFAULT (now() + interval '24 hours')
);

-- 4. 数据脱敏规则表
CREATE TABLE IF NOT EXISTS ai_data_masking_rules (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  module_key text NOT NULL,
  table_name text NOT NULL,
  field_name text NOT NULL,
  field_type text NOT NULL CHECK (field_type IN ('phone', 'email', 'name', 'address', 'id_card', 'bank_account', 'password', 'custom')),
  masking_method text NOT NULL CHECK (masking_method IN ('hash', 'partial', 'replace', 'encrypt', 'remove', 'anonymize')),
  masking_config jsonb DEFAULT '{}',
  is_active boolean DEFAULT true,
  priority integer DEFAULT 100,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  UNIQUE(module_key, table_name, field_name)
);

-- 5. AI执行日志表
CREATE TABLE IF NOT EXISTS ai_execution_logs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  domain_id uuid REFERENCES sys_domains(id) ON DELETE CASCADE,
  operation_queue_id uuid REFERENCES ai_operation_queue(id) ON DELETE SET NULL,
  operation_type text NOT NULL,
  target_module text NOT NULL,
  target_table text NOT NULL,
  operation_summary text NOT NULL,
  executed_by uuid REFERENCES sys_admins(id) ON DELETE SET NULL,
  execution_status text DEFAULT 'success' CHECK (execution_status IN ('success', 'failed', 'partial')),
  records_affected integer DEFAULT 0,
  execution_time_ms integer,
  error_message text,
  rollback_data jsonb,
  created_at timestamptz DEFAULT now()
);

-- 6. AI训练样本表（已脱敏）
CREATE TABLE IF NOT EXISTS ai_training_samples (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  sample_type text NOT NULL CHECK (sample_type IN ('query_pattern', 'optimization', 'prediction', 'recommendation')),
  input_features jsonb NOT NULL,
  expected_output jsonb NOT NULL,
  actual_output jsonb,
  accuracy_score numeric(5,2),
  is_validated boolean DEFAULT false,
  validation_date timestamptz,
  usage_count integer DEFAULT 0,
  last_used_at timestamptz,
  created_at timestamptz DEFAULT now()
);

-- 启用RLS
ALTER TABLE ai_module_registry ENABLE ROW LEVEL SECURITY;
ALTER TABLE ai_learning_data ENABLE ROW LEVEL SECURITY;
ALTER TABLE ai_operation_queue ENABLE ROW LEVEL SECURITY;
ALTER TABLE ai_data_masking_rules ENABLE ROW LEVEL SECURITY;
ALTER TABLE ai_execution_logs ENABLE ROW LEVEL SECURITY;
ALTER TABLE ai_training_samples ENABLE ROW LEVEL SECURITY;

-- 创建索引
CREATE INDEX IF NOT EXISTS idx_ai_module_registry_key ON ai_module_registry(module_key);
CREATE INDEX IF NOT EXISTS idx_ai_learning_data_domain ON ai_learning_data(domain_id);
CREATE INDEX IF NOT EXISTS idx_ai_learning_data_type ON ai_learning_data(learning_type);
CREATE INDEX IF NOT EXISTS idx_ai_operation_queue_domain ON ai_operation_queue(domain_id);
CREATE INDEX IF NOT EXISTS idx_ai_operation_queue_status ON ai_operation_queue(status);
CREATE INDEX IF NOT EXISTS idx_ai_operation_queue_expires ON ai_operation_queue(expires_at);
CREATE INDEX IF NOT EXISTS idx_ai_masking_rules_module ON ai_data_masking_rules(module_key, table_name);
CREATE INDEX IF NOT EXISTS idx_ai_execution_logs_domain ON ai_execution_logs(domain_id);
CREATE INDEX IF NOT EXISTS idx_ai_training_samples_type ON ai_training_samples(sample_type);

-- RLS策略 - 只有超级管理员可以访问AI高级功能

-- ai_module_registry - 公开读取，只有超级管理员可以修改
CREATE POLICY "Anyone can view module registry"
  ON ai_module_registry FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Only super admin can manage module registry"
  ON ai_module_registry FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM sys_admins
      WHERE id = auth.uid()
      AND is_super_admin = true
    )
  );

-- ai_learning_data - 只能查看自己域的数据
CREATE POLICY "Users can view own domain learning data"
  ON ai_learning_data FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM sys_admin_domains ad
      WHERE ad.admin_id = auth.uid()
      AND ad.domain_id = ai_learning_data.domain_id
    )
  );

CREATE POLICY "Users can create learning data for own domain"
  ON ai_learning_data FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM sys_admin_domains ad
      WHERE ad.admin_id = auth.uid()
      AND ad.domain_id = ai_learning_data.domain_id
    )
  );

-- ai_operation_queue - 只能操作自己域的队列
CREATE POLICY "Users can view own domain operation queue"
  ON ai_operation_queue FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM sys_admin_domains ad
      WHERE ad.admin_id = auth.uid()
      AND ad.domain_id = ai_operation_queue.domain_id
    )
  );

CREATE POLICY "Users can create operations for own domain"
  ON ai_operation_queue FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM sys_admin_domains ad
      WHERE ad.admin_id = auth.uid()
      AND ad.domain_id = ai_operation_queue.domain_id
    )
  );

CREATE POLICY "Super admin can review any operation"
  ON ai_operation_queue FOR UPDATE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM sys_admins
      WHERE id = auth.uid()
      AND is_super_admin = true
    )
  );

-- ai_data_masking_rules - 只有超级管理员可以管理
CREATE POLICY "Anyone can view masking rules"
  ON ai_data_masking_rules FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Only super admin can manage masking rules"
  ON ai_data_masking_rules FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM sys_admins
      WHERE id = auth.uid()
      AND is_super_admin = true
    )
  );

-- ai_execution_logs - 只能查看自己域的日志
CREATE POLICY "Users can view own domain execution logs"
  ON ai_execution_logs FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM sys_admin_domains ad
      WHERE ad.admin_id = auth.uid()
      AND ad.domain_id = ai_execution_logs.domain_id
    )
  );

-- ai_training_samples - 只有超级管理员可以访问
CREATE POLICY "Only super admin can access training samples"
  ON ai_training_samples FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM sys_admins
      WHERE id = auth.uid()
      AND is_super_admin = true
    )
  );

-- 自动注册现有模块到AI系统
INSERT INTO ai_module_registry (module_key, module_name, table_names, allowed_operations, data_sensitivity, requires_masking, masking_fields) VALUES
  ('products', '{"zh": "商品管理", "en": "Products"}', ARRAY['products', 'product_images', 'product_categories'], ARRAY['read', 'create', 'update'], 'normal', false, '[]'),
  ('orders', '{"zh": "订单管理", "en": "Orders"}', ARRAY['orders', 'order_items'], ARRAY['read'], 'high', true, '["customer_name", "customer_phone", "shipping_address"]'),
  ('warehouses', '{"zh": "仓库管理", "en": "Warehouses"}', ARRAY['warehouses', 'warehouse_inventory', 'warehouse_stock_logs'], ARRAY['read', 'update'], 'normal', false, '[]'),
  ('logistics', '{"zh": "物流管理", "en": "Logistics"}', ARRAY['logistics_orders', 'logistics_tracking'], ARRAY['read'], 'high', true, '["recipient_name", "recipient_phone", "recipient_address"]'),
  ('customer_service', '{"zh": "客服管理", "en": "Customer Service"}', ARRAY['cs_tickets', 'cs_messages', 'cs_knowledge_base'], ARRAY['read', 'create'], 'high', true, '["customer_name", "customer_contact"]'),
  ('finance', '{"zh": "财务管理", "en": "Finance"}', ARRAY['finance_accounts', 'finance_transactions', 'finance_invoices'], ARRAY['read'], 'critical', true, '["account_number", "payer_payee", "tax_id"]'),
  ('advertising', '{"zh": "广告管理", "en": "Advertising"}', ARRAY['ad_campaigns', 'ad_performance', 'ad_budgets'], ARRAY['read', 'update'], 'normal', false, '[]'),
  ('promotions', '{"zh": "促销管理", "en": "Promotions"}', ARRAY['promotions', 'promotion_products', 'promotion_usage'], ARRAY['read', 'create', 'update'], 'normal', false, '[]'),
  ('smart_purchase', '{"zh": "智能采购", "en": "Smart Purchase"}', ARRAY['purchase_predictions', 'purchase_recommendations', 'supplier_performance'], ARRAY['read', 'create'], 'normal', false, '[]')
ON CONFLICT (module_key) DO UPDATE SET
  table_names = EXCLUDED.table_names,
  allowed_operations = EXCLUDED.allowed_operations,
  is_active = true;

-- 插入默认数据脱敏规则
INSERT INTO ai_data_masking_rules (module_key, table_name, field_name, field_type, masking_method, masking_config) VALUES
  ('orders', 'orders', 'customer_name', 'name', 'partial', '{"keep_first": 1, "keep_last": 0, "replace_with": "*"}'),
  ('orders', 'orders', 'customer_phone', 'phone', 'partial', '{"keep_first": 3, "keep_last": 4, "replace_with": "****"}'),
  ('orders', 'orders', 'shipping_address', 'address', 'partial', '{"keep_first": 10, "replace_with": "***"}'),
  ('logistics', 'logistics_orders', 'recipient_name', 'name', 'partial', '{"keep_first": 1, "keep_last": 0, "replace_with": "*"}'),
  ('logistics', 'logistics_orders', 'recipient_phone', 'phone', 'partial', '{"keep_first": 3, "keep_last": 4, "replace_with": "****"}'),
  ('logistics', 'logistics_orders', 'recipient_address', 'address', 'partial', '{"keep_first": 10, "replace_with": "***"}'),
  ('customer_service', 'cs_tickets', 'customer_name', 'name', 'anonymize', '{"prefix": "用户"}'),
  ('customer_service', 'cs_tickets', 'customer_contact', 'phone', 'partial', '{"keep_first": 3, "keep_last": 4, "replace_with": "****"}'),
  ('finance', 'finance_accounts', 'account_number', 'bank_account', 'partial', '{"keep_first": 4, "keep_last": 4, "replace_with": "********"}'),
  ('finance', 'finance_transactions', 'payer_payee', 'name', 'partial', '{"keep_first": 1, "replace_with": "**"}'),
  ('finance', 'finance_invoices', 'tax_id', 'id_card', 'partial', '{"keep_first": 6, "keep_last": 4, "replace_with": "******"}')
ON CONFLICT (module_key, table_name, field_name) DO UPDATE SET
  masking_method = EXCLUDED.masking_method,
  masking_config = EXCLUDED.masking_config,
  is_active = true;