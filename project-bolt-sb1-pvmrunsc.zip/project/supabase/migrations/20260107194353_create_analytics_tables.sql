/*
  # Create Analytics Tables

  1. New Tables
    - `daily_sales`
      - `id` (uuid, primary key)
      - `date` (date, unique) - Sales date
      - `open` (decimal) - Opening price
      - `high` (decimal) - Highest price
      - `low` (decimal) - Lowest price
      - `close` (decimal) - Closing price
      - `volume` (integer) - Transaction volume
      - `created_at` (timestamptz)
    
    - `monthly_revenue`
      - `id` (uuid, primary key)
      - `month` (date, unique) - Month (stored as first day of month)
      - `revenue` (decimal) - Total revenue
      - `orders` (integer) - Order count
      - `visitors` (integer) - Visitor count
      - `created_at` (timestamptz)
    
    - `hourly_activity`
      - `id` (uuid, primary key)
      - `date` (date) - Activity date
      - `hour` (integer) - Hour of day (0-23)
      - `users` (integer) - User count
      - `created_at` (timestamptz)
      - Unique constraint on (date, hour)
    
    - `realtime_stats`
      - `id` (uuid, primary key)
      - `online_users` (integer) - Current online users
      - `total_visitors` (integer) - Total visitors today
      - `active_now` (integer) - Active users now
      - `bounce_rate` (decimal) - Bounce rate percentage
      - `avg_session_time` (text) - Average session time
      - `timestamp` (timestamptz)

  2. Security
    - Enable RLS on all tables
    - Add policies for authenticated users to read data
    - Add policies for authenticated users to insert/update data

  3. Indexes
    - Add indexes for date-based queries
*/

-- Create daily_sales table
CREATE TABLE IF NOT EXISTS daily_sales (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  date date UNIQUE NOT NULL,
  open decimal(10,2) NOT NULL DEFAULT 0,
  high decimal(10,2) NOT NULL DEFAULT 0,
  low decimal(10,2) NOT NULL DEFAULT 0,
  close decimal(10,2) NOT NULL DEFAULT 0,
  volume integer NOT NULL DEFAULT 0,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE daily_sales ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Authenticated users can read daily sales"
  ON daily_sales FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Authenticated users can insert daily sales"
  ON daily_sales FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE POLICY "Authenticated users can update daily sales"
  ON daily_sales FOR UPDATE
  TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE INDEX IF NOT EXISTS idx_daily_sales_date ON daily_sales(date DESC);

-- Create monthly_revenue table
CREATE TABLE IF NOT EXISTS monthly_revenue (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  month date UNIQUE NOT NULL,
  revenue decimal(12,2) NOT NULL DEFAULT 0,
  orders integer NOT NULL DEFAULT 0,
  visitors integer NOT NULL DEFAULT 0,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE monthly_revenue ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Authenticated users can read monthly revenue"
  ON monthly_revenue FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Authenticated users can insert monthly revenue"
  ON monthly_revenue FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE POLICY "Authenticated users can update monthly revenue"
  ON monthly_revenue FOR UPDATE
  TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE INDEX IF NOT EXISTS idx_monthly_revenue_month ON monthly_revenue(month DESC);

-- Create hourly_activity table
CREATE TABLE IF NOT EXISTS hourly_activity (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  date date NOT NULL,
  hour integer NOT NULL CHECK (hour >= 0 AND hour <= 23),
  users integer NOT NULL DEFAULT 0,
  created_at timestamptz DEFAULT now(),
  UNIQUE(date, hour)
);

ALTER TABLE hourly_activity ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Authenticated users can read hourly activity"
  ON hourly_activity FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Authenticated users can insert hourly activity"
  ON hourly_activity FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE POLICY "Authenticated users can update hourly activity"
  ON hourly_activity FOR UPDATE
  TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE INDEX IF NOT EXISTS idx_hourly_activity_date_hour ON hourly_activity(date DESC, hour);

-- Create realtime_stats table
CREATE TABLE IF NOT EXISTS realtime_stats (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  online_users integer NOT NULL DEFAULT 0,
  total_visitors integer NOT NULL DEFAULT 0,
  active_now integer NOT NULL DEFAULT 0,
  bounce_rate decimal(5,2) NOT NULL DEFAULT 0,
  avg_session_time text NOT NULL DEFAULT '0:00',
  timestamp timestamptz DEFAULT now()
);

ALTER TABLE realtime_stats ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Authenticated users can read realtime stats"
  ON realtime_stats FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Authenticated users can insert realtime stats"
  ON realtime_stats FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE INDEX IF NOT EXISTS idx_realtime_stats_timestamp ON realtime_stats(timestamp DESC);

-- Insert sample data for daily_sales
INSERT INTO daily_sales (date, open, high, low, close, volume) VALUES
  ('2026-01-01', 12000, 15000, 11500, 14500, 850),
  ('2026-01-02', 14500, 16000, 14000, 15200, 920),
  ('2026-01-03', 15200, 15800, 14800, 14900, 780),
  ('2026-01-04', 14900, 16500, 14700, 16200, 1100),
  ('2026-01-05', 16200, 17000, 15900, 16800, 1050),
  ('2026-01-06', 16800, 17500, 16500, 17200, 980),
  ('2026-01-07', 17200, 18000, 17000, 17800, 1200)
ON CONFLICT (date) DO NOTHING;

-- Insert sample data for monthly_revenue
INSERT INTO monthly_revenue (month, revenue, orders, visitors) VALUES
  ('2025-07-01', 45000, 320, 12000),
  ('2025-08-01', 52000, 380, 15000),
  ('2025-09-01', 48000, 350, 13500),
  ('2025-10-01', 61000, 420, 18000),
  ('2025-11-01', 58000, 400, 16500),
  ('2025-12-01', 70000, 480, 20000)
ON CONFLICT (month) DO NOTHING;

-- Insert sample data for hourly_activity (today)
INSERT INTO hourly_activity (date, hour, users) VALUES
  (CURRENT_DATE, 0, 45),
  (CURRENT_DATE, 2, 32),
  (CURRENT_DATE, 4, 28),
  (CURRENT_DATE, 6, 58),
  (CURRENT_DATE, 8, 142),
  (CURRENT_DATE, 10, 258),
  (CURRENT_DATE, 12, 312),
  (CURRENT_DATE, 14, 285),
  (CURRENT_DATE, 16, 298),
  (CURRENT_DATE, 18, 345),
  (CURRENT_DATE, 20, 268),
  (CURRENT_DATE, 22, 156)
ON CONFLICT (date, hour) DO NOTHING;

-- Insert sample realtime stats
INSERT INTO realtime_stats (online_users, total_visitors, active_now, bounce_rate, avg_session_time)
VALUES (324, 12458, 324, 42.3, '3:24');