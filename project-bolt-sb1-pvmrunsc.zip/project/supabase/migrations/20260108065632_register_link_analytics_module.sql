/*
  # 注册链接统计分析模块

  ## 功能说明
  注册链接追踪和统计分析模块的路由
  1. 权限管理（超级管理员）
  2. 链接管理
  3. 统计分析

  ## 新增路由
  - /admin/analytics/permissions: 权限管理（超级管理员）
  - /admin/analytics/links: 链接追踪管理
  - /admin/analytics/dashboard: 统计分析仪表板
*/

DO $$
DECLARE
  v_module_id uuid;
BEGIN
  SELECT id INTO v_module_id FROM sys_modules WHERE module_key = 'link_analytics';

  IF v_module_id IS NULL THEN
    INSERT INTO sys_modules (
      module_key,
      module_name,
      description,
      module_version,
      category,
      icon,
      color,
      status,
      is_core,
      is_system,
      module_type
    ) VALUES (
      'link_analytics',
      '{"zh": "链接统计分析", "en": "Link Analytics"}'::jsonb,
      '{"zh": "链接追踪、访问统计和数据分析", "en": "Link tracking, visit statistics and data analysis"}'::jsonb,
      '1.0.0',
      'analytics',
      'bar-chart-3',
      'indigo',
      'enabled',
      false,
      false,
      'full'
    ) RETURNING id INTO v_module_id;
  END IF;

  IF NOT EXISTS (SELECT 1 FROM sys_module_routes WHERE route_path = '/admin/analytics/permissions') THEN
    INSERT INTO sys_module_routes (
      module_id,
      route_path,
      component_name,
      is_menu_item,
      menu_label,
      menu_icon,
      menu_order,
      requires_auth,
      required_permissions,
      is_active
    ) VALUES (
      v_module_id,
      '/admin/analytics/permissions',
      'AnalyticsPermissions',
      true,
      '{"zh": "权限管理", "en": "Permissions"}'::jsonb,
      'shield',
      200,
      true,
      '["analytics.manage_permissions"]'::jsonb,
      true
    );
  END IF;

  IF NOT EXISTS (SELECT 1 FROM sys_module_routes WHERE route_path = '/admin/analytics/links') THEN
    INSERT INTO sys_module_routes (
      module_id,
      route_path,
      component_name,
      is_menu_item,
      menu_label,
      menu_icon,
      menu_order,
      requires_auth,
      required_permissions,
      is_active
    ) VALUES (
      v_module_id,
      '/admin/analytics/links',
      'LinkTracker',
      true,
      '{"zh": "链接管理", "en": "Links"}'::jsonb,
      'link',
      201,
      true,
      '["analytics.manage_links"]'::jsonb,
      true
    );
  END IF;

  IF NOT EXISTS (SELECT 1 FROM sys_module_routes WHERE route_path = '/admin/analytics/dashboard') THEN
    INSERT INTO sys_module_routes (
      module_id,
      route_path,
      component_name,
      is_menu_item,
      menu_label,
      menu_icon,
      menu_order,
      requires_auth,
      required_permissions,
      is_active
    ) VALUES (
      v_module_id,
      '/admin/analytics/dashboard',
      'LinkAnalytics',
      true,
      '{"zh": "统计分析", "en": "Analytics"}'::jsonb,
      'bar-chart-3',
      202,
      true,
      '["analytics.view_analytics"]'::jsonb,
      true
    );
  END IF;

  RAISE NOTICE '链接统计分析模块路由已注册';
END $$;
