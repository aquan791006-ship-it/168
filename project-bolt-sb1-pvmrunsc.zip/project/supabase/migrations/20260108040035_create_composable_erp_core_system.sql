/*
  # 可组合式 ERP 核心系统架构

  ## 设计理念
  1. 模块化：每个业务功能作为独立模块
  2. 热插拔：支持运行时启用/禁用模块
  3. 数据隔离：模块数据通过命名空间隔离
  4. 标准接口：统一的模块注册和通信协议
  5. 依赖管理：自动处理模块间依赖关系

  ## 核心表结构
  1. sys_modules - 模块注册表
  2. sys_module_configs - 模块配置
  3. sys_module_routes - 模块路由
  4. sys_module_apis - 模块 API 端点
  5. sys_module_events - 模块事件总线
  6. sys_module_dependencies - 模块依赖关系
  7. sys_module_permissions - 模块权限
  8. sys_module_data_schemas - 模块数据架构

  ## 模块生命周期
  1. registered - 已注册但未安装
  2. installing - 安装中（数据库迁移）
  3. installed - 已安装但未启用
  4. enabled - 已启用运行中
  5. disabled - 已禁用
  6. error - 错误状态
*/

-- 1. 模块注册表
CREATE TABLE IF NOT EXISTS sys_modules (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  
  -- 模块标识
  module_key varchar(100) UNIQUE NOT NULL,
  module_name jsonb NOT NULL DEFAULT '{"zh": "", "en": ""}',
  module_version varchar(20) NOT NULL DEFAULT '1.0.0',
  
  -- 模块描述
  description jsonb DEFAULT '{"zh": "", "en": ""}',
  category varchar(50) NOT NULL DEFAULT 'business',
  icon varchar(50),
  color varchar(20) DEFAULT '#3B82F6',
  
  -- 状态管理
  status varchar(20) NOT NULL DEFAULT 'registered',
  is_core boolean DEFAULT false,
  is_system boolean DEFAULT false,
  
  -- 技术信息
  frontend_entry_url text,
  backend_entry_url text,
  module_type varchar(30) NOT NULL DEFAULT 'full',
  
  -- 配置
  config_schema jsonb DEFAULT '{}',
  default_config jsonb DEFAULT '{}',
  current_config jsonb DEFAULT '{}',
  
  -- 元数据
  author varchar(100),
  license varchar(50) DEFAULT 'MIT',
  repository_url text,
  documentation_url text,
  
  -- 统计
  install_count integer DEFAULT 0,
  usage_count bigint DEFAULT 0,
  last_used_at timestamptz,
  
  -- 审计字段
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  installed_at timestamptz,
  enabled_at timestamptz,
  disabled_at timestamptz,
  created_by uuid,
  
  CONSTRAINT valid_status CHECK (status IN ('registered', 'installing', 'installed', 'enabled', 'disabled', 'error')),
  CONSTRAINT valid_category CHECK (category IN ('business', 'finance', 'supply_chain', 'sales', 'hr', 'system', 'integration', 'analytics', 'other')),
  CONSTRAINT valid_module_type CHECK (module_type IN ('full', 'frontend_only', 'backend_only', 'widget', 'integration'))
);

CREATE INDEX idx_modules_status ON sys_modules(status);
CREATE INDEX idx_modules_category ON sys_modules(category);
CREATE INDEX idx_modules_key ON sys_modules(module_key);

-- 2. 模块配置表
CREATE TABLE IF NOT EXISTS sys_module_configs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  module_id uuid REFERENCES sys_modules(id) ON DELETE CASCADE,
  
  config_key varchar(100) NOT NULL,
  config_value jsonb NOT NULL,
  value_type varchar(20) NOT NULL DEFAULT 'string',
  
  is_required boolean DEFAULT false,
  is_sensitive boolean DEFAULT false,
  is_runtime_editable boolean DEFAULT true,
  
  validation_rules jsonb,
  
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  updated_by uuid,
  
  CONSTRAINT valid_value_type CHECK (value_type IN ('string', 'number', 'boolean', 'json', 'array', 'encrypted')),
  UNIQUE(module_id, config_key)
);

CREATE INDEX idx_module_configs_module ON sys_module_configs(module_id);

-- 3. 模块路由表（用于前端微前端路由注册）
CREATE TABLE IF NOT EXISTS sys_module_routes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  module_id uuid REFERENCES sys_modules(id) ON DELETE CASCADE,
  
  route_path varchar(200) NOT NULL,
  component_name varchar(100) NOT NULL,
  
  menu_label jsonb DEFAULT '{"zh": "", "en": ""}',
  menu_icon varchar(50),
  menu_order integer DEFAULT 0,
  is_menu_item boolean DEFAULT true,
  
  parent_route_id uuid REFERENCES sys_module_routes(id),
  
  requires_auth boolean DEFAULT true,
  required_permissions jsonb DEFAULT '[]',
  
  meta jsonb DEFAULT '{}',
  
  is_active boolean DEFAULT true,
  created_at timestamptz DEFAULT now(),
  
  UNIQUE(module_id, route_path)
);

CREATE INDEX idx_module_routes_module ON sys_module_routes(module_id);
CREATE INDEX idx_module_routes_path ON sys_module_routes(route_path);

-- 4. 模块 API 端点表（用于 API Gateway 路由）
CREATE TABLE IF NOT EXISTS sys_module_apis (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  module_id uuid REFERENCES sys_modules(id) ON DELETE CASCADE,
  
  api_key varchar(100) NOT NULL,
  api_path varchar(200) NOT NULL,
  http_method varchar(10) NOT NULL DEFAULT 'GET',
  
  edge_function_name varchar(100),
  handler_type varchar(30) NOT NULL DEFAULT 'edge_function',
  
  description jsonb DEFAULT '{"zh": "", "en": ""}',
  
  request_schema jsonb,
  response_schema jsonb,
  
  requires_auth boolean DEFAULT true,
  required_permissions jsonb DEFAULT '[]',
  
  rate_limit integer DEFAULT 100,
  timeout_ms integer DEFAULT 30000,
  
  is_active boolean DEFAULT true,
  created_at timestamptz DEFAULT now(),
  
  CONSTRAINT valid_method CHECK (http_method IN ('GET', 'POST', 'PUT', 'PATCH', 'DELETE')),
  CONSTRAINT valid_handler CHECK (handler_type IN ('edge_function', 'rpc', 'rest', 'graphql')),
  UNIQUE(module_id, api_key)
);

CREATE INDEX idx_module_apis_module ON sys_module_apis(module_id);
CREATE INDEX idx_module_apis_path ON sys_module_apis(api_path);

-- 5. 模块事件总线（用于模块间通信）
CREATE TABLE IF NOT EXISTS sys_module_events (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  
  event_name varchar(100) NOT NULL,
  publisher_module_id uuid REFERENCES sys_modules(id),
  
  event_data jsonb NOT NULL DEFAULT '{}',
  event_type varchar(30) NOT NULL DEFAULT 'notification',
  priority integer DEFAULT 5,
  
  status varchar(20) NOT NULL DEFAULT 'pending',
  
  published_at timestamptz DEFAULT now(),
  processed_at timestamptz,
  
  subscribers_notified jsonb DEFAULT '[]',
  
  CONSTRAINT valid_event_type CHECK (event_type IN ('notification', 'command', 'query', 'system')),
  CONSTRAINT valid_status CHECK (status IN ('pending', 'processing', 'completed', 'failed'))
);

CREATE INDEX idx_module_events_name ON sys_module_events(event_name);
CREATE INDEX idx_module_events_status ON sys_module_events(status);
CREATE INDEX idx_module_events_published ON sys_module_events(published_at);

-- 6. 模块事件订阅表
CREATE TABLE IF NOT EXISTS sys_module_event_subscriptions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  module_id uuid REFERENCES sys_modules(id) ON DELETE CASCADE,
  
  event_pattern varchar(200) NOT NULL,
  handler_function varchar(100) NOT NULL,
  
  is_active boolean DEFAULT true,
  created_at timestamptz DEFAULT now(),
  
  UNIQUE(module_id, event_pattern)
);

CREATE INDEX idx_event_subs_module ON sys_module_event_subscriptions(module_id);

-- 7. 模块依赖关系表
CREATE TABLE IF NOT EXISTS sys_module_dependencies (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  module_id uuid REFERENCES sys_modules(id) ON DELETE CASCADE,
  depends_on_module_id uuid REFERENCES sys_modules(id) ON DELETE CASCADE,
  
  dependency_type varchar(20) NOT NULL DEFAULT 'required',
  min_version varchar(20),
  
  created_at timestamptz DEFAULT now(),
  
  CONSTRAINT valid_dependency_type CHECK (dependency_type IN ('required', 'optional', 'peer')),
  CONSTRAINT no_self_dependency CHECK (module_id != depends_on_module_id),
  UNIQUE(module_id, depends_on_module_id)
);

CREATE INDEX idx_module_deps_module ON sys_module_dependencies(module_id);
CREATE INDEX idx_module_deps_depends ON sys_module_dependencies(depends_on_module_id);

-- 8. 模块权限表
CREATE TABLE IF NOT EXISTS sys_module_permissions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  module_id uuid REFERENCES sys_modules(id) ON DELETE CASCADE,
  
  permission_key varchar(100) NOT NULL,
  permission_name jsonb NOT NULL DEFAULT '{"zh": "", "en": ""}',
  description jsonb DEFAULT '{"zh": "", "en": ""}',
  
  permission_type varchar(20) NOT NULL DEFAULT 'action',
  
  created_at timestamptz DEFAULT now(),
  
  CONSTRAINT valid_permission_type CHECK (permission_type IN ('action', 'data', 'api', 'ui')),
  UNIQUE(module_id, permission_key)
);

CREATE INDEX idx_module_perms_module ON sys_module_permissions(module_id);

-- 9. 模块数据架构表（用于动态扩展）
CREATE TABLE IF NOT EXISTS sys_module_data_schemas (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  module_id uuid REFERENCES sys_modules(id) ON DELETE CASCADE,
  
  table_name varchar(100) NOT NULL,
  schema_name varchar(50) DEFAULT 'public',
  
  table_schema jsonb NOT NULL,
  indexes jsonb DEFAULT '[]',
  constraints jsonb DEFAULT '[]',
  
  migration_status varchar(20) DEFAULT 'pending',
  migration_sql text,
  migration_executed_at timestamptz,
  
  created_at timestamptz DEFAULT now(),
  
  CONSTRAINT valid_migration_status CHECK (migration_status IN ('pending', 'executing', 'completed', 'failed', 'rollback')),
  UNIQUE(module_id, table_name)
);

CREATE INDEX idx_module_schemas_module ON sys_module_data_schemas(module_id);
CREATE INDEX idx_module_schemas_status ON sys_module_data_schemas(migration_status);

-- 10. 模块安装历史
CREATE TABLE IF NOT EXISTS sys_module_install_history (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  module_id uuid REFERENCES sys_modules(id) ON DELETE CASCADE,
  
  action varchar(20) NOT NULL,
  from_version varchar(20),
  to_version varchar(20),
  
  status varchar(20) NOT NULL DEFAULT 'in_progress',
  error_message text,
  
  started_at timestamptz DEFAULT now(),
  completed_at timestamptz,
  performed_by uuid,
  
  CONSTRAINT valid_action CHECK (action IN ('install', 'uninstall', 'upgrade', 'downgrade', 'enable', 'disable')),
  CONSTRAINT valid_history_status CHECK (status IN ('in_progress', 'completed', 'failed', 'rolled_back'))
);

CREATE INDEX idx_install_history_module ON sys_module_install_history(module_id);
CREATE INDEX idx_install_history_action ON sys_module_install_history(action);

-- RLS 策略
ALTER TABLE sys_modules ENABLE ROW LEVEL SECURITY;
ALTER TABLE sys_module_configs ENABLE ROW LEVEL SECURITY;
ALTER TABLE sys_module_routes ENABLE ROW LEVEL SECURITY;
ALTER TABLE sys_module_apis ENABLE ROW LEVEL SECURITY;
ALTER TABLE sys_module_events ENABLE ROW LEVEL SECURITY;
ALTER TABLE sys_module_event_subscriptions ENABLE ROW LEVEL SECURITY;
ALTER TABLE sys_module_dependencies ENABLE ROW LEVEL SECURITY;
ALTER TABLE sys_module_permissions ENABLE ROW LEVEL SECURITY;
ALTER TABLE sys_module_data_schemas ENABLE ROW LEVEL SECURITY;
ALTER TABLE sys_module_install_history ENABLE ROW LEVEL SECURITY;

-- 管理员可以查看所有模块
CREATE POLICY "Admins can view all modules"
  ON sys_modules FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Admins can manage modules"
  ON sys_modules FOR ALL
  TO authenticated
  USING (true)
  WITH CHECK (true);

-- 其他表类似策略
CREATE POLICY "Admins can view module configs"
  ON sys_module_configs FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Admins can manage module configs"
  ON sys_module_configs FOR ALL
  TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Anyone can view active routes"
  ON sys_module_routes FOR SELECT
  TO authenticated
  USING (is_active = true);

CREATE POLICY "Admins can manage routes"
  ON sys_module_routes FOR ALL
  TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Anyone can view active APIs"
  ON sys_module_apis FOR SELECT
  TO authenticated
  USING (is_active = true);

CREATE POLICY "Admins can manage APIs"
  ON sys_module_apis FOR ALL
  TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Modules can publish events"
  ON sys_module_events FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE POLICY "Anyone can view events"
  ON sys_module_events FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "System can update events"
  ON sys_module_events FOR UPDATE
  TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Anyone can view subscriptions"
  ON sys_module_event_subscriptions FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Admins can manage subscriptions"
  ON sys_module_event_subscriptions FOR ALL
  TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Anyone can view dependencies"
  ON sys_module_dependencies FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Anyone can view permissions"
  ON sys_module_permissions FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Anyone can view data schemas"
  ON sys_module_data_schemas FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Admins can manage data schemas"
  ON sys_module_data_schemas FOR ALL
  TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Anyone can view install history"
  ON sys_module_install_history FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "System can record install history"
  ON sys_module_install_history FOR INSERT
  TO authenticated
  WITH CHECK (true);
