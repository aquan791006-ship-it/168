/*
  # 创建弹窗公告系统

  ## 新增表
  - sys_announcements: 系统弹窗公告表
  
  ## 功能说明
  1. 支持文字和图片公告
  2. 支持超链接
  3. 可设置显示条件和时间
  4. 支持多域名隔离
  5. 可控制显示频率
*/

CREATE TABLE IF NOT EXISTS sys_announcements (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  domain_id uuid REFERENCES sys_domains(id) ON DELETE CASCADE,
  title varchar(200) NOT NULL,
  content text,
  announcement_type varchar(50) DEFAULT 'text',
  image_url text,
  link_url text,
  link_text varchar(100),
  button_text varchar(50) DEFAULT '我知道了',
  button_color varchar(50) DEFAULT 'blue',
  display_position varchar(50) DEFAULT 'center',
  display_frequency varchar(50) DEFAULT 'once',
  priority integer DEFAULT 0,
  target_audience varchar(50) DEFAULT 'all',
  is_active boolean DEFAULT true,
  start_date timestamptz DEFAULT now(),
  end_date timestamptz,
  max_display_count integer,
  current_display_count integer DEFAULT 0,
  click_count integer DEFAULT 0,
  close_count integer DEFAULT 0,
  created_by uuid,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  CONSTRAINT valid_type CHECK (
    announcement_type IN ('text', 'image', 'text_with_image', 'html')
  ),
  CONSTRAINT valid_position CHECK (
    display_position IN ('center', 'top', 'bottom', 'top-right', 'top-left')
  ),
  CONSTRAINT valid_frequency CHECK (
    display_frequency IN ('once', 'daily', 'always', 'session')
  ),
  CONSTRAINT valid_audience CHECK (
    target_audience IN ('all', 'admin_only', 'customer_only', 'new_users')
  )
);

CREATE INDEX idx_announcements_domain ON sys_announcements(domain_id);
CREATE INDEX idx_announcements_active ON sys_announcements(is_active, start_date, end_date) 
  WHERE is_active = true;
CREATE INDEX idx_announcements_priority ON sys_announcements(priority DESC);

ALTER TABLE sys_announcements ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users manage domain announcements"
  ON sys_announcements FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM sys_admin_domains
      WHERE admin_id = auth.uid() AND domain_id = sys_announcements.domain_id
    )
  );

CREATE POLICY "Public view active announcements"
  ON sys_announcements FOR SELECT
  TO anon
  USING (
    is_active = true 
    AND start_date <= now() 
    AND (end_date IS NULL OR end_date >= now())
  );

CREATE TABLE IF NOT EXISTS sys_announcement_views (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  announcement_id uuid REFERENCES sys_announcements(id) ON DELETE CASCADE,
  viewer_id uuid,
  viewer_ip varchar(50),
  viewer_type varchar(50),
  action_type varchar(50) NOT NULL,
  viewed_at timestamptz DEFAULT now(),
  CONSTRAINT valid_action CHECK (
    action_type IN ('view', 'click', 'close', 'ignore')
  )
);

CREATE INDEX idx_announcement_views_announcement ON sys_announcement_views(announcement_id);
CREATE INDEX idx_announcement_views_viewer ON sys_announcement_views(viewer_id) 
  WHERE viewer_id IS NOT NULL;

ALTER TABLE sys_announcement_views ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users view domain announcement stats"
  ON sys_announcement_views FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM sys_announcements a
      JOIN sys_admin_domains ad ON a.domain_id = ad.domain_id
      WHERE a.id = sys_announcement_views.announcement_id
      AND ad.admin_id = auth.uid()
    )
  );

CREATE OR REPLACE FUNCTION get_active_announcements(
  p_domain_id uuid DEFAULT NULL,
  p_viewer_id uuid DEFAULT NULL,
  p_viewer_type varchar DEFAULT 'customer'
)
RETURNS TABLE (
  id uuid,
  title varchar,
  content text,
  announcement_type varchar,
  image_url text,
  link_url text,
  link_text varchar,
  button_text varchar,
  button_color varchar,
  display_position varchar,
  priority integer
)
LANGUAGE plpgsql
AS $$
BEGIN
  RETURN QUERY
  SELECT 
    a.id,
    a.title,
    a.content,
    a.announcement_type,
    a.image_url,
    a.link_url,
    a.link_text,
    a.button_text,
    a.button_color,
    a.display_position,
    a.priority
  FROM sys_announcements a
  WHERE 
    (p_domain_id IS NULL OR a.domain_id = p_domain_id)
    AND a.is_active = true
    AND a.start_date <= now()
    AND (a.end_date IS NULL OR a.end_date >= now())
    AND (a.max_display_count IS NULL OR a.current_display_count < a.max_display_count)
    AND (
      a.target_audience = 'all'
      OR (a.target_audience = 'admin_only' AND p_viewer_type = 'admin')
      OR (a.target_audience = 'customer_only' AND p_viewer_type = 'customer')
    )
    AND (
      a.display_frequency = 'always'
      OR (
        a.display_frequency = 'once' 
        AND NOT EXISTS (
          SELECT 1 FROM sys_announcement_views
          WHERE announcement_id = a.id
          AND (viewer_id = p_viewer_id OR viewer_ip IS NOT NULL)
          AND action_type IN ('view', 'close')
        )
      )
      OR (
        a.display_frequency = 'daily'
        AND NOT EXISTS (
          SELECT 1 FROM sys_announcement_views
          WHERE announcement_id = a.id
          AND (viewer_id = p_viewer_id OR viewer_ip IS NOT NULL)
          AND action_type IN ('view', 'close')
          AND viewed_at >= CURRENT_DATE
        )
      )
    )
  ORDER BY a.priority DESC, a.created_at DESC
  LIMIT 1;
END;
$$;

CREATE OR REPLACE FUNCTION record_announcement_action(
  p_announcement_id uuid,
  p_viewer_id uuid DEFAULT NULL,
  p_viewer_ip varchar DEFAULT NULL,
  p_viewer_type varchar DEFAULT 'customer',
  p_action_type varchar DEFAULT 'view'
)
RETURNS jsonb
LANGUAGE plpgsql
AS $$
DECLARE
  v_view_id uuid;
BEGIN
  INSERT INTO sys_announcement_views (
    announcement_id, viewer_id, viewer_ip, viewer_type, action_type
  ) VALUES (
    p_announcement_id, p_viewer_id, p_viewer_ip, p_viewer_type, p_action_type
  ) RETURNING id INTO v_view_id;
  
  IF p_action_type = 'view' THEN
    UPDATE sys_announcements
    SET current_display_count = current_display_count + 1
    WHERE id = p_announcement_id;
  ELSIF p_action_type = 'click' THEN
    UPDATE sys_announcements
    SET click_count = click_count + 1
    WHERE id = p_announcement_id;
  ELSIF p_action_type = 'close' THEN
    UPDATE sys_announcements
    SET close_count = close_count + 1
    WHERE id = p_announcement_id;
  END IF;
  
  RETURN jsonb_build_object(
    'success', true,
    'view_id', v_view_id,
    'action', p_action_type,
    'timestamp', now()
  );
END;
$$;

CREATE OR REPLACE FUNCTION get_announcement_statistics(
  p_domain_id uuid
)
RETURNS jsonb
LANGUAGE plpgsql
AS $$
DECLARE
  v_result jsonb;
  v_total_active integer;
  v_total_views integer;
  v_total_clicks integer;
BEGIN
  SELECT 
    COUNT(*) FILTER (WHERE is_active = true) as active_count,
    SUM(current_display_count) as total_views,
    SUM(click_count) as total_clicks
  INTO v_total_active, v_total_views, v_total_clicks
  FROM sys_announcements
  WHERE domain_id = p_domain_id;
  
  v_result := jsonb_build_object(
    'total_active_announcements', COALESCE(v_total_active, 0),
    'total_views', COALESCE(v_total_views, 0),
    'total_clicks', COALESCE(v_total_clicks, 0),
    'click_through_rate', CASE 
      WHEN v_total_views > 0 THEN 
        ROUND((v_total_clicks::numeric / v_total_views * 100), 2)
      ELSE 0
    END,
    'timestamp', now()
  );
  
  RETURN v_result;
END;
$$;

COMMENT ON TABLE sys_announcements IS '系统弹窗公告表';
COMMENT ON TABLE sys_announcement_views IS '公告浏览记录表';
COMMENT ON FUNCTION get_active_announcements IS '获取当前活跃的弹窗公告';
COMMENT ON FUNCTION record_announcement_action IS '记录用户对公告的操作';
COMMENT ON FUNCTION get_announcement_statistics IS '获取公告统计数据';
