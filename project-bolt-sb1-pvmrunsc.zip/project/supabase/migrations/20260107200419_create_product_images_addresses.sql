/*
  # 产品图片和地址管理

  1. 新增表
    - `product_images` - 产品图片管理
      - `id` (uuid, primary key)
      - `product_id` (uuid, foreign key)
      - `image_type` (text) - 图片类型：main(主图), module(模块图), detail(详情图)
      - `image_url` (text) - 图片URL
      - `link_url` (text, nullable) - 模块图可添加跳转链接
      - `sort_order` (integer) - 排序顺序
      - `created_at` (timestamptz)
    
    - `china_addresses` - 中国地址库
      - `id` (uuid, primary key)
      - `code` (text) - 行政区划代码
      - `name` (text) - 地区名称
      - `level` (text) - 级别：province(省), city(市), district(区/县), street(街道)
      - `parent_code` (text, nullable) - 父级代码
      - `sort_order` (integer) - 排序
      - `is_active` (boolean) - 是否启用

  2. 安全性
    - 启用所有表的RLS
    - 添加认证管理员的访问策略
*/

-- 创建产品图片表
CREATE TABLE IF NOT EXISTS product_images (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  product_id uuid NOT NULL REFERENCES products(id) ON DELETE CASCADE,
  image_type text NOT NULL CHECK (image_type IN ('main', 'module', 'detail')),
  image_url text NOT NULL,
  link_url text,
  sort_order integer DEFAULT 0,
  created_at timestamptz DEFAULT now()
);

-- 创建中国地址库表
CREATE TABLE IF NOT EXISTS china_addresses (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  code text NOT NULL UNIQUE,
  name text NOT NULL,
  level text NOT NULL CHECK (level IN ('province', 'city', 'district', 'street')),
  parent_code text,
  sort_order integer DEFAULT 0,
  is_active boolean DEFAULT true,
  created_at timestamptz DEFAULT now()
);

-- 创建索引
CREATE INDEX IF NOT EXISTS idx_product_images_product_id ON product_images(product_id);
CREATE INDEX IF NOT EXISTS idx_product_images_type ON product_images(image_type);
CREATE INDEX IF NOT EXISTS idx_china_addresses_parent ON china_addresses(parent_code);
CREATE INDEX IF NOT EXISTS idx_china_addresses_level ON china_addresses(level);
CREATE INDEX IF NOT EXISTS idx_china_addresses_code ON china_addresses(code);

-- 启用RLS
ALTER TABLE product_images ENABLE ROW LEVEL SECURITY;
ALTER TABLE china_addresses ENABLE ROW LEVEL SECURITY;

-- 产品图片策略
CREATE POLICY "管理员可查看产品图片"
  ON product_images FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "管理员可添加产品图片"
  ON product_images FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE POLICY "管理员可更新产品图片"
  ON product_images FOR UPDATE
  TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "管理员可删除产品图片"
  ON product_images FOR DELETE
  TO authenticated
  USING (true);

-- 地址库策略（只读）
CREATE POLICY "管理员可查看地址库"
  ON china_addresses FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "管理员可管理地址库"
  ON china_addresses FOR ALL
  TO authenticated
  USING (true)
  WITH CHECK (true);

-- 插入一些基础省份数据
INSERT INTO china_addresses (code, name, level, parent_code, sort_order) VALUES
  ('110000', '北京市', 'province', NULL, 1),
  ('120000', '天津市', 'province', NULL, 2),
  ('310000', '上海市', 'province', NULL, 3),
  ('500000', '重庆市', 'province', NULL, 4),
  ('440000', '广东省', 'province', NULL, 5),
  ('330000', '浙江省', 'province', NULL, 6),
  ('320000', '江苏省', 'province', NULL, 7),
  ('510000', '四川省', 'province', NULL, 8),
  ('420000', '湖北省', 'province', NULL, 9),
  ('430000', '湖南省', 'province', NULL, 10)
ON CONFLICT (code) DO NOTHING;

-- 插入广东省的市级数据
INSERT INTO china_addresses (code, name, level, parent_code, sort_order) VALUES
  ('440100', '广州市', 'city', '440000', 1),
  ('440300', '深圳市', 'city', '440000', 2),
  ('440400', '珠海市', 'city', '440000', 3),
  ('440600', '佛山市', 'city', '440000', 4),
  ('441900', '东莞市', 'city', '440000', 5)
ON CONFLICT (code) DO NOTHING;

-- 插入广州市的区级数据
INSERT INTO china_addresses (code, name, level, parent_code, sort_order) VALUES
  ('440103', '荔湾区', 'district', '440100', 1),
  ('440104', '越秀区', 'district', '440100', 2),
  ('440105', '海珠区', 'district', '440100', 3),
  ('440106', '天河区', 'district', '440100', 4),
  ('440111', '白云区', 'district', '440100', 5),
  ('440113', '番禺区', 'district', '440100', 6)
ON CONFLICT (code) DO NOTHING;