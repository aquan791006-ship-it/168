/*
  # Update Admin Login Function

  1. Changes
    - Remove reference to non-existent `deleted_at` column
    - Function now only checks email and status fields that exist in the table
    - Maintains all security checks and password verification

  2. Security
    - Function remains publicly accessible for login purposes
    - Password verification using crypt extension
    - Returns sanitized admin data without password hash
*/

CREATE OR REPLACE FUNCTION admin_login(
  p_email TEXT,
  p_password TEXT
)
RETURNS JSON
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  v_admin RECORD;
  v_result JSON;
BEGIN
  SELECT * INTO v_admin
  FROM admins
  WHERE email = p_email
  AND (status = 'active' OR status IS NULL);

  IF NOT FOUND THEN
    RETURN json_build_object(
      'success', false,
      'message', 'Invalid email or password'
    );
  END IF;

  IF v_admin.password_hash = crypt(p_password, v_admin.password_hash) THEN
    v_result := json_build_object(
      'success', true,
      'message', 'Login successful',
      'admin', json_build_object(
        'id', v_admin.id,
        'email', v_admin.email,
        'full_name', v_admin.full_name,
        'is_super_admin', v_admin.is_super_admin,
        'status', v_admin.status,
        'permissions', v_admin.permissions,
        'department_id', v_admin.department_id,
        'admin_type', v_admin.admin_type
      )
    );
    
    RETURN v_result;
  ELSE
    RETURN json_build_object(
      'success', false,
      'message', 'Invalid email or password'
    );
  END IF;
END;
$$;