/*
  # 创建链接统计追踪系统

  ## 功能说明
  提供完整的链接追踪和访问统计功能，支持：
  1. 商城商品链接统计
  2. 整站链接统计
  3. 外部网站链接统计
  4. 访问来源分析（IP、设备、浏览器、地理位置）
  5. 实时访问数据
  6. 权限控制（超级管理员决定谁可以使用）

  ## 新增表
  1. sys_analytics_permissions - 统计权限表
  2. sys_tracked_links - 追踪链接表
  3. sys_link_visits - 访问记录表
  4. sys_link_analytics - 统计汇总表

  ## 安全措施
  - 启用 RLS
  - 权限检查函数
  - 数据隔离
*/

-- ============================================
-- 统计权限表
-- ============================================

CREATE TABLE IF NOT EXISTS sys_analytics_permissions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  domain_id uuid REFERENCES sys_domains(id) ON DELETE CASCADE,
  admin_id uuid REFERENCES sys_admins(id) ON DELETE CASCADE,
  can_view_analytics boolean DEFAULT false,
  can_create_links boolean DEFAULT false,
  can_manage_links boolean DEFAULT false,
  can_export_data boolean DEFAULT false,
  granted_by uuid REFERENCES sys_admins(id),
  granted_at timestamptz DEFAULT now(),
  expires_at timestamptz,
  notes text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  UNIQUE(domain_id, admin_id)
);

ALTER TABLE sys_analytics_permissions ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Admins can view own analytics permissions"
  ON sys_analytics_permissions FOR SELECT
  TO authenticated
  USING (
    admin_id = auth.uid() OR
    EXISTS (SELECT 1 FROM sys_admins WHERE id = auth.uid() AND is_super_admin = true)
  );

CREATE POLICY "Super admins can manage analytics permissions"
  ON sys_analytics_permissions FOR ALL
  TO authenticated
  USING (
    EXISTS (SELECT 1 FROM sys_admins WHERE id = auth.uid() AND is_super_admin = true)
  )
  WITH CHECK (
    EXISTS (SELECT 1 FROM sys_admins WHERE id = auth.uid() AND is_super_admin = true)
  );

COMMENT ON TABLE sys_analytics_permissions IS '统计分析权限表，由超级管理员分配';

-- ============================================
-- 追踪链接表
-- ============================================

CREATE TABLE IF NOT EXISTS sys_tracked_links (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  domain_id uuid REFERENCES sys_domains(id) ON DELETE CASCADE,
  short_code varchar(20) UNIQUE NOT NULL,
  original_url text NOT NULL,
  link_type varchar(50) NOT NULL DEFAULT 'external',
  link_category varchar(100),
  title varchar(255),
  description text,
  product_id uuid REFERENCES sys_products(id) ON DELETE SET NULL,
  campaign_name varchar(255),
  utm_source varchar(255),
  utm_medium varchar(255),
  utm_campaign varchar(255),
  utm_term varchar(255),
  utm_content varchar(255),
  custom_params jsonb DEFAULT '{}'::jsonb,
  is_active boolean DEFAULT true,
  click_count bigint DEFAULT 0,
  unique_click_count bigint DEFAULT 0,
  last_clicked_at timestamptz,
  expires_at timestamptz,
  created_by uuid REFERENCES sys_admins(id),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  CONSTRAINT valid_link_type CHECK (
    link_type IN ('product', 'category', 'page', 'external', 'campaign', 'promotion')
  )
);

CREATE INDEX idx_tracked_links_domain ON sys_tracked_links(domain_id);
CREATE INDEX idx_tracked_links_short_code ON sys_tracked_links(short_code);
CREATE INDEX idx_tracked_links_product ON sys_tracked_links(product_id);
CREATE INDEX idx_tracked_links_type ON sys_tracked_links(link_type);
CREATE INDEX idx_tracked_links_created ON sys_tracked_links(created_at DESC);

ALTER TABLE sys_tracked_links ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users with analytics permission can view tracked links"
  ON sys_tracked_links FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM sys_analytics_permissions
      WHERE domain_id = sys_tracked_links.domain_id
      AND admin_id = auth.uid()
      AND can_view_analytics = true
    ) OR
    EXISTS (SELECT 1 FROM sys_admins WHERE id = auth.uid() AND is_super_admin = true)
  );

CREATE POLICY "Users with permission can create tracked links"
  ON sys_tracked_links FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM sys_analytics_permissions
      WHERE domain_id = sys_tracked_links.domain_id
      AND admin_id = auth.uid()
      AND can_create_links = true
    ) OR
    EXISTS (SELECT 1 FROM sys_admins WHERE id = auth.uid() AND is_super_admin = true)
  );

CREATE POLICY "Users with permission can manage tracked links"
  ON sys_tracked_links FOR UPDATE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM sys_analytics_permissions
      WHERE domain_id = sys_tracked_links.domain_id
      AND admin_id = auth.uid()
      AND can_manage_links = true
    ) OR
    EXISTS (SELECT 1 FROM sys_admins WHERE id = auth.uid() AND is_super_admin = true)
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM sys_analytics_permissions
      WHERE domain_id = sys_tracked_links.domain_id
      AND admin_id = auth.uid()
      AND can_manage_links = true
    ) OR
    EXISTS (SELECT 1 FROM sys_admins WHERE id = auth.uid() AND is_super_admin = true)
  );

CREATE POLICY "Users with permission can delete tracked links"
  ON sys_tracked_links FOR DELETE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM sys_analytics_permissions
      WHERE domain_id = sys_tracked_links.domain_id
      AND admin_id = auth.uid()
      AND can_manage_links = true
    ) OR
    EXISTS (SELECT 1 FROM sys_admins WHERE id = auth.uid() AND is_super_admin = true)
  );

COMMENT ON TABLE sys_tracked_links IS '追踪链接表，支持商品、整站、外部链接统计';

-- ============================================
-- 访问记录表
-- ============================================

CREATE TABLE IF NOT EXISTS sys_link_visits (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  link_id uuid REFERENCES sys_tracked_links(id) ON DELETE CASCADE NOT NULL,
  domain_id uuid REFERENCES sys_domains(id) ON DELETE CASCADE,
  visitor_ip inet,
  visitor_country varchar(100),
  visitor_city varchar(100),
  visitor_region varchar(100),
  user_agent text,
  device_type varchar(50),
  browser varchar(100),
  browser_version varchar(50),
  os varchar(100),
  os_version varchar(50),
  referrer text,
  referrer_domain varchar(255),
  landing_page text,
  utm_source varchar(255),
  utm_medium varchar(255),
  utm_campaign varchar(255),
  session_id uuid,
  is_unique_visit boolean DEFAULT true,
  visit_duration_seconds integer,
  pages_viewed integer DEFAULT 1,
  converted boolean DEFAULT false,
  conversion_value decimal(15,2),
  custom_data jsonb DEFAULT '{}'::jsonb,
  visited_at timestamptz DEFAULT now(),
  CONSTRAINT valid_device_type CHECK (
    device_type IS NULL OR device_type IN ('desktop', 'mobile', 'tablet', 'bot', 'other')
  )
);

CREATE INDEX idx_link_visits_link ON sys_link_visits(link_id);
CREATE INDEX idx_link_visits_domain ON sys_link_visits(domain_id);
CREATE INDEX idx_link_visits_date ON sys_link_visits(visited_at DESC);
CREATE INDEX idx_link_visits_country ON sys_link_visits(visitor_country);
CREATE INDEX idx_link_visits_device ON sys_link_visits(device_type);
CREATE INDEX idx_link_visits_referrer ON sys_link_visits(referrer_domain);
CREATE INDEX idx_link_visits_session ON sys_link_visits(session_id);

ALTER TABLE sys_link_visits ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users with analytics permission can view visits"
  ON sys_link_visits FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM sys_analytics_permissions
      WHERE domain_id = sys_link_visits.domain_id
      AND admin_id = auth.uid()
      AND can_view_analytics = true
    ) OR
    EXISTS (SELECT 1 FROM sys_admins WHERE id = auth.uid() AND is_super_admin = true)
  );

COMMENT ON TABLE sys_link_visits IS '访问记录表，记录每次链接点击的详细信息';

-- ============================================
-- 统计汇总表（按天）
-- ============================================

CREATE TABLE IF NOT EXISTS sys_link_analytics (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  link_id uuid REFERENCES sys_tracked_links(id) ON DELETE CASCADE NOT NULL,
  domain_id uuid REFERENCES sys_domains(id) ON DELETE CASCADE,
  date date NOT NULL,
  total_clicks bigint DEFAULT 0,
  unique_clicks bigint DEFAULT 0,
  mobile_clicks bigint DEFAULT 0,
  desktop_clicks bigint DEFAULT 0,
  tablet_clicks bigint DEFAULT 0,
  top_countries jsonb DEFAULT '[]'::jsonb,
  top_referrers jsonb DEFAULT '[]'::jsonb,
  top_browsers jsonb DEFAULT '[]'::jsonb,
  top_devices jsonb DEFAULT '[]'::jsonb,
  conversion_count integer DEFAULT 0,
  conversion_rate decimal(5,2),
  total_conversion_value decimal(15,2),
  avg_visit_duration integer,
  bounce_rate decimal(5,2),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  UNIQUE(link_id, date)
);

CREATE INDEX idx_link_analytics_link ON sys_link_analytics(link_id);
CREATE INDEX idx_link_analytics_domain ON sys_link_analytics(domain_id);
CREATE INDEX idx_link_analytics_date ON sys_link_analytics(date DESC);

ALTER TABLE sys_link_analytics ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users with analytics permission can view analytics"
  ON sys_link_analytics FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM sys_analytics_permissions
      WHERE domain_id = sys_link_analytics.domain_id
      AND admin_id = auth.uid()
      AND can_view_analytics = true
    ) OR
    EXISTS (SELECT 1 FROM sys_admins WHERE id = auth.uid() AND is_super_admin = true)
  );

COMMENT ON TABLE sys_link_analytics IS '链接统计汇总表，按天聚合数据';

-- ============================================
-- 辅助函数
-- ============================================

-- 生成短链接代码
CREATE OR REPLACE FUNCTION generate_short_code()
RETURNS text
LANGUAGE plpgsql
AS $$
DECLARE
  characters text := 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
  short_code text := '';
  i integer;
  code_exists boolean;
BEGIN
  LOOP
    short_code := '';
    FOR i IN 1..8 LOOP
      short_code := short_code || substr(characters, floor(random() * length(characters) + 1)::integer, 1);
    END LOOP;
    
    SELECT EXISTS(SELECT 1 FROM sys_tracked_links WHERE sys_tracked_links.short_code = short_code) INTO code_exists;
    
    IF NOT code_exists THEN
      EXIT;
    END IF;
  END LOOP;
  
  RETURN short_code;
END;
$$;

-- 检查用户统计权限
CREATE OR REPLACE FUNCTION check_analytics_permission(
  p_domain_id uuid,
  p_admin_id uuid,
  p_permission_type text
)
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  v_has_permission boolean := false;
  v_is_super_admin boolean := false;
BEGIN
  SELECT is_super_admin INTO v_is_super_admin
  FROM sys_admins
  WHERE id = p_admin_id;
  
  IF v_is_super_admin THEN
    RETURN true;
  END IF;
  
  CASE p_permission_type
    WHEN 'view' THEN
      SELECT can_view_analytics INTO v_has_permission
      FROM sys_analytics_permissions
      WHERE domain_id = p_domain_id
      AND admin_id = p_admin_id
      AND (expires_at IS NULL OR expires_at > now());
      
    WHEN 'create' THEN
      SELECT can_create_links INTO v_has_permission
      FROM sys_analytics_permissions
      WHERE domain_id = p_domain_id
      AND admin_id = p_admin_id
      AND (expires_at IS NULL OR expires_at > now());
      
    WHEN 'manage' THEN
      SELECT can_manage_links INTO v_has_permission
      FROM sys_analytics_permissions
      WHERE domain_id = p_domain_id
      AND admin_id = p_admin_id
      AND (expires_at IS NULL OR expires_at > now());
      
    WHEN 'export' THEN
      SELECT can_export_data INTO v_has_permission
      FROM sys_analytics_permissions
      WHERE domain_id = p_domain_id
      AND admin_id = p_admin_id
      AND (expires_at IS NULL OR expires_at > now());
  END CASE;
  
  RETURN COALESCE(v_has_permission, false);
END;
$$;

-- 记录访问（用于Edge Function调用）
CREATE OR REPLACE FUNCTION record_link_visit(
  p_short_code text,
  p_visitor_ip inet,
  p_user_agent text,
  p_referrer text DEFAULT NULL,
  p_custom_data jsonb DEFAULT '{}'::jsonb
)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  v_link sys_tracked_links;
  v_visit_id uuid;
  v_is_unique boolean;
BEGIN
  SELECT * INTO v_link
  FROM sys_tracked_links
  WHERE short_code = p_short_code
  AND is_active = true
  AND (expires_at IS NULL OR expires_at > now());
  
  IF NOT FOUND THEN
    RETURN jsonb_build_object(
      'success', false,
      'error', 'Link not found or expired'
    );
  END IF;
  
  SELECT NOT EXISTS (
    SELECT 1 FROM sys_link_visits
    WHERE link_id = v_link.id
    AND visitor_ip = p_visitor_ip
    AND visited_at > now() - interval '24 hours'
  ) INTO v_is_unique;
  
  INSERT INTO sys_link_visits (
    link_id,
    domain_id,
    visitor_ip,
    user_agent,
    referrer,
    is_unique_visit,
    custom_data
  ) VALUES (
    v_link.id,
    v_link.domain_id,
    p_visitor_ip,
    p_user_agent,
    p_referrer,
    v_is_unique,
    p_custom_data
  ) RETURNING id INTO v_visit_id;
  
  UPDATE sys_tracked_links
  SET 
    click_count = click_count + 1,
    unique_click_count = unique_click_count + CASE WHEN v_is_unique THEN 1 ELSE 0 END,
    last_clicked_at = now()
  WHERE id = v_link.id;
  
  RETURN jsonb_build_object(
    'success', true,
    'visit_id', v_visit_id,
    'redirect_url', v_link.original_url
  );
END;
$$;

COMMENT ON FUNCTION check_analytics_permission IS '检查用户是否有统计分析权限';
COMMENT ON FUNCTION record_link_visit IS '记录链接访问，返回重定向URL';
