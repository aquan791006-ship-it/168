/*
  # 仓储系统增强

  ## 新增表
  1. `wms_inventory_transactions` - 库存流水记录表
     - 记录所有库存变动明细
     - 支持审计和追溯
  
  ## 增强现有表
  - `wms_stock_alerts` - 添加自动补货相关字段
  - `wms_outbound` - 添加自动创建和拣货员分配字段

  ## 核心功能
  1. 库存预警与自动补货触发
  2. 库存流水完整记录
  3. 订单自动创建出库单
  4. 自动分配拣货员

  ## 安全性
  - 所有表启用RLS
  - 库存变动需要管理员权限
*/

-- 库存流水记录表
CREATE TABLE IF NOT EXISTS wms_inventory_transactions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  inventory_id uuid REFERENCES wms_inventory(id) ON DELETE CASCADE,
  transaction_type text NOT NULL CHECK (transaction_type IN 
    ('inbound', 'outbound', 'adjustment', 'transfer', 'lock', 'unlock', 'return')
  ),
  
  -- 关联单据
  related_type text,
  related_id uuid,
  related_code text,
  
  -- 数量变化
  quantity_change integer NOT NULL,
  quantity_before integer NOT NULL,
  quantity_after integer NOT NULL,
  
  -- 锁定数量变化（如果适用）
  locked_change integer DEFAULT 0,
  locked_before integer DEFAULT 0,
  locked_after integer DEFAULT 0,
  
  -- 操作信息
  operator_id uuid REFERENCES sys_admins(id),
  notes text,
  metadata jsonb DEFAULT '{}'::jsonb,
  
  created_at timestamptz DEFAULT now()
);

-- 增强库存预警表
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'wms_stock_alerts' AND column_name = 'auto_replenish'
  ) THEN
    ALTER TABLE wms_stock_alerts ADD COLUMN auto_replenish boolean DEFAULT false;
  END IF;
  
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'wms_stock_alerts' AND column_name = 'replenish_quantity'
  ) THEN
    ALTER TABLE wms_stock_alerts ADD COLUMN replenish_quantity integer;
  END IF;
  
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'wms_stock_alerts' AND column_name = 'replenish_triggered'
  ) THEN
    ALTER TABLE wms_stock_alerts ADD COLUMN replenish_triggered boolean DEFAULT false;
  END IF;
  
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'wms_stock_alerts' AND column_name = 'triggered_purchase_order_id'
  ) THEN
    ALTER TABLE wms_stock_alerts ADD COLUMN triggered_purchase_order_id uuid REFERENCES pur_purchase_orders(id);
  END IF;
END $$;

-- 增强出库单表
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'wms_outbound' AND column_name = 'auto_created'
  ) THEN
    ALTER TABLE wms_outbound ADD COLUMN auto_created boolean DEFAULT false;
  END IF;
  
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'wms_outbound' AND column_name = 'auto_assign_picker'
  ) THEN
    ALTER TABLE wms_outbound ADD COLUMN auto_assign_picker boolean DEFAULT true;
  END IF;
  
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'wms_outbound' AND column_name = 'picker_assigned_at'
  ) THEN
    ALTER TABLE wms_outbound ADD COLUMN picker_assigned_at timestamptz;
  END IF;
END $$;

-- 启用RLS
ALTER TABLE wms_inventory_transactions ENABLE ROW LEVEL SECURITY;

-- RLS策略：管理员可查看库存流水
CREATE POLICY "Admins can view inventory transactions"
  ON wms_inventory_transactions FOR SELECT TO authenticated
  USING (
    EXISTS (SELECT 1 FROM sys_admins WHERE id = auth.uid())
  );

-- RLS策略：管理员可创建库存流水
CREATE POLICY "Admins can create inventory transactions"
  ON wms_inventory_transactions FOR INSERT TO authenticated
  WITH CHECK (
    EXISTS (SELECT 1 FROM sys_admins WHERE id = auth.uid())
  );

-- 创建索引
CREATE INDEX IF NOT EXISTS idx_inventory_transactions_inventory ON wms_inventory_transactions(inventory_id);
CREATE INDEX IF NOT EXISTS idx_inventory_transactions_type ON wms_inventory_transactions(transaction_type);
CREATE INDEX IF NOT EXISTS idx_inventory_transactions_created ON wms_inventory_transactions(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_inventory_transactions_related ON wms_inventory_transactions(related_type, related_id);
CREATE INDEX IF NOT EXISTS idx_stock_alerts_triggered ON wms_stock_alerts(replenish_triggered) WHERE replenish_triggered = false;
CREATE INDEX IF NOT EXISTS idx_outbound_auto_created ON wms_outbound(auto_created) WHERE auto_created = true;
