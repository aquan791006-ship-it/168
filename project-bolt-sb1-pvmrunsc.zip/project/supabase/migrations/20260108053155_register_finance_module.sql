/*
  # 注册财务管理模块

  ## 功能说明
  将财务管理模块注册到系统模块管理中，使其可以通过模块管理系统进行启用/禁用。

  ## 模块信息
  - 模块名称：财务管理
  - 模块标识：finance
  - 功能描述：安全智能的财务数据管理与分析系统
*/

DO $$
DECLARE
  v_module_id uuid;
BEGIN
  -- 注册财务管理模块
  INSERT INTO sys_modules (
    module_key,
    module_name,
    description,
    icon,
    category,
    module_version,
    is_core,
    status,
    module_type
  ) VALUES (
    'finance',
    jsonb_build_object(
      'zh', '财务管理',
      'en', 'Finance Management'
    ),
    jsonb_build_object(
      'zh', '安全智能高效的财务管理系统，支持多账户管理、收支记录、发票管理、预算控制、自动对账和财务分析',
      'en', 'Secure and intelligent financial management system with multi-account management, transaction tracking, invoice management, budget control, auto-reconciliation and financial analysis'
    ),
    'Wallet',
    'business',
    '1.0.0',
    false,
    'enabled',
    'frontend_only'
  )
  ON CONFLICT (module_key) DO UPDATE SET
    status = 'enabled',
    updated_at = now()
  RETURNING id INTO v_module_id;

  -- 如果是更新，获取已存在的模块ID
  IF v_module_id IS NULL THEN
    SELECT id INTO v_module_id FROM sys_modules WHERE module_key = 'finance';
  END IF;

  -- 注册财务管理模块路由
  INSERT INTO sys_module_routes (
    module_id,
    route_path,
    component_name,
    menu_label,
    menu_icon,
    menu_order,
    is_menu_item,
    requires_auth,
    required_permissions,
    is_active
  ) VALUES (
    v_module_id,
    '/admin/finance',
    'Finance',
    jsonb_build_object('zh', '财务管理', 'en', 'Finance'),
    'Wallet',
    150,
    true,
    true,
    jsonb_build_array('finance:view', 'finance:manage'),
    true
  )
  ON CONFLICT (module_id, route_path) DO UPDATE SET
    is_menu_item = true,
    menu_order = 150,
    is_active = true;

END $$;