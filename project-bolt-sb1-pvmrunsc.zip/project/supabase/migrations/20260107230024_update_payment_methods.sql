/*
  # 更新付款方式配置

  ## 变更说明
  1. 修改订单表payment_method字段的CHECK约束
     - 旧值：'cod', 'online', 'usdt'
     - 新值：'cod'(货到付款), 'usd'(美元), 'usdt'(USDT), 'cny'(人民币)
  
  2. 更新默认值说明
     - cod: 货到付款 (Cash On Delivery)
     - usd: 美元支付
     - usdt: USDT加密货币支付
     - cny: 人民币支付
  
  ## 安全性
  - 仅修改约束，不影响现有数据
  - 如果现有数据有'online'值，需要手动迁移
*/

-- 删除旧的CHECK约束（如果存在）
DO $$ 
BEGIN
  IF EXISTS (
    SELECT 1 FROM information_schema.constraint_column_usage 
    WHERE table_name = 'sys_orders' 
    AND constraint_name LIKE '%payment_method%'
  ) THEN
    ALTER TABLE sys_orders DROP CONSTRAINT IF EXISTS sys_orders_payment_method_check;
  END IF;
END $$;

-- 添加新的CHECK约束，支持4种付款方式
ALTER TABLE sys_orders 
ADD CONSTRAINT sys_orders_payment_method_check 
CHECK (payment_method IN ('cod', 'usd', 'usdt', 'cny'));

-- 更新现有的'online'值为'usd'（如果有）
UPDATE sys_orders 
SET payment_method = 'usd' 
WHERE payment_method = 'online';

-- 为products表的payment_methods字段添加注释
COMMENT ON COLUMN products.payment_methods IS 
'支持的付款方式数组，可选值: ["cod", "usd", "usdt", "cny"]';

-- 为sys_orders表的payment_method字段添加注释
COMMENT ON COLUMN sys_orders.payment_method IS 
'订单付款方式: cod(货到付款), usd(美元), usdt(USDT), cny(人民币)';
