/*
  # 插入初始ERP数据
  
  ## 数据内容
  1. 初始部门结构
  2. 初始物流配置
  3. 初始商品类目
  4. 初始排名规则
*/

-- ============================================
-- 1. 初始部门结构
-- ============================================

INSERT INTO sys_departments (code, name, description, level, sort_order) VALUES
  ('ADMIN', '管理层', '公司高层管理', 1, 1),
  ('HR', '人事部', '人力资源管理', 1, 2),
  ('FIN', '财务部', '财务核算与结算', 1, 3),
  ('PROC', '采购部', '商品采购管理', 1, 4),
  ('WMS', '仓储部', '仓库与库存管理', 1, 5),
  ('LGS', '物流部', '配送与物流管理', 1, 6),
  ('CS', '客服部', '客户服务与支持', 1, 7),
  ('MKT', '营销部', '市场推广与营销', 1, 8),
  ('OPS', '运营部', '日常运营管理', 1, 9),
  ('TECH', '技术部', '技术开发与维护', 1, 10),
  ('MERCHANT', '商家', '平台商家管理', 1, 11)
ON CONFLICT (code) DO NOTHING;

-- ============================================
-- 2. 初始物流配置
-- ============================================

-- 自营物流公司
INSERT INTO lgs_carriers (code, name, type, is_active) VALUES
  ('SELF_001', '168自营物流', 'self_operated', true),
  ('SF_EXPRESS', '顺丰速运', 'third_party', true),
  ('ZTO_EXPRESS', '中通快递', 'third_party', true),
  ('YTO_EXPRESS', '圆通速递', 'third_party', true),
  ('STO_EXPRESS', '申通快递', 'third_party', true)
ON CONFLICT (code) DO NOTHING;

-- ============================================
-- 3. 初始商品类目
-- ============================================

-- 一级类目
INSERT INTO sys_categories (name, slug, level, sort_order, is_active) VALUES
  ('电子数码', 'electronics', 1, 1, true),
  ('服装鞋包', 'fashion', 1, 2, true),
  ('食品饮料', 'food-beverage', 1, 3, true),
  ('家居生活', 'home-living', 1, 4, true),
  ('美妆个护', 'beauty-personal', 1, 5, true),
  ('母婴用品', 'baby-maternity', 1, 6, true),
  ('运动户外', 'sports-outdoor', 1, 7, true),
  ('图书文娱', 'books-entertainment', 1, 8, true)
ON CONFLICT DO NOTHING;

-- 服务类目
INSERT INTO sys_service_categories (name, slug, service_type, level, sort_order, is_active) VALUES
  ('家政服务', 'home-services', 'home', 1, 1, true),
  ('教育培训', 'education', 'education', 1, 2, true),
  ('医疗健康', 'healthcare', 'health', 1, 3, true),
  ('商务服务', 'business-services', 'business', 1, 4, true),
  ('个人服务', 'personal-services', 'personal', 1, 5, true)
ON CONFLICT DO NOTHING;

-- 美食餐饮类目
INSERT INTO sys_food_categories (name, slug, cuisine_type, level, sort_order, is_active) VALUES
  ('中餐', 'chinese', '中式', 1, 1, true),
  ('西餐', 'western', '西式', 1, 2, true),
  ('日韩料理', 'japanese-korean', '日韩', 1, 3, true),
  ('东南亚菜', 'southeast-asian', '东南亚', 1, 4, true),
  ('快餐小吃', 'fast-food', '快餐', 1, 5, true),
  ('甜品饮品', 'desserts-drinks', '甜品', 1, 6, true)
ON CONFLICT DO NOTHING;

-- ============================================
-- 4. 初始排名规则
-- ============================================

-- 默认排名规则
INSERT INTO alg_ranking_rules (
  rule_name,
  weights,
  filters,
  is_active,
  priority
) VALUES (
  '默认综合排名',
  '{
    "sales_score": 0.35,
    "rating_score": 0.20,
    "conversion_score": 0.20,
    "profit_score": 0.15,
    "freshness_score": 0.10
  }'::jsonb,
  '{
    "min_rating": 3.0,
    "min_orders": 0
  }'::jsonb,
  true,
  1
) ON CONFLICT (rule_name) DO NOTHING;

-- 新品推荐规则
INSERT INTO alg_ranking_rules (
  rule_name,
  weights,
  filters,
  boost_conditions,
  is_active,
  priority
) VALUES (
  '新品推荐',
  '{
    "sales_score": 0.15,
    "rating_score": 0.15,
    "conversion_score": 0.15,
    "profit_score": 0.15,
    "freshness_score": 0.40
  }'::jsonb,
  '{
    "days_since_created": 30
  }'::jsonb,
  '{
    "is_new": 1.5
  }'::jsonb,
  true,
  2
) ON CONFLICT (rule_name) DO NOTHING;

-- 热销商品规则
INSERT INTO alg_ranking_rules (
  rule_name,
  weights,
  filters,
  boost_conditions,
  is_active,
  priority
) VALUES (
  '热销商品',
  '{
    "sales_score": 0.50,
    "rating_score": 0.20,
    "conversion_score": 0.20,
    "profit_score": 0.05,
    "freshness_score": 0.05
  }'::jsonb,
  '{
    "min_orders": 50
  }'::jsonb,
  '{
    "high_sales": 1.3
  }'::jsonb,
  true,
  3
) ON CONFLICT (rule_name) DO NOTHING;

-- ============================================
-- 5. 初始快捷回复
-- ============================================

INSERT INTO cs_quick_replies (category, title, content, shortcut, is_active) VALUES
  ('问候语', '欢迎语', '您好！欢迎来到168全球购，很高兴为您服务！有什么可以帮到您的吗？', '/hi', true),
  ('常见问题', '物流查询', '您可以在订单详情页面查看物流信息，或者提供订单号给我，我来帮您查询。', '/track', true),
  ('常见问题', '退换货政策', '我们支持7天无理由退换货（商品需保持完好）。请在订单详情页面申请退换货，或联系客服协助处理。', '/return', true),
  ('常见问题', '支付方式', '我们支持货到付款(COD)、在线支付等多种支付方式。', '/payment', true),
  ('结束语', '感谢语', '感谢您的咨询！如有其他问题，随时联系我们。祝您生活愉快！', '/bye', true)
ON CONFLICT DO NOTHING;