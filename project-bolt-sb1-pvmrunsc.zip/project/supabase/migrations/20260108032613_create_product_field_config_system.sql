/*
  # 商品字段配置系统

  ## 新增表
  - `sys_product_field_config` - 商品字段配置表
    - 控制商品表单中哪些字段显示/隐藏
    - 控制哪些字段必填/选填
    - 支持动态表单生成

  ## 说明
  1. 主图、价格、数量、SKU默认为必填项
  2. 其他字段（产品编号、名称、描述、分类、发货地址等）可通过配置控制
  3. 支持字段排序和验证规则配置
  4. 多语言支持

  ## 安全性
  - 启用RLS
  - 管理员可查看和修改配置
*/

-- 商品字段配置表
CREATE TABLE IF NOT EXISTS sys_product_field_config (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  domain_id uuid REFERENCES sys_domains(id) ON DELETE CASCADE,
  field_name text NOT NULL,
  display_name jsonb NOT NULL DEFAULT '{"zh": "", "en": ""}'::jsonb,
  is_required boolean DEFAULT false,
  is_visible boolean DEFAULT true,
  sort_order integer DEFAULT 0,
  field_type text DEFAULT 'text',
  validation_rules jsonb DEFAULT '{}'::jsonb,
  default_value text,
  placeholder jsonb DEFAULT '{"zh": "", "en": ""}'::jsonb,
  help_text jsonb DEFAULT '{"zh": "", "en": ""}'::jsonb,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  CONSTRAINT unique_domain_field UNIQUE NULLS NOT DISTINCT (domain_id, field_name)
);

-- 启用RLS
ALTER TABLE sys_product_field_config ENABLE ROW LEVEL SECURITY;

-- RLS策略：管理员可查看自己域的配置
CREATE POLICY "Admins can view own domain field config"
  ON sys_product_field_config
  FOR SELECT
  TO authenticated
  USING (
    domain_id IS NULL OR
    domain_id IN (
      SELECT domain_id FROM sys_admins WHERE id = auth.uid()
    )
  );

-- RLS策略：管理员可修改自己域的配置
CREATE POLICY "Admins can update own domain field config"
  ON sys_product_field_config
  FOR UPDATE
  TO authenticated
  USING (
    domain_id IS NULL OR
    domain_id IN (
      SELECT domain_id FROM sys_admins WHERE id = auth.uid()
    )
  )
  WITH CHECK (
    domain_id IS NULL OR
    domain_id IN (
      SELECT domain_id FROM sys_admins WHERE id = auth.uid()
    )
  );

-- 插入默认字段配置
INSERT INTO sys_product_field_config (
  field_name, 
  display_name, 
  is_required, 
  is_visible, 
  field_type, 
  sort_order,
  placeholder,
  help_text
) VALUES
  (
    'main_image', 
    '{"zh": "主图", "en": "Main Image"}'::jsonb, 
    true, 
    true, 
    'image_multi', 
    1,
    '{"zh": "上传商品主图", "en": "Upload main images"}'::jsonb,
    '{"zh": "第一张图片将作为主图显示，最多可上传10张", "en": "First image will be the main image, max 10 images"}'::jsonb
  ),
  (
    'price', 
    '{"zh": "价格", "en": "Price"}'::jsonb, 
    true, 
    true, 
    'number', 
    2,
    '{"zh": "0.00", "en": "0.00"}'::jsonb,
    '{"zh": "商品售价", "en": "Product selling price"}'::jsonb
  ),
  (
    'quantity', 
    '{"zh": "库存数量", "en": "Stock Quantity"}'::jsonb, 
    true, 
    true, 
    'number', 
    3,
    '{"zh": "0", "en": "0"}'::jsonb,
    '{"zh": "可售库存数量", "en": "Available stock quantity"}'::jsonb
  ),
  (
    'sku', 
    '{"zh": "SKU编码", "en": "SKU Code"}'::jsonb, 
    true, 
    true, 
    'text', 
    4,
    '{"zh": "例如：SKU-001", "en": "e.g.: SKU-001"}'::jsonb,
    '{"zh": "库存单位标识码", "en": "Stock Keeping Unit identifier"}'::jsonb
  ),
  (
    'serial_number', 
    '{"zh": "产品编号", "en": "Serial Number"}'::jsonb, 
    false, 
    false, 
    'text', 
    5,
    '{"zh": "例如：P001", "en": "e.g.: P001"}'::jsonb,
    '{"zh": "用于仓库拣货识别", "en": "For warehouse picking identification"}'::jsonb
  ),
  (
    'title', 
    '{"zh": "产品名称", "en": "Product Name"}'::jsonb, 
    false, 
    true, 
    'text', 
    6,
    '{"zh": "请输入产品名称", "en": "Enter product name"}'::jsonb,
    '{"zh": "商品的展示名称", "en": "Display name of the product"}'::jsonb
  ),
  (
    'description', 
    '{"zh": "产品描述", "en": "Description"}'::jsonb, 
    false, 
    true, 
    'textarea', 
    7,
    '{"zh": "请输入产品描述", "en": "Enter product description"}'::jsonb,
    '{"zh": "详细的商品描述信息", "en": "Detailed product description"}'::jsonb
  ),
  (
    'category', 
    '{"zh": "产品分类", "en": "Category"}'::jsonb, 
    false, 
    true, 
    'text', 
    8,
    '{"zh": "例如：电子产品", "en": "e.g.: Electronics"}'::jsonb,
    '{"zh": "商品所属分类", "en": "Product category"}'::jsonb
  ),
  (
    'shipping_address', 
    '{"zh": "发货地址", "en": "Shipping Address"}'::jsonb, 
    false, 
    false, 
    'address', 
    9,
    '{"zh": "选择发货地址", "en": "Select shipping address"}'::jsonb,
    '{"zh": "商品的默认发货地址", "en": "Default shipping address for the product"}'::jsonb
  ),
  (
    'product_type',
    '{"zh": "产品类型", "en": "Product Type"}'::jsonb,
    false,
    false,
    'select',
    10,
    '{"zh": "选择产品类型", "en": "Select product type"}'::jsonb,
    '{"zh": "单品或多品链接类型", "en": "Single or multi-product link type"}'::jsonb
  )
ON CONFLICT (domain_id, field_name) DO UPDATE SET
  is_required = EXCLUDED.is_required,
  is_visible = EXCLUDED.is_visible,
  display_name = EXCLUDED.display_name,
  placeholder = EXCLUDED.placeholder,
  help_text = EXCLUDED.help_text,
  sort_order = EXCLUDED.sort_order;

-- 创建索引
CREATE INDEX IF NOT EXISTS idx_product_field_config_domain ON sys_product_field_config(domain_id);
CREATE INDEX IF NOT EXISTS idx_product_field_config_visible ON sys_product_field_config(is_visible) WHERE is_visible = true;
CREATE INDEX IF NOT EXISTS idx_product_field_config_sort ON sys_product_field_config(sort_order);
