/*
  # 按重要程度重新排列模块导航菜单 v2

  ## 排序逻辑
  1. 核心业务（10-40）
  2. 营销推广（50-70）
  3. 数据分析（80-90）
  4. 供应链（100-120）
  5. 服务管理（130-140）
  6. 工具模块（150）
  7. 系统管理（900+）
*/

DO $$
BEGIN
  UPDATE sys_module_routes SET menu_order = 10 
  WHERE route_path = '/admin/dashboard' AND is_menu_item = true;

  UPDATE sys_module_routes SET menu_order = 20 
  WHERE route_path = '/admin/store' AND is_menu_item = true;

  UPDATE sys_module_routes SET menu_order = 30 
  WHERE route_path = '/admin/products' AND is_menu_item = true;

  UPDATE sys_module_routes SET menu_order = 40 
  WHERE route_path = '/admin/orders' AND is_menu_item = true;

  UPDATE sys_module_routes SET menu_order = 50 
  WHERE route_path = '/admin/advertising' AND is_menu_item = true;

  UPDATE sys_module_routes SET menu_order = 60 
  WHERE route_path = '/admin/promotions' AND is_menu_item = true;

  UPDATE sys_module_routes SET menu_order = 70 
  WHERE route_path = '/admin/link-tracker' AND is_menu_item = true;

  UPDATE sys_module_routes SET menu_order = 80 
  WHERE route_path = '/admin/analytics' AND is_menu_item = true;

  UPDATE sys_module_routes SET menu_order = 90 
  WHERE route_path = '/admin/smart-insight' AND is_menu_item = true;

  UPDATE sys_module_routes SET menu_order = 100 
  WHERE route_path = '/admin/smart-purchase' AND is_menu_item = true;

  UPDATE sys_module_routes SET menu_order = 110 
  WHERE route_path = '/admin/warehouses' AND is_menu_item = true;

  UPDATE sys_module_routes SET menu_order = 120 
  WHERE route_path = '/admin/logistics' AND is_menu_item = true;

  UPDATE sys_module_routes SET menu_order = 130 
  WHERE route_path = '/admin/customer-service' AND is_menu_item = true;

  UPDATE sys_module_routes SET menu_order = 140 
  WHERE route_path = '/admin/finance' AND is_menu_item = true;

  UPDATE sys_module_routes SET menu_order = 150 
  WHERE route_path = '/admin/ai-image-studio' AND is_menu_item = true;

  UPDATE sys_module_routes SET menu_order = 900 
  WHERE route_path = '/admin/system/monitor' AND is_menu_item = true;

  UPDATE sys_module_routes SET menu_order = 910 
  WHERE route_path = '/admin/system/modules' AND is_menu_item = true;

  UPDATE sys_module_routes SET menu_order = 920 
  WHERE route_path = '/admin/module-manager' AND is_menu_item = true;

  UPDATE sys_module_routes SET menu_order = 980 
  WHERE route_path = '/admin/settings' AND is_menu_item = true;

  UPDATE sys_module_routes SET menu_order = 990 
  WHERE route_path LIKE '/admin/product-field-config%' AND is_menu_item = true;

  UPDATE sys_module_routes SET menu_order = 995 
  WHERE route_path LIKE '/admin/lucky-draw%' AND is_menu_item = true;

  RAISE NOTICE '模块导航菜单已按重要程度重新排序';
END $$;
