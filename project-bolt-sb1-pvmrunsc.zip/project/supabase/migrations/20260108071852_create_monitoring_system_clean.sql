/*
  # 创建系统监控和AI预警系统

  ## 新增表
  - sys_performance_metrics: 性能指标记录
  - sys_module_health: 模块健康状态
  - sys_ai_alerts: AI预警记录
*/

CREATE TABLE IF NOT EXISTS sys_performance_metrics (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  domain_id uuid REFERENCES sys_domains(id) ON DELETE CASCADE,
  module_code varchar(100),
  metric_type varchar(100) NOT NULL,
  metric_name varchar(200) NOT NULL,
  response_time numeric,
  error_count integer DEFAULT 0,
  success_count integer DEFAULT 0,
  metadata jsonb DEFAULT '{}'::jsonb,
  recorded_at timestamptz DEFAULT now()
);

CREATE INDEX idx_perf_domain_new ON sys_performance_metrics(domain_id);
CREATE INDEX idx_perf_module_new ON sys_performance_metrics(module_code);
CREATE INDEX idx_perf_time_new ON sys_performance_metrics(recorded_at DESC);

ALTER TABLE sys_performance_metrics ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users view performance metrics"
  ON sys_performance_metrics FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM sys_admin_domains
      WHERE admin_id = auth.uid() AND domain_id = sys_performance_metrics.domain_id
    )
  );

CREATE TABLE IF NOT EXISTS sys_module_health (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  domain_id uuid REFERENCES sys_domains(id) ON DELETE CASCADE,
  module_code varchar(100) NOT NULL,
  health_status varchar(50) DEFAULT 'healthy',
  uptime_percentage numeric(5,2) DEFAULT 100.00,
  avg_response_time numeric DEFAULT 0,
  error_rate numeric(5,2) DEFAULT 0.00,
  total_requests bigint DEFAULT 0,
  failed_requests bigint DEFAULT 0,
  last_health_check timestamptz DEFAULT now(),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  UNIQUE(domain_id, module_code)
);

CREATE INDEX idx_health_domain_new ON sys_module_health(domain_id);
CREATE INDEX idx_health_status_new ON sys_module_health(health_status);

ALTER TABLE sys_module_health ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users view module health"
  ON sys_module_health FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM sys_admin_domains
      WHERE admin_id = auth.uid() AND domain_id = sys_module_health.domain_id
    )
  );

CREATE TABLE IF NOT EXISTS sys_ai_alerts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  domain_id uuid REFERENCES sys_domains(id) ON DELETE CASCADE,
  alert_type varchar(100) NOT NULL,
  severity varchar(50) NOT NULL,
  module_code varchar(100),
  title text NOT NULL,
  description text NOT NULL,
  recommended_actions jsonb DEFAULT '[]'::jsonb,
  ai_confidence_score numeric(5,2),
  status varchar(50) DEFAULT 'active',
  created_at timestamptz DEFAULT now()
);

CREATE INDEX idx_alerts_domain_new ON sys_ai_alerts(domain_id);
CREATE INDEX idx_alerts_status_new ON sys_ai_alerts(status);
CREATE INDEX idx_alerts_severity_new ON sys_ai_alerts(severity);

ALTER TABLE sys_ai_alerts ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users view ai alerts"
  ON sys_ai_alerts FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM sys_admin_domains
      WHERE admin_id = auth.uid() AND domain_id = sys_ai_alerts.domain_id
    )
  );

CREATE OR REPLACE FUNCTION record_performance_metric(
  p_domain_id uuid,
  p_module_code varchar,
  p_metric_type varchar,
  p_metric_name varchar,
  p_response_time numeric DEFAULT NULL,
  p_success boolean DEFAULT true
)
RETURNS uuid
LANGUAGE plpgsql
AS $$
DECLARE
  v_metric_id uuid;
BEGIN
  INSERT INTO sys_performance_metrics (
    domain_id, module_code, metric_type, metric_name,
    response_time, success_count, error_count
  ) VALUES (
    p_domain_id, p_module_code, p_metric_type, p_metric_name,
    p_response_time,
    CASE WHEN p_success THEN 1 ELSE 0 END,
    CASE WHEN p_success THEN 0 ELSE 1 END
  ) RETURNING id INTO v_metric_id;
  
  PERFORM update_module_health(p_domain_id, p_module_code, p_success, p_response_time);
  
  RETURN v_metric_id;
END;
$$;

CREATE OR REPLACE FUNCTION update_module_health(
  p_domain_id uuid,
  p_module_code varchar,
  p_success boolean,
  p_response_time numeric DEFAULT NULL
)
RETURNS void
LANGUAGE plpgsql
AS $$
DECLARE
  v_error_rate numeric;
  v_new_status varchar;
BEGIN
  INSERT INTO sys_module_health (
    domain_id, module_code, total_requests, failed_requests,
    avg_response_time, last_health_check
  ) VALUES (
    p_domain_id, p_module_code, 1,
    CASE WHEN p_success THEN 0 ELSE 1 END,
    COALESCE(p_response_time, 0), now()
  )
  ON CONFLICT (domain_id, module_code) DO UPDATE SET
    total_requests = sys_module_health.total_requests + 1,
    failed_requests = sys_module_health.failed_requests + 
      CASE WHEN p_success THEN 0 ELSE 1 END,
    avg_response_time = CASE 
      WHEN p_response_time IS NOT NULL THEN
        COALESCE((sys_module_health.avg_response_time * 0.9 + p_response_time * 0.1), p_response_time)
      ELSE sys_module_health.avg_response_time
    END,
    last_health_check = now(),
    updated_at = now();
  
  SELECT 
    CASE 
      WHEN total_requests > 0 THEN (failed_requests::numeric / total_requests * 100)
      ELSE 0 
    END
  INTO v_error_rate
  FROM sys_module_health
  WHERE domain_id = p_domain_id AND module_code = p_module_code;
  
  v_new_status := CASE
    WHEN v_error_rate >= 50 THEN 'critical'
    WHEN v_error_rate >= 25 THEN 'warning'
    WHEN v_error_rate >= 10 THEN 'degraded'
    ELSE 'healthy'
  END;
  
  UPDATE sys_module_health
  SET 
    error_rate = v_error_rate,
    health_status = v_new_status,
    uptime_percentage = 100 - v_error_rate
  WHERE domain_id = p_domain_id AND module_code = p_module_code;
END;
$$;

CREATE OR REPLACE FUNCTION detect_system_anomalies(
  p_domain_id uuid
)
RETURNS jsonb
LANGUAGE plpgsql
AS $$
DECLARE
  v_module record;
  v_alert_count integer := 0;
BEGIN
  DELETE FROM sys_ai_alerts
  WHERE domain_id = p_domain_id
  AND status = 'active'
  AND created_at < now() - interval '24 hours';
  
  FOR v_module IN
    SELECT 
      module_code,
      health_status,
      error_rate,
      avg_response_time,
      failed_requests,
      total_requests
    FROM sys_module_health
    WHERE domain_id = p_domain_id
    AND health_status IN ('critical', 'warning', 'degraded')
  LOOP
    IF v_module.error_rate >= 30 THEN
      INSERT INTO sys_ai_alerts (
        domain_id, alert_type, severity, module_code,
        title, description, recommended_actions, ai_confidence_score
      ) VALUES (
        p_domain_id, 'high_error_rate', 
        CASE WHEN v_module.error_rate >= 50 THEN 'critical' ELSE 'high' END,
        v_module.module_code,
        '模块错误率异常',
        format('模块"%s"错误率达到%.1f%%，需要立即处理', v_module.module_code, v_module.error_rate),
        jsonb_build_array(
          '检查模块错误日志',
          '验证数据库连接状态',
          '考虑重启模块服务',
          '通知技术支持团队'
        ),
        92.0
      );
      v_alert_count := v_alert_count + 1;
    END IF;
    
    IF v_module.avg_response_time > 2000 THEN
      INSERT INTO sys_ai_alerts (
        domain_id, alert_type, severity, module_code,
        title, description, recommended_actions, ai_confidence_score
      ) VALUES (
        p_domain_id, 'performance_degradation', 'high', v_module.module_code,
        '模块性能严重下降',
        format('模块"%s"响应时间%.0fms，远超正常范围', v_module.module_code, v_module.avg_response_time),
        jsonb_build_array(
          '优化数据库查询',
          '检查缓存命中率',
          '分析慢查询日志',
          '考虑增加服务器资源'
        ),
        85.5
      );
      v_alert_count := v_alert_count + 1;
    END IF;
  END LOOP;
  
  RETURN jsonb_build_object(
    'success', true,
    'alerts_generated', v_alert_count,
    'timestamp', now()
  );
END;
$$;

CREATE OR REPLACE FUNCTION get_system_health_overview(
  p_domain_id uuid
)
RETURNS jsonb
LANGUAGE plpgsql
AS $$
DECLARE
  v_stats record;
  v_active_alerts integer;
BEGIN
  SELECT
    COUNT(*) as total,
    COUNT(*) FILTER (WHERE health_status = 'healthy') as healthy,
    COUNT(*) FILTER (WHERE health_status = 'critical') as critical,
    AVG(avg_response_time) as avg_time,
    AVG(error_rate) as avg_error_rate
  INTO v_stats
  FROM sys_module_health
  WHERE domain_id = p_domain_id;
  
  SELECT COUNT(*)
  INTO v_active_alerts
  FROM sys_ai_alerts
  WHERE domain_id = p_domain_id
  AND status = 'active'
  AND severity IN ('high', 'critical');
  
  RETURN jsonb_build_object(
    'total_modules', COALESCE(v_stats.total, 0),
    'healthy_modules', COALESCE(v_stats.healthy, 0),
    'critical_modules', COALESCE(v_stats.critical, 0),
    'active_critical_alerts', COALESCE(v_active_alerts, 0),
    'avg_response_time', ROUND(COALESCE(v_stats.avg_time, 0), 2),
    'avg_error_rate', ROUND(COALESCE(v_stats.avg_error_rate, 0), 2),
    'overall_status', CASE
      WHEN COALESCE(v_stats.critical, 0) > 0 THEN 'critical'
      WHEN COALESCE(v_stats.healthy, 0)::numeric / NULLIF(v_stats.total, 0) >= 0.9 THEN 'healthy'
      WHEN COALESCE(v_stats.healthy, 0)::numeric / NULLIF(v_stats.total, 0) >= 0.7 THEN 'warning'
      ELSE 'degraded'
    END,
    'checked_at', now()
  );
END;
$$;
