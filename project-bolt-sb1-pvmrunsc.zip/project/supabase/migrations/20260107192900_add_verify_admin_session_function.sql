/*
  # 添加验证管理员会话的函数

  1. 新增功能
    - `verify_admin_session` 函数 - 验证管理员会话是否有效
    - 绕过 RLS，允许在页面刷新时验证管理员状态
  
  2. 安全性
    - 使用 SECURITY DEFINER 绕过 RLS
    - 只返回活跃状态的管理员
    - 不返回密码哈希等敏感信息
*/

CREATE OR REPLACE FUNCTION verify_admin_session(
  p_admin_id UUID
)
RETURNS JSON
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  v_admin RECORD;
BEGIN
  SELECT * INTO v_admin
  FROM admins
  WHERE id = p_admin_id
  AND (status = 'active' OR status = 'approved');

  IF NOT FOUND THEN
    RETURN json_build_object(
      'valid', false,
      'admin', null
    );
  END IF;

  RETURN json_build_object(
    'valid', true,
    'admin', json_build_object(
      'id', v_admin.id,
      'email', v_admin.email,
      'full_name', v_admin.full_name,
      'is_super_admin', v_admin.is_super_admin,
      'status', v_admin.status,
      'permissions', v_admin.permissions,
      'department_id', v_admin.department_id,
      'admin_type', v_admin.admin_type,
      'role', v_admin.admin_type
    )
  );
END;
$$;