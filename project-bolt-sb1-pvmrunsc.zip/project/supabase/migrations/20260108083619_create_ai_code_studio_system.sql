-- AI代码工作室系统
-- 
-- 1. 新建表
--    - ai_code_projects: AI代码项目表
--    - ai_code_files: AI代码文件表
-- 
-- 2. 安全
--    - 启用 RLS
--    - 添加域级别访问控制策略

-- 创建AI代码项目表
CREATE TABLE IF NOT EXISTS ai_code_projects (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  domain_id uuid NOT NULL REFERENCES sys_domains(id) ON DELETE CASCADE,
  project_name text NOT NULL,
  description text,
  language text NOT NULL DEFAULT 'javascript',
  framework text,
  tags text[] DEFAULT ARRAY[]::text[],
  created_by uuid REFERENCES sys_admins(id),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- 创建AI代码文件表
CREATE TABLE IF NOT EXISTS ai_code_files (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  project_id uuid REFERENCES ai_code_projects(id) ON DELETE CASCADE,
  file_name text NOT NULL,
  file_path text,
  language text NOT NULL DEFAULT 'javascript',
  code_content text NOT NULL,
  ai_prompt text,
  ai_model text DEFAULT 'SmartInsight AI',
  version integer DEFAULT 1,
  is_active boolean DEFAULT true,
  file_size integer DEFAULT 0,
  created_by uuid REFERENCES sys_admins(id),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- 添加索引
CREATE INDEX IF NOT EXISTS idx_ai_code_projects_domain ON ai_code_projects(domain_id);
CREATE INDEX IF NOT EXISTS idx_ai_code_projects_created_by ON ai_code_projects(created_by);
CREATE INDEX IF NOT EXISTS idx_ai_code_files_project ON ai_code_files(project_id);
CREATE INDEX IF NOT EXISTS idx_ai_code_files_language ON ai_code_files(language);

-- 启用 RLS
ALTER TABLE ai_code_projects ENABLE ROW LEVEL SECURITY;
ALTER TABLE ai_code_files ENABLE ROW LEVEL SECURITY;

-- 代码项目访问策略
CREATE POLICY "Users can view code projects in their domain"
  ON ai_code_projects FOR SELECT
  TO authenticated
  USING (
    domain_id IN (
      SELECT domain_id FROM sys_admins WHERE id = auth.uid()
    )
  );

CREATE POLICY "Users can create code projects in their domain"
  ON ai_code_projects FOR INSERT
  TO authenticated
  WITH CHECK (
    domain_id IN (
      SELECT domain_id FROM sys_admins WHERE id = auth.uid()
    )
  );

CREATE POLICY "Users can update their code projects"
  ON ai_code_projects FOR UPDATE
  TO authenticated
  USING (
    domain_id IN (
      SELECT domain_id FROM sys_admins WHERE id = auth.uid()
    )
  )
  WITH CHECK (
    domain_id IN (
      SELECT domain_id FROM sys_admins WHERE id = auth.uid()
    )
  );

CREATE POLICY "Users can delete their code projects"
  ON ai_code_projects FOR DELETE
  TO authenticated
  USING (
    domain_id IN (
      SELECT domain_id FROM sys_admins WHERE id = auth.uid()
    )
  );

-- 代码文件访问策略
CREATE POLICY "Users can view code files in their domain"
  ON ai_code_files FOR SELECT
  TO authenticated
  USING (
    project_id IN (
      SELECT id FROM ai_code_projects
      WHERE domain_id IN (
        SELECT domain_id FROM sys_admins WHERE id = auth.uid()
      )
    )
  );

CREATE POLICY "Users can create code files in their domain"
  ON ai_code_files FOR INSERT
  TO authenticated
  WITH CHECK (
    project_id IN (
      SELECT id FROM ai_code_projects
      WHERE domain_id IN (
        SELECT domain_id FROM sys_admins WHERE id = auth.uid()
      )
    )
  );

CREATE POLICY "Users can update code files in their domain"
  ON ai_code_files FOR UPDATE
  TO authenticated
  USING (
    project_id IN (
      SELECT id FROM ai_code_projects
      WHERE domain_id IN (
        SELECT domain_id FROM sys_admins WHERE id = auth.uid()
      )
    )
  )
  WITH CHECK (
    project_id IN (
      SELECT id FROM ai_code_projects
      WHERE domain_id IN (
        SELECT domain_id FROM sys_admins WHERE id = auth.uid()
      )
    )
  );

CREATE POLICY "Users can delete code files in their domain"
  ON ai_code_files FOR DELETE
  TO authenticated
  USING (
    project_id IN (
      SELECT id FROM ai_code_projects
      WHERE domain_id IN (
        SELECT domain_id FROM sys_admins WHERE id = auth.uid()
      )
    )
  );