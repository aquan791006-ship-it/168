/*
  # 图片超链接功能支持

  ## 功能说明
  为商品图片添加超链接功能支持，特别是单品模式

  ## 修改内容
  1. 为product_images表添加link_url字段
  2. 添加链接验证和安全性检查
  3. 更新相关策略

  ## 使用场景
  - 单品模式：图片可添加单品页面链接
  - 多品模式：图片可添加跳转链接（如分类页、促销页等）
*/

-- 1. 检查并添加link_url字段到product_images表
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'product_images' AND column_name = 'link_url'
  ) THEN
    ALTER TABLE product_images ADD COLUMN link_url text;
  END IF;
END $$;

-- 2. 添加link_url字段的注释
COMMENT ON COLUMN product_images.link_url IS '图片点击跳转链接，单品模式下用于设置单品页面链接';

-- 3. 创建图片链接验证函数（可选）
CREATE OR REPLACE FUNCTION validate_image_link_url(p_url text)
RETURNS boolean AS $$
BEGIN
  -- 如果链接为空，直接返回true
  IF p_url IS NULL OR p_url = '' THEN
    RETURN true;
  END IF;
  
  -- 检查链接格式（简单验证）
  -- 允许相对路径和绝对路径
  IF p_url ~ '^(/|https?://)' THEN
    RETURN true;
  END IF;
  
  RETURN false;
END;
$$ LANGUAGE plpgsql;

-- 4. 添加约束检查（可选，但建议注释掉以允许更灵活的链接格式）
-- ALTER TABLE product_images 
-- ADD CONSTRAINT check_link_url_format 
-- CHECK (link_url IS NULL OR link_url = '' OR validate_image_link_url(link_url));

-- 5. 为sys_product_images表也添加link_url支持（如果存在）
DO $$
BEGIN
  IF EXISTS (
    SELECT 1 FROM information_schema.tables
    WHERE table_name = 'sys_product_images'
  ) THEN
    IF NOT EXISTS (
      SELECT 1 FROM information_schema.columns
      WHERE table_name = 'sys_product_images' AND column_name = 'link_url'
    ) THEN
      ALTER TABLE sys_product_images ADD COLUMN link_url text;
      COMMENT ON COLUMN sys_product_images.link_url IS '图片点击跳转链接，单品模式下用于设置单品页面链接';
    END IF;
  END IF;
END $$;