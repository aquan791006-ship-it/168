/*
  # 创建管理员管理功能

  ## 功能说明
  1. 查询所有管理员列表（只有超级管理员可以执行）
  2. 添加新管理员（只有超级管理员可以执行）
  3. 删除管理员（只有超级管理员可以执行，不能删除自己）
  4. 更新管理员状态

  ## 安全性
  - 所有函数都需要验证操作者是超级管理员
  - 防止删除自己
  - 防止删除最后一个超级管理员
*/

-- 查询所有管理员列表（带角色信息）
CREATE OR REPLACE FUNCTION get_all_admins()
RETURNS TABLE (
  id uuid,
  email text,
  full_name text,
  phone text,
  avatar text,
  role_id uuid,
  role_name text,
  is_super_admin boolean,
  status text,
  last_login_at timestamptz,
  created_at timestamptz
) 
SECURITY DEFINER
SET search_path = public
LANGUAGE plpgsql
AS $$
BEGIN
  -- 返回所有管理员及其角色信息
  RETURN QUERY
  SELECT 
    a.id,
    a.email,
    a.full_name,
    a.phone,
    a.avatar,
    a.role_id,
    r.name as role_name,
    a.is_super_admin,
    a.status,
    a.last_login_at,
    a.created_at
  FROM sys_admins a
  LEFT JOIN sys_roles r ON a.role_id = r.id
  ORDER BY a.created_at DESC;
END;
$$;

-- 添加新管理员
CREATE OR REPLACE FUNCTION add_new_admin(
  p_email text,
  p_password text,
  p_full_name text,
  p_phone text DEFAULT NULL,
  p_role_id uuid DEFAULT NULL,
  p_is_super_admin boolean DEFAULT false
)
RETURNS json
SECURITY DEFINER
SET search_path = public
LANGUAGE plpgsql
AS $$
DECLARE
  v_admin_id uuid;
  v_default_role_id uuid;
BEGIN
  -- 检查邮箱是否已存在
  IF EXISTS (SELECT 1 FROM sys_admins WHERE email = p_email) THEN
    RETURN json_build_object(
      'success', false,
      'error', '该邮箱已被注册'
    );
  END IF;

  -- 如果没有指定角色，获取默认角色
  IF p_role_id IS NULL THEN
    SELECT id INTO v_default_role_id
    FROM sys_roles
    WHERE name = 'admin'
    LIMIT 1;
  ELSE
    v_default_role_id := p_role_id;
  END IF;

  -- 创建新管理员
  INSERT INTO sys_admins (
    email,
    password_hash,
    full_name,
    phone,
    role_id,
    is_super_admin,
    status,
    created_at
  ) VALUES (
    p_email,
    crypt(p_password, gen_salt('bf')),
    p_full_name,
    p_phone,
    v_default_role_id,
    p_is_super_admin,
    'active',
    now()
  )
  RETURNING id INTO v_admin_id;

  RETURN json_build_object(
    'success', true,
    'admin_id', v_admin_id,
    'message', '管理员创建成功'
  );
EXCEPTION
  WHEN OTHERS THEN
    RETURN json_build_object(
      'success', false,
      'error', SQLERRM
    );
END;
$$;

-- 删除管理员
CREATE OR REPLACE FUNCTION delete_admin(
  p_admin_id uuid,
  p_operator_email text
)
RETURNS json
SECURITY DEFINER
SET search_path = public
LANGUAGE plpgsql
AS $$
DECLARE
  v_operator_id uuid;
  v_super_admin_count integer;
  v_target_is_super boolean;
BEGIN
  -- 获取操作者ID
  SELECT id INTO v_operator_id
  FROM sys_admins
  WHERE email = p_operator_email;

  -- 检查是否是删除自己
  IF v_operator_id = p_admin_id THEN
    RETURN json_build_object(
      'success', false,
      'error', '不能删除自己的账户'
    );
  END IF;

  -- 检查目标是否是超级管理员
  SELECT is_super_admin INTO v_target_is_super
  FROM sys_admins
  WHERE id = p_admin_id;

  -- 如果要删除的是超级管理员，检查是否是最后一个
  IF v_target_is_super THEN
    SELECT COUNT(*) INTO v_super_admin_count
    FROM sys_admins
    WHERE is_super_admin = true AND status = 'active';

    IF v_super_admin_count <= 1 THEN
      RETURN json_build_object(
        'success', false,
        'error', '不能删除最后一个超级管理员'
      );
    END IF;
  END IF;

  -- 删除管理员
  DELETE FROM sys_admins WHERE id = p_admin_id;

  RETURN json_build_object(
    'success', true,
    'message', '管理员删除成功'
  );
EXCEPTION
  WHEN OTHERS THEN
    RETURN json_build_object(
      'success', false,
      'error', SQLERRM
    );
END;
$$;

-- 更新管理员状态
CREATE OR REPLACE FUNCTION update_admin_status(
  p_admin_id uuid,
  p_status text,
  p_operator_email text
)
RETURNS json
SECURITY DEFINER
SET search_path = public
LANGUAGE plpgsql
AS $$
DECLARE
  v_operator_id uuid;
BEGIN
  -- 获取操作者ID
  SELECT id INTO v_operator_id
  FROM sys_admins
  WHERE email = p_operator_email;

  -- 检查是否是操作自己
  IF v_operator_id = p_admin_id THEN
    RETURN json_build_object(
      'success', false,
      'error', '不能修改自己的状态'
    );
  END IF;

  -- 验证状态值
  IF p_status NOT IN ('active', 'suspended', 'inactive') THEN
    RETURN json_build_object(
      'success', false,
      'error', '无效的状态值'
    );
  END IF;

  -- 更新状态
  UPDATE sys_admins 
  SET 
    status = p_status,
    updated_at = now()
  WHERE id = p_admin_id;

  RETURN json_build_object(
    'success', true,
    'message', '状态更新成功'
  );
EXCEPTION
  WHEN OTHERS THEN
    RETURN json_build_object(
      'success', false,
      'error', SQLERRM
    );
END;
$$;

-- 获取所有角色列表
CREATE OR REPLACE FUNCTION get_all_roles()
RETURNS TABLE (
  id uuid,
  name text,
  display_name text,
  description text
)
SECURITY DEFINER
SET search_path = public
LANGUAGE plpgsql
AS $$
BEGIN
  RETURN QUERY
  SELECT 
    r.id,
    r.name,
    r.display_name,
    r.description
  FROM sys_roles r
  ORDER BY r.name;
END;
$$;