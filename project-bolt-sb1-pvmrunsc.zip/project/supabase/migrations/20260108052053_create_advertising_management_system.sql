/*
  # 创建广告推广管理系统

  ## 功能说明
  智能化的多平台广告推广管理系统，支持：
  1. 多平台广告账户管理（Facebook, Google Ads, TikTok, 微信广告等）
  2. 广告活动、广告组、广告创意管理
  3. 实时数据统计和分析
  4. 智能预算优化和自动化规则
  5. ROI分析和转化追踪

  ## 新增表
  1. `ad_platforms` - 广告平台配置
  2. `ad_accounts` - 广告账户
  3. `ad_campaigns` - 广告活动
  4. `ad_groups` - 广告组
  5. `ad_creatives` - 广告创意
  6. `ad_stats` - 广告数据统计
  7. `ad_automation_rules` - 自动化规则
  8. `ad_optimization_logs` - 优化日志

  ## 安全性
  - 启用RLS，所有表都基于domain_id进行隔离
  - 只有有权限的管理员才能访问
*/

-- 1. 广告平台配置表
CREATE TABLE IF NOT EXISTS ad_platforms (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  platform_code text UNIQUE NOT NULL,
  platform_name text NOT NULL,
  platform_name_cn text NOT NULL,
  description text,
  api_endpoint text,
  support_auto_optimize boolean DEFAULT false,
  icon_url text,
  is_active boolean DEFAULT true,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- 2. 广告账户表
CREATE TABLE IF NOT EXISTS ad_accounts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  domain_id uuid REFERENCES sys_domains(id) ON DELETE CASCADE,
  platform_id uuid REFERENCES ad_platforms(id) ON DELETE CASCADE,
  account_name text NOT NULL,
  account_id text NOT NULL,
  api_token text,
  api_secret text,
  currency text DEFAULT 'CNY',
  timezone text DEFAULT 'Asia/Shanghai',
  daily_budget numeric(12,2) DEFAULT 0,
  total_budget numeric(12,2) DEFAULT 0,
  status text DEFAULT 'active' CHECK (status IN ('active', 'paused', 'suspended')),
  created_by uuid REFERENCES sys_admins(id) ON DELETE SET NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- 3. 广告活动表
CREATE TABLE IF NOT EXISTS ad_campaigns (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  domain_id uuid REFERENCES sys_domains(id) ON DELETE CASCADE,
  account_id uuid REFERENCES ad_accounts(id) ON DELETE CASCADE,
  campaign_name text NOT NULL,
  campaign_objective text NOT NULL,
  campaign_type text DEFAULT 'standard',
  daily_budget numeric(12,2) DEFAULT 0,
  total_budget numeric(12,2),
  bid_strategy text DEFAULT 'auto',
  target_audience jsonb DEFAULT '{}',
  start_date date,
  end_date date,
  status text DEFAULT 'draft' CHECK (status IN ('draft', 'active', 'paused', 'completed', 'archived')),
  created_by uuid REFERENCES sys_admins(id) ON DELETE SET NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- 4. 广告组表
CREATE TABLE IF NOT EXISTS ad_groups (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  domain_id uuid REFERENCES sys_domains(id) ON DELETE CASCADE,
  campaign_id uuid REFERENCES ad_campaigns(id) ON DELETE CASCADE,
  group_name text NOT NULL,
  daily_budget numeric(12,2) DEFAULT 0,
  bid_amount numeric(12,2) DEFAULT 0,
  target_cpa numeric(12,2),
  target_roas numeric(12,2),
  placement_config jsonb DEFAULT '{}',
  audience_config jsonb DEFAULT '{}',
  schedule_config jsonb DEFAULT '{}',
  status text DEFAULT 'active' CHECK (status IN ('active', 'paused', 'deleted')),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- 5. 广告创意表
CREATE TABLE IF NOT EXISTS ad_creatives (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  domain_id uuid REFERENCES sys_domains(id) ON DELETE CASCADE,
  ad_group_id uuid REFERENCES ad_groups(id) ON DELETE CASCADE,
  creative_name text NOT NULL,
  creative_type text NOT NULL CHECK (creative_type IN ('image', 'video', 'carousel', 'collection')),
  headline text NOT NULL,
  description text,
  call_to_action text DEFAULT 'Learn More',
  destination_url text NOT NULL,
  media_urls jsonb DEFAULT '[]',
  tracking_params jsonb DEFAULT '{}',
  status text DEFAULT 'active' CHECK (status IN ('active', 'paused', 'rejected', 'deleted')),
  review_status text DEFAULT 'pending' CHECK (review_status IN ('pending', 'approved', 'rejected')),
  rejection_reason text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- 6. 广告数据统计表
CREATE TABLE IF NOT EXISTS ad_stats (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  domain_id uuid REFERENCES sys_domains(id) ON DELETE CASCADE,
  campaign_id uuid REFERENCES ad_campaigns(id) ON DELETE CASCADE,
  ad_group_id uuid REFERENCES ad_groups(id) ON DELETE SET NULL,
  creative_id uuid REFERENCES ad_creatives(id) ON DELETE SET NULL,
  stat_date date NOT NULL,
  impressions bigint DEFAULT 0,
  clicks bigint DEFAULT 0,
  conversions integer DEFAULT 0,
  spend numeric(12,2) DEFAULT 0,
  revenue numeric(12,2) DEFAULT 0,
  ctr numeric(8,4) DEFAULT 0,
  cpc numeric(12,2) DEFAULT 0,
  cpm numeric(12,2) DEFAULT 0,
  cpa numeric(12,2) DEFAULT 0,
  roas numeric(12,2) DEFAULT 0,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  UNIQUE(campaign_id, ad_group_id, creative_id, stat_date)
);

-- 7. 自动化规则表
CREATE TABLE IF NOT EXISTS ad_automation_rules (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  domain_id uuid REFERENCES sys_domains(id) ON DELETE CASCADE,
  rule_name text NOT NULL,
  rule_type text NOT NULL CHECK (rule_type IN ('budget', 'bid', 'status', 'alert')),
  target_level text NOT NULL CHECK (target_level IN ('campaign', 'ad_group', 'creative')),
  target_ids jsonb DEFAULT '[]',
  conditions jsonb NOT NULL,
  actions jsonb NOT NULL,
  frequency text DEFAULT 'daily' CHECK (frequency IN ('hourly', 'daily', 'weekly')),
  is_enabled boolean DEFAULT true,
  last_executed_at timestamptz,
  created_by uuid REFERENCES sys_admins(id) ON DELETE SET NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- 8. 优化日志表
CREATE TABLE IF NOT EXISTS ad_optimization_logs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  domain_id uuid REFERENCES sys_domains(id) ON DELETE CASCADE,
  rule_id uuid REFERENCES ad_automation_rules(id) ON DELETE SET NULL,
  campaign_id uuid REFERENCES ad_campaigns(id) ON DELETE SET NULL,
  optimization_type text NOT NULL,
  action_taken text NOT NULL,
  before_value jsonb DEFAULT '{}',
  after_value jsonb DEFAULT '{}',
  reason text,
  impact_score numeric(5,2),
  created_at timestamptz DEFAULT now()
);

-- 启用RLS
ALTER TABLE ad_platforms ENABLE ROW LEVEL SECURITY;
ALTER TABLE ad_accounts ENABLE ROW LEVEL SECURITY;
ALTER TABLE ad_campaigns ENABLE ROW LEVEL SECURITY;
ALTER TABLE ad_groups ENABLE ROW LEVEL SECURITY;
ALTER TABLE ad_creatives ENABLE ROW LEVEL SECURITY;
ALTER TABLE ad_stats ENABLE ROW LEVEL SECURITY;
ALTER TABLE ad_automation_rules ENABLE ROW LEVEL SECURITY;
ALTER TABLE ad_optimization_logs ENABLE ROW LEVEL SECURITY;

-- 创建索引
CREATE INDEX IF NOT EXISTS idx_ad_accounts_domain ON ad_accounts(domain_id);
CREATE INDEX IF NOT EXISTS idx_ad_accounts_platform ON ad_accounts(platform_id);
CREATE INDEX IF NOT EXISTS idx_ad_campaigns_domain ON ad_campaigns(domain_id);
CREATE INDEX IF NOT EXISTS idx_ad_campaigns_account ON ad_campaigns(account_id);
CREATE INDEX IF NOT EXISTS idx_ad_campaigns_status ON ad_campaigns(status);
CREATE INDEX IF NOT EXISTS idx_ad_groups_campaign ON ad_groups(campaign_id);
CREATE INDEX IF NOT EXISTS idx_ad_creatives_group ON ad_creatives(ad_group_id);
CREATE INDEX IF NOT EXISTS idx_ad_stats_campaign ON ad_stats(campaign_id);
CREATE INDEX IF NOT EXISTS idx_ad_stats_date ON ad_stats(stat_date);
CREATE INDEX IF NOT EXISTS idx_ad_automation_rules_domain ON ad_automation_rules(domain_id);

-- RLS 策略 - ad_platforms (所有人可读)
CREATE POLICY "Anyone can read platforms"
  ON ad_platforms FOR SELECT
  USING (true);

-- RLS 策略 - ad_accounts
CREATE POLICY "Users can view own domain ad accounts"
  ON ad_accounts FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM sys_admin_domains ad
      WHERE ad.admin_id = auth.uid()
      AND ad.domain_id = ad_accounts.domain_id
    )
  );

CREATE POLICY "Users can insert own domain ad accounts"
  ON ad_accounts FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM sys_admin_domains ad
      WHERE ad.admin_id = auth.uid()
      AND ad.domain_id = ad_accounts.domain_id
    )
  );

CREATE POLICY "Users can update own domain ad accounts"
  ON ad_accounts FOR UPDATE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM sys_admin_domains ad
      WHERE ad.admin_id = auth.uid()
      AND ad.domain_id = ad_accounts.domain_id
    )
  );

-- RLS 策略 - ad_campaigns
CREATE POLICY "Users can view own domain campaigns"
  ON ad_campaigns FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM sys_admin_domains ad
      WHERE ad.admin_id = auth.uid()
      AND ad.domain_id = ad_campaigns.domain_id
    )
  );

CREATE POLICY "Users can insert own domain campaigns"
  ON ad_campaigns FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM sys_admin_domains ad
      WHERE ad.admin_id = auth.uid()
      AND ad.domain_id = ad_campaigns.domain_id
    )
  );

CREATE POLICY "Users can update own domain campaigns"
  ON ad_campaigns FOR UPDATE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM sys_admin_domains ad
      WHERE ad.admin_id = auth.uid()
      AND ad.domain_id = ad_campaigns.domain_id
    )
  );

-- RLS 策略 - ad_groups
CREATE POLICY "Users can view own domain ad groups"
  ON ad_groups FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM sys_admin_domains ad
      WHERE ad.admin_id = auth.uid()
      AND ad.domain_id = ad_groups.domain_id
    )
  );

CREATE POLICY "Users can manage own domain ad groups"
  ON ad_groups FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM sys_admin_domains ad
      WHERE ad.admin_id = auth.uid()
      AND ad.domain_id = ad_groups.domain_id
    )
  );

-- RLS 策略 - ad_creatives
CREATE POLICY "Users can view own domain creatives"
  ON ad_creatives FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM sys_admin_domains ad
      WHERE ad.admin_id = auth.uid()
      AND ad.domain_id = ad_creatives.domain_id
    )
  );

CREATE POLICY "Users can manage own domain creatives"
  ON ad_creatives FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM sys_admin_domains ad
      WHERE ad.admin_id = auth.uid()
      AND ad.domain_id = ad_creatives.domain_id
    )
  );

-- RLS 策略 - ad_stats
CREATE POLICY "Users can view own domain stats"
  ON ad_stats FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM sys_admin_domains ad
      WHERE ad.admin_id = auth.uid()
      AND ad.domain_id = ad_stats.domain_id
    )
  );

CREATE POLICY "Users can insert own domain stats"
  ON ad_stats FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM sys_admin_domains ad
      WHERE ad.admin_id = auth.uid()
      AND ad.domain_id = ad_stats.domain_id
    )
  );

-- RLS 策略 - ad_automation_rules
CREATE POLICY "Users can view own domain rules"
  ON ad_automation_rules FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM sys_admin_domains ad
      WHERE ad.admin_id = auth.uid()
      AND ad.domain_id = ad_automation_rules.domain_id
    )
  );

CREATE POLICY "Users can manage own domain rules"
  ON ad_automation_rules FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM sys_admin_domains ad
      WHERE ad.admin_id = auth.uid()
      AND ad.domain_id = ad_automation_rules.domain_id
    )
  );

-- RLS 策略 - ad_optimization_logs
CREATE POLICY "Users can view own domain optimization logs"
  ON ad_optimization_logs FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM sys_admin_domains ad
      WHERE ad.admin_id = auth.uid()
      AND ad.domain_id = ad_optimization_logs.domain_id
    )
  );

-- 插入默认广告平台
INSERT INTO ad_platforms (platform_code, platform_name, platform_name_cn, description, support_auto_optimize) VALUES
  ('facebook', 'Facebook Ads', 'Facebook广告', 'Facebook广告平台，包括Facebook和Instagram', true),
  ('google', 'Google Ads', '谷歌广告', 'Google Ads搜索和展示广告', true),
  ('tiktok', 'TikTok Ads', 'TikTok广告', 'TikTok短视频广告平台', true),
  ('wechat', 'WeChat Ads', '微信广告', '微信朋友圈和公众号广告', false),
  ('xiaohongshu', 'Xiaohongshu', '小红书广告', '小红书种草广告平台', false),
  ('douyin', 'Douyin Ads', '抖音广告', '抖音短视频广告平台', true),
  ('baidu', 'Baidu Ads', '百度推广', '百度搜索推广', false),
  ('taobao', 'Taobao Ads', '淘宝直通车', '淘宝站内推广', false)
ON CONFLICT (platform_code) DO NOTHING;