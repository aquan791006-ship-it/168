/*
  # 初始化核心模块数据
  
  将现有的系统功能注册为可插拔模块
*/

-- 1. 核心系统模块
INSERT INTO sys_modules (module_key, module_name, description, category, icon, color, status, is_core, is_system, module_version, module_type)
VALUES 
  ('core.system', 
   '{"zh": "系统核心", "en": "System Core"}',
   '{"zh": "系统核心功能，包括用户管理、权限控制等", "en": "Core system functionalities"}',
   'system', 'Settings', '#1E40AF', 'enabled', true, true, '1.0.0', 'full'),
  
  ('core.dashboard',
   '{"zh": "数据仪表板", "en": "Dashboard"}',
   '{"zh": "系统数据可视化仪表板", "en": "System data visualization dashboard"}',
   'analytics', 'BarChart', '#3B82F6', 'enabled', true, false, '1.0.0', 'frontend_only');

-- 2. 业务模块
INSERT INTO sys_modules (module_key, module_name, description, category, icon, color, status, is_core, module_version, module_type)
VALUES 
  ('module.products',
   '{"zh": "商品管理", "en": "Product Management"}',
   '{"zh": "商品信息、SKU、库存管理", "en": "Product info, SKU, inventory management"}',
   'business', 'Package', '#10B981', 'enabled', false, '1.0.0', 'full'),
  
  ('module.orders',
   '{"zh": "订单管理", "en": "Order Management"}',
   '{"zh": "订单处理、状态跟踪、支付管理", "en": "Order processing, status tracking"}',
   'sales', 'ShoppingCart', '#F59E0B', 'enabled', false, '1.0.0', 'full'),
  
  ('module.warehouses',
   '{"zh": "仓储管理", "en": "Warehouse Management"}',
   '{"zh": "仓库、库存、出入库管理", "en": "Warehouse, inventory, inbound/outbound"}',
   'supply_chain', 'Building', '#8B5CF6', 'enabled', false, '1.0.0', 'full'),
  
  ('module.logistics',
   '{"zh": "物流管理", "en": "Logistics Management"}',
   '{"zh": "物流跟踪、配送管理", "en": "Logistics tracking and delivery"}',
   'supply_chain', 'Truck', '#EC4899', 'enabled', false, '1.0.0', 'full'),
  
  ('module.customer_service',
   '{"zh": "客户服务", "en": "Customer Service"}',
   '{"zh": "客服工单、在线咨询、客户关系管理", "en": "Customer support and CRM"}',
   'business', 'Headphones', '#06B6D4', 'enabled', false, '1.0.0', 'full'),
  
  ('module.promotions',
   '{"zh": "营销推广", "en": "Marketing & Promotions"}',
   '{"zh": "优惠券、活动、营销工具", "en": "Coupons, campaigns, marketing tools"}',
   'sales', 'Megaphone', '#F43F5E', 'enabled', false, '1.0.0', 'full'),
  
  ('module.analytics',
   '{"zh": "数据分析", "en": "Analytics"}',
   '{"zh": "业务数据分析、报表、BI", "en": "Business analytics and reporting"}',
   'analytics', 'TrendingUp', '#6366F1', 'enabled', false, '1.0.0', 'frontend_only'),
  
  ('module.smart_purchase',
   '{"zh": "智能采购", "en": "Smart Purchase"}',
   '{"zh": "供应商商品抓取、自动定价、智能补货", "en": "Smart procurement and auto-pricing"}',
   'supply_chain', 'ShoppingCart', '#14B8A6', 'enabled', false, '1.0.0', 'full'),
  
  ('module.product_fields',
   '{"zh": "商品字段配置", "en": "Product Field Config"}',
   '{"zh": "动态配置商品表单字段", "en": "Dynamic product field configuration"}',
   'system', 'Settings', '#84CC16', 'enabled', false, '1.0.0', 'frontend_only'),
  
  ('module.stock_alerts',
   '{"zh": "库存预警", "en": "Stock Alerts"}',
   '{"zh": "实时库存监控、自动预警、智能补货", "en": "Real-time stock monitoring and alerts"}',
   'supply_chain', 'AlertTriangle', '#EAB308', 'enabled', false, '1.0.0', 'full');

-- 3. 注册模块路由
INSERT INTO sys_module_routes (module_id, route_path, component_name, menu_label, menu_icon, menu_order, is_menu_item)
SELECT 
  m.id,
  '/admin/dashboard',
  'Dashboard',
  '{"zh": "仪表板", "en": "Dashboard"}',
  'BarChart',
  1,
  true
FROM sys_modules m WHERE m.module_key = 'core.dashboard';

INSERT INTO sys_module_routes (module_id, route_path, component_name, menu_label, menu_icon, menu_order, is_menu_item)
SELECT 
  m.id,
  '/admin/products',
  'Products',
  '{"zh": "商品管理", "en": "Products"}',
  'Package',
  10,
  true
FROM sys_modules m WHERE m.module_key = 'module.products';

INSERT INTO sys_module_routes (module_id, route_path, component_name, menu_label, menu_icon, menu_order, is_menu_item)
SELECT 
  m.id,
  '/admin/product-fields',
  'ProductFieldConfig',
  '{"zh": "字段配置", "en": "Field Config"}',
  'Settings',
  11,
  true
FROM sys_modules m WHERE m.module_key = 'module.product_fields';

INSERT INTO sys_module_routes (module_id, route_path, component_name, menu_label, menu_icon, menu_order, is_menu_item)
SELECT 
  m.id,
  '/admin/smart-purchase',
  'SmartPurchase',
  '{"zh": "智能采购", "en": "Smart Purchase"}',
  'ShoppingCart',
  20,
  true
FROM sys_modules m WHERE m.module_key = 'module.smart_purchase';

INSERT INTO sys_module_routes (module_id, route_path, component_name, menu_label, menu_icon, menu_order, is_menu_item)
SELECT 
  m.id,
  '/admin/orders',
  'Orders',
  '{"zh": "订单管理", "en": "Orders"}',
  'ShoppingCart',
  30,
  true
FROM sys_modules m WHERE m.module_key = 'module.orders';

INSERT INTO sys_module_routes (module_id, route_path, component_name, menu_label, menu_icon, menu_order, is_menu_item)
SELECT 
  m.id,
  '/admin/warehouses',
  'Warehouses',
  '{"zh": "仓储管理", "en": "Warehouses"}',
  'Building',
  40,
  true
FROM sys_modules m WHERE m.module_key = 'module.warehouses';

INSERT INTO sys_module_routes (module_id, route_path, component_name, menu_label, menu_icon, menu_order, is_menu_item)
SELECT 
  m.id,
  '/admin/stock-alerts',
  'StockAlerts',
  '{"zh": "库存预警", "en": "Stock Alerts"}',
  'AlertTriangle',
  41,
  true
FROM sys_modules m WHERE m.module_key = 'module.stock_alerts';

INSERT INTO sys_module_routes (module_id, route_path, component_name, menu_label, menu_icon, menu_order, is_menu_item)
SELECT 
  m.id,
  '/admin/logistics',
  'Logistics',
  '{"zh": "物流管理", "en": "Logistics"}',
  'Truck',
  50,
  true
FROM sys_modules m WHERE m.module_key = 'module.logistics';

INSERT INTO sys_module_routes (module_id, route_path, component_name, menu_label, menu_icon, menu_order, is_menu_item)
SELECT 
  m.id,
  '/admin/customer-service',
  'CustomerService',
  '{"zh": "客户服务", "en": "Customer Service"}',
  'Headphones',
  60,
  true
FROM sys_modules m WHERE m.module_key = 'module.customer_service';

INSERT INTO sys_module_routes (module_id, route_path, component_name, menu_label, menu_icon, menu_order, is_menu_item)
SELECT 
  m.id,
  '/admin/promotions',
  'Promotions',
  '{"zh": "营销推广", "en": "Promotions"}',
  'Megaphone',
  70,
  true
FROM sys_modules m WHERE m.module_key = 'module.promotions';

INSERT INTO sys_module_routes (module_id, route_path, component_name, menu_label, menu_icon, menu_order, is_menu_item)
SELECT 
  m.id,
  '/admin/analytics',
  'Analytics',
  '{"zh": "数据分析", "en": "Analytics"}',
  'TrendingUp',
  80,
  true
FROM sys_modules m WHERE m.module_key = 'module.analytics';

INSERT INTO sys_module_routes (module_id, route_path, component_name, menu_label, menu_icon, menu_order, is_menu_item)
SELECT 
  m.id,
  '/admin/settings',
  'Settings',
  '{"zh": "系统设置", "en": "Settings"}',
  'Settings',
  90,
  true
FROM sys_modules m WHERE m.module_key = 'core.system';

-- 4. 设置模块依赖关系
INSERT INTO sys_module_dependencies (module_id, depends_on_module_id, dependency_type)
SELECT 
  m1.id,
  m2.id,
  'required'
FROM sys_modules m1
CROSS JOIN sys_modules m2
WHERE m1.module_key = 'module.products'
  AND m2.module_key = 'core.system';

INSERT INTO sys_module_dependencies (module_id, depends_on_module_id, dependency_type)
SELECT 
  m1.id,
  m2.id,
  'required'
FROM sys_modules m1
CROSS JOIN sys_modules m2
WHERE m1.module_key = 'module.smart_purchase'
  AND m2.module_key = 'module.products';

INSERT INTO sys_module_dependencies (module_id, depends_on_module_id, dependency_type)
SELECT 
  m1.id,
  m2.id,
  'required'
FROM sys_modules m1
CROSS JOIN sys_modules m2
WHERE m1.module_key = 'module.stock_alerts'
  AND m2.module_key = 'module.warehouses';

INSERT INTO sys_module_dependencies (module_id, depends_on_module_id, dependency_type)
SELECT 
  m1.id,
  m2.id,
  'required'
FROM sys_modules m1
CROSS JOIN sys_modules m2
WHERE m1.module_key = 'module.orders'
  AND m2.module_key = 'module.products';

-- 5. 注册模块权限
INSERT INTO sys_module_permissions (module_id, permission_key, permission_name, description, permission_type)
SELECT 
  m.id,
  'products.view',
  '{"zh": "查看商品", "en": "View Products"}',
  '{"zh": "允许查看商品列表和详情", "en": "Allow viewing products"}',
  'data'
FROM sys_modules m WHERE m.module_key = 'module.products';

INSERT INTO sys_module_permissions (module_id, permission_key, permission_name, description, permission_type)
SELECT 
  m.id,
  'products.create',
  '{"zh": "创建商品", "en": "Create Products"}',
  '{"zh": "允许创建新商品", "en": "Allow creating products"}',
  'action'
FROM sys_modules m WHERE m.module_key = 'module.products';

INSERT INTO sys_module_permissions (module_id, permission_key, permission_name, description, permission_type)
SELECT 
  m.id,
  'orders.view',
  '{"zh": "查看订单", "en": "View Orders"}',
  '{"zh": "允许查看订单列表和详情", "en": "Allow viewing orders"}',
  'data'
FROM sys_modules m WHERE m.module_key = 'module.orders';

INSERT INTO sys_module_permissions (module_id, permission_key, permission_name, description, permission_type)
SELECT 
  m.id,
  'orders.manage',
  '{"zh": "管理订单", "en": "Manage Orders"}',
  '{"zh": "允许修改订单状态", "en": "Allow managing order status"}',
  'action'
FROM sys_modules m WHERE m.module_key = 'module.orders';
