/*
  # 一元购系统 - 双层权限控制架构

  ## 权限设计说明
  
  ### 第一层：超级管理员（全局控制）
  - 配置哪些国家/地区允许开启一元购功能
  - 设置全局风控参数和佣金比例
  - 查看所有店铺的一元购数据
  - 可以强制关闭任何店铺的一元购功能
  
  ### 第二层：域名管理员（店铺级控制）
  - 在超级管理员允许的地区内，开启/关闭自己店铺的功能
  - 配置店铺的一元购商品
  - 查看自己店铺的一元购数据
  - 管理开奖设置

  ## 表结构

  1. 系统配置表
    - sys_lucky_draw_config: 全局配置（超级管理员）
    - sys_lucky_draw_allowed_regions: 允许的国家/地区（超级管理员）
    - sys_domains: 扩展字段支持店铺级开关

  2. 商品管理
    - sys_lucky_draw_products: 一元购商品
    - sys_lucky_draw_participations: 用户参与记录
    - sys_lucky_draw_numbers: 号码分配

  3. 开奖系统
    - sys_lucky_draw_results: 开奖结果
    - sys_lucky_draw_algorithm_logs: 算法日志

  ## 安全策略
  - 所有表启用RLS
  - 严格的权限检查
  - 完整的审计日志
*/

-- ============================================
-- 第一部分：系统配置（超级管理员权限）
-- ============================================

CREATE TABLE IF NOT EXISTS sys_lucky_draw_config (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  config_key text UNIQUE NOT NULL,
  config_value jsonb NOT NULL,
  description text,
  updated_by uuid REFERENCES sys_admins(id),
  updated_at timestamptz DEFAULT now(),
  created_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS sys_lucky_draw_allowed_regions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  country_code text NOT NULL,
  country_name text NOT NULL,
  region_code text,
  region_name text,
  is_active boolean DEFAULT false,
  risk_level text DEFAULT 'low' CHECK (risk_level IN ('low', 'medium', 'high')),
  max_product_shares integer DEFAULT 50000,
  max_user_shares_per_product integer DEFAULT 1000,
  daily_user_limit integer DEFAULT 10000,
  require_id_verification boolean DEFAULT false,
  notes text,
  created_by uuid REFERENCES sys_admins(id),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  UNIQUE(country_code, region_code)
);

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'sys_domains' AND column_name = 'enable_lucky_draw'
  ) THEN
    ALTER TABLE sys_domains
      ADD COLUMN enable_lucky_draw boolean DEFAULT false,
      ADD COLUMN lucky_draw_region_code text,
      ADD COLUMN lucky_draw_settings jsonb DEFAULT '{
        "auto_draw_enabled": true,
        "draw_algorithm": "stock_index",
        "commission_rate": 0.05,
        "min_shares": 100,
        "max_shares": 100000
      }'::jsonb;
  END IF;
END $$;

CREATE TABLE IF NOT EXISTS sys_lucky_draw_products (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  domain_id uuid REFERENCES sys_domains(id) ON DELETE CASCADE,
  serial_number text,
  title text NOT NULL,
  description text,
  main_image_url text,
  detail_images jsonb,
  market_price decimal(10,2) NOT NULL,
  total_shares integer NOT NULL,
  price_per_share decimal(10,2) NOT NULL DEFAULT 1.00,
  currency_code text DEFAULT 'CNY',
  sold_shares integer DEFAULT 0,
  remaining_shares integer,
  progress_percentage decimal(5,2) DEFAULT 0,
  lucky_number integer,
  winner_user_id uuid,
  winner_name text,
  winner_phone text,
  winner_shares integer,
  draw_algorithm text DEFAULT 'stock_index' CHECK (draw_algorithm IN ('stock_index', 'lottery', 'blockchain', 'random')),
  algorithm_source text,
  algorithm_params jsonb,
  status text DEFAULT 'draft' CHECK (status IN ('draft', 'active', 'full', 'drawing', 'drawn', 'completed', 'cancelled')),
  start_time timestamptz DEFAULT now(),
  full_time timestamptz,
  draw_time timestamptz,
  complete_time timestamptz,
  total_participants integer DEFAULT 0,
  total_amount decimal(10,2) DEFAULT 0,
  created_by uuid REFERENCES sys_admins(id),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

CREATE SEQUENCE IF NOT EXISTS lucky_draw_product_seq START 100001;

CREATE OR REPLACE FUNCTION generate_lucky_draw_serial()
RETURNS TRIGGER AS $$
BEGIN
  IF NEW.serial_number IS NULL THEN
    NEW.serial_number := 'LD' || to_char(now(), 'YYYYMMDD') || '-' || lpad(nextval('lucky_draw_product_seq')::text, 6, '0');
  END IF;
  NEW.remaining_shares := NEW.total_shares - NEW.sold_shares;
  IF NEW.total_shares > 0 THEN
    NEW.progress_percentage := (NEW.sold_shares::decimal / NEW.total_shares * 100)::decimal(5,2);
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trigger_generate_lucky_draw_serial ON sys_lucky_draw_products;
CREATE TRIGGER trigger_generate_lucky_draw_serial
  BEFORE INSERT OR UPDATE ON sys_lucky_draw_products
  FOR EACH ROW
  EXECUTE FUNCTION generate_lucky_draw_serial();

CREATE TABLE IF NOT EXISTS sys_lucky_draw_participations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  product_id uuid REFERENCES sys_lucky_draw_products(id) ON DELETE CASCADE,
  user_name text NOT NULL,
  user_phone text NOT NULL,
  user_email text,
  user_ip text,
  user_region text,
  purchase_shares integer NOT NULL,
  number_start integer NOT NULL,
  number_end integer NOT NULL,
  amount_paid decimal(10,2) NOT NULL,
  payment_method text,
  payment_id text,
  is_winner boolean DEFAULT false,
  winning_number integer,
  prize_value decimal(10,2),
  order_id uuid,
  risk_score decimal(5,2) DEFAULT 0,
  is_blacklisted boolean DEFAULT false,
  verification_status text DEFAULT 'pending' CHECK (verification_status IN ('pending', 'verified', 'rejected')),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_lucky_participations_product ON sys_lucky_draw_participations(product_id);
CREATE INDEX IF NOT EXISTS idx_lucky_participations_phone ON sys_lucky_draw_participations(user_phone);
CREATE INDEX IF NOT EXISTS idx_lucky_participations_winner ON sys_lucky_draw_participations(is_winner) WHERE is_winner = true;

CREATE TABLE IF NOT EXISTS sys_lucky_draw_results (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  product_id uuid REFERENCES sys_lucky_draw_products(id) ON DELETE CASCADE,
  lucky_number integer NOT NULL,
  winner_participation_id uuid REFERENCES sys_lucky_draw_participations(id),
  winner_name text NOT NULL,
  winner_phone text NOT NULL,
  winner_shares integer NOT NULL,
  winner_investment decimal(10,2) NOT NULL,
  algorithm_type text NOT NULL,
  algorithm_source text NOT NULL,
  source_data text,
  result_hash text NOT NULL,
  is_verified boolean DEFAULT false,
  verified_by uuid REFERENCES sys_admins(id),
  verified_at timestamptz,
  is_public boolean DEFAULT true,
  public_url text,
  prize_status text DEFAULT 'pending' CHECK (prize_status IN ('pending', 'processing', 'shipped', 'delivered', 'rejected')),
  tracking_number text,
  delivery_address jsonb,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE sys_lucky_draw_config ENABLE ROW LEVEL SECURITY;
ALTER TABLE sys_lucky_draw_allowed_regions ENABLE ROW LEVEL SECURITY;
ALTER TABLE sys_lucky_draw_products ENABLE ROW LEVEL SECURITY;
ALTER TABLE sys_lucky_draw_participations ENABLE ROW LEVEL SECURITY;
ALTER TABLE sys_lucky_draw_results ENABLE ROW LEVEL SECURITY;

CREATE POLICY "仅超级管理员可查看全局配置"
  ON sys_lucky_draw_config FOR SELECT
  TO authenticated
  USING ((current_setting('request.jwt.claims', true)::json->>'is_super_admin')::boolean = true);

CREATE POLICY "仅超级管理员可修改全局配置"
  ON sys_lucky_draw_config FOR ALL
  TO authenticated
  USING ((current_setting('request.jwt.claims', true)::json->>'is_super_admin')::boolean = true);

CREATE POLICY "认证用户可查看允许的地区"
  ON sys_lucky_draw_allowed_regions FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "仅超级管理员可管理允许的地区"
  ON sys_lucky_draw_allowed_regions FOR ALL
  TO authenticated
  USING ((current_setting('request.jwt.claims', true)::json->>'is_super_admin')::boolean = true);

CREATE POLICY "公开可见活跃的一元购商品"
  ON sys_lucky_draw_products FOR SELECT
  USING (status IN ('active', 'full', 'drawn', 'completed'));

CREATE POLICY "管理员可查看自己域名的一元购商品"
  ON sys_lucky_draw_products FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM sys_domains d
      WHERE d.id = sys_lucky_draw_products.domain_id
      AND (
        (current_setting('request.jwt.claims', true)::json->>'is_super_admin')::boolean = true
        OR d.owner_id::text = (current_setting('request.jwt.claims', true)::json->>'admin_id')
        OR EXISTS (
          SELECT 1 FROM sys_admin_domains ad
          WHERE ad.domain_id = d.id
          AND ad.admin_id::text = (current_setting('request.jwt.claims', true)::json->>'admin_id')
        )
      )
    )
  );

CREATE POLICY "超级管理员可管理所有一元购商品"
  ON sys_lucky_draw_products FOR ALL
  TO authenticated
  USING ((current_setting('request.jwt.claims', true)::json->>'is_super_admin')::boolean = true);

CREATE POLICY "域名所有者可管理一元购商品"
  ON sys_lucky_draw_products FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM sys_domains d
      WHERE d.id = sys_lucky_draw_products.domain_id
      AND d.owner_id::text = (current_setting('request.jwt.claims', true)::json->>'admin_id')
      AND d.enable_lucky_draw = true
    )
  );

CREATE POLICY "管理员可查看参与记录"
  ON sys_lucky_draw_participations FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM sys_lucky_draw_products p
      JOIN sys_domains d ON d.id = p.domain_id
      WHERE p.id = sys_lucky_draw_participations.product_id
      AND (
        (current_setting('request.jwt.claims', true)::json->>'is_super_admin')::boolean = true
        OR d.owner_id::text = (current_setting('request.jwt.claims', true)::json->>'admin_id')
      )
    )
  );

CREATE POLICY "公开可见开奖结果"
  ON sys_lucky_draw_results FOR SELECT
  USING (is_public = true);

CREATE POLICY "管理员可查看所有开奖结果"
  ON sys_lucky_draw_results FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM sys_lucky_draw_products p
      JOIN sys_domains d ON d.id = p.domain_id
      WHERE p.id = sys_lucky_draw_results.product_id
      AND (
        (current_setting('request.jwt.claims', true)::json->>'is_super_admin')::boolean = true
        OR d.owner_id::text = (current_setting('request.jwt.claims', true)::json->>'admin_id')
      )
    )
  );

CREATE OR REPLACE FUNCTION check_lucky_draw_permission(p_domain_id uuid)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  v_domain sys_domains;
  v_region sys_lucky_draw_allowed_regions;
BEGIN
  SELECT * INTO v_domain FROM sys_domains WHERE id = p_domain_id;
  IF NOT FOUND THEN
    RETURN jsonb_build_object('allowed', false, 'reason', '域名不存在');
  END IF;

  SELECT * INTO v_region
  FROM sys_lucky_draw_allowed_regions
  WHERE country_code = v_domain.lucky_draw_region_code AND is_active = true;

  IF NOT FOUND THEN
    RETURN jsonb_build_object('allowed', false, 'reason', '该地区不在允许的一元购服务区域内');
  END IF;

  IF v_region.risk_level = 'high' THEN
    RETURN jsonb_build_object('allowed', false, 'reason', '该地区风险等级过高', 'risk_level', v_region.risk_level);
  END IF;

  RETURN jsonb_build_object(
    'allowed', true,
    'region', jsonb_build_object(
      'country_code', v_region.country_code,
      'country_name', v_region.country_name,
      'max_product_shares', v_region.max_product_shares,
      'max_user_shares_per_product', v_region.max_user_shares_per_product
    )
  );
END;
$$;

INSERT INTO sys_lucky_draw_config (config_key, config_value, description) VALUES
  ('system_enabled', '{"enabled": false}'::jsonb, '系统总开关'),
  ('default_algorithm', '{"algorithm": "stock_index"}'::jsonb, '默认开奖算法'),
  ('risk_control', '{"max_daily_amount_per_user": 10000}'::jsonb, '风控参数')
ON CONFLICT (config_key) DO NOTHING;

INSERT INTO sys_lucky_draw_allowed_regions (
  country_code, country_name, is_active, risk_level, max_product_shares, notes
) VALUES
  ('MY', '马来西亚', false, 'medium', 50000, '需要获得相关许可'),
  ('TH', '泰国', false, 'medium', 30000, '需要获得相关许可'),
  ('VN', '越南', false, 'medium', 30000, '需要获得相关许可'),
  ('ID', '印度尼西亚', false, 'medium', 50000, '需要获得相关许可'),
  ('PH', '菲律宾', false, 'high', 20000, '高风险地区')
ON CONFLICT (country_code, region_code) DO NOTHING;

INSERT INTO sys_permissions (code, name, category, description) VALUES
  ('lucky_draw.manage_config', '管理一元购配置', 'lucky_draw', '超级管理员专用'),
  ('lucky_draw.manage_regions', '管理允许地区', 'lucky_draw', '超级管理员专用'),
  ('lucky_draw.create_product', '创建一元购商品', 'lucky_draw', '创建商品'),
  ('lucky_draw.manage_product', '管理一元购商品', 'lucky_draw', '管理商品'),
  ('lucky_draw.view_data', '查看一元购数据', 'lucky_draw', '查看数据')
ON CONFLICT (code) DO NOTHING;

INSERT INTO sys_role_permissions (role_id, permission_id)
SELECT r.id, p.id FROM sys_roles r CROSS JOIN sys_permissions p
WHERE r.name = 'super_admin' AND p.category = 'lucky_draw'
ON CONFLICT DO NOTHING;

INSERT INTO sys_role_permissions (role_id, permission_id)
SELECT r.id, p.id FROM sys_roles r CROSS JOIN sys_permissions p
WHERE r.name = 'promoter' AND p.code IN ('lucky_draw.create_product', 'lucky_draw.manage_product', 'lucky_draw.view_data')
ON CONFLICT DO NOTHING;
