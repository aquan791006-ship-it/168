/*
  # 添加公开商城访问权限

  ## 变更内容
  1. RLS策略变更
    - 允许匿名用户查看已发布的产品（状态为active）
    - 允许匿名用户查看产品图片
    - 允许匿名用户查看产品SKU
    - 允许匿名用户查看产品模块

  ## 安全考虑
  - 只开放status='active'的产品给公众
  - 不暴露任何管理员信息
  - 保持其他表的访问限制不变
*/

-- 允许匿名用户查看已发布的产品
CREATE POLICY "公众可查看已发布产品"
  ON sys_products FOR SELECT
  TO anon
  USING (status = 'active');

-- 允许匿名用户查看产品图片
CREATE POLICY "公众可查看产品图片"
  ON sys_product_images FOR SELECT
  TO anon
  USING (
    EXISTS (
      SELECT 1 FROM sys_products
      WHERE sys_products.id = sys_product_images.product_id
      AND sys_products.status = 'active'
    )
  );

-- 允许匿名用户查看产品SKU
CREATE POLICY "公众可查看产品SKU"
  ON sys_product_skus FOR SELECT
  TO anon
  USING (
    is_enabled = true
    AND EXISTS (
      SELECT 1 FROM sys_products
      WHERE sys_products.id = sys_product_skus.product_id
      AND sys_products.status = 'active'
    )
  );

-- 允许匿名用户查看产品模块
CREATE POLICY "公众可查看产品模块"
  ON sys_product_modules FOR SELECT
  TO anon
  USING (
    is_enabled = true
    AND EXISTS (
      SELECT 1 FROM sys_products
      WHERE sys_products.id = sys_product_modules.product_id
      AND sys_products.status = 'active'
    )
  );