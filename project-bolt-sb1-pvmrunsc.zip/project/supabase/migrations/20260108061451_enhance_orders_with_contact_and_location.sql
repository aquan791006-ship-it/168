/*
  # 增强订单系统 - 支持联系方式类型和国家信息

  ## 功能说明
  为订单表添加联系方式类型、国家、地址详情等字段，支持更灵活的订单管理

  ## 新增字段
  1. contact_type - 联系方式类型（phone/telegram/whatsapp/wechat）
  2. shipping_country - 配送国家代码
  3. shipping_province - 配送省份
  4. shipping_city - 配送城市
  5. shipping_district - 配送区县
  6. shipping_street - 配送街道
  7. shipping_detail - 详细地址
  8. notes - 订单备注

  ## 修改内容
  1. 检查并添加新字段到orders表
  2. 添加字段注释说明
  3. 创建索引提升查询性能
*/

-- 1. 为orders表添加contact_type字段（联系方式类型）
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'orders' AND column_name = 'contact_type'
  ) THEN
    ALTER TABLE orders ADD COLUMN contact_type text DEFAULT 'phone';
  END IF;
END $$;

COMMENT ON COLUMN orders.contact_type IS '联系方式类型: phone(电话), telegram(Telegram), whatsapp(WhatsApp), wechat(微信)';

-- 2. 为orders表添加shipping_country字段（配送国家）
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'orders' AND column_name = 'shipping_country'
  ) THEN
    ALTER TABLE orders ADD COLUMN shipping_country text DEFAULT 'CN';
  END IF;
END $$;

COMMENT ON COLUMN orders.shipping_country IS '配送国家代码，如：CN(中国)、US(美国)等';

-- 3. 为orders表添加shipping_province字段（配送省份）
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'orders' AND column_name = 'shipping_province'
  ) THEN
    ALTER TABLE orders ADD COLUMN shipping_province text;
  END IF;
END $$;

COMMENT ON COLUMN orders.shipping_province IS '配送省份/州';

-- 4. 为orders表添加shipping_city字段（配送城市）
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'orders' AND column_name = 'shipping_city'
  ) THEN
    ALTER TABLE orders ADD COLUMN shipping_city text;
  END IF;
END $$;

COMMENT ON COLUMN orders.shipping_city IS '配送城市';

-- 5. 为orders表添加shipping_district字段（配送区县）
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'orders' AND column_name = 'shipping_district'
  ) THEN
    ALTER TABLE orders ADD COLUMN shipping_district text;
  END IF;
END $$;

COMMENT ON COLUMN orders.shipping_district IS '配送区/县';

-- 6. 为orders表添加shipping_street字段（配送街道）
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'orders' AND column_name = 'shipping_street'
  ) THEN
    ALTER TABLE orders ADD COLUMN shipping_street text;
  END IF;
END $$;

COMMENT ON COLUMN orders.shipping_street IS '配送街道/乡镇';

-- 7. 为orders表添加shipping_detail字段（详细地址）
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'orders' AND column_name = 'shipping_detail'
  ) THEN
    ALTER TABLE orders ADD COLUMN shipping_detail text;
  END IF;
END $$;

COMMENT ON COLUMN orders.shipping_detail IS '详细地址（门牌号、楼栋单元等）';

-- 8. 为orders表添加notes字段（订单备注）
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'orders' AND column_name = 'notes'
  ) THEN
    ALTER TABLE orders ADD COLUMN notes text;
  END IF;
END $$;

COMMENT ON COLUMN orders.notes IS '订单备注信息';

-- 9. 创建索引提升查询性能
CREATE INDEX IF NOT EXISTS idx_orders_shipping_country ON orders(shipping_country);
CREATE INDEX IF NOT EXISTS idx_orders_shipping_province ON orders(shipping_province);
CREATE INDEX IF NOT EXISTS idx_orders_shipping_city ON orders(shipping_city);
CREATE INDEX IF NOT EXISTS idx_orders_contact_type ON orders(contact_type);

-- 10. 创建联系方式类型验证函数
CREATE OR REPLACE FUNCTION validate_contact_type(p_type text)
RETURNS boolean AS $$
BEGIN
  RETURN p_type IN ('phone', 'telegram', 'whatsapp', 'wechat');
END;
$$ LANGUAGE plpgsql;

-- 11. 创建国家代码验证函数
CREATE OR REPLACE FUNCTION validate_country_code(p_code text)
RETURNS boolean AS $$
BEGIN
  -- 检查是否为2位字母的国家代码
  RETURN p_code ~ '^[A-Z]{2}$';
END;
$$ LANGUAGE plpgsql;