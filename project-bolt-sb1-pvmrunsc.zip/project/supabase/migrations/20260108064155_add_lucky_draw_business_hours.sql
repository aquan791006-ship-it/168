/*
  # 一元购系统 - 增加营业时间控制

  ## 功能说明
  为一元购系统增加营业时间控制，支持店铺管理员设置：
  - 每天几点开启
  - 每天几点关闭
  - 支持跨天营业（如：23:00 - 02:00）
  - 支持按星期配置不同营业时间
  - 支持临时暂停

  ## 新增字段
  1. sys_domains 扩展字段
    - lucky_draw_business_hours: 营业时间配置（jsonb）
    - lucky_draw_timezone: 时区设置

  ## 配置示例
  {
    "enabled": true,
    "timezone": "Asia/Kuala_Lumpur",
    "default_hours": {
      "open": "09:00",
      "close": "23:00"
    },
    "weekly_schedule": {
      "monday": {"open": "09:00", "close": "23:00", "enabled": true},
      "tuesday": {"open": "09:00", "close": "23:00", "enabled": true},
      "wednesday": {"open": "09:00", "close": "23:00", "enabled": true},
      "thursday": {"open": "09:00", "close": "23:00", "enabled": true},
      "friday": {"open": "09:00", "close": "23:00", "enabled": true},
      "saturday": {"open": "09:00", "close": "23:00", "enabled": true},
      "sunday": {"open": "09:00", "close": "23:00", "enabled": true}
    },
    "special_dates": [
      {"date": "2024-01-01", "enabled": false, "note": "New Year"}
    ]
  }
*/

-- ============================================
-- 扩展 sys_domains 表
-- ============================================

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'sys_domains' AND column_name = 'lucky_draw_business_hours'
  ) THEN
    ALTER TABLE sys_domains
      ADD COLUMN lucky_draw_business_hours jsonb DEFAULT '{
        "enabled": true,
        "timezone": "Asia/Kuala_Lumpur",
        "default_hours": {
          "open": "09:00",
          "close": "23:00"
        },
        "weekly_schedule": {
          "monday": {"open": "09:00", "close": "23:00", "enabled": true},
          "tuesday": {"open": "09:00", "close": "23:00", "enabled": true},
          "wednesday": {"open": "09:00", "close": "23:00", "enabled": true},
          "thursday": {"open": "09:00", "close": "23:00", "enabled": true},
          "friday": {"open": "09:00", "close": "23:00", "enabled": true},
          "saturday": {"open": "09:00", "close": "23:00", "enabled": true},
          "sunday": {"open": "09:00", "close": "23:00", "enabled": true}
        },
        "special_dates": []
      }'::jsonb,
      ADD COLUMN lucky_draw_timezone text DEFAULT 'Asia/Kuala_Lumpur';
  END IF;
END $$;

COMMENT ON COLUMN sys_domains.lucky_draw_business_hours IS '一元购营业时间配置，支持每天、每周、特殊日期设置';
COMMENT ON COLUMN sys_domains.lucky_draw_timezone IS '一元购时区设置，默认马来西亚时区';

-- ============================================
-- 扩展 sys_lucky_draw_products 表
-- ============================================

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'sys_lucky_draw_products' AND column_name = 'is_paused'
  ) THEN
    ALTER TABLE sys_lucky_draw_products
      ADD COLUMN is_paused boolean DEFAULT false,
      ADD COLUMN pause_reason text,
      ADD COLUMN paused_at timestamptz,
      ADD COLUMN paused_by uuid REFERENCES sys_admins(id);
  END IF;
END $$;

COMMENT ON COLUMN sys_lucky_draw_products.is_paused IS '是否临时暂停（不影响营业时间设置）';

-- ============================================
-- 营业时间检查函数
-- ============================================

CREATE OR REPLACE FUNCTION check_lucky_draw_business_hours(
  p_domain_id uuid,
  p_check_time timestamptz DEFAULT now()
)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  v_domain sys_domains;
  v_config jsonb;
  v_timezone text;
  v_local_time time;
  v_day_of_week text;
  v_day_schedule jsonb;
  v_open_time time;
  v_close_time time;
  v_is_open boolean := false;
  v_next_open_time text;
BEGIN
  -- 获取域名信息
  SELECT * INTO v_domain FROM sys_domains WHERE id = p_domain_id;
  
  IF NOT FOUND THEN
    RETURN jsonb_build_object(
      'is_open', false,
      'reason', '域名不存在'
    );
  END IF;

  -- 检查功能是否启用
  IF NOT v_domain.enable_lucky_draw THEN
    RETURN jsonb_build_object(
      'is_open', false,
      'reason', '一元购功能未启用'
    );
  END IF;

  -- 获取营业时间配置
  v_config := v_domain.lucky_draw_business_hours;
  v_timezone := v_domain.lucky_draw_timezone;

  -- 检查营业时间功能是否启用
  IF NOT (v_config->>'enabled')::boolean THEN
    RETURN jsonb_build_object(
      'is_open', true,
      'reason', '24小时营业（未设置营业时间限制）'
    );
  END IF;

  -- 转换到本地时区获取当前时间
  v_local_time := (p_check_time AT TIME ZONE v_timezone)::time;
  
  -- 获取星期几（小写英文）
  v_day_of_week := lower(to_char(p_check_time AT TIME ZONE v_timezone, 'Day'));
  v_day_of_week := trim(v_day_of_week);

  -- 获取当天的营业时间配置
  v_day_schedule := v_config->'weekly_schedule'->v_day_of_week;

  -- 如果当天未配置，使用默认时间
  IF v_day_schedule IS NULL THEN
    v_day_schedule := v_config->'default_hours';
  END IF;

  -- 检查当天是否营业
  IF NOT COALESCE((v_day_schedule->>'enabled')::boolean, true) THEN
    RETURN jsonb_build_object(
      'is_open', false,
      'reason', '今天不营业',
      'day_of_week', v_day_of_week
    );
  END IF;

  -- 获取开门和关门时间
  v_open_time := (v_day_schedule->>'open')::time;
  v_close_time := (v_day_schedule->>'close')::time;

  -- 判断是否在营业时间内
  IF v_close_time > v_open_time THEN
    -- 正常情况：如 09:00 - 23:00
    v_is_open := v_local_time >= v_open_time AND v_local_time < v_close_time;
  ELSE
    -- 跨天情况：如 23:00 - 02:00
    v_is_open := v_local_time >= v_open_time OR v_local_time < v_close_time;
  END IF;

  -- 如果不在营业时间，计算下次开门时间
  IF NOT v_is_open THEN
    IF v_local_time < v_open_time THEN
      v_next_open_time := '今天 ' || v_open_time::text;
    ELSE
      v_next_open_time := '明天 ' || v_open_time::text;
    END IF;
  END IF;

  RETURN jsonb_build_object(
    'is_open', v_is_open,
    'current_time', v_local_time::text,
    'timezone', v_timezone,
    'day_of_week', v_day_of_week,
    'business_hours', jsonb_build_object(
      'open', v_open_time::text,
      'close', v_close_time::text
    ),
    'next_open_time', v_next_open_time,
    'reason', CASE 
      WHEN v_is_open THEN '营业中'
      ELSE '不在营业时间内'
    END
  );
END;
$$;

COMMENT ON FUNCTION check_lucky_draw_business_hours IS '检查一元购是否在营业时间内，支持复杂的时间配置';

-- ============================================
-- 更新权限检查函数（整合营业时间）
-- ============================================

CREATE OR REPLACE FUNCTION check_lucky_draw_permission_full(p_domain_id uuid)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  v_permission_check jsonb;
  v_business_hours_check jsonb;
  v_domain sys_domains;
BEGIN
  -- 第一步：检查地区权限
  v_permission_check := check_lucky_draw_permission(p_domain_id);
  
  IF NOT (v_permission_check->>'allowed')::boolean THEN
    RETURN v_permission_check;
  END IF;

  -- 第二步：检查营业时间
  v_business_hours_check := check_lucky_draw_business_hours(p_domain_id);
  
  IF NOT (v_business_hours_check->>'is_open')::boolean THEN
    RETURN jsonb_build_object(
      'allowed', false,
      'reason', v_business_hours_check->>'reason',
      'business_hours', v_business_hours_check
    );
  END IF;

  -- 第三步：检查功能是否启用
  SELECT * INTO v_domain FROM sys_domains WHERE id = p_domain_id;
  
  IF NOT v_domain.enable_lucky_draw THEN
    RETURN jsonb_build_object(
      'allowed', false,
      'reason', '店铺未启用一元购功能'
    );
  END IF;

  -- 全部检查通过
  RETURN jsonb_build_object(
    'allowed', true,
    'region', v_permission_check->'region',
    'business_hours', v_business_hours_check,
    'message', '一元购功能可用'
  );
END;
$$;

COMMENT ON FUNCTION check_lucky_draw_permission_full IS '完整的一元购权限检查：地区权限 + 营业时间 + 功能开关';

-- ============================================
-- 创建视图：当前营业状态
-- ============================================

CREATE OR REPLACE VIEW v_lucky_draw_store_status AS
SELECT 
  d.id as domain_id,
  d.domain,
  d.display_name,
  d.enable_lucky_draw,
  d.lucky_draw_region_code,
  d.lucky_draw_timezone,
  d.lucky_draw_business_hours,
  r.country_name,
  r.is_active as region_is_active,
  r.risk_level,
  CASE 
    WHEN NOT d.enable_lucky_draw THEN '未启用'
    WHEN NOT r.is_active THEN '地区未开放'
    WHEN (d.lucky_draw_business_hours->>'enabled')::boolean = false THEN '24小时营业'
    ELSE '按营业时间'
  END as status_text,
  (SELECT check_lucky_draw_business_hours(d.id)) as current_business_status
FROM sys_domains d
LEFT JOIN sys_lucky_draw_allowed_regions r 
  ON r.country_code = d.lucky_draw_region_code;

COMMENT ON VIEW v_lucky_draw_store_status IS '一元购店铺状态视图，显示每个店铺的当前营业状态';
