/*
  # 注册AI作图工作室模块（最终版）

  ## 功能说明
  将AI作图工作室模块注册到系统模块管理中，添加：
  1. 模块注册信息
  2. 路由配置
  3. 菜单配置
  4. 权限配置

  ## 注册内容
  - 模块Key: ai_image_studio
  - 模块名称: AI作图工作室
  - 路由路径: /admin/ai-image-studio
  - 组件名称: AIImageStudio
  - 菜单图标: image
  - 分类: system (AI工具)
  - 模块类型: frontend_only
*/

DO $$
DECLARE
  v_module_id uuid;
BEGIN
  -- 插入或更新模块配置
  INSERT INTO sys_modules (
    module_key,
    module_name,
    module_version,
    description,
    category,
    icon,
    color,
    status,
    is_core,
    is_system,
    module_type,
    author,
    license
  ) VALUES (
    'ai_image_studio',
    '{"zh": "AI作图工作室", "en": "AI Image Studio"}',
    '1.0.0',
    '{"zh": "智能对话式图片生成与编辑，支持PNG、JPG、WebP、GIF、APNG、SVG等多种格式", "en": "Intelligent conversational image generation and editing with multi-format support"}',
    'system',
    'image',
    'pink',
    'enabled',
    false,
    false,
    'frontend_only',
    '168全球购',
    'MIT'
  ) ON CONFLICT (module_key) DO UPDATE SET
    module_name = EXCLUDED.module_name,
    description = EXCLUDED.description,
    status = 'enabled',
    updated_at = now()
  RETURNING id INTO v_module_id;

  -- 插入路由配置
  INSERT INTO sys_module_routes (
    module_id,
    route_path,
    component_name,
    menu_label,
    menu_icon,
    menu_order,
    is_menu_item,
    requires_auth,
    required_permissions,
    is_active
  ) VALUES (
    v_module_id,
    '/admin/ai-image-studio',
    'AIImageStudio',
    '{"zh": "AI作图", "en": "AI Image"}',
    'image',
    85,
    true,
    true,
    '{"read": true, "create": true}',
    true
  ) ON CONFLICT (module_id, route_path) 
  DO UPDATE SET
    component_name = EXCLUDED.component_name,
    menu_label = EXCLUDED.menu_label,
    menu_icon = EXCLUDED.menu_icon,
    is_menu_item = EXCLUDED.is_menu_item,
    is_active = true;
END $$;