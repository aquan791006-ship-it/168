/*
  # 创建增强的系统监控和优化系统

  ## 功能说明
  创建完整的系统监控、性能优化和AI预警系统
  1. 性能指标追踪
  2. 资源使用监控
  3. 优化任务管理
  4. 错误日志系统
  5. 智能分析和建议

  ## 新增表和功能
  - 性能指标表
  - 资源监控表
  - 优化任务表
  - 错误日志表
  - AI分析函数
*/

-- ============================================
-- 性能指标表
-- ============================================

CREATE TABLE IF NOT EXISTS sys_performance_metrics (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  metric_type varchar(100) NOT NULL,
  metric_name varchar(255) NOT NULL,
  metric_value numeric(15,4),
  metric_unit varchar(50),
  module_key varchar(100),
  domain_id uuid REFERENCES sys_domains(id) ON DELETE CASCADE,
  labels jsonb DEFAULT '{}'::jsonb,
  threshold_warning numeric(15,4),
  threshold_critical numeric(15,4),
  is_anomaly boolean DEFAULT false,
  trend varchar(50),
  recorded_at timestamptz DEFAULT now(),
  CONSTRAINT valid_trend CHECK (
    trend IS NULL OR trend IN ('increasing', 'decreasing', 'stable', 'volatile')
  )
);

DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_indexes WHERE indexname = 'idx_perf_metrics_type') THEN
    CREATE INDEX idx_perf_metrics_type ON sys_performance_metrics(metric_type);
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_indexes WHERE indexname = 'idx_perf_metrics_name') THEN
    CREATE INDEX idx_perf_metrics_name ON sys_performance_metrics(metric_name);
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_indexes WHERE indexname = 'idx_perf_metrics_module') THEN
    CREATE INDEX idx_perf_metrics_module ON sys_performance_metrics(module_key);
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_indexes WHERE indexname = 'idx_perf_metrics_time') THEN
    CREATE INDEX idx_perf_metrics_time ON sys_performance_metrics(recorded_at DESC);
  END IF;
END $$;

ALTER TABLE sys_performance_metrics ENABLE ROW LEVEL SECURITY;

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE schemaname = 'public' 
    AND tablename = 'sys_performance_metrics' 
    AND policyname = 'Super admins can view performance metrics'
  ) THEN
    CREATE POLICY "Super admins can view performance metrics"
      ON sys_performance_metrics FOR SELECT
      TO authenticated
      USING (
        EXISTS (SELECT 1 FROM sys_admins WHERE id = auth.uid() AND is_super_admin = true)
      );
  END IF;
END $$;

-- ============================================
-- 资源使用监控表
-- ============================================

CREATE TABLE IF NOT EXISTS sys_resource_usage (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  resource_type varchar(100) NOT NULL,
  used_amount numeric(15,4),
  total_amount numeric(15,4),
  usage_percent numeric(5,2),
  domain_id uuid REFERENCES sys_domains(id) ON DELETE CASCADE,
  module_key varchar(100),
  peak_usage numeric(15,4),
  avg_usage numeric(15,4),
  predictions jsonb DEFAULT '{}'::jsonb,
  optimization_suggestions jsonb DEFAULT '[]'::jsonb,
  recorded_at timestamptz DEFAULT now(),
  CONSTRAINT valid_resource_type CHECK (
    resource_type IN ('database_connections', 'storage_space', 'bandwidth', 'api_calls', 
                      'edge_function_invocations', 'memory', 'cpu', 'cache')
  )
);

DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_indexes WHERE indexname = 'idx_res_usage_type') THEN
    CREATE INDEX idx_res_usage_type ON sys_resource_usage(resource_type);
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_indexes WHERE indexname = 'idx_res_usage_module') THEN
    CREATE INDEX idx_res_usage_module ON sys_resource_usage(module_key);
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_indexes WHERE indexname = 'idx_res_usage_time') THEN
    CREATE INDEX idx_res_usage_time ON sys_resource_usage(recorded_at DESC);
  END IF;
END $$;

ALTER TABLE sys_resource_usage ENABLE ROW LEVEL SECURITY;

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE schemaname = 'public' 
    AND tablename = 'sys_resource_usage' 
    AND policyname = 'Super admins can view resource usage'
  ) THEN
    CREATE POLICY "Super admins can view resource usage"
      ON sys_resource_usage FOR SELECT
      TO authenticated
      USING (
        EXISTS (SELECT 1 FROM sys_admins WHERE id = auth.uid() AND is_super_admin = true)
      );
  END IF;
END $$;

-- ============================================
-- 优化任务表
-- ============================================

CREATE TABLE IF NOT EXISTS sys_optimization_tasks (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  task_type varchar(100) NOT NULL,
  priority varchar(50) NOT NULL DEFAULT 'medium',
  title varchar(255) NOT NULL,
  description text,
  module_key varchar(100),
  target_metric varchar(100),
  current_value numeric(15,4),
  target_value numeric(15,4),
  expected_improvement_percent numeric(5,2),
  estimated_execution_time integer,
  sql_commands text,
  rollback_commands text,
  requires_downtime boolean DEFAULT false,
  auto_execute boolean DEFAULT false,
  status varchar(50) DEFAULT 'pending',
  execution_result jsonb,
  executed_by uuid REFERENCES sys_admins(id),
  executed_at timestamptz,
  created_at timestamptz DEFAULT now(),
  CONSTRAINT valid_priority CHECK (
    priority IN ('low', 'medium', 'high', 'urgent')
  ),
  CONSTRAINT valid_task_status CHECK (
    status IN ('pending', 'approved', 'executing', 'completed', 'failed', 'rolled_back', 'cancelled')
  )
);

DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_indexes WHERE indexname = 'idx_opt_tasks_type') THEN
    CREATE INDEX idx_opt_tasks_type ON sys_optimization_tasks(task_type);
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_indexes WHERE indexname = 'idx_opt_tasks_priority') THEN
    CREATE INDEX idx_opt_tasks_priority ON sys_optimization_tasks(priority);
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_indexes WHERE indexname = 'idx_opt_tasks_status') THEN
    CREATE INDEX idx_opt_tasks_status ON sys_optimization_tasks(status);
  END IF;
END $$;

ALTER TABLE sys_optimization_tasks ENABLE ROW LEVEL SECURITY;

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE schemaname = 'public' 
    AND tablename = 'sys_optimization_tasks' 
    AND policyname = 'Super admins can manage optimization tasks'
  ) THEN
    CREATE POLICY "Super admins can manage optimization tasks"
      ON sys_optimization_tasks FOR ALL
      TO authenticated
      USING (
        EXISTS (SELECT 1 FROM sys_admins WHERE id = auth.uid() AND is_super_admin = true)
      )
      WITH CHECK (
        EXISTS (SELECT 1 FROM sys_admins WHERE id = auth.uid() AND is_super_admin = true)
      );
  END IF;
END $$;

-- ============================================
-- 错误日志表
-- ============================================

CREATE TABLE IF NOT EXISTS sys_error_logs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  error_type varchar(100) NOT NULL,
  error_code varchar(50),
  error_message text NOT NULL,
  stack_trace text,
  module_key varchar(100),
  function_name varchar(255),
  user_id uuid,
  domain_id uuid REFERENCES sys_domains(id) ON DELETE CASCADE,
  request_path text,
  request_method varchar(10),
  request_params jsonb,
  user_agent text,
  ip_address inet,
  severity varchar(50) DEFAULT 'error',
  is_handled boolean DEFAULT false,
  retry_count integer DEFAULT 0,
  auto_recovered boolean DEFAULT false,
  recovery_action text,
  similar_errors_count integer DEFAULT 1,
  first_occurrence timestamptz DEFAULT now(),
  last_occurrence timestamptz DEFAULT now(),
  created_at timestamptz DEFAULT now(),
  CONSTRAINT valid_error_severity CHECK (
    severity IN ('debug', 'info', 'warning', 'error', 'critical', 'fatal')
  )
);

DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_indexes WHERE indexname = 'idx_err_logs_type') THEN
    CREATE INDEX idx_err_logs_type ON sys_error_logs(error_type);
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_indexes WHERE indexname = 'idx_err_logs_module') THEN
    CREATE INDEX idx_err_logs_module ON sys_error_logs(module_key);
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_indexes WHERE indexname = 'idx_err_logs_severity') THEN
    CREATE INDEX idx_err_logs_severity ON sys_error_logs(severity);
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_indexes WHERE indexname = 'idx_err_logs_time') THEN
    CREATE INDEX idx_err_logs_time ON sys_error_logs(created_at DESC);
  END IF;
END $$;

ALTER TABLE sys_error_logs ENABLE ROW LEVEL SECURITY;

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE schemaname = 'public' 
    AND tablename = 'sys_error_logs' 
    AND policyname = 'Super admins can view error logs'
  ) THEN
    CREATE POLICY "Super admins can view error logs"
      ON sys_error_logs FOR SELECT
      TO authenticated
      USING (
        EXISTS (SELECT 1 FROM sys_admins WHERE id = auth.uid() AND is_super_admin = true)
      );
  END IF;
END $$;

-- ============================================
-- 检测循环依赖的函数
-- ============================================

CREATE OR REPLACE FUNCTION detect_circular_dependency(
  p_module_key varchar,
  p_depends_on varchar
)
RETURNS boolean
LANGUAGE plpgsql
AS $$
DECLARE
  v_circular boolean := false;
BEGIN
  WITH RECURSIVE dep_chain AS (
    SELECT 
      depends_on_module,
      module_key,
      ARRAY[module_key, depends_on_module] as path,
      1 as depth
    FROM sys_module_dependencies
    WHERE module_key = p_depends_on
    
    UNION ALL
    
    SELECT 
      d.depends_on_module,
      d.module_key,
      dc.path || d.depends_on_module,
      dc.depth + 1
    FROM sys_module_dependencies d
    JOIN dep_chain dc ON d.module_key = dc.depends_on_module
    WHERE dc.depth < 20
    AND NOT (d.depends_on_module = ANY(dc.path))
  )
  SELECT EXISTS(
    SELECT 1 FROM dep_chain WHERE depends_on_module = p_module_key
  ) INTO v_circular;
  
  RETURN v_circular;
END;
$$;

CREATE OR REPLACE FUNCTION check_dependency_before_insert()
RETURNS TRIGGER
LANGUAGE plpgsql
AS $$
BEGIN
  IF detect_circular_dependency(NEW.module_key, NEW.depends_on_module) THEN
    RAISE EXCEPTION 'Circular dependency detected: % -> %', NEW.module_key, NEW.depends_on_module;
  END IF;
  
  RETURN NEW;
END;
$$;

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_trigger 
    WHERE tgname = 'prevent_circular_dependencies'
  ) THEN
    CREATE TRIGGER prevent_circular_dependencies
      BEFORE INSERT OR UPDATE ON sys_module_dependencies
      FOR EACH ROW
      EXECUTE FUNCTION check_dependency_before_insert();
  END IF;
END $$;

-- ============================================
-- AI分析和预警函数
-- ============================================

CREATE OR REPLACE FUNCTION analyze_system_performance()
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  v_result jsonb;
  v_slow_queries integer;
  v_high_memory integer;
  v_db_connections integer;
  v_avg_response_time numeric;
BEGIN
  SELECT COUNT(*) INTO v_slow_queries
  FROM sys_performance_metrics
  WHERE metric_type = 'query_time'
  AND metric_value > 1000
  AND recorded_at > now() - interval '1 hour';
  
  SELECT COUNT(*) INTO v_high_memory
  FROM sys_resource_usage
  WHERE resource_type = 'memory'
  AND usage_percent > 80
  AND recorded_at > now() - interval '1 hour';
  
  SELECT 
    AVG(metric_value) INTO v_avg_response_time
  FROM sys_performance_metrics
  WHERE metric_type = 'response_time'
  AND recorded_at > now() - interval '1 hour';
  
  v_result := jsonb_build_object(
    'analysis_time', now(),
    'slow_queries_count', COALESCE(v_slow_queries, 0),
    'high_memory_alerts', COALESCE(v_high_memory, 0),
    'avg_response_time_ms', COALESCE(v_avg_response_time, 0),
    'status', CASE 
      WHEN v_slow_queries > 10 OR v_high_memory > 5 THEN 'critical'
      WHEN v_slow_queries > 5 OR v_high_memory > 2 THEN 'warning'
      ELSE 'healthy'
    END,
    'recommendations', CASE
      WHEN v_slow_queries > 10 THEN jsonb_build_array(
        '优化慢查询SQL',
        '添加必要的数据库索引',
        '考虑查询结果缓存'
      )
      WHEN v_high_memory > 5 THEN jsonb_build_array(
        '检查内存泄漏',
        '优化数据加载策略',
        '增加服务器内存'
      )
      ELSE jsonb_build_array('系统运行正常')
    END
  );
  
  RETURN v_result;
END;
$$;

CREATE OR REPLACE FUNCTION create_optimization_suggestion(
  p_task_type varchar,
  p_title varchar,
  p_description text,
  p_module_key varchar DEFAULT NULL
)
RETURNS uuid
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  v_task_id uuid;
BEGIN
  INSERT INTO sys_optimization_tasks (
    task_type,
    priority,
    title,
    description,
    module_key,
    auto_execute
  ) VALUES (
    p_task_type,
    'medium',
    p_title,
    p_description,
    p_module_key,
    false
  ) RETURNING id INTO v_task_id;
  
  RETURN v_task_id;
END;
$$;

CREATE OR REPLACE FUNCTION log_error(
  p_error_type varchar,
  p_error_message text,
  p_module_key varchar DEFAULT NULL,
  p_severity varchar DEFAULT 'error',
  p_stack_trace text DEFAULT NULL
)
RETURNS uuid
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  v_log_id uuid;
  v_existing_id uuid;
BEGIN
  SELECT id INTO v_existing_id
  FROM sys_error_logs
  WHERE error_type = p_error_type
  AND error_message = p_error_message
  AND module_key IS NOT DISTINCT FROM p_module_key
  AND created_at > now() - interval '1 hour'
  ORDER BY created_at DESC
  LIMIT 1;
  
  IF v_existing_id IS NOT NULL THEN
    UPDATE sys_error_logs
    SET 
      similar_errors_count = similar_errors_count + 1,
      last_occurrence = now()
    WHERE id = v_existing_id;
    
    RETURN v_existing_id;
  ELSE
    INSERT INTO sys_error_logs (
      error_type,
      error_message,
      module_key,
      severity,
      stack_trace
    ) VALUES (
      p_error_type,
      p_error_message,
      p_module_key,
      p_severity,
      p_stack_trace
    ) RETURNING id INTO v_log_id;
    
    RETURN v_log_id;
  END IF;
END;
$$;

CREATE OR REPLACE FUNCTION auto_cleanup_old_monitoring_data()
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  DELETE FROM sys_performance_metrics WHERE recorded_at < now() - interval '90 days';
  
  DELETE FROM sys_resource_usage WHERE recorded_at < now() - interval '90 days';
  
  DELETE FROM sys_error_logs 
  WHERE created_at < now() - interval '90 days'
  AND severity NOT IN ('critical', 'fatal');
  
  UPDATE sys_optimization_tasks SET status = 'cancelled'
  WHERE status = 'pending'
  AND created_at < now() - interval '30 days';
  
  RAISE NOTICE 'Auto cleanup completed at %', now();
END;
$$;

COMMENT ON FUNCTION analyze_system_performance IS 'AI分析系统性能状况';
COMMENT ON FUNCTION create_optimization_suggestion IS '创建系统优化建议';
COMMENT ON FUNCTION log_error IS '记录系统错误日志';
COMMENT ON FUNCTION auto_cleanup_old_monitoring_data IS '自动清理历史监控数据';
COMMENT ON FUNCTION detect_circular_dependency IS '检测模块循环依赖';
