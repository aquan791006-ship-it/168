/*
  # SmartInsight AI 模块 - 核心函数

  ## 功能
  1. AI 分析任务执行
  2. 工作流管理和执行
  3. 洞察生成和管理
  4. 智能规则执行
  5. 预测分析
*/

-- 1. 执行 AI 分析任务
CREATE OR REPLACE FUNCTION execute_ai_analysis_task(
  p_task_key varchar,
  p_trigger_type varchar DEFAULT 'manual',
  p_triggered_by uuid DEFAULT NULL
)
RETURNS jsonb AS $$
DECLARE
  v_task record;
  v_execution_id varchar;
  v_execution_record_id uuid;
BEGIN
  SELECT * INTO v_task FROM ai_analysis_tasks WHERE task_key = p_task_key;
  
  IF v_task.id IS NULL THEN
    RETURN jsonb_build_object(
      'success', false,
      'error', 'Task not found: ' || p_task_key
    );
  END IF;
  
  IF v_task.is_enabled = false THEN
    RETURN jsonb_build_object(
      'success', false,
      'error', 'Task is disabled'
    );
  END IF;
  
  v_execution_id := 'exec_' || gen_random_uuid()::text;
  
  INSERT INTO ai_task_executions (
    task_id,
    execution_id,
    status,
    trigger_type,
    triggered_by
  ) VALUES (
    v_task.id,
    v_execution_id,
    'running',
    p_trigger_type,
    p_triggered_by
  ) RETURNING id INTO v_execution_record_id;
  
  UPDATE ai_analysis_tasks
  SET status = 'running',
      total_executions = total_executions + 1,
      last_execution_at = now()
  WHERE id = v_task.id;
  
  RETURN jsonb_build_object(
    'success', true,
    'execution_id', v_execution_id,
    'task_key', v_task.task_key,
    'status', 'running'
  );
END;
$$ LANGUAGE plpgsql;

-- 2. 完成 AI 分析任务执行
CREATE OR REPLACE FUNCTION complete_ai_task_execution(
  p_execution_id varchar,
  p_status varchar,
  p_output_data jsonb DEFAULT '{}',
  p_records_processed integer DEFAULT 0,
  p_insights_generated integer DEFAULT 0,
  p_error_message text DEFAULT NULL
)
RETURNS jsonb AS $$
DECLARE
  v_execution record;
  v_duration_ms integer;
BEGIN
  SELECT * INTO v_execution FROM ai_task_executions WHERE execution_id = p_execution_id;
  
  IF v_execution.id IS NULL THEN
    RETURN jsonb_build_object(
      'success', false,
      'error', 'Execution not found'
    );
  END IF;
  
  v_duration_ms := EXTRACT(EPOCH FROM (now() - v_execution.started_at)) * 1000;
  
  UPDATE ai_task_executions
  SET status = p_status,
      completed_at = now(),
      duration_ms = v_duration_ms,
      output_data = p_output_data,
      records_processed = p_records_processed,
      insights_generated = p_insights_generated,
      error_message = p_error_message
  WHERE id = v_execution.id;
  
  UPDATE ai_analysis_tasks
  SET status = CASE 
        WHEN p_status = 'completed' THEN 'active'
        WHEN p_status = 'failed' THEN 'error'
        ELSE status
      END,
      success_count = CASE WHEN p_status = 'completed' THEN success_count + 1 ELSE success_count END,
      failure_count = CASE WHEN p_status = 'failed' THEN failure_count + 1 ELSE failure_count END,
      last_execution_status = p_status,
      last_execution_duration_ms = v_duration_ms
  WHERE id = v_execution.task_id;
  
  RETURN jsonb_build_object(
    'success', true,
    'execution_id', p_execution_id,
    'status', p_status,
    'duration_ms', v_duration_ms
  );
END;
$$ LANGUAGE plpgsql;

-- 3. 创建 AI 洞察
CREATE OR REPLACE FUNCTION create_ai_insight(
  p_insight_key varchar,
  p_insight_title jsonb,
  p_insight_summary jsonb,
  p_insight_type varchar,
  p_category varchar,
  p_severity varchar DEFAULT 'info',
  p_insight_data jsonb DEFAULT '{}',
  p_confidence_score numeric DEFAULT 0.00,
  p_impact_score numeric DEFAULT 0.00,
  p_related_task_id uuid DEFAULT NULL
)
RETURNS jsonb AS $$
DECLARE
  v_insight_id uuid;
BEGIN
  INSERT INTO ai_insights (
    insight_key,
    insight_title,
    insight_summary,
    insight_type,
    category,
    severity,
    insight_data,
    confidence_score,
    impact_score,
    related_task_id,
    status
  ) VALUES (
    p_insight_key,
    p_insight_title,
    p_insight_summary,
    p_insight_type,
    p_category,
    p_severity,
    p_insight_data,
    p_confidence_score,
    p_impact_score,
    p_related_task_id,
    'new'
  ) RETURNING id INTO v_insight_id;
  
  INSERT INTO sys_module_events (
    event_name,
    publisher_module_id,
    event_data,
    event_type
  ) SELECT
    'ai.insight_created',
    m.id,
    jsonb_build_object(
      'insight_id', v_insight_id,
      'insight_type', p_insight_type,
      'severity', p_severity,
      'category', p_category
    ),
    'notification'
  FROM sys_modules m WHERE m.module_key = 'module.smartinsight';
  
  RETURN jsonb_build_object(
    'success', true,
    'insight_id', v_insight_id,
    'insight_key', p_insight_key
  );
END;
$$ LANGUAGE plpgsql;

-- 4. 执行 AI 工作流
CREATE OR REPLACE FUNCTION execute_ai_workflow(
  p_workflow_key varchar,
  p_input_data jsonb DEFAULT '{}',
  p_trigger_type varchar DEFAULT 'manual',
  p_triggered_by uuid DEFAULT NULL
)
RETURNS jsonb AS $$
DECLARE
  v_workflow record;
  v_execution_id varchar;
  v_execution_record_id uuid;
BEGIN
  SELECT * INTO v_workflow FROM ai_workflows WHERE workflow_key = p_workflow_key;
  
  IF v_workflow.id IS NULL THEN
    RETURN jsonb_build_object(
      'success', false,
      'error', 'Workflow not found: ' || p_workflow_key
    );
  END IF;
  
  IF v_workflow.is_enabled = false THEN
    RETURN jsonb_build_object(
      'success', false,
      'error', 'Workflow is disabled'
    );
  END IF;
  
  v_execution_id := 'wf_exec_' || gen_random_uuid()::text;
  
  INSERT INTO ai_workflow_executions (
    workflow_id,
    execution_id,
    status,
    input_data,
    trigger_type,
    triggered_by
  ) VALUES (
    v_workflow.id,
    v_execution_id,
    'running',
    p_input_data,
    p_trigger_type,
    p_triggered_by
  ) RETURNING id INTO v_execution_record_id;
  
  UPDATE ai_workflows
  SET total_executions = total_executions + 1,
      last_execution_at = now()
  WHERE id = v_workflow.id;
  
  RETURN jsonb_build_object(
    'success', true,
    'execution_id', v_execution_id,
    'workflow_key', v_workflow.workflow_key,
    'status', 'running'
  );
END;
$$ LANGUAGE plpgsql;

-- 5. 执行智能规则
CREATE OR REPLACE FUNCTION execute_ai_rule(
  p_rule_key varchar,
  p_trigger_event varchar,
  p_trigger_data jsonb DEFAULT '{}'
)
RETURNS jsonb AS $$
DECLARE
  v_rule record;
  v_execution_id uuid;
  v_conditions_met boolean;
BEGIN
  SELECT * INTO v_rule FROM ai_rules WHERE rule_key = p_rule_key;
  
  IF v_rule.id IS NULL THEN
    RETURN jsonb_build_object(
      'success', false,
      'error', 'Rule not found: ' || p_rule_key
    );
  END IF;
  
  IF v_rule.is_enabled = false THEN
    RETURN jsonb_build_object(
      'success', false,
      'error', 'Rule is disabled'
    );
  END IF;
  
  v_conditions_met := true;
  
  INSERT INTO ai_rule_executions (
    rule_id,
    trigger_event,
    trigger_data,
    conditions_met,
    status
  ) VALUES (
    v_rule.id,
    p_trigger_event,
    p_trigger_data,
    v_conditions_met,
    'success'
  ) RETURNING id INTO v_execution_id;
  
  UPDATE ai_rules
  SET total_triggers = total_triggers + 1,
      total_executions = total_executions + 1,
      success_count = success_count + 1,
      last_executed_at = now()
  WHERE id = v_rule.id;
  
  RETURN jsonb_build_object(
    'success', true,
    'rule_key', v_rule.rule_key,
    'conditions_met', v_conditions_met,
    'status', 'success'
  );
END;
$$ LANGUAGE plpgsql;

-- 6. 获取 AI 洞察统计
CREATE OR REPLACE FUNCTION get_ai_insights_statistics()
RETURNS jsonb AS $$
DECLARE
  v_stats jsonb;
BEGIN
  SELECT jsonb_build_object(
    'total_insights', COUNT(*),
    'new_insights', COUNT(*) FILTER (WHERE status = 'new'),
    'by_type', (
      SELECT jsonb_object_agg(insight_type, count)
      FROM (
        SELECT insight_type, COUNT(*) as count
        FROM ai_insights
        WHERE created_at >= now() - interval '30 days'
        GROUP BY insight_type
      ) type_counts
    ),
    'by_severity', (
      SELECT jsonb_object_agg(severity, count)
      FROM (
        SELECT severity, COUNT(*) as count
        FROM ai_insights
        WHERE created_at >= now() - interval '30 days'
        GROUP BY severity
      ) severity_counts
    ),
    'high_priority', COUNT(*) FILTER (WHERE priority >= 8 AND status = 'new')
  ) INTO v_stats
  FROM ai_insights
  WHERE created_at >= now() - interval '30 days';
  
  RETURN v_stats;
END;
$$ LANGUAGE plpgsql;

-- 7. 获取 AI 任务统计
CREATE OR REPLACE FUNCTION get_ai_tasks_statistics()
RETURNS jsonb AS $$
DECLARE
  v_stats jsonb;
BEGIN
  SELECT jsonb_build_object(
    'total_tasks', COUNT(*),
    'active_tasks', COUNT(*) FILTER (WHERE is_enabled = true),
    'running_tasks', COUNT(*) FILTER (WHERE status = 'running'),
    'total_executions', SUM(total_executions),
    'success_rate', CASE 
      WHEN SUM(total_executions) > 0 
      THEN ROUND((SUM(success_count)::numeric / SUM(total_executions)::numeric) * 100, 2)
      ELSE 0
    END,
    'by_type', (
      SELECT jsonb_object_agg(task_type, count)
      FROM (
        SELECT task_type, COUNT(*) as count
        FROM ai_analysis_tasks
        WHERE is_enabled = true
        GROUP BY task_type
      ) type_counts
    )
  ) INTO v_stats
  FROM ai_analysis_tasks;
  
  RETURN v_stats;
END;
$$ LANGUAGE plpgsql;

-- 8. 获取 AI 工作流统计
CREATE OR REPLACE FUNCTION get_ai_workflows_statistics()
RETURNS jsonb AS $$
DECLARE
  v_stats jsonb;
BEGIN
  SELECT jsonb_build_object(
    'total_workflows', COUNT(*),
    'active_workflows', COUNT(*) FILTER (WHERE is_enabled = true),
    'total_executions', SUM(total_executions),
    'success_rate', CASE 
      WHEN SUM(total_executions) > 0 
      THEN ROUND((SUM(success_count)::numeric / SUM(total_executions)::numeric) * 100, 2)
      ELSE 0
    END,
    'by_type', (
      SELECT jsonb_object_agg(workflow_type, count)
      FROM (
        SELECT workflow_type, COUNT(*) as count
        FROM ai_workflows
        WHERE status = 'active'
        GROUP BY workflow_type
      ) type_counts
    )
  ) INTO v_stats
  FROM ai_workflows;
  
  RETURN v_stats;
END;
$$ LANGUAGE plpgsql;
