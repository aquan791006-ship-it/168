/*
  # 注册 SmartInsight AI 模块到系统 v2
  
  将 SmartInsight 作为可插拔模块注册到可组合式 ERP 系统
*/

-- 1. 注册 SmartInsight 模块
INSERT INTO sys_modules (
  module_key,
  module_name,
  description,
  category,
  icon,
  color,
  status,
  is_core,
  is_system,
  module_version,
  module_type,
  config_schema,
  default_config
) VALUES (
  'module.smartinsight',
  '{"zh": "SmartInsight AI", "en": "SmartInsight AI"}',
  '{"zh": "企业级AI插件模块，提供智能数据分析、自主工作流、预测分析和异常检测", "en": "Enterprise AI plugin providing intelligent data analysis, autonomous workflows, predictive analytics and anomaly detection"}',
  'analytics',
  'Brain',
  '#8B5CF6',
  'enabled',
  false,
  false,
  '1.0.0',
  'full',
  '{
    "ai_provider": {
      "type": "string",
      "default": "openai",
      "options": ["openai", "anthropic", "local"],
      "description": "AI 服务提供商"
    },
    "enable_auto_insights": {
      "type": "boolean",
      "default": true,
      "description": "自动生成洞察"
    },
    "enable_predictions": {
      "type": "boolean",
      "default": true,
      "description": "启用预测分析"
    },
    "enable_workflows": {
      "type": "boolean",
      "default": true,
      "description": "启用自动化工作流"
    },
    "confidence_threshold": {
      "type": "number",
      "default": 0.75,
      "min": 0,
      "max": 1,
      "description": "洞察置信度阈值"
    }
  }',
  '{
    "ai_provider": "openai",
    "enable_auto_insights": true,
    "enable_predictions": true,
    "enable_workflows": true,
    "confidence_threshold": 0.75
  }'
) ON CONFLICT (module_key) DO UPDATE
SET 
  module_name = EXCLUDED.module_name,
  description = EXCLUDED.description,
  updated_at = now();

-- 2. 注册模块路由
INSERT INTO sys_module_routes (
  module_id,
  route_path,
  component_name,
  menu_label,
  menu_icon,
  menu_order,
  is_menu_item,
  requires_auth
) VALUES
(
  (SELECT id FROM sys_modules WHERE module_key = 'module.smartinsight'),
  '/admin/smartinsight',
  'SmartInsight',
  '{"zh": "AI 智能中心", "en": "AI Intelligence"}',
  'Brain',
  85,
  true,
  true
)
ON CONFLICT (module_id, route_path) DO NOTHING;

-- 3. 注册模块权限
INSERT INTO sys_module_permissions (
  module_id,
  permission_key,
  permission_name,
  description,
  permission_type
) VALUES
(
  (SELECT id FROM sys_modules WHERE module_key = 'module.smartinsight'),
  'smartinsight.view',
  '{"zh": "查看AI分析", "en": "View AI Analysis"}',
  '{"zh": "允许查看AI分析结果和洞察", "en": "Allow viewing AI analysis and insights"}',
  'data'
),
(
  (SELECT id FROM sys_modules WHERE module_key = 'module.smartinsight'),
  'smartinsight.manage_tasks',
  '{"zh": "管理分析任务", "en": "Manage Analysis Tasks"}',
  '{"zh": "允许创建和管理AI分析任务", "en": "Allow creating and managing AI analysis tasks"}',
  'action'
),
(
  (SELECT id FROM sys_modules WHERE module_key = 'module.smartinsight'),
  'smartinsight.manage_workflows',
  '{"zh": "管理工作流", "en": "Manage Workflows"}',
  '{"zh": "允许创建和管理AI工作流", "en": "Allow creating and managing AI workflows"}',
  'action'
),
(
  (SELECT id FROM sys_modules WHERE module_key = 'module.smartinsight'),
  'smartinsight.configure',
  '{"zh": "配置AI模块", "en": "Configure AI Module"}',
  '{"zh": "允许配置AI模块设置", "en": "Allow configuring AI module settings"}',
  'action'
)
ON CONFLICT (module_id, permission_key) DO NOTHING;

-- 4. 设置模块依赖
INSERT INTO sys_module_dependencies (
  module_id,
  depends_on_module_id,
  dependency_type,
  min_version
) VALUES
(
  (SELECT id FROM sys_modules WHERE module_key = 'module.smartinsight'),
  (SELECT id FROM sys_modules WHERE module_key = 'core.system'),
  'required',
  '1.0.0'
)
ON CONFLICT (module_id, depends_on_module_id) DO NOTHING;

-- 5. 创建示例 AI 分析任务
INSERT INTO ai_analysis_tasks (
  task_key,
  task_name,
  description,
  task_type,
  analysis_category,
  data_source,
  analysis_config,
  schedule_type,
  status,
  is_enabled
) VALUES
(
  'sales_trend_analysis',
  '{"zh": "销售趋势分析", "en": "Sales Trend Analysis"}',
  '{"zh": "分析近期销售数据，识别趋势和模式", "en": "Analyze recent sales data to identify trends and patterns"}',
  'trend_prediction',
  'sales',
  '{
    "table": "orders",
    "date_field": "created_at",
    "value_field": "total_amount",
    "time_range": "30d"
  }',
  '{
    "metrics": ["total_sales", "order_count", "avg_order_value"],
    "aggregation": "daily",
    "forecast_days": 7
  }',
  'cron',
  'active',
  true
),
(
  'inventory_anomaly_detection',
  '{"zh": "库存异常检测", "en": "Inventory Anomaly Detection"}',
  '{"zh": "实时监控库存变化，检测异常情况", "en": "Monitor inventory changes in real-time to detect anomalies"}',
  'anomaly_detection',
  'inventory',
  '{
    "table": "inventory",
    "metrics": ["quantity", "turnover_rate"]
  }',
  '{
    "threshold_method": "statistical",
    "sensitivity": "medium",
    "alert_severity": "high"
  }',
  'real_time',
  'active',
  true
),
(
  'customer_segmentation',
  '{"zh": "客户分群分析", "en": "Customer Segmentation"}',
  '{"zh": "基于购买行为对客户进行智能分群", "en": "Intelligently segment customers based on purchase behavior"}',
  'clustering',
  'customer',
  '{
    "table": "orders",
    "join": ["customers"],
    "features": ["total_purchases", "avg_order_value", "purchase_frequency", "last_purchase_days"]
  }',
  '{
    "algorithm": "kmeans",
    "n_clusters": 5,
    "feature_scaling": true
  }',
  'manual',
  'inactive',
  false
)
ON CONFLICT (task_key) DO NOTHING;

-- 6. 创建示例 AI 智能规则
INSERT INTO ai_rules (
  rule_key,
  rule_name,
  description,
  rule_type,
  category,
  conditions,
  actions,
  priority,
  trigger_events,
  status,
  is_enabled
) VALUES
(
  'low_stock_alert_rule',
  '{"zh": "低库存自动预警", "en": "Low Stock Auto Alert"}',
  '{"zh": "当商品库存低于阈值时自动创建预警", "en": "Automatically create alerts when product stock falls below threshold"}',
  'threshold',
  'automation',
  '[
    {
      "field": "inventory.quantity",
      "operator": "less_than",
      "value": "inventory.reorder_point"
    }
  ]',
  '[
    {
      "type": "create_insight",
      "params": {
        "insight_type": "alert",
        "severity": "high",
        "category": "inventory"
      }
    },
    {
      "type": "send_notification",
      "params": {
        "channels": ["email", "system"],
        "recipients": ["inventory_manager"]
      }
    }
  ]',
  9,
  '["inventory.updated"]',
  'active',
  true
),
(
  'high_value_customer_rule',
  '{"zh": "高价值客户识别", "en": "High Value Customer Identification"}',
  '{"zh": "识别高价值客户并触发特殊服务流程", "en": "Identify high-value customers and trigger special service workflows"}',
  'condition_action',
  'automation',
  '[
    {
      "field": "customer.lifetime_value",
      "operator": "greater_than",
      "value": 10000
    }
  ]',
  '[
    {
      "type": "tag_customer",
      "params": {
        "tag": "vip_customer"
      }
    },
    {
      "type": "execute_workflow",
      "params": {
        "workflow_key": "vip_customer_onboarding"
      }
    }
  ]',
  8,
  '["order.completed"]',
  'draft',
  false
)
ON CONFLICT (rule_key) DO NOTHING;

-- 7. 创建示例工作流
INSERT INTO ai_workflows (
  workflow_key,
  workflow_name,
  description,
  workflow_type,
  category,
  workflow_definition,
  trigger_config,
  trigger_type,
  status,
  is_enabled
) VALUES
(
  'daily_sales_report',
  '{"zh": "每日销售报告", "en": "Daily Sales Report"}',
  '{"zh": "自动生成并发送每日销售分析报告", "en": "Automatically generate and send daily sales analysis report"}',
  'sequential',
  'automation',
  '{
    "nodes": [
      {
        "id": "fetch_data",
        "type": "data_query",
        "config": {
          "query": "SELECT * FROM orders WHERE DATE(created_at) = CURRENT_DATE"
        }
      },
      {
        "id": "analyze",
        "type": "ai_analysis",
        "config": {
          "task_key": "sales_trend_analysis"
        }
      },
      {
        "id": "generate_report",
        "type": "report_generator",
        "config": {
          "template": "daily_sales"
        }
      },
      {
        "id": "send_email",
        "type": "email",
        "config": {
          "recipients": ["management@company.com"],
          "subject": "每日销售报告"
        }
      }
    ],
    "edges": [
      {"from": "fetch_data", "to": "analyze"},
      {"from": "analyze", "to": "generate_report"},
      {"from": "generate_report", "to": "send_email"}
    ]
  }',
  '{
    "schedule": "0 9 * * *",
    "timezone": "Asia/Shanghai"
  }',
  'scheduled',
  'draft',
  false
)
ON CONFLICT (workflow_key) DO NOTHING;
