/*
  # 168全球购COD系统 - 完整数据库架构

  ## 系统概述
  专业的货到付款(COD)电商订单与流量管理系统
  - 多租户架构：基于域名的数据隔离
  - RBAC权限系统：角色+权限精细化控制
  - 多语言多币种支持
  - 完整的数据分析和风控系统

  ## 核心表结构

  ### 1. 权限管理系统
    - sys_roles: 系统角色表
    - sys_permissions: 系统权限表
    - sys_role_permissions: 角色权限关联表
    - sys_admins: 管理员表
    - sys_domains: 域名表（多租户核心）
    - sys_admin_domains: 管理员域名权限表

  ### 2. 产品管理系统
    - sys_products: 产品表
    - sys_product_images: 产品图片表
    - sys_product_modules: 产品模块表（动态模块配置）
    - sys_product_skus: SKU表
    - sys_product_prices: 阶梯价格表

  ### 3. 订单系统
    - sys_orders: 订单表
    - sys_order_items: 订单明细表
    - sys_order_logs: 订单日志表

  ### 4. 风控系统
    - sys_blacklist: 黑名单表
    - sys_risk_rules: 风控规则表

  ### 5. 数据分析系统
    - sys_analytics_logs: 访问日志表
    - sys_analytics_hourly: 小时级统计表
    - sys_analytics_daily: 日级统计表

  ## 安全策略
    - 所有表启用RLS
    - 超级管理员：完全访问权限
    - 主推广员：仅访问自己域名的数据
    - 运营人员：仅操作产品和订单
    - 查看者：只读权限
*/

-- ============================================
-- 第一部分：权限管理系统
-- ============================================

-- 1. 系统角色表
CREATE TABLE IF NOT EXISTS sys_roles (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text UNIQUE NOT NULL,
  display_name text NOT NULL,
  description text,
  level integer NOT NULL DEFAULT 999,
  is_system_role boolean DEFAULT false,
  created_at timestamptz DEFAULT now()
);

-- 2. 系统权限表
CREATE TABLE IF NOT EXISTS sys_permissions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  code text UNIQUE NOT NULL,
  name text NOT NULL,
  category text NOT NULL,
  description text,
  created_at timestamptz DEFAULT now()
);

-- 3. 角色权限关联表
CREATE TABLE IF NOT EXISTS sys_role_permissions (
  role_id uuid REFERENCES sys_roles(id) ON DELETE CASCADE,
  permission_id uuid REFERENCES sys_permissions(id) ON DELETE CASCADE,
  created_at timestamptz DEFAULT now(),
  PRIMARY KEY (role_id, permission_id)
);

-- 4. 管理员表
CREATE TABLE IF NOT EXISTS sys_admins (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  email text UNIQUE NOT NULL,
  password_hash text NOT NULL,
  full_name text NOT NULL,
  phone text,
  avatar text,
  role_id uuid REFERENCES sys_roles(id) ON DELETE SET NULL,
  parent_admin_id uuid,
  is_super_admin boolean DEFAULT false,
  status text DEFAULT 'active' CHECK (status IN ('active', 'suspended', 'inactive')),
  last_login_at timestamptz,
  last_login_ip text,
  created_at timestamptz DEFAULT now(),
  created_by uuid,
  updated_at timestamptz DEFAULT now()
);

-- 添加自引用外键
ALTER TABLE sys_admins DROP CONSTRAINT IF EXISTS fk_sys_admins_parent;
ALTER TABLE sys_admins DROP CONSTRAINT IF EXISTS fk_sys_admins_created_by;
ALTER TABLE sys_admins 
  ADD CONSTRAINT fk_sys_admins_parent 
  FOREIGN KEY (parent_admin_id) REFERENCES sys_admins(id) ON DELETE SET NULL;
ALTER TABLE sys_admins 
  ADD CONSTRAINT fk_sys_admins_created_by 
  FOREIGN KEY (created_by) REFERENCES sys_admins(id) ON DELETE SET NULL;

-- 5. 域名表（多租户核心）
CREATE TABLE IF NOT EXISTS sys_domains (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  domain text UNIQUE NOT NULL,
  display_name text NOT NULL,
  owner_id uuid REFERENCES sys_admins(id) ON DELETE CASCADE,
  status text DEFAULT 'active' CHECK (status IN ('active', 'suspended', 'expired')),
  is_primary boolean DEFAULT false,
  ssl_enabled boolean DEFAULT true,
  anti_block_rotation boolean DEFAULT false,
  tracking_pixel_fb text,
  tracking_pixel_tiktok text,
  tracking_pixel_google text,
  language_code text DEFAULT 'zh-CN',
  currency_code text DEFAULT 'CNY',
  created_at timestamptz DEFAULT now(),
  expires_at timestamptz,
  updated_at timestamptz DEFAULT now()
);

-- 6. 管理员域名权限表
CREATE TABLE IF NOT EXISTS sys_admin_domains (
  admin_id uuid REFERENCES sys_admins(id) ON DELETE CASCADE,
  domain_id uuid REFERENCES sys_domains(id) ON DELETE CASCADE,
  access_level text DEFAULT 'viewer' CHECK (access_level IN ('owner', 'manager', 'viewer')),
  created_at timestamptz DEFAULT now(),
  PRIMARY KEY (admin_id, domain_id)
);

-- 7. 操作日志表
CREATE TABLE IF NOT EXISTS sys_operation_logs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  admin_id uuid REFERENCES sys_admins(id) ON DELETE SET NULL,
  domain_id uuid REFERENCES sys_domains(id) ON DELETE SET NULL,
  operation text NOT NULL,
  resource_type text,
  resource_id uuid,
  details jsonb,
  ip_address text,
  user_agent text,
  created_at timestamptz DEFAULT now()
);

-- ============================================
-- 第二部分：产品管理系统
-- ============================================

-- 1. 产品表
CREATE TABLE IF NOT EXISTS sys_products (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  domain_id uuid REFERENCES sys_domains(id) ON DELETE CASCADE,
  serial_number text,
  product_type text DEFAULT 'single' CHECK (product_type IN ('single', 'multi', 'link')),
  title jsonb NOT NULL,
  description jsonb,
  page_title text,
  base_price decimal(10,2) NOT NULL,
  compare_price decimal(10,2),
  currency_code text DEFAULT 'CNY',
  stock integer DEFAULT 0,
  category text,
  tags text[],
  seo_keywords text,
  status text DEFAULT 'draft' CHECK (status IN ('draft', 'active', 'inactive', 'archived')),
  enable_video boolean DEFAULT false,
  video_url text,
  enable_countdown boolean DEFAULT false,
  countdown_end_at timestamptz,
  views_count integer DEFAULT 0,
  orders_count integer DEFAULT 0,
  conversion_rate decimal(5,2) DEFAULT 0,
  created_by uuid REFERENCES sys_admins(id) ON DELETE SET NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  published_at timestamptz
);

-- 2. 产品图片表
CREATE TABLE IF NOT EXISTS sys_product_images (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  product_id uuid REFERENCES sys_products(id) ON DELETE CASCADE,
  image_type text NOT NULL CHECK (image_type IN ('main', 'module', 'detail')),
  original_url text NOT NULL,
  webp_url text,
  avif_url text,
  link_url text,
  sort_order integer DEFAULT 0,
  is_primary boolean DEFAULT false,
  created_at timestamptz DEFAULT now()
);

-- 3. 产品模块表（动态模块配置）
CREATE TABLE IF NOT EXISTS sys_product_modules (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  product_id uuid REFERENCES sys_products(id) ON DELETE CASCADE,
  module_type text NOT NULL,
  module_name jsonb NOT NULL,
  module_config jsonb,
  sort_order integer DEFAULT 0,
  is_enabled boolean DEFAULT true,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- 4. SKU表
CREATE TABLE IF NOT EXISTS sys_product_skus (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  product_id uuid REFERENCES sys_products(id) ON DELETE CASCADE,
  sku_code text UNIQUE NOT NULL,
  name jsonb NOT NULL,
  attributes jsonb,
  price decimal(10,2) NOT NULL,
  stock integer DEFAULT 0,
  image_url text,
  is_enabled boolean DEFAULT true,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- 5. 阶梯价格表
CREATE TABLE IF NOT EXISTS sys_product_prices (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  product_id uuid REFERENCES sys_products(id) ON DELETE CASCADE,
  sku_id uuid REFERENCES sys_product_skus(id) ON DELETE CASCADE,
  min_quantity integer NOT NULL,
  max_quantity integer,
  price decimal(10,2) NOT NULL,
  discount_percent decimal(5,2),
  created_at timestamptz DEFAULT now()
);

-- ============================================
-- 第三部分：订单系统
-- ============================================

-- 1. 订单表
CREATE TABLE IF NOT EXISTS sys_orders (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  order_number text UNIQUE NOT NULL,
  domain_id uuid REFERENCES sys_domains(id) ON DELETE SET NULL,
  customer_name text NOT NULL,
  customer_phone text NOT NULL,
  customer_email text,
  customer_address jsonb NOT NULL,
  province text,
  city text,
  district text,
  detailed_address text,
  zip_code text,
  total_amount decimal(10,2) NOT NULL,
  shipping_fee decimal(10,2) DEFAULT 0,
  discount_amount decimal(10,2) DEFAULT 0,
  final_amount decimal(10,2) NOT NULL,
  currency_code text DEFAULT 'CNY',
  payment_method text DEFAULT 'cod' CHECK (payment_method IN ('cod', 'online', 'usdt')),
  payment_status text DEFAULT 'pending' CHECK (payment_status IN ('pending', 'paid', 'failed', 'refunded')),
  order_status text DEFAULT 'pending' CHECK (order_status IN ('pending', 'confirmed', 'processing', 'shipped', 'delivered', 'cancelled', 'returned')),
  shipping_company text,
  tracking_number text,
  customer_ip text,
  customer_user_agent text,
  utm_source text,
  utm_medium text,
  utm_campaign text,
  is_risk_order boolean DEFAULT false,
  risk_score integer DEFAULT 0,
  risk_reason text,
  notes text,
  deleted_at timestamptz,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  confirmed_at timestamptz,
  shipped_at timestamptz,
  delivered_at timestamptz,
  cancelled_at timestamptz
);

-- 2. 订单明细表
CREATE TABLE IF NOT EXISTS sys_order_items (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  order_id uuid REFERENCES sys_orders(id) ON DELETE CASCADE,
  product_id uuid REFERENCES sys_products(id) ON DELETE SET NULL,
  sku_id uuid REFERENCES sys_product_skus(id) ON DELETE SET NULL,
  product_name text NOT NULL,
  sku_name text,
  quantity integer NOT NULL,
  unit_price decimal(10,2) NOT NULL,
  total_price decimal(10,2) NOT NULL,
  created_at timestamptz DEFAULT now()
);

-- 3. 订单日志表
CREATE TABLE IF NOT EXISTS sys_order_logs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  order_id uuid REFERENCES sys_orders(id) ON DELETE CASCADE,
  admin_id uuid REFERENCES sys_admins(id) ON DELETE SET NULL,
  action text NOT NULL,
  from_status text,
  to_status text,
  notes text,
  created_at timestamptz DEFAULT now()
);

-- ============================================
-- 第四部分：风控系统
-- ============================================

-- 1. 黑名单表
CREATE TABLE IF NOT EXISTS sys_blacklist (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  type text NOT NULL CHECK (type IN ('phone', 'ip', 'address', 'email')),
  value text NOT NULL,
  reason text,
  domain_id uuid REFERENCES sys_domains(id) ON DELETE SET NULL,
  is_global boolean DEFAULT false,
  added_by uuid REFERENCES sys_admins(id) ON DELETE SET NULL,
  created_at timestamptz DEFAULT now(),
  expires_at timestamptz,
  UNIQUE(type, value, domain_id)
);

-- 2. 风控规则表
CREATE TABLE IF NOT EXISTS sys_risk_rules (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  rule_type text NOT NULL CHECK (rule_type IN ('ip_location', 'order_frequency', 'amount_threshold', 'address_mismatch')),
  conditions jsonb NOT NULL,
  risk_score integer DEFAULT 0,
  action text DEFAULT 'flag' CHECK (action IN ('flag', 'block', 'review')),
  is_enabled boolean DEFAULT true,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- ============================================
-- 第五部分：数据分析系统
-- ============================================

-- 1. 访问日志表
CREATE TABLE IF NOT EXISTS sys_analytics_logs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  domain_id uuid REFERENCES sys_domains(id) ON DELETE CASCADE,
  product_id uuid REFERENCES sys_products(id) ON DELETE SET NULL,
  event_type text NOT NULL CHECK (event_type IN ('page_view', 'product_view', 'add_to_cart', 'checkout', 'order')),
  visitor_ip text,
  visitor_country text,
  visitor_city text,
  user_agent text,
  referrer text,
  utm_source text,
  utm_medium text,
  utm_campaign text,
  device_type text,
  browser text,
  os text,
  session_id text,
  metadata jsonb,
  created_at timestamptz DEFAULT now()
);

-- 2. 小时级统计表
CREATE TABLE IF NOT EXISTS sys_analytics_hourly (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  domain_id uuid REFERENCES sys_domains(id) ON DELETE CASCADE,
  product_id uuid REFERENCES sys_products(id) ON DELETE SET NULL,
  hour_start timestamptz NOT NULL,
  page_views integer DEFAULT 0,
  unique_visitors integer DEFAULT 0,
  orders_count integer DEFAULT 0,
  revenue decimal(10,2) DEFAULT 0,
  conversion_rate decimal(5,2) DEFAULT 0,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  UNIQUE(domain_id, product_id, hour_start)
);

-- 3. 日级统计表
CREATE TABLE IF NOT EXISTS sys_analytics_daily (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  domain_id uuid REFERENCES sys_domains(id) ON DELETE CASCADE,
  product_id uuid REFERENCES sys_products(id) ON DELETE SET NULL,
  date date NOT NULL,
  page_views integer DEFAULT 0,
  unique_visitors integer DEFAULT 0,
  orders_count integer DEFAULT 0,
  revenue decimal(10,2) DEFAULT 0,
  avg_order_value decimal(10,2) DEFAULT 0,
  conversion_rate decimal(5,2) DEFAULT 0,
  bounce_rate decimal(5,2) DEFAULT 0,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  UNIQUE(domain_id, product_id, date)
);

-- ============================================
-- 创建索引
-- ============================================

-- 管理员表索引
CREATE INDEX IF NOT EXISTS idx_sys_admins_email ON sys_admins(email);
CREATE INDEX IF NOT EXISTS idx_sys_admins_status ON sys_admins(status);
CREATE INDEX IF NOT EXISTS idx_sys_admins_role_id ON sys_admins(role_id);
CREATE INDEX IF NOT EXISTS idx_sys_admins_parent_id ON sys_admins(parent_admin_id);
CREATE INDEX IF NOT EXISTS idx_sys_admins_is_super_admin ON sys_admins(is_super_admin);

-- 域名表索引
CREATE INDEX IF NOT EXISTS idx_sys_domains_owner_id ON sys_domains(owner_id);
CREATE INDEX IF NOT EXISTS idx_sys_domains_status ON sys_domains(status);
CREATE INDEX IF NOT EXISTS idx_sys_domains_domain ON sys_domains(domain);

-- 产品表索引
CREATE INDEX IF NOT EXISTS idx_sys_products_domain_id ON sys_products(domain_id);
CREATE INDEX IF NOT EXISTS idx_sys_products_status ON sys_products(status);
CREATE INDEX IF NOT EXISTS idx_sys_products_serial_number ON sys_products(serial_number);
CREATE INDEX IF NOT EXISTS idx_sys_products_created_at ON sys_products(created_at DESC);

-- 订单表索引
CREATE INDEX IF NOT EXISTS idx_sys_orders_domain_id ON sys_orders(domain_id);
CREATE INDEX IF NOT EXISTS idx_sys_orders_order_number ON sys_orders(order_number);
CREATE INDEX IF NOT EXISTS idx_sys_orders_customer_phone ON sys_orders(customer_phone);
CREATE INDEX IF NOT EXISTS idx_sys_orders_status ON sys_orders(order_status);
CREATE INDEX IF NOT EXISTS idx_sys_orders_created_at ON sys_orders(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_sys_orders_deleted_at ON sys_orders(deleted_at);

-- 分析日志索引
CREATE INDEX IF NOT EXISTS idx_sys_analytics_logs_domain_id ON sys_analytics_logs(domain_id);
CREATE INDEX IF NOT EXISTS idx_sys_analytics_logs_product_id ON sys_analytics_logs(product_id);
CREATE INDEX IF NOT EXISTS idx_sys_analytics_logs_created_at ON sys_analytics_logs(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_sys_analytics_logs_event_type ON sys_analytics_logs(event_type);

-- ============================================
-- 插入系统角色
-- ============================================

INSERT INTO sys_roles (name, display_name, description, level, is_system_role) VALUES
  ('super_admin', '超级管理员', '拥有系统所有权限，第一个注册用户默认为超级管理员', 1, true),
  ('promoter', '主推广员', '可管理自己的域名、产品和订单，可创建子账户', 50, true),
  ('operator', '运营人员', '可管理产品和订单，但不能管理用户', 100, true),
  ('viewer', '查看者', '只能查看数据，不能修改', 999, true)
ON CONFLICT (name) DO NOTHING;

-- ============================================
-- 插入系统权限
-- ============================================

INSERT INTO sys_permissions (code, name, category, description) VALUES
  -- 管理员权限
  ('admins.view_all', '查看所有管理员', 'admins', '可查看系统所有管理员'),
  ('admins.view_own', '查看下级管理员', 'admins', '可查看自己创建的管理员'),
  ('admins.create', '创建管理员', 'admins', '可创建新管理员'),
  ('admins.update', '更新管理员', 'admins', '可更新管理员信息'),
  ('admins.delete', '删除管理员', 'admins', '可删除管理员'),
  
  -- 域名权限
  ('domains.view_all', '查看所有域名', 'domains', '可查看系统所有域名'),
  ('domains.view_own', '查看自己的域名', 'domains', '只能查看自己的域名'),
  ('domains.create', '创建域名', 'domains', '可创建新域名'),
  ('domains.update', '更新域名', 'domains', '可更新域名配置'),
  ('domains.delete', '删除域名', 'domains', '可删除域名'),
  
  -- 产品权限
  ('products.view_all', '查看所有产品', 'products', '可查看系统所有产品'),
  ('products.view_own', '查看自己的产品', 'products', '只能查看自己域名的产品'),
  ('products.create', '创建产品', 'products', '可创建新产品'),
  ('products.update', '更新产品', 'products', '可更新产品信息'),
  ('products.delete', '删除产品', 'products', '可删除产品'),
  
  -- 订单权限
  ('orders.view_all', '查看所有订单', 'orders', '可查看系统所有订单'),
  ('orders.view_own', '查看自己的订单', 'orders', '只能查看自己域名的订单'),
  ('orders.create', '创建订单', 'orders', '可创建新订单'),
  ('orders.update', '更新订单', 'orders', '可更新订单状态'),
  ('orders.delete', '删除订单', 'orders', '可删除订单'),
  ('orders.export', '导出订单', 'orders', '可导出订单数据'),
  
  -- 数据分析权限
  ('analytics.view_all', '查看所有数据', 'analytics', '可查看系统所有统计数据'),
  ('analytics.view_own', '查看自己的数据', 'analytics', '只能查看自己域名的统计数据'),
  
  -- 系统配置权限
  ('settings.view', '查看系统配置', 'settings', '可查看系统配置'),
  ('settings.update', '更新系统配置', 'settings', '可更新系统配置')
ON CONFLICT (code) DO NOTHING;