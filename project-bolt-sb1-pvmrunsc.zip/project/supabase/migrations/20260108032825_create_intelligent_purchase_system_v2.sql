/*
  # 智能采购系统 V2

  ## 新增表
  1. `pur_supplier_products` - 供应商商品库
     - 存储从供应商链接抓取的商品信息
     - 支持自动定价和上架
  
  2. `pur_listing_queue` - 商品自动上架队列
     - 管理待上架商品的处理流程
  
  3. `pur_price_rules` - 定价规则表
     - 管理不同的定价策略

  ## 增强现有表
  - `pur_purchase_orders` - 添加自动入库标记
  - `pur_purchase_items` - 添加供应商商品关联

  ## 核心功能
  1. 自动抓取供应商链接的商品信息（图片、标题、描述、价格）
  2. 按配置的加价百分比自动计算售价
  3. 采购入库后自动上架到商品系统
  4. 支持批量处理和队列管理

  ## 安全性
  - 所有表启用RLS
  - 仅管理员可访问和操作
*/

-- 定价规则表
CREATE TABLE IF NOT EXISTS pur_price_rules (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  rule_name text NOT NULL,
  rule_type text DEFAULT 'percentage_markup' CHECK (rule_type IN ('percentage_markup', 'fixed_markup', 'tiered')),
  markup_value numeric(10,2) NOT NULL,
  rounding_rule text DEFAULT 'normal' CHECK (rounding_rule IN ('normal', 'to_9', 'to_5', 'ceil', 'floor')),
  min_price numeric(10,2),
  max_price numeric(10,2),
  is_active boolean DEFAULT true,
  created_by uuid REFERENCES sys_admins(id),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- 供应商商品库
CREATE TABLE IF NOT EXISTS pur_supplier_products (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  supplier_id uuid REFERENCES pur_suppliers(id) ON DELETE CASCADE,
  product_link text NOT NULL,
  product_code text,
  
  -- 抓取的商品信息
  scraped_title text,
  scraped_description text,
  scraped_images jsonb DEFAULT '[]'::jsonb,
  scraped_specs jsonb DEFAULT '{}'::jsonb,
  scraped_price numeric(10,2),
  
  -- 定价信息
  cost_price numeric(10,2) NOT NULL,
  markup_percentage numeric(5,2) DEFAULT 0,
  selling_price numeric(10,2),
  price_rule_id uuid REFERENCES pur_price_rules(id),
  
  -- 状态管理
  scrape_status text DEFAULT 'pending' CHECK (scrape_status IN ('pending', 'processing', 'success', 'failed')),
  scrape_error text,
  last_scraped_at timestamptz,
  
  -- 采购与上架
  is_purchased boolean DEFAULT false,
  purchased_quantity integer DEFAULT 0,
  is_listed boolean DEFAULT false,
  listed_product_id uuid REFERENCES sys_products(id),
  
  created_by uuid REFERENCES sys_admins(id),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- 商品自动上架队列
CREATE TABLE IF NOT EXISTS pur_listing_queue (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  supplier_product_id uuid REFERENCES pur_supplier_products(id) ON DELETE CASCADE,
  purchase_item_id uuid REFERENCES pur_purchase_items(id),
  
  -- 上架配置
  target_category_id uuid REFERENCES sys_categories(id),
  price_rule_id uuid REFERENCES pur_price_rules(id),
  initial_stock integer DEFAULT 100,
  
  -- 自动生成配置
  auto_title boolean DEFAULT true,
  custom_title text,
  auto_description boolean DEFAULT true,
  custom_description text,
  auto_images boolean DEFAULT true,
  
  -- 处理状态
  status text DEFAULT 'pending' CHECK (status IN ('pending', 'processing', 'completed', 'failed', 'cancelled')),
  error_message text,
  retry_count integer DEFAULT 0,
  max_retries integer DEFAULT 3,
  
  processed_at timestamptz,
  created_by uuid REFERENCES sys_admins(id),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- 增强采购订单表（如果列不存在则添加）
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'pur_purchase_orders' AND column_name = 'auto_inbound'
  ) THEN
    ALTER TABLE pur_purchase_orders ADD COLUMN auto_inbound boolean DEFAULT true;
  END IF;
  
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'pur_purchase_orders' AND column_name = 'order_type'
  ) THEN
    ALTER TABLE pur_purchase_orders ADD COLUMN order_type text DEFAULT 'manual' CHECK (order_type IN ('manual', 'auto'));
  END IF;
END $$;

-- 增强采购明细表（如果列不存在则添加）
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'pur_purchase_items' AND column_name = 'supplier_product_id'
  ) THEN
    ALTER TABLE pur_purchase_items ADD COLUMN supplier_product_id uuid REFERENCES pur_supplier_products(id);
  END IF;
END $$;

-- 启用RLS
ALTER TABLE pur_price_rules ENABLE ROW LEVEL SECURITY;
ALTER TABLE pur_supplier_products ENABLE ROW LEVEL SECURITY;
ALTER TABLE pur_listing_queue ENABLE ROW LEVEL SECURITY;

-- RLS策略：管理员可以查看所有数据
CREATE POLICY "Admins can view price rules"
  ON pur_price_rules FOR SELECT TO authenticated
  USING (
    EXISTS (SELECT 1 FROM sys_admins WHERE id = auth.uid())
  );

CREATE POLICY "Admins can manage price rules"
  ON pur_price_rules FOR ALL TO authenticated
  USING (
    EXISTS (SELECT 1 FROM sys_admins WHERE id = auth.uid())
  )
  WITH CHECK (
    EXISTS (SELECT 1 FROM sys_admins WHERE id = auth.uid())
  );

CREATE POLICY "Admins can view supplier products"
  ON pur_supplier_products FOR SELECT TO authenticated
  USING (
    EXISTS (SELECT 1 FROM sys_admins WHERE id = auth.uid())
  );

CREATE POLICY "Admins can manage supplier products"
  ON pur_supplier_products FOR ALL TO authenticated
  USING (
    EXISTS (SELECT 1 FROM sys_admins WHERE id = auth.uid())
  )
  WITH CHECK (
    EXISTS (SELECT 1 FROM sys_admins WHERE id = auth.uid())
  );

CREATE POLICY "Admins can view listing queue"
  ON pur_listing_queue FOR SELECT TO authenticated
  USING (
    EXISTS (SELECT 1 FROM sys_admins WHERE id = auth.uid())
  );

CREATE POLICY "Admins can manage listing queue"
  ON pur_listing_queue FOR ALL TO authenticated
  USING (
    EXISTS (SELECT 1 FROM sys_admins WHERE id = auth.uid())
  )
  WITH CHECK (
    EXISTS (SELECT 1 FROM sys_admins WHERE id = auth.uid())
  );

-- 创建索引
CREATE INDEX IF NOT EXISTS idx_supplier_products_link ON pur_supplier_products(product_link);
CREATE INDEX IF NOT EXISTS idx_supplier_products_status ON pur_supplier_products(scrape_status);
CREATE INDEX IF NOT EXISTS idx_supplier_products_supplier ON pur_supplier_products(supplier_id);
CREATE INDEX IF NOT EXISTS idx_listing_queue_status ON pur_listing_queue(status);
CREATE INDEX IF NOT EXISTS idx_price_rules_active ON pur_price_rules(is_active) WHERE is_active = true;
