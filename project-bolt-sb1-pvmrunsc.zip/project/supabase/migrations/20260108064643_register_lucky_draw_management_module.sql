/*
  # 注册一元购管理模块路由

  ## 功能说明
  为一元购系统添加两个管理页面：
  1. 地区管理页面（超级管理员专用）
  2. 店铺设置页面（店铺管理员）

  ## 新增路由
  - /admin/lucky-draw/regions: 地区管理（仅超级管理员）
  - /admin/lucky-draw/settings: 一元购设置（店铺管理员）
*/

DO $$
DECLARE
  v_module_id uuid;
BEGIN
  SELECT id INTO v_module_id FROM sys_modules WHERE module_key = 'lucky_draw';

  IF v_module_id IS NULL THEN
    INSERT INTO sys_modules (
      module_key,
      module_name,
      description,
      module_version,
      category,
      icon,
      color,
      status,
      is_core,
      is_system,
      module_type
    ) VALUES (
      'lucky_draw',
      '{"zh": "一元购管理", "en": "Lucky Draw Management"}'::jsonb,
      '{"zh": "一元购功能管理与配置", "en": "Lucky draw feature management and configuration"}'::jsonb,
      '1.0.0',
      'sales',
      'gift',
      'purple',
      'enabled',
      false,
      false,
      'full'
    ) RETURNING id INTO v_module_id;
  END IF;

  IF NOT EXISTS (SELECT 1 FROM sys_module_routes WHERE route_path = '/admin/lucky-draw/regions') THEN
    INSERT INTO sys_module_routes (
      module_id,
      route_path,
      component_name,
      is_menu_item,
      menu_label,
      menu_icon,
      menu_order,
      requires_auth,
      required_permissions,
      is_active
    ) VALUES (
      v_module_id,
      '/admin/lucky-draw/regions',
      'LuckyDrawRegions',
      true,
      '{"zh": "地区管理", "en": "Regions"}'::jsonb,
      'globe',
      100,
      true,
      '["lucky_draw.manage_regions"]'::jsonb,
      true
    );
  END IF;

  IF NOT EXISTS (SELECT 1 FROM sys_module_routes WHERE route_path = '/admin/lucky-draw/settings') THEN
    INSERT INTO sys_module_routes (
      module_id,
      route_path,
      component_name,
      is_menu_item,
      menu_label,
      menu_icon,
      menu_order,
      requires_auth,
      required_permissions,
      is_active
    ) VALUES (
      v_module_id,
      '/admin/lucky-draw/settings',
      'LuckyDrawSettings',
      true,
      '{"zh": "一元购设置", "en": "Settings"}'::jsonb,
      'settings',
      101,
      true,
      '["lucky_draw.manage_product"]'::jsonb,
      true
    );
  END IF;

  RAISE NOTICE '一元购管理模块路由已注册';
END $$;
