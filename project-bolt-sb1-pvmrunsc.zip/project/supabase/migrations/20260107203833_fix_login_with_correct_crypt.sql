/*
  # 修复登录函数 - 正确使用crypt

  ## 修复内容
  直接使用crypt函数，不加schema前缀
*/

CREATE OR REPLACE FUNCTION sys_admin_login(
  p_email text,
  p_password text
)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  v_admin sys_admins;
  v_role sys_roles;
  v_password_match boolean;
BEGIN
  -- 查找管理员
  SELECT * INTO v_admin
  FROM sys_admins
  WHERE email = p_email
    AND status = 'active';
  
  IF NOT FOUND THEN
    RETURN jsonb_build_object(
      'success', false,
      'message', '邮箱或密码错误'
    );
  END IF;
  
  -- 验证密码
  SELECT crypt(p_password, v_admin.password_hash) = v_admin.password_hash
  INTO v_password_match;
  
  IF NOT v_password_match THEN
    RETURN jsonb_build_object(
      'success', false,
      'message', '邮箱或密码错误'
    );
  END IF;
  
  -- 获取角色信息
  SELECT * INTO v_role
  FROM sys_roles
  WHERE id = v_admin.role_id;
  
  -- 更新最后登录时间
  UPDATE sys_admins
  SET last_login_at = now()
  WHERE id = v_admin.id;
  
  -- 返回管理员信息
  RETURN jsonb_build_object(
    'success', true,
    'admin', jsonb_build_object(
      'id', v_admin.id,
      'email', v_admin.email,
      'full_name', v_admin.full_name,
      'phone', v_admin.phone,
      'avatar', v_admin.avatar,
      'is_super_admin', v_admin.is_super_admin,
      'status', v_admin.status,
      'role', jsonb_build_object(
        'id', v_role.id,
        'name', v_role.name,
        'display_name', v_role.display_name,
        'level', v_role.level
      )
    )
  );
EXCEPTION
  WHEN OTHERS THEN
    RETURN jsonb_build_object(
      'success', false,
      'message', '登录失败：' || SQLERRM
    );
END;
$$;