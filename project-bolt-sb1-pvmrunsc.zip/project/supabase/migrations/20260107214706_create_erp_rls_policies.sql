/*
  # ERP系统RLS策略

  ## 安全策略
  1. 启用所有新表的RLS
  2. 创建基于角色的访问控制策略
  3. 超级管理员拥有完全访问权限
  4. 内部员工根据部门和权限访问
  5. 商家只能访问自己的数据
*/

-- ============================================
-- 启用RLS
-- ============================================

ALTER TABLE sys_departments ENABLE ROW LEVEL SECURITY;
ALTER TABLE wms_warehouses ENABLE ROW LEVEL SECURITY;
ALTER TABLE wms_locations ENABLE ROW LEVEL SECURITY;
ALTER TABLE wms_inventory ENABLE ROW LEVEL SECURITY;
ALTER TABLE wms_inbound ENABLE ROW LEVEL SECURITY;
ALTER TABLE wms_inbound_items ENABLE ROW LEVEL SECURITY;
ALTER TABLE wms_outbound ENABLE ROW LEVEL SECURITY;
ALTER TABLE wms_outbound_items ENABLE ROW LEVEL SECURITY;
ALTER TABLE wms_stock_alerts ENABLE ROW LEVEL SECURITY;
ALTER TABLE lgs_carriers ENABLE ROW LEVEL SECURITY;
ALTER TABLE lgs_routes ENABLE ROW LEVEL SECURITY;
ALTER TABLE lgs_drivers ENABLE ROW LEVEL SECURITY;
ALTER TABLE lgs_vehicles ENABLE ROW LEVEL SECURITY;
ALTER TABLE lgs_shipments ENABLE ROW LEVEL SECURITY;
ALTER TABLE lgs_tracking ENABLE ROW LEVEL SECURITY;
ALTER TABLE lgs_delivery_zones ENABLE ROW LEVEL SECURITY;
ALTER TABLE fin_accounts ENABLE ROW LEVEL SECURITY;
ALTER TABLE fin_transactions ENABLE ROW LEVEL SECURITY;
ALTER TABLE fin_merchant_fees ENABLE ROW LEVEL SECURITY;
ALTER TABLE fin_employee_salaries ENABLE ROW LEVEL SECURITY;
ALTER TABLE fin_rewards_penalties ENABLE ROW LEVEL SECURITY;
ALTER TABLE fin_tax_records ENABLE ROW LEVEL SECURITY;
ALTER TABLE fin_settlements ENABLE ROW LEVEL SECURITY;
ALTER TABLE fin_invoices ENABLE ROW LEVEL SECURITY;
ALTER TABLE lot_campaigns ENABLE ROW LEVEL SECURITY;
ALTER TABLE lot_products ENABLE ROW LEVEL SECURITY;
ALTER TABLE lot_numbers ENABLE ROW LEVEL SECURITY;
ALTER TABLE lot_orders ENABLE ROW LEVEL SECURITY;
ALTER TABLE lot_draws ENABLE ROW LEVEL SECURITY;
ALTER TABLE lot_winners ENABLE ROW LEVEL SECURITY;
ALTER TABLE cs_conversations ENABLE ROW LEVEL SECURITY;
ALTER TABLE cs_messages ENABLE ROW LEVEL SECURITY;
ALTER TABLE cs_tickets ENABLE ROW LEVEL SECURITY;
ALTER TABLE cs_quick_replies ENABLE ROW LEVEL SECURITY;
ALTER TABLE cs_ratings ENABLE ROW LEVEL SECURITY;
ALTER TABLE alg_product_scores ENABLE ROW LEVEL SECURITY;
ALTER TABLE alg_ranking_rules ENABLE ROW LEVEL SECURITY;
ALTER TABLE alg_user_preferences ENABLE ROW LEVEL SECURITY;
ALTER TABLE alg_recommendations ENABLE ROW LEVEL SECURITY;
ALTER TABLE prm_channels ENABLE ROW LEVEL SECURITY;
ALTER TABLE prm_campaigns ENABLE ROW LEVEL SECURITY;
ALTER TABLE prm_materials ENABLE ROW LEVEL SECURITY;
ALTER TABLE prm_tracking ENABLE ROW LEVEL SECURITY;
ALTER TABLE prm_conversions ENABLE ROW LEVEL SECURITY;
ALTER TABLE pur_suppliers ENABLE ROW LEVEL SECURITY;
ALTER TABLE pur_purchase_orders ENABLE ROW LEVEL SECURITY;
ALTER TABLE pur_purchase_items ENABLE ROW LEVEL SECURITY;
ALTER TABLE pur_price_rules ENABLE ROW LEVEL SECURITY;
ALTER TABLE pur_auto_listing ENABLE ROW LEVEL SECURITY;
ALTER TABLE sys_categories ENABLE ROW LEVEL SECURITY;
ALTER TABLE sys_service_categories ENABLE ROW LEVEL SECURITY;
ALTER TABLE sys_food_categories ENABLE ROW LEVEL SECURITY;

-- ============================================
-- 部门管理策略
-- ============================================

CREATE POLICY "超管和HR可查看所有部门"
  ON sys_departments FOR SELECT
  TO authenticated
  USING (
    (current_setting('request.jwt.claims', true)::json->>'is_super_admin')::boolean = true
    OR EXISTS (
      SELECT 1 FROM sys_admins
      WHERE sys_admins.id::text = current_setting('request.jwt.claims', true)::json->>'sub'
      AND sys_admins.department_id IN (
        SELECT id FROM sys_departments WHERE name IN ('人事部', 'HR')
      )
    )
  );

CREATE POLICY "超管和HR可管理部门"
  ON sys_departments FOR ALL
  TO authenticated
  USING (
    (current_setting('request.jwt.claims', true)::json->>'is_super_admin')::boolean = true
  );

-- ============================================
-- 仓储管理策略
-- ============================================

CREATE POLICY "认证用户可查看仓库"
  ON wms_warehouses FOR SELECT
  TO authenticated
  USING (
    (current_setting('request.jwt.claims', true)::json->>'is_super_admin')::boolean = true
    OR type = 'self_operated'
    OR manager_id::text = current_setting('request.jwt.claims', true)::json->>'sub'
  );

CREATE POLICY "仓库管理员可管理仓库"
  ON wms_warehouses FOR ALL
  TO authenticated
  USING (
    (current_setting('request.jwt.claims', true)::json->>'is_super_admin')::boolean = true
    OR manager_id::text = current_setting('request.jwt.claims', true)::json->>'sub'
  );

CREATE POLICY "商家可查看自己的库存"
  ON wms_inventory FOR SELECT
  TO authenticated
  USING (
    (current_setting('request.jwt.claims', true)::json->>'is_super_admin')::boolean = true
    OR merchant_id::text = current_setting('request.jwt.claims', true)::json->>'sub'
    OR EXISTS (
      SELECT 1 FROM sys_admins
      WHERE sys_admins.id::text = current_setting('request.jwt.claims', true)::json->>'sub'
      AND sys_admins.admin_type = 'internal'
    )
  );

-- ============================================
-- 物流管理策略
-- ============================================

CREATE POLICY "认证用户可查看物流公司"
  ON lgs_carriers FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "超管可管理物流公司"
  ON lgs_carriers FOR ALL
  TO authenticated
  USING (
    (current_setting('request.jwt.claims', true)::json->>'is_super_admin')::boolean = true
  );

CREATE POLICY "认证用户可查看发货单"
  ON lgs_shipments FOR SELECT
  TO authenticated
  USING (true);

-- ============================================
-- 财务管理策略
-- ============================================

CREATE POLICY "用户可查看自己的账户"
  ON fin_accounts FOR SELECT
  TO authenticated
  USING (
    (current_setting('request.jwt.claims', true)::json->>'is_super_admin')::boolean = true
    OR owner_id::text = current_setting('request.jwt.claims', true)::json->>'sub'
    OR EXISTS (
      SELECT 1 FROM sys_admins
      WHERE sys_admins.id::text = current_setting('request.jwt.claims', true)::json->>'sub'
      AND sys_admins.department_id IN (
        SELECT id FROM sys_departments WHERE name IN ('财务部', 'Finance')
      )
    )
  );

CREATE POLICY "财务部门可查看所有交易"
  ON fin_transactions FOR SELECT
  TO authenticated
  USING (
    (current_setting('request.jwt.claims', true)::json->>'is_super_admin')::boolean = true
    OR EXISTS (
      SELECT 1 FROM sys_admins
      WHERE sys_admins.id::text = current_setting('request.jwt.claims', true)::json->>'sub'
      AND sys_admins.department_id IN (
        SELECT id FROM sys_departments WHERE name IN ('财务部', 'Finance')
      )
    )
  );

CREATE POLICY "员工可查看自己的工资"
  ON fin_employee_salaries FOR SELECT
  TO authenticated
  USING (
    (current_setting('request.jwt.claims', true)::json->>'is_super_admin')::boolean = true
    OR employee_id::text = current_setting('request.jwt.claims', true)::json->>'sub'
    OR EXISTS (
      SELECT 1 FROM sys_admins
      WHERE sys_admins.id::text = current_setting('request.jwt.claims', true)::json->>'sub'
      AND (
        sys_admins.department_id IN (
          SELECT id FROM sys_departments WHERE name IN ('财务部', 'Finance', '人事部', 'HR')
        )
        OR sys_admins.is_super_admin = true
      )
    )
  );

-- ============================================
-- 一元购策略
-- ============================================

CREATE POLICY "认证用户可查看已批准的一元购活动"
  ON lot_campaigns FOR SELECT
  TO authenticated
  USING (
    status IN ('approved', 'active', 'completed')
    OR created_by::text = current_setting('request.jwt.claims', true)::json->>'sub'
    OR (current_setting('request.jwt.claims', true)::json->>'is_super_admin')::boolean = true
  );

CREATE POLICY "超管可管理一元购活动"
  ON lot_campaigns FOR ALL
  TO authenticated
  USING (
    (current_setting('request.jwt.claims', true)::json->>'is_super_admin')::boolean = true
  );

CREATE POLICY "商家可申请参加一元购"
  ON lot_products FOR INSERT
  TO authenticated
  WITH CHECK (
    merchant_id::text = current_setting('request.jwt.claims', true)::json->>'sub'
  );

CREATE POLICY "商家可查看自己的一元购商品"
  ON lot_products FOR SELECT
  TO authenticated
  USING (
    merchant_id::text = current_setting('request.jwt.claims', true)::json->>'sub'
    OR (current_setting('request.jwt.claims', true)::json->>'is_super_admin')::boolean = true
  );

CREATE POLICY "匿名用户可查看已激活的一元购商品"
  ON lot_products FOR SELECT
  TO anon
  USING (status IN ('active', 'drawing', 'completed'));

CREATE POLICY "匿名用户可查看可用号码"
  ON lot_numbers FOR SELECT
  TO anon
  USING (status = 'available');

-- ============================================
-- 客服系统策略
-- ============================================

CREATE POLICY "客服可查看分配给自己的会话"
  ON cs_conversations FOR SELECT
  TO authenticated
  USING (
    agent_id::text = current_setting('request.jwt.claims', true)::json->>'sub'
    OR (current_setting('request.jwt.claims', true)::json->>'is_super_admin')::boolean = true
    OR EXISTS (
      SELECT 1 FROM sys_admins
      WHERE sys_admins.id::text = current_setting('request.jwt.claims', true)::json->>'sub'
      AND sys_admins.department_id IN (
        SELECT id FROM sys_departments WHERE name IN ('客服部', 'Customer Service')
      )
    )
  );

CREATE POLICY "客服可查看会话消息"
  ON cs_messages FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM cs_conversations
      WHERE cs_conversations.id = cs_messages.conversation_id
      AND (
        cs_conversations.agent_id::text = current_setting('request.jwt.claims', true)::json->>'sub'
        OR (current_setting('request.jwt.claims', true)::json->>'is_super_admin')::boolean = true
      )
    )
  );

-- ============================================
-- 智能算法策略
-- ============================================

CREATE POLICY "认证用户可查看商品评分"
  ON alg_product_scores FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "超管可管理排名规则"
  ON alg_ranking_rules FOR ALL
  TO authenticated
  USING (
    (current_setting('request.jwt.claims', true)::json->>'is_super_admin')::boolean = true
  );

CREATE POLICY "系统可查看排名规则"
  ON alg_ranking_rules FOR SELECT
  TO authenticated
  USING (true);

-- ============================================
-- 推广系统策略
-- ============================================

CREATE POLICY "推广人员可查看推广渠道"
  ON prm_channels FOR SELECT
  TO authenticated
  USING (
    (current_setting('request.jwt.claims', true)::json->>'is_super_admin')::boolean = true
    OR EXISTS (
      SELECT 1 FROM sys_admins
      WHERE sys_admins.id::text = current_setting('request.jwt.claims', true)::json->>'sub'
      AND sys_admins.department_id IN (
        SELECT id FROM sys_departments WHERE name IN ('营销部', 'Marketing')
      )
    )
  );

CREATE POLICY "推广人员可管理推广活动"
  ON prm_campaigns FOR ALL
  TO authenticated
  USING (
    (current_setting('request.jwt.claims', true)::json->>'is_super_admin')::boolean = true
    OR created_by::text = current_setting('request.jwt.claims', true)::json->>'sub'
    OR EXISTS (
      SELECT 1 FROM sys_admins
      WHERE sys_admins.id::text = current_setting('request.jwt.claims', true)::json->>'sub'
      AND sys_admins.department_id IN (
        SELECT id FROM sys_departments WHERE name IN ('营销部', 'Marketing')
      )
    )
  );

-- ============================================
-- 采购系统策略
-- ============================================

CREATE POLICY "采购人员可查看供应商"
  ON pur_suppliers FOR SELECT
  TO authenticated
  USING (
    (current_setting('request.jwt.claims', true)::json->>'is_super_admin')::boolean = true
    OR EXISTS (
      SELECT 1 FROM sys_admins
      WHERE sys_admins.id::text = current_setting('request.jwt.claims', true)::json->>'sub'
      AND sys_admins.department_id IN (
        SELECT id FROM sys_departments WHERE name IN ('采购部', 'Procurement')
      )
    )
  );

CREATE POLICY "采购人员可管理采购单"
  ON pur_purchase_orders FOR ALL
  TO authenticated
  USING (
    (current_setting('request.jwt.claims', true)::json->>'is_super_admin')::boolean = true
    OR created_by::text = current_setting('request.jwt.claims', true)::json->>'sub'
    OR EXISTS (
      SELECT 1 FROM sys_admins
      WHERE sys_admins.id::text = current_setting('request.jwt.claims', true)::json->>'sub'
      AND sys_admins.department_id IN (
        SELECT id FROM sys_departments WHERE name IN ('采购部', 'Procurement')
      )
    )
  );

-- ============================================
-- 商城分类策略
-- ============================================

CREATE POLICY "所有人可查看激活的类目"
  ON sys_categories FOR SELECT
  TO authenticated, anon
  USING (is_active = true);

CREATE POLICY "超管可管理类目"
  ON sys_categories FOR ALL
  TO authenticated
  USING (
    (current_setting('request.jwt.claims', true)::json->>'is_super_admin')::boolean = true
  );

CREATE POLICY "所有人可查看服务类目"
  ON sys_service_categories FOR SELECT
  TO authenticated, anon
  USING (is_active = true);

CREATE POLICY "超管可管理服务类目"
  ON sys_service_categories FOR ALL
  TO authenticated
  USING (
    (current_setting('request.jwt.claims', true)::json->>'is_super_admin')::boolean = true
  );

CREATE POLICY "所有人可查看美食类目"
  ON sys_food_categories FOR SELECT
  TO authenticated, anon
  USING (is_active = true);

CREATE POLICY "超管可管理美食类目"
  ON sys_food_categories FOR ALL
  TO authenticated
  USING (
    (current_setting('request.jwt.claims', true)::json->>'is_super_admin')::boolean = true
  );