/*
  # 商城配置与商品功能增强

  ## 功能说明
  1. 新增商城配置表，支持商城名称、LOGO、网站标题等可配置项
  2. 为商品表添加唯一商品ID（product_code）字段
  3. 为商品表添加商品链接（product_url）字段
  4. 创建自动生成唯一商品ID的函数
  5. 创建触发器自动为新商品生成ID

  ## 新增表
  1. `store_configs` - 商城配置表

  ## 修改表
  1. `sys_products` - 添加product_code和product_url字段

  ## 新增函数
  1. `generate_unique_product_code()` - 生成唯一商品ID
  2. `auto_generate_product_code()` - 触发器函数
*/

-- 1. 创建商城配置表
CREATE TABLE IF NOT EXISTS store_configs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  domain_id uuid REFERENCES sys_domains(id) ON DELETE CASCADE,
  store_name jsonb NOT NULL DEFAULT '{"zh": "168全球购", "en": "168 Global Shop"}',
  store_logo_url text,
  site_title jsonb DEFAULT '{"zh": "168全球购 - 全球精选好物", "en": "168 Global Shop - Selected Products"}',
  site_subtitle jsonb DEFAULT '{"zh": "全球精选好物 · 货到付款", "en": "Selected Products · Cash on Delivery"}',
  site_description jsonb,
  site_keywords text[] DEFAULT ARRAY['全球购', '跨境电商', '精选好物'],
  header_bg_color text DEFAULT '#ffffff',
  primary_color text DEFAULT '#14b8a6',
  secondary_color text DEFAULT '#10b981',
  footer_text jsonb DEFAULT '{"zh": "© 2026 168全球购 All rights reserved", "en": "© 2026 168 Global Shop All rights reserved"}',
  contact_email text,
  contact_phone text,
  contact_address jsonb,
  social_links jsonb DEFAULT '{}',
  is_active boolean DEFAULT true,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  created_by uuid REFERENCES sys_admins(id) ON DELETE SET NULL,
  UNIQUE(domain_id)
);

-- 2. 为商品表添加商品ID和链接字段
DO $$
BEGIN
  -- 添加product_code字段（唯一商品ID）
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'sys_products' AND column_name = 'product_code'
  ) THEN
    ALTER TABLE sys_products ADD COLUMN product_code text UNIQUE;
    CREATE INDEX idx_sys_products_product_code ON sys_products(product_code);
  END IF;

  -- 添加product_url字段（商品链接）
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'sys_products' AND column_name = 'product_url'
  ) THEN
    ALTER TABLE sys_products ADD COLUMN product_url text;
    CREATE INDEX idx_sys_products_product_url ON sys_products(product_url);
  END IF;
END $$;

-- 3. 创建生成唯一商品ID的函数
CREATE OR REPLACE FUNCTION generate_unique_product_code()
RETURNS text AS $$
DECLARE
  chars text := 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  result text := 'P-';
  i integer;
  code_exists boolean := true;
BEGIN
  WHILE code_exists LOOP
    result := 'P-';
    
    -- 生成8位随机字符（大写字母和数字）
    FOR i IN 1..8 LOOP
      result := result || substr(chars, floor(random() * length(chars) + 1)::integer, 1);
    END LOOP;
    
    -- 添加一个特殊符号
    result := result || '-';
    
    -- 再添加4位随机字符
    FOR i IN 1..4 LOOP
      result := result || substr(chars, floor(random() * length(chars) + 1)::integer, 1);
    END LOOP;
    
    -- 检查是否已存在
    SELECT EXISTS(SELECT 1 FROM sys_products WHERE product_code = result) INTO code_exists;
  END LOOP;
  
  RETURN result;
END;
$$ LANGUAGE plpgsql;

-- 4. 创建触发器函数：自动为新商品生成product_code
CREATE OR REPLACE FUNCTION auto_generate_product_code()
RETURNS TRIGGER AS $$
BEGIN
  IF NEW.product_code IS NULL THEN
    NEW.product_code := generate_unique_product_code();
  END IF;
  
  -- 如果没有设置product_url，使用domain和product_code生成默认URL
  IF NEW.product_url IS NULL AND NEW.domain_id IS NOT NULL THEN
    NEW.product_url := '/product/' || NEW.product_code;
  END IF;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- 5. 创建触发器
DROP TRIGGER IF EXISTS trigger_auto_generate_product_code ON sys_products;
CREATE TRIGGER trigger_auto_generate_product_code
  BEFORE INSERT ON sys_products
  FOR EACH ROW
  EXECUTE FUNCTION auto_generate_product_code();

-- 6. 为现有商品生成product_code（如果还没有）
UPDATE sys_products 
SET product_code = generate_unique_product_code()
WHERE product_code IS NULL;

-- 7. 为现有商品生成product_url（如果还没有）
UPDATE sys_products 
SET product_url = '/product/' || product_code
WHERE product_url IS NULL AND product_code IS NOT NULL;

-- 8. 启用RLS
ALTER TABLE store_configs ENABLE ROW LEVEL SECURITY;

-- 9. RLS策略 - store_configs
CREATE POLICY "Users can view store configs for their domains"
  ON store_configs FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM sys_admin_domains ad
      WHERE ad.admin_id = auth.uid()
      AND ad.domain_id = store_configs.domain_id
    )
  );

CREATE POLICY "Users can manage store configs for their domains"
  ON store_configs FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM sys_admin_domains ad
      WHERE ad.admin_id = auth.uid()
      AND ad.domain_id = store_configs.domain_id
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM sys_admin_domains ad
      WHERE ad.admin_id = auth.uid()
      AND ad.domain_id = store_configs.domain_id
    )
  );

-- 10. 为所有域创建默认商城配置
INSERT INTO store_configs (domain_id, created_by)
SELECT 
  d.id,
  (SELECT id FROM sys_admins WHERE is_super_admin = true LIMIT 1)
FROM sys_domains d
WHERE NOT EXISTS (
  SELECT 1 FROM store_configs sc WHERE sc.domain_id = d.id
)
ON CONFLICT (domain_id) DO NOTHING;

-- 11. 创建更新商城配置的函数
CREATE OR REPLACE FUNCTION update_store_config(
  p_domain_id uuid,
  p_store_name jsonb DEFAULT NULL,
  p_store_logo_url text DEFAULT NULL,
  p_site_title jsonb DEFAULT NULL,
  p_site_subtitle jsonb DEFAULT NULL,
  p_primary_color text DEFAULT NULL,
  p_secondary_color text DEFAULT NULL
)
RETURNS store_configs AS $$
DECLARE
  v_config store_configs;
BEGIN
  UPDATE store_configs
  SET
    store_name = COALESCE(p_store_name, store_name),
    store_logo_url = COALESCE(p_store_logo_url, store_logo_url),
    site_title = COALESCE(p_site_title, site_title),
    site_subtitle = COALESCE(p_site_subtitle, site_subtitle),
    primary_color = COALESCE(p_primary_color, primary_color),
    secondary_color = COALESCE(p_secondary_color, secondary_color),
    updated_at = now()
  WHERE domain_id = p_domain_id
  RETURNING * INTO v_config;
  
  RETURN v_config;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;