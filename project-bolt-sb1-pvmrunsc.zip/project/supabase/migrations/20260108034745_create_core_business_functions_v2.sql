/*
  # 核心业务函数和触发器 V2

  ## 功能
  1. 自动定价计算函数
  2. 采购入库自动触发函数
  3. 自动上架商品函数
  4. 库存预警检查函数
  5. 自动补货触发函数
  6. 订单确认自动创建出库单
  7. 自动分配客服函数
  8. 供应商商品添加时自动创建抓取任务

  ## 设计原则
  - 避免递归
  - 使用异步任务队列处理耗时操作
  - 完善的错误处理
  - 事务安全
*/

-- 1. 自动定价计算函数
CREATE OR REPLACE FUNCTION calculate_selling_price(
  p_cost_price numeric,
  p_markup_percentage numeric DEFAULT 50,
  p_price_rule_id uuid DEFAULT NULL
)
RETURNS numeric AS $$
DECLARE
  v_selling_price numeric;
  v_rule record;
BEGIN
  IF p_cost_price IS NULL OR p_cost_price <= 0 THEN
    RETURN NULL;
  END IF;
  
  IF p_price_rule_id IS NOT NULL THEN
    SELECT * INTO v_rule FROM pur_price_rules WHERE id = p_price_rule_id AND is_active = true;
    
    IF v_rule.id IS NOT NULL THEN
      IF v_rule.rule_type = 'percentage_markup' THEN
        v_selling_price := p_cost_price * (1 + v_rule.markup_value / 100);
      ELSIF v_rule.rule_type = 'fixed_markup' THEN
        v_selling_price := p_cost_price + v_rule.markup_value;
      ELSE
        v_selling_price := p_cost_price * (1 + p_markup_percentage / 100);
      END IF;
      
      IF v_rule.rounding_rule = 'to_9' THEN
        v_selling_price := FLOOR(v_selling_price / 10) * 10 + 9;
      ELSIF v_rule.rounding_rule = 'to_5' THEN
        v_selling_price := ROUND(v_selling_price / 5) * 5;
      ELSIF v_rule.rounding_rule = 'ceil' THEN
        v_selling_price := CEIL(v_selling_price);
      ELSIF v_rule.rounding_rule = 'floor' THEN
        v_selling_price := FLOOR(v_selling_price);
      END IF;
      
      IF v_rule.min_price IS NOT NULL AND v_selling_price < v_rule.min_price THEN
        v_selling_price := v_rule.min_price;
      END IF;
      
      IF v_rule.max_price IS NOT NULL AND v_selling_price > v_rule.max_price THEN
        v_selling_price := v_rule.max_price;
      END IF;
    ELSE
      v_selling_price := p_cost_price * (1 + p_markup_percentage / 100);
    END IF;
  ELSE
    v_selling_price := p_cost_price * (1 + p_markup_percentage / 100);
  END IF;
  
  RETURN ROUND(v_selling_price, 2);
END;
$$ LANGUAGE plpgsql;

-- 2. 供应商商品插入时自动计算售价和创建抓取任务
CREATE OR REPLACE FUNCTION trigger_supplier_product_actions()
RETURNS TRIGGER AS $$
BEGIN
  IF NEW.cost_price IS NOT NULL THEN
    NEW.selling_price := calculate_selling_price(
      NEW.cost_price, 
      COALESCE(NEW.markup_percentage, 50),
      NEW.price_rule_id
    );
  END IF;
  
  IF TG_OP = 'INSERT' AND NEW.product_link IS NOT NULL THEN
    INSERT INTO sys_async_jobs (job_type, job_name, payload, priority, created_by)
    VALUES (
      'scrape_product',
      'Scrape: ' || LEFT(NEW.product_link, 50),
      jsonb_build_object(
        'supplier_product_id', NEW.id,
        'product_link', NEW.product_link,
        'supplier_id', NEW.supplier_id
      ),
      2,
      NEW.created_by
    );
  END IF;
  
  IF TG_OP = 'UPDATE' AND (
    OLD.cost_price IS DISTINCT FROM NEW.cost_price OR
    OLD.markup_percentage IS DISTINCT FROM NEW.markup_percentage OR
    OLD.price_rule_id IS DISTINCT FROM NEW.price_rule_id
  ) THEN
    NEW.selling_price := calculate_selling_price(
      NEW.cost_price, 
      COALESCE(NEW.markup_percentage, 50),
      NEW.price_rule_id
    );
  END IF;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS on_supplier_product_change ON pur_supplier_products;
CREATE TRIGGER on_supplier_product_change
  BEFORE INSERT OR UPDATE ON pur_supplier_products
  FOR EACH ROW
  EXECUTE FUNCTION trigger_supplier_product_actions();

-- 3. 采购订单收货后自动创建入库单
CREATE OR REPLACE FUNCTION auto_create_inbound_on_purchase()
RETURNS TRIGGER AS $$
DECLARE
  v_inbound_id uuid;
  v_item record;
BEGIN
  IF NEW.status = 'received' AND 
     OLD.status != 'received' AND 
     NEW.auto_inbound = true THEN
    
    INSERT INTO wms_inbound (
      code,
      warehouse_id,
      source_type,
      source_code,
      status,
      operator_id,
      expected_date
    ) VALUES (
      'IN-' || to_char(now(), 'YYYYMMDD-') || LPAD(FLOOR(RANDOM() * 10000)::text, 4, '0'),
      NEW.warehouse_id,
      'purchase',
      NEW.po_number,
      'pending',
      NEW.created_by,
      now()
    ) RETURNING id INTO v_inbound_id;
    
    FOR v_item IN 
      SELECT * FROM pur_purchase_items WHERE purchase_order_id = NEW.id
    LOOP
      INSERT INTO wms_inbound_items (
        inbound_id,
        product_id,
        expected_quantity,
        received_quantity,
        notes
      ) VALUES (
        v_inbound_id,
        v_item.product_id,
        v_item.quantity,
        0,
        'Auto created from PO: ' || NEW.po_number
      );
    END LOOP;
    
  END IF;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS on_purchase_order_received ON pur_purchase_orders;
CREATE TRIGGER on_purchase_order_received
  AFTER UPDATE ON pur_purchase_orders
  FOR EACH ROW
  EXECUTE FUNCTION auto_create_inbound_on_purchase();

-- 4. 自动上架商品函数
CREATE OR REPLACE FUNCTION auto_list_product(
  p_supplier_product_id uuid,
  p_initial_stock integer DEFAULT 100,
  p_custom_title text DEFAULT NULL,
  p_custom_description text DEFAULT NULL
)
RETURNS uuid AS $$
DECLARE
  v_supplier_product record;
  v_new_product_id uuid;
  v_image jsonb;
  v_image_index integer := 0;
BEGIN
  SELECT * INTO v_supplier_product 
  FROM pur_supplier_products 
  WHERE id = p_supplier_product_id;
  
  IF v_supplier_product.id IS NULL THEN
    RAISE EXCEPTION 'Supplier product not found';
  END IF;
  
  INSERT INTO sys_products (
    title,
    description,
    base_price,
    compare_price,
    status,
    metadata
  ) VALUES (
    jsonb_build_object('zh', COALESCE(p_custom_title, v_supplier_product.scraped_title)),
    jsonb_build_object('zh', COALESCE(p_custom_description, v_supplier_product.scraped_description)),
    v_supplier_product.selling_price,
    v_supplier_product.scraped_price,
    'active',
    jsonb_build_object(
      'quantity', p_initial_stock,
      'supplier_product_id', v_supplier_product.id,
      'cost_price', v_supplier_product.cost_price,
      'supplier_link', v_supplier_product.product_link
    )
  ) RETURNING id INTO v_new_product_id;
  
  IF v_supplier_product.scraped_images IS NOT NULL THEN
    FOR v_image IN SELECT * FROM jsonb_array_elements(v_supplier_product.scraped_images)
    LOOP
      v_image_index := v_image_index + 1;
      
      INSERT INTO sys_product_images (
        product_id,
        image_type,
        original_url,
        sort_order
      ) VALUES (
        v_new_product_id,
        CASE WHEN v_image_index = 1 THEN 'main' ELSE 'gallery' END,
        v_image->>'url',
        v_image_index
      );
      
      EXIT WHEN v_image_index >= 10;
    END LOOP;
  END IF;
  
  UPDATE pur_supplier_products
  SET is_listed = true, 
      listed_product_id = v_new_product_id,
      updated_at = now()
  WHERE id = p_supplier_product_id;
  
  RETURN v_new_product_id;
END;
$$ LANGUAGE plpgsql;

-- 5. 订单确认后自动创建出库单
CREATE OR REPLACE FUNCTION auto_create_outbound_on_order()
RETURNS TRIGGER AS $$
DECLARE
  v_outbound_id uuid;
  v_item record;
  v_inventory record;
BEGIN
  IF NEW.order_status = 'confirmed' AND 
     (OLD.order_status IS NULL OR OLD.order_status != 'confirmed') THEN
    
    INSERT INTO wms_outbound (
      code,
      order_id,
      type,
      status,
      auto_created
    ) VALUES (
      'OUT-' || to_char(now(), 'YYYYMMDD-') || LPAD(FLOOR(RANDOM() * 10000)::text, 4, '0'),
      NEW.id,
      'order',
      'pending',
      true
    ) RETURNING id INTO v_outbound_id;
    
    FOR v_item IN 
      SELECT * FROM sys_order_items WHERE order_id = NEW.id
    LOOP
      SELECT * INTO v_inventory
      FROM wms_inventory
      WHERE product_id = v_item.product_id
      LIMIT 1;
      
      IF v_inventory.id IS NOT NULL THEN
        UPDATE wms_inventory
        SET locked_quantity = locked_quantity + v_item.quantity,
            available_quantity = GREATEST(0, quantity - locked_quantity - v_item.quantity),
            updated_at = now()
        WHERE id = v_inventory.id;
        
        INSERT INTO wms_inventory_transactions (
          inventory_id,
          transaction_type,
          related_type,
          related_id,
          related_code,
          quantity_change,
          quantity_before,
          quantity_after,
          locked_change,
          locked_before,
          locked_after,
          operator_id
        ) VALUES (
          v_inventory.id,
          'lock',
          'sales_order',
          NEW.id,
          NEW.order_number,
          0,
          v_inventory.quantity,
          v_inventory.quantity,
          v_item.quantity,
          v_inventory.locked_quantity,
          v_inventory.locked_quantity + v_item.quantity,
          NEW.customer_id
        );
      END IF;
      
      INSERT INTO wms_outbound_items (
        outbound_id,
        product_id,
        sku_id,
        quantity,
        status
      ) VALUES (
        v_outbound_id,
        v_item.product_id,
        v_item.sku_id,
        v_item.quantity,
        'pending'
      );
    END LOOP;
    
    INSERT INTO sys_async_jobs (job_type, job_name, payload, priority)
    VALUES (
      'assign_picker',
      'Auto assign picker for: ' || NEW.order_number,
      jsonb_build_object('outbound_id', v_outbound_id, 'order_id', NEW.id),
      3
    );
    
  END IF;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS on_order_confirmed ON sys_orders;
CREATE TRIGGER on_order_confirmed
  AFTER UPDATE ON sys_orders
  FOR EACH ROW
  EXECUTE FUNCTION auto_create_outbound_on_order();

-- 6. 自动分配客服函数
CREATE OR REPLACE FUNCTION auto_assign_customer_service()
RETURNS TRIGGER AS $$
DECLARE
  v_agent_id uuid;
  v_workload integer;
BEGIN
  IF TG_OP = 'INSERT' AND NEW.status = 'waiting' AND NEW.agent_id IS NULL THEN
    
    SELECT agent_id, (active_conversations + pending_tickets) INTO v_agent_id, v_workload
    FROM cs_agent_workload
    WHERE is_online = true
      AND status = 'online'
      AND active_conversations < max_concurrent
    ORDER BY (active_conversations + pending_tickets) ASC
    LIMIT 1;
    
    IF v_agent_id IS NOT NULL THEN
      UPDATE cs_conversations
      SET agent_id = v_agent_id,
          status = 'active',
          assigned_at = now(),
          auto_assigned = true
      WHERE id = NEW.id;
      
      INSERT INTO cs_assignment_logs (
        conversation_id,
        assigned_agent_id,
        assignment_method,
        workload_at_assignment
      ) VALUES (
        NEW.id,
        v_agent_id,
        'auto',
        v_workload
      );
      
      UPDATE cs_agent_workload
      SET active_conversations = active_conversations + 1,
          updated_at = now()
      WHERE agent_id = v_agent_id;
    END IF;
    
  END IF;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS on_conversation_created ON cs_conversations;
CREATE TRIGGER on_conversation_created
  AFTER INSERT ON cs_conversations
  FOR EACH ROW
  EXECUTE FUNCTION auto_assign_customer_service();

-- 7. 库存预警检查函数
CREATE OR REPLACE FUNCTION check_stock_alerts()
RETURNS integer AS $$
DECLARE
  v_inventory record;
  v_alert_id uuid;
  v_count integer := 0;
BEGIN
  FOR v_inventory IN 
    SELECT * FROM wms_inventory 
    WHERE available_quantity <= alert_threshold 
      AND alert_threshold > 0
  LOOP
    SELECT id INTO v_alert_id
    FROM wms_stock_alerts
    WHERE inventory_id = v_inventory.id
      AND status = 'active'
    LIMIT 1;
    
    IF v_alert_id IS NULL THEN
      INSERT INTO wms_stock_alerts (
        inventory_id,
        alert_type,
        current_quantity,
        threshold_quantity,
        priority,
        status
      ) VALUES (
        v_inventory.id,
        CASE 
          WHEN v_inventory.available_quantity = 0 THEN 'out_of_stock'
          ELSE 'low_stock'
        END,
        v_inventory.available_quantity,
        v_inventory.alert_threshold,
        CASE 
          WHEN v_inventory.available_quantity = 0 THEN 'critical'
          WHEN v_inventory.available_quantity <= v_inventory.alert_threshold * 0.5 THEN 'high'
          ELSE 'medium'
        END,
        'active'
      );
      
      v_count := v_count + 1;
    END IF;
  END LOOP;
  
  RETURN v_count;
END;
$$ LANGUAGE plpgsql;

-- 8. 自动补货触发函数
CREATE OR REPLACE FUNCTION trigger_auto_replenishment(
  p_alert_id uuid
)
RETURNS uuid AS $$
DECLARE
  v_alert record;
  v_supplier_product record;
  v_purchase_order_id uuid;
  v_replenish_qty integer;
  v_inventory_id uuid;
  v_product_id uuid;
  v_warehouse_id uuid;
  v_available_qty integer;
  v_threshold integer;
BEGIN
  SELECT inventory_id INTO v_inventory_id
  FROM wms_stock_alerts
  WHERE id = p_alert_id;
  
  IF v_inventory_id IS NULL THEN
    RAISE EXCEPTION 'Alert not found';
  END IF;
  
  SELECT product_id, warehouse_id, available_quantity, alert_threshold
  INTO v_product_id, v_warehouse_id, v_available_qty, v_threshold
  FROM wms_inventory
  WHERE id = v_inventory_id;
  
  SELECT sp.* INTO v_supplier_product
  FROM pur_supplier_products sp
  WHERE sp.listed_product_id = v_product_id
    AND sp.is_listed = true
  LIMIT 1;
  
  IF v_supplier_product.id IS NULL THEN
    RAISE EXCEPTION 'No supplier product found for auto replenishment';
  END IF;
  
  v_replenish_qty := GREATEST(v_threshold * 3, 100);
  
  INSERT INTO pur_purchase_orders (
    po_number,
    supplier_id,
    warehouse_id,
    order_type,
    subtotal,
    total_amount,
    status
  ) VALUES (
    'PO-AUTO-' || to_char(now(), 'YYYYMMDD-HH24MISS'),
    v_supplier_product.supplier_id,
    v_warehouse_id,
    'auto',
    v_supplier_product.cost_price * v_replenish_qty,
    v_supplier_product.cost_price * v_replenish_qty,
    'draft'
  ) RETURNING id INTO v_purchase_order_id;
  
  INSERT INTO pur_purchase_items (
    purchase_order_id,
    supplier_product_id,
    product_id,
    product_name,
    quantity,
    unit_price,
    total_price
  ) VALUES (
    v_purchase_order_id,
    v_supplier_product.id,
    v_product_id,
    v_supplier_product.scraped_title,
    v_replenish_qty,
    v_supplier_product.cost_price,
    v_supplier_product.cost_price * v_replenish_qty
  );
  
  UPDATE wms_stock_alerts
  SET replenish_triggered = true,
      triggered_purchase_order_id = v_purchase_order_id,
      replenish_quantity = v_replenish_qty,
      updated_at = now()
  WHERE id = p_alert_id;
  
  RETURN v_purchase_order_id;
END;
$$ LANGUAGE plpgsql;
