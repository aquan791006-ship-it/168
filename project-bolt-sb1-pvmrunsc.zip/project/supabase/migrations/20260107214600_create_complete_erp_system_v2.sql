/*
  # 168全球购完整ERP系统 - 企业级架构

  ## 系统模块概览
  
  ### 1. 部门和分层权限管理
    - sys_departments: 部门表（支持多级部门）
    - sys_admin_types: 管理员类型（内部员工、商家管理员）
    - 更新sys_admins: 添加部门和上级关系

  ### 2. 仓储管理系统
    - wms_warehouses: 仓库主表
    - wms_locations: 库位表
    - wms_inventory: 库存表
    - wms_inbound: 入库单
    - wms_inbound_items: 入库明细
    - wms_outbound: 出库单
    - wms_outbound_items: 出库明细
    - wms_stock_alerts: 库存预警

  ### 3. 物流管理系统
    - lgs_carriers: 物流公司
    - lgs_routes: 配送路线
    - lgs_drivers: 司机信息
    - lgs_vehicles: 车辆信息
    - lgs_shipments: 发货单
    - lgs_tracking: 物流追踪
    - lgs_delivery_zones: 配送区域

  ### 4. 财务结算系统
    - fin_accounts: 账户表
    - fin_transactions: 交易记录
    - fin_merchant_fees: 商家服务费配置
    - fin_employee_salaries: 员工工资
    - fin_rewards_penalties: 奖惩记录
    - fin_tax_records: 税务记录
    - fin_settlements: 结算单
    - fin_invoices: 发票管理

  ### 5. 一元购抽奖系统
    - lot_campaigns: 一元购活动
    - lot_products: 参与商品
    - lot_numbers: 号码池
    - lot_orders: 抽奖订单
    - lot_draws: 开奖记录
    - lot_winners: 中奖记录

  ### 6. 客服系统
    - cs_conversations: 会话
    - cs_messages: 消息
    - cs_tickets: 工单
    - cs_quick_replies: 快捷回复
    - cs_ratings: 客服评价

  ### 7. 智能算法系统
    - alg_product_scores: 商品评分
    - alg_ranking_rules: 排名规则
    - alg_user_preferences: 用户偏好
    - alg_recommendations: 推荐记录

  ### 8. 推广系统
    - prm_channels: 推广渠道
    - prm_campaigns: 推广活动
    - prm_materials: 推广素材
    - prm_tracking: 推广追踪
    - prm_conversions: 转化记录

  ### 9. 采购系统
    - pur_suppliers: 供应商
    - pur_purchase_orders: 采购单
    - pur_purchase_items: 采购明细
    - pur_price_rules: 调价规则
    - pur_auto_listing: 自动上架配置

  ### 10. 商城分类扩展
    - sys_categories: 商品类目（多级分类）
    - sys_service_categories: 服务类目
    - sys_food_categories: 美食餐饮类目
*/

-- ============================================
-- 1. 部门和分层权限管理
-- ============================================

-- 管理员类型枚举（如果不存在则创建）
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'admin_type_enum') THEN
    CREATE TYPE admin_type_enum AS ENUM ('internal', 'merchant');
  END IF;
END $$;

-- 部门表（支持多级）
CREATE TABLE IF NOT EXISTS sys_departments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  parent_id uuid REFERENCES sys_departments(id) ON DELETE CASCADE,
  name text NOT NULL,
  code text UNIQUE NOT NULL,
  description text,
  manager_id uuid,
  level integer DEFAULT 1,
  sort_order integer DEFAULT 0,
  is_active boolean DEFAULT true,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- 更新管理员表，添加部门和类型
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'sys_admins' AND column_name = 'admin_type') THEN
    ALTER TABLE sys_admins ADD COLUMN admin_type admin_type_enum DEFAULT 'internal';
  END IF;
  
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'sys_admins' AND column_name = 'department_id') THEN
    ALTER TABLE sys_admins ADD COLUMN department_id uuid REFERENCES sys_departments(id) ON DELETE SET NULL;
  END IF;
  
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'sys_admins' AND column_name = 'direct_supervisor_id') THEN
    ALTER TABLE sys_admins ADD COLUMN direct_supervisor_id uuid REFERENCES sys_admins(id) ON DELETE SET NULL;
  END IF;
  
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'sys_admins' AND column_name = 'permissions_limit') THEN
    ALTER TABLE sys_admins ADD COLUMN permissions_limit jsonb DEFAULT '[]';
  END IF;
END $$;

-- ============================================
-- 2. 仓储管理系统
-- ============================================

-- 仓库主表
CREATE TABLE IF NOT EXISTS wms_warehouses (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  code text UNIQUE NOT NULL,
  name text NOT NULL,
  type text CHECK (type IN ('self_operated', 'third_party', 'merchant')) DEFAULT 'self_operated',
  address jsonb NOT NULL,
  manager_id uuid REFERENCES sys_admins(id),
  capacity integer DEFAULT 0,
  current_usage integer DEFAULT 0,
  status text CHECK (status IN ('active', 'inactive', 'maintenance')) DEFAULT 'active',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- 库位表
CREATE TABLE IF NOT EXISTS wms_locations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  warehouse_id uuid REFERENCES wms_warehouses(id) ON DELETE CASCADE,
  code text NOT NULL,
  zone text NOT NULL,
  aisle text,
  shelf text,
  level integer,
  capacity integer DEFAULT 0,
  is_available boolean DEFAULT true,
  created_at timestamptz DEFAULT now(),
  UNIQUE(warehouse_id, code)
);

-- 库存表
CREATE TABLE IF NOT EXISTS wms_inventory (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  warehouse_id uuid REFERENCES wms_warehouses(id) ON DELETE CASCADE,
  location_id uuid REFERENCES wms_locations(id),
  product_id uuid REFERENCES sys_products(id) ON DELETE CASCADE,
  sku_id uuid REFERENCES sys_product_skus(id),
  merchant_id uuid REFERENCES sys_admins(id),
  quantity integer DEFAULT 0,
  available_quantity integer DEFAULT 0,
  locked_quantity integer DEFAULT 0,
  alert_threshold integer DEFAULT 10,
  last_inbound_at timestamptz,
  last_outbound_at timestamptz,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- 入库单
CREATE TABLE IF NOT EXISTS wms_inbound (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  code text UNIQUE NOT NULL,
  warehouse_id uuid REFERENCES wms_warehouses(id),
  merchant_id uuid REFERENCES sys_admins(id),
  source_type text CHECK (source_type IN ('purchase', 'return', 'transfer', 'other')),
  source_code text,
  status text CHECK (status IN ('pending', 'in_progress', 'completed', 'cancelled')) DEFAULT 'pending',
  expected_at timestamptz,
  received_at timestamptz,
  operator_id uuid REFERENCES sys_admins(id),
  notes text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- 入库明细
CREATE TABLE IF NOT EXISTS wms_inbound_items (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  inbound_id uuid REFERENCES wms_inbound(id) ON DELETE CASCADE,
  product_id uuid REFERENCES sys_products(id),
  sku_id uuid REFERENCES sys_product_skus(id),
  location_id uuid REFERENCES wms_locations(id),
  expected_quantity integer NOT NULL,
  received_quantity integer DEFAULT 0,
  damaged_quantity integer DEFAULT 0,
  status text CHECK (status IN ('pending', 'received', 'partial')) DEFAULT 'pending',
  created_at timestamptz DEFAULT now()
);

-- 出库单
CREATE TABLE IF NOT EXISTS wms_outbound (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  code text UNIQUE NOT NULL,
  warehouse_id uuid REFERENCES wms_warehouses(id),
  order_id uuid REFERENCES sys_orders(id),
  type text CHECK (type IN ('order', 'transfer', 'return', 'loss', 'lottery')) DEFAULT 'order',
  priority integer DEFAULT 1,
  status text CHECK (status IN ('pending', 'picking', 'picked', 'packed', 'shipped', 'cancelled')) DEFAULT 'pending',
  picker_id uuid REFERENCES sys_admins(id),
  packer_id uuid REFERENCES sys_admins(id),
  picked_at timestamptz,
  packed_at timestamptz,
  shipped_at timestamptz,
  notes text,
  is_lottery_order boolean DEFAULT false,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- 出库明细
CREATE TABLE IF NOT EXISTS wms_outbound_items (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  outbound_id uuid REFERENCES wms_outbound(id) ON DELETE CASCADE,
  product_id uuid REFERENCES sys_products(id),
  sku_id uuid REFERENCES sys_product_skus(id),
  location_id uuid REFERENCES wms_locations(id),
  quantity integer NOT NULL,
  picked_quantity integer DEFAULT 0,
  status text CHECK (status IN ('pending', 'picked', 'packed')) DEFAULT 'pending',
  created_at timestamptz DEFAULT now()
);

-- 库存预警
CREATE TABLE IF NOT EXISTS wms_stock_alerts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  inventory_id uuid REFERENCES wms_inventory(id) ON DELETE CASCADE,
  alert_type text CHECK (alert_type IN ('low_stock', 'out_of_stock', 'overstock', 'expired')) NOT NULL,
  current_quantity integer NOT NULL,
  threshold_quantity integer,
  priority text CHECK (priority IN ('low', 'medium', 'high', 'critical')) DEFAULT 'medium',
  status text CHECK (status IN ('active', 'resolved', 'ignored')) DEFAULT 'active',
  resolved_at timestamptz,
  resolved_by uuid REFERENCES sys_admins(id),
  notes text,
  created_at timestamptz DEFAULT now()
);

-- ============================================
-- 3. 物流管理系统
-- ============================================

-- 物流公司
CREATE TABLE IF NOT EXISTS lgs_carriers (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  code text UNIQUE NOT NULL,
  name text NOT NULL,
  type text CHECK (type IN ('self_operated', 'third_party')) DEFAULT 'third_party',
  contact_person text,
  contact_phone text,
  api_config jsonb,
  is_active boolean DEFAULT true,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- 配送路线
CREATE TABLE IF NOT EXISTS lgs_routes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  start_location jsonb NOT NULL,
  end_location jsonb NOT NULL,
  waypoints jsonb DEFAULT '[]',
  distance decimal(10,2),
  estimated_duration integer,
  is_active boolean DEFAULT true,
  created_at timestamptz DEFAULT now()
);

-- 司机信息
CREATE TABLE IF NOT EXISTS lgs_drivers (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  admin_id uuid REFERENCES sys_admins(id),
  name text NOT NULL,
  phone text NOT NULL,
  license_number text UNIQUE NOT NULL,
  license_type text,
  license_expiry date,
  status text CHECK (status IN ('available', 'busy', 'off_duty', 'suspended')) DEFAULT 'available',
  rating decimal(3,2) DEFAULT 5.00,
  total_deliveries integer DEFAULT 0,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- 车辆信息
CREATE TABLE IF NOT EXISTS lgs_vehicles (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  plate_number text UNIQUE NOT NULL,
  vehicle_type text,
  capacity decimal(10,2),
  driver_id uuid REFERENCES lgs_drivers(id),
  status text CHECK (status IN ('available', 'in_use', 'maintenance', 'retired')) DEFAULT 'available',
  last_maintenance_at timestamptz,
  next_maintenance_at timestamptz,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- 发货单
CREATE TABLE IF NOT EXISTS lgs_shipments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tracking_number text UNIQUE NOT NULL,
  outbound_id uuid REFERENCES wms_outbound(id),
  order_id uuid REFERENCES sys_orders(id),
  carrier_id uuid REFERENCES lgs_carriers(id),
  driver_id uuid REFERENCES lgs_drivers(id),
  vehicle_id uuid REFERENCES lgs_vehicles(id),
  route_id uuid REFERENCES lgs_routes(id),
  from_address jsonb NOT NULL,
  to_address jsonb NOT NULL,
  status text CHECK (status IN ('pending', 'picked_up', 'in_transit', 'out_for_delivery', 'delivered', 'failed', 'returned')) DEFAULT 'pending',
  priority text CHECK (priority IN ('normal', 'urgent', 'express')) DEFAULT 'normal',
  weight decimal(10,3),
  volume decimal(10,3),
  cod_amount decimal(10,2),
  is_lottery_shipment boolean DEFAULT false,
  shipped_at timestamptz,
  delivered_at timestamptz,
  signature text,
  notes text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- 物流追踪
CREATE TABLE IF NOT EXISTS lgs_tracking (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  shipment_id uuid REFERENCES lgs_shipments(id) ON DELETE CASCADE,
  status text NOT NULL,
  location jsonb,
  description text,
  operator_id uuid REFERENCES sys_admins(id),
  created_at timestamptz DEFAULT now()
);

-- 配送区域
CREATE TABLE IF NOT EXISTS lgs_delivery_zones (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  region_code text,
  polygon jsonb,
  base_fee decimal(10,2) DEFAULT 0,
  per_km_fee decimal(10,2) DEFAULT 0,
  min_order_amount decimal(10,2) DEFAULT 0,
  is_cod_available boolean DEFAULT true,
  is_active boolean DEFAULT true,
  created_at timestamptz DEFAULT now()
);

-- ============================================
-- 4. 财务结算系统
-- ============================================

-- 账户表
CREATE TABLE IF NOT EXISTS fin_accounts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  account_type text CHECK (account_type IN ('platform', 'merchant', 'employee', 'customer')) NOT NULL,
  owner_id uuid NOT NULL,
  owner_type text NOT NULL,
  balance decimal(15,2) DEFAULT 0,
  frozen_balance decimal(15,2) DEFAULT 0,
  total_income decimal(15,2) DEFAULT 0,
  total_expense decimal(15,2) DEFAULT 0,
  currency_code text DEFAULT 'CNY',
  status text CHECK (status IN ('active', 'frozen', 'closed')) DEFAULT 'active',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- 交易记录
CREATE TABLE IF NOT EXISTS fin_transactions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  transaction_no text UNIQUE NOT NULL,
  account_id uuid REFERENCES fin_accounts(id),
  type text CHECK (type IN ('income', 'expense', 'freeze', 'unfreeze', 'refund')) NOT NULL,
  category text NOT NULL,
  amount decimal(15,2) NOT NULL,
  balance_after decimal(15,2) NOT NULL,
  related_type text,
  related_id uuid,
  description text,
  created_by uuid REFERENCES sys_admins(id),
  created_at timestamptz DEFAULT now()
);

-- 商家服务费配置
CREATE TABLE IF NOT EXISTS fin_merchant_fees (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  merchant_id uuid REFERENCES sys_admins(id),
  fee_type text CHECK (fee_type IN ('commission', 'transaction', 'monthly', 'annual', 'listing')) NOT NULL,
  fee_rate decimal(5,4),
  fixed_amount decimal(10,2),
  min_amount decimal(10,2) DEFAULT 0,
  max_amount decimal(10,2),
  is_active boolean DEFAULT true,
  effective_from timestamptz DEFAULT now(),
  effective_to timestamptz,
  created_by uuid REFERENCES sys_admins(id),
  created_at timestamptz DEFAULT now()
);

-- 员工工资
CREATE TABLE IF NOT EXISTS fin_employee_salaries (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  employee_id uuid REFERENCES sys_admins(id) ON DELETE CASCADE,
  year integer NOT NULL,
  month integer NOT NULL,
  base_salary decimal(10,2) NOT NULL,
  bonus decimal(10,2) DEFAULT 0,
  deductions decimal(10,2) DEFAULT 0,
  net_salary decimal(10,2) NOT NULL,
  status text CHECK (status IN ('draft', 'approved', 'paid', 'cancelled')) DEFAULT 'draft',
  approved_by uuid REFERENCES sys_admins(id),
  approved_at timestamptz,
  paid_at timestamptz,
  notes text,
  created_at timestamptz DEFAULT now(),
  UNIQUE(employee_id, year, month)
);

-- 奖惩记录
CREATE TABLE IF NOT EXISTS fin_rewards_penalties (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  employee_id uuid REFERENCES sys_admins(id) ON DELETE CASCADE,
  type text CHECK (type IN ('reward', 'penalty')) NOT NULL,
  category text NOT NULL,
  amount decimal(10,2) NOT NULL,
  reason text NOT NULL,
  evidence jsonb,
  status text CHECK (status IN ('pending', 'approved', 'rejected', 'executed')) DEFAULT 'pending',
  approved_by uuid REFERENCES sys_admins(id),
  approved_at timestamptz,
  executed_at timestamptz,
  created_by uuid REFERENCES sys_admins(id),
  created_at timestamptz DEFAULT now()
);

-- 税务记录
CREATE TABLE IF NOT EXISTS fin_tax_records (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  payer_type text CHECK (payer_type IN ('merchant', 'employee')) NOT NULL,
  payer_id uuid NOT NULL,
  tax_type text CHECK (tax_type IN ('income_tax', 'vat', 'business_tax', 'other')) NOT NULL,
  tax_period text NOT NULL,
  taxable_amount decimal(15,2) NOT NULL,
  tax_rate decimal(5,4) NOT NULL,
  tax_amount decimal(15,2) NOT NULL,
  status text CHECK (status IN ('calculated', 'withheld', 'paid', 'filed')) DEFAULT 'calculated',
  paid_at timestamptz,
  filed_at timestamptz,
  notes text,
  created_at timestamptz DEFAULT now()
);

-- 结算单
CREATE TABLE IF NOT EXISTS fin_settlements (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  settlement_no text UNIQUE NOT NULL,
  settlement_type text CHECK (settlement_type IN ('merchant', 'platform', 'employee')) NOT NULL,
  target_id uuid NOT NULL,
  period_start timestamptz NOT NULL,
  period_end timestamptz NOT NULL,
  total_amount decimal(15,2) NOT NULL,
  fee_amount decimal(15,2) DEFAULT 0,
  tax_amount decimal(15,2) DEFAULT 0,
  net_amount decimal(15,2) NOT NULL,
  status text CHECK (status IN ('pending', 'approved', 'paid', 'cancelled')) DEFAULT 'pending',
  approved_by uuid REFERENCES sys_admins(id),
  approved_at timestamptz,
  paid_at timestamptz,
  details jsonb,
  created_at timestamptz DEFAULT now()
);

-- 发票管理
CREATE TABLE IF NOT EXISTS fin_invoices (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  invoice_no text UNIQUE NOT NULL,
  invoice_type text CHECK (invoice_type IN ('regular', 'vat', 'electronic')) NOT NULL,
  issuer_type text NOT NULL,
  issuer_id uuid NOT NULL,
  recipient_type text NOT NULL,
  recipient_id uuid NOT NULL,
  amount decimal(15,2) NOT NULL,
  tax_amount decimal(15,2) DEFAULT 0,
  total_amount decimal(15,2) NOT NULL,
  status text CHECK (status IN ('draft', 'issued', 'sent', 'cancelled')) DEFAULT 'draft',
  issued_at timestamptz,
  file_url text,
  notes text,
  created_at timestamptz DEFAULT now()
);

-- ============================================
-- 5. 一元购抽奖系统
-- ============================================

-- 一元购活动
CREATE TABLE IF NOT EXISTS lot_campaigns (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  code text UNIQUE NOT NULL,
  title text NOT NULL,
  description text,
  cover_image text,
  start_time timestamptz NOT NULL,
  end_time timestamptz NOT NULL,
  status text CHECK (status IN ('draft', 'pending_approval', 'approved', 'active', 'paused', 'completed', 'cancelled')) DEFAULT 'draft',
  is_enabled boolean DEFAULT false,
  enabled_regions jsonb DEFAULT '[]',
  approved_by uuid REFERENCES sys_admins(id),
  approved_at timestamptz,
  created_by uuid REFERENCES sys_admins(id),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- 一元购商品
CREATE TABLE IF NOT EXISTS lot_products (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  campaign_id uuid REFERENCES lot_campaigns(id) ON DELETE CASCADE,
  product_id uuid REFERENCES sys_products(id),
  merchant_id uuid REFERENCES sys_admins(id),
  title text NOT NULL,
  original_price decimal(10,2) NOT NULL,
  unit_price decimal(10,2) DEFAULT 1.00,
  total_units integer NOT NULL,
  sold_units integer DEFAULT 0,
  status text CHECK (status IN ('pending', 'approved', 'active', 'drawing', 'completed', 'rejected')) DEFAULT 'pending',
  draw_time timestamptz,
  winner_id uuid,
  winner_number text,
  applied_at timestamptz DEFAULT now(),
  approved_at timestamptz,
  completed_at timestamptz,
  created_at timestamptz DEFAULT now()
);

-- 号码池
CREATE TABLE IF NOT EXISTS lot_numbers (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  lot_product_id uuid REFERENCES lot_products(id) ON DELETE CASCADE,
  number text NOT NULL,
  sequence integer NOT NULL,
  customer_id uuid,
  order_id uuid,
  status text CHECK (status IN ('available', 'sold', 'reserved', 'winning')) DEFAULT 'available',
  purchased_at timestamptz,
  created_at timestamptz DEFAULT now(),
  UNIQUE(lot_product_id, number)
);

-- 创建索引以确保号码唯一性
CREATE INDEX IF NOT EXISTS idx_lot_numbers_product_number ON lot_numbers(lot_product_id, number);

-- 抽奖订单
CREATE TABLE IF NOT EXISTS lot_orders (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  order_no text UNIQUE NOT NULL,
  lot_product_id uuid REFERENCES lot_products(id),
  customer_id uuid,
  customer_info jsonb NOT NULL,
  units_purchased integer NOT NULL,
  unit_price decimal(10,2) NOT NULL,
  total_amount decimal(10,2) NOT NULL,
  numbers jsonb NOT NULL,
  payment_status text CHECK (payment_status IN ('pending', 'paid', 'refunded')) DEFAULT 'pending',
  paid_at timestamptz,
  created_at timestamptz DEFAULT now()
);

-- 开奖记录
CREATE TABLE IF NOT EXISTS lot_draws (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  lot_product_id uuid REFERENCES lot_products(id) ON DELETE CASCADE,
  draw_method text DEFAULT 'random',
  winning_number text NOT NULL,
  winner_id uuid,
  winner_order_id uuid REFERENCES lot_orders(id),
  total_participants integer NOT NULL,
  draw_config jsonb,
  drawn_at timestamptz DEFAULT now(),
  drawn_by uuid REFERENCES sys_admins(id),
  is_verified boolean DEFAULT false,
  verified_at timestamptz,
  created_at timestamptz DEFAULT now()
);

-- 中奖记录
CREATE TABLE IF NOT EXISTS lot_winners (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  draw_id uuid REFERENCES lot_draws(id) ON DELETE CASCADE,
  lot_product_id uuid REFERENCES lot_products(id),
  customer_id uuid NOT NULL,
  winning_number text NOT NULL,
  prize_value decimal(10,2) NOT NULL,
  delivery_address jsonb NOT NULL,
  shipment_id uuid REFERENCES lgs_shipments(id),
  status text CHECK (status IN ('pending', 'notified', 'confirmed', 'shipped', 'delivered', 'completed')) DEFAULT 'pending',
  notified_at timestamptz,
  confirmed_at timestamptz,
  shipped_at timestamptz,
  delivered_at timestamptz,
  notes text,
  created_at timestamptz DEFAULT now()
);

-- ============================================
-- 6. 客服系统
-- ============================================

-- 会话
CREATE TABLE IF NOT EXISTS cs_conversations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  customer_id uuid,
  customer_info jsonb,
  agent_id uuid REFERENCES sys_admins(id),
  channel text CHECK (channel IN ('web', 'app', 'wechat', 'phone', 'email')) DEFAULT 'web',
  status text CHECK (status IN ('waiting', 'active', 'resolved', 'closed')) DEFAULT 'waiting',
  priority text CHECK (priority IN ('low', 'normal', 'high', 'urgent')) DEFAULT 'normal',
  subject text,
  started_at timestamptz DEFAULT now(),
  assigned_at timestamptz,
  resolved_at timestamptz,
  closed_at timestamptz,
  tags text[],
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- 消息
CREATE TABLE IF NOT EXISTS cs_messages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  conversation_id uuid REFERENCES cs_conversations(id) ON DELETE CASCADE,
  sender_type text CHECK (sender_type IN ('customer', 'agent', 'system')) NOT NULL,
  sender_id uuid,
  content text NOT NULL,
  message_type text CHECK (message_type IN ('text', 'image', 'file', 'audio', 'video')) DEFAULT 'text',
  attachments jsonb,
  is_read boolean DEFAULT false,
  read_at timestamptz,
  created_at timestamptz DEFAULT now()
);

-- 工单
CREATE TABLE IF NOT EXISTS cs_tickets (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  ticket_no text UNIQUE NOT NULL,
  conversation_id uuid REFERENCES cs_conversations(id),
  customer_id uuid,
  category text NOT NULL,
  subject text NOT NULL,
  description text NOT NULL,
  priority text CHECK (priority IN ('low', 'normal', 'high', 'urgent')) DEFAULT 'normal',
  status text CHECK (status IN ('open', 'in_progress', 'pending', 'resolved', 'closed')) DEFAULT 'open',
  assigned_to uuid REFERENCES sys_admins(id),
  assigned_by uuid REFERENCES sys_admins(id),
  resolved_by uuid REFERENCES sys_admins(id),
  created_at timestamptz DEFAULT now(),
  assigned_at timestamptz,
  resolved_at timestamptz,
  closed_at timestamptz,
  updated_at timestamptz DEFAULT now()
);

-- 快捷回复
CREATE TABLE IF NOT EXISTS cs_quick_replies (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  category text NOT NULL,
  title text NOT NULL,
  content text NOT NULL,
  shortcut text,
  usage_count integer DEFAULT 0,
  is_active boolean DEFAULT true,
  created_by uuid REFERENCES sys_admins(id),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- 客服评价
CREATE TABLE IF NOT EXISTS cs_ratings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  conversation_id uuid REFERENCES cs_conversations(id),
  agent_id uuid REFERENCES sys_admins(id),
  customer_id uuid,
  rating integer CHECK (rating BETWEEN 1 AND 5) NOT NULL,
  comment text,
  tags text[],
  created_at timestamptz DEFAULT now()
);

-- ============================================
-- 7. 智能算法系统
-- ============================================

-- 商品评分
CREATE TABLE IF NOT EXISTS alg_product_scores (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  product_id uuid REFERENCES sys_products(id) ON DELETE CASCADE,
  sales_score decimal(10,4) DEFAULT 0,
  rating_score decimal(10,4) DEFAULT 0,
  conversion_score decimal(10,4) DEFAULT 0,
  profit_score decimal(10,4) DEFAULT 0,
  freshness_score decimal(10,4) DEFAULT 0,
  total_score decimal(10,4) DEFAULT 0,
  rank_position integer DEFAULT 0,
  category_rank integer DEFAULT 0,
  calculated_at timestamptz DEFAULT now(),
  created_at timestamptz DEFAULT now(),
  UNIQUE(product_id)
);

-- 排名规则
CREATE TABLE IF NOT EXISTS alg_ranking_rules (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  rule_name text UNIQUE NOT NULL,
  category text,
  weights jsonb NOT NULL,
  filters jsonb,
  boost_conditions jsonb,
  is_active boolean DEFAULT true,
  priority integer DEFAULT 1,
  created_by uuid REFERENCES sys_admins(id),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- 用户偏好
CREATE TABLE IF NOT EXISTS alg_user_preferences (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL,
  categories jsonb DEFAULT '[]',
  price_range jsonb,
  favorite_merchants jsonb DEFAULT '[]',
  browsing_history jsonb DEFAULT '[]',
  purchase_history jsonb DEFAULT '[]',
  preferences_vector jsonb,
  updated_at timestamptz DEFAULT now(),
  created_at timestamptz DEFAULT now(),
  UNIQUE(user_id)
);

-- 推荐记录
CREATE TABLE IF NOT EXISTS alg_recommendations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid,
  product_id uuid REFERENCES sys_products(id),
  recommendation_type text CHECK (recommendation_type IN ('personalized', 'trending', 'similar', 'bundled')) NOT NULL,
  score decimal(10,4) NOT NULL,
  position integer,
  algorithm_version text,
  context jsonb,
  is_clicked boolean DEFAULT false,
  clicked_at timestamptz,
  is_purchased boolean DEFAULT false,
  purchased_at timestamptz,
  created_at timestamptz DEFAULT now()
);

-- ============================================
-- 8. 推广系统
-- ============================================

-- 推广渠道
CREATE TABLE IF NOT EXISTS prm_channels (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  code text UNIQUE NOT NULL,
  name text NOT NULL,
  type text CHECK (type IN ('social', 'search', 'display', 'email', 'affiliate', 'other')) NOT NULL,
  platform text,
  description text,
  config jsonb,
  budget_limit decimal(15,2),
  spent_amount decimal(15,2) DEFAULT 0,
  is_active boolean DEFAULT true,
  created_by uuid REFERENCES sys_admins(id),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- 推广活动
CREATE TABLE IF NOT EXISTS prm_campaigns (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  campaign_code text UNIQUE NOT NULL,
  name text NOT NULL,
  channel_id uuid REFERENCES prm_channels(id),
  type text CHECK (type IN ('cpc', 'cpm', 'cpa', 'cps', 'flat_rate')) NOT NULL,
  target_audience jsonb,
  start_date timestamptz NOT NULL,
  end_date timestamptz NOT NULL,
  budget decimal(15,2),
  spent_amount decimal(15,2) DEFAULT 0,
  impressions integer DEFAULT 0,
  clicks integer DEFAULT 0,
  conversions integer DEFAULT 0,
  revenue decimal(15,2) DEFAULT 0,
  status text CHECK (status IN ('draft', 'active', 'paused', 'completed', 'cancelled')) DEFAULT 'draft',
  created_by uuid REFERENCES sys_admins(id),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- 推广素材
CREATE TABLE IF NOT EXISTS prm_materials (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  campaign_id uuid REFERENCES prm_campaigns(id) ON DELETE CASCADE,
  name text NOT NULL,
  type text CHECK (type IN ('image', 'video', 'text', 'html', 'link')) NOT NULL,
  content_url text,
  content_data jsonb,
  dimensions text,
  file_size integer,
  clicks integer DEFAULT 0,
  conversions integer DEFAULT 0,
  is_active boolean DEFAULT true,
  created_at timestamptz DEFAULT now()
);

-- 推广追踪
CREATE TABLE IF NOT EXISTS prm_tracking (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  campaign_id uuid REFERENCES prm_campaigns(id),
  material_id uuid REFERENCES prm_materials(id),
  visitor_id text,
  event_type text CHECK (event_type IN ('impression', 'click', 'visit', 'conversion', 'purchase')) NOT NULL,
  source_url text,
  referrer text,
  device_info jsonb,
  location_info jsonb,
  session_data jsonb,
  created_at timestamptz DEFAULT now()
);

-- 转化记录
CREATE TABLE IF NOT EXISTS prm_conversions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tracking_id uuid REFERENCES prm_tracking(id),
  campaign_id uuid REFERENCES prm_campaigns(id),
  conversion_type text CHECK (conversion_type IN ('signup', 'purchase', 'subscribe', 'other')) NOT NULL,
  customer_id uuid,
  order_id uuid REFERENCES sys_orders(id),
  conversion_value decimal(15,2),
  commission_amount decimal(15,2),
  created_at timestamptz DEFAULT now()
);

-- ============================================
-- 9. 采购系统
-- ============================================

-- 供应商
CREATE TABLE IF NOT EXISTS pur_suppliers (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  code text UNIQUE NOT NULL,
  name text NOT NULL,
  type text CHECK (type IN ('manufacturer', 'wholesaler', 'distributor', '1688', 'taobao', 'other')) NOT NULL,
  contact_person text,
  contact_phone text,
  contact_email text,
  address jsonb,
  platform_account jsonb,
  rating decimal(3,2) DEFAULT 5.00,
  cooperation_status text CHECK (cooperation_status IN ('active', 'inactive', 'blacklisted')) DEFAULT 'active',
  payment_terms jsonb,
  notes text,
  created_by uuid REFERENCES sys_admins(id),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- 采购单
CREATE TABLE IF NOT EXISTS pur_purchase_orders (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  po_number text UNIQUE NOT NULL,
  supplier_id uuid REFERENCES pur_suppliers(id),
  warehouse_id uuid REFERENCES wms_warehouses(id),
  order_type text CHECK (order_type IN ('regular', 'urgent', 'pre_order', 'auto')) DEFAULT 'regular',
  status text CHECK (status IN ('draft', 'submitted', 'confirmed', 'in_transit', 'received', 'completed', 'cancelled')) DEFAULT 'draft',
  subtotal decimal(15,2) NOT NULL,
  tax_amount decimal(15,2) DEFAULT 0,
  shipping_cost decimal(15,2) DEFAULT 0,
  total_amount decimal(15,2) NOT NULL,
  payment_status text CHECK (payment_status IN ('unpaid', 'partial', 'paid')) DEFAULT 'unpaid',
  expected_delivery_date timestamptz,
  actual_delivery_date timestamptz,
  notes text,
  created_by uuid REFERENCES sys_admins(id),
  approved_by uuid REFERENCES sys_admins(id),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- 采购明细
CREATE TABLE IF NOT EXISTS pur_purchase_items (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  purchase_order_id uuid REFERENCES pur_purchase_orders(id) ON DELETE CASCADE,
  supplier_product_code text,
  product_name text NOT NULL,
  product_link text,
  specifications jsonb,
  quantity integer NOT NULL,
  unit_price decimal(10,2) NOT NULL,
  total_price decimal(10,2) NOT NULL,
  received_quantity integer DEFAULT 0,
  quality_status text CHECK (quality_status IN ('pending', 'passed', 'failed')) DEFAULT 'pending',
  auto_list_config_id uuid,
  created_at timestamptz DEFAULT now()
);

-- 调价规则
CREATE TABLE IF NOT EXISTS pur_price_rules (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  rule_name text NOT NULL,
  rule_type text CHECK (rule_type IN ('fixed_markup', 'percentage_markup', 'tiered', 'dynamic')) NOT NULL,
  category text,
  supplier_id uuid REFERENCES pur_suppliers(id),
  cost_range_min decimal(10,2),
  cost_range_max decimal(10,2),
  markup_value decimal(10,4) NOT NULL,
  rounding_rule text CHECK (rounding_rule IN ('none', 'nearest', 'up', 'down', 'to_9')) DEFAULT 'to_9',
  min_profit_margin decimal(5,4),
  max_selling_price decimal(10,2),
  is_active boolean DEFAULT true,
  priority integer DEFAULT 1,
  created_by uuid REFERENCES sys_admins(id),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- 自动上架配置
CREATE TABLE IF NOT EXISTS pur_auto_listing (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  purchase_item_id uuid REFERENCES pur_purchase_items(id),
  price_rule_id uuid REFERENCES pur_price_rules(id),
  target_category text,
  auto_generate_title boolean DEFAULT true,
  title_template text,
  auto_generate_description boolean DEFAULT true,
  description_template text,
  auto_set_images boolean DEFAULT true,
  default_stock_quantity integer DEFAULT 100,
  publish_immediately boolean DEFAULT false,
  status text CHECK (status IN ('pending', 'processing', 'completed', 'failed')) DEFAULT 'pending',
  listed_product_id uuid REFERENCES sys_products(id),
  error_message text,
  processed_at timestamptz,
  created_at timestamptz DEFAULT now()
);

-- ============================================
-- 10. 商城分类扩展
-- ============================================

-- 商品类目（多级分类）
CREATE TABLE IF NOT EXISTS sys_categories (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  parent_id uuid REFERENCES sys_categories(id) ON DELETE CASCADE,
  name text NOT NULL,
  slug text NOT NULL,
  level integer DEFAULT 1,
  sort_order integer DEFAULT 0,
  icon text,
  image text,
  description text,
  is_active boolean DEFAULT true,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- 服务类目
CREATE TABLE IF NOT EXISTS sys_service_categories (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  parent_id uuid REFERENCES sys_service_categories(id) ON DELETE CASCADE,
  name text NOT NULL,
  slug text NOT NULL,
  level integer DEFAULT 1,
  sort_order integer DEFAULT 0,
  icon text,
  description text,
  service_type text CHECK (service_type IN ('personal', 'business', 'home', 'education', 'health', 'other')),
  is_active boolean DEFAULT true,
  created_at timestamptz DEFAULT now()
);

-- 美食餐饮类目
CREATE TABLE IF NOT EXISTS sys_food_categories (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  parent_id uuid REFERENCES sys_food_categories(id) ON DELETE CASCADE,
  name text NOT NULL,
  slug text NOT NULL,
  level integer DEFAULT 1,
  sort_order integer DEFAULT 0,
  icon text,
  description text,
  cuisine_type text,
  is_active boolean DEFAULT true,
  created_at timestamptz DEFAULT now()
);

-- ============================================
-- 创建索引优化查询性能
-- ============================================

-- 部门索引
CREATE INDEX IF NOT EXISTS idx_departments_parent ON sys_departments(parent_id);
CREATE INDEX IF NOT EXISTS idx_admins_department ON sys_admins(department_id);
CREATE INDEX IF NOT EXISTS idx_admins_supervisor ON sys_admins(direct_supervisor_id);

-- 仓储索引
CREATE INDEX IF NOT EXISTS idx_inventory_warehouse ON wms_inventory(warehouse_id);
CREATE INDEX IF NOT EXISTS idx_inventory_product ON wms_inventory(product_id);
CREATE INDEX IF NOT EXISTS idx_inventory_merchant ON wms_inventory(merchant_id);
CREATE INDEX IF NOT EXISTS idx_inbound_warehouse ON wms_inbound(warehouse_id);
CREATE INDEX IF NOT EXISTS idx_outbound_warehouse ON wms_outbound(warehouse_id);
CREATE INDEX IF NOT EXISTS idx_outbound_order ON wms_outbound(order_id);
CREATE INDEX IF NOT EXISTS idx_stock_alerts_status ON wms_stock_alerts(status);

-- 物流索引
CREATE INDEX IF NOT EXISTS idx_shipments_order ON lgs_shipments(order_id);
CREATE INDEX IF NOT EXISTS idx_shipments_tracking ON lgs_shipments(tracking_number);
CREATE INDEX IF NOT EXISTS idx_shipments_status ON lgs_shipments(status);
CREATE INDEX IF NOT EXISTS idx_tracking_shipment ON lgs_tracking(shipment_id);

-- 财务索引
CREATE INDEX IF NOT EXISTS idx_accounts_owner ON fin_accounts(owner_id, owner_type);
CREATE INDEX IF NOT EXISTS idx_transactions_account ON fin_transactions(account_id);
CREATE INDEX IF NOT EXISTS idx_settlements_target ON fin_settlements(target_id, settlement_type);

-- 一元购索引
CREATE INDEX IF NOT EXISTS idx_lot_products_campaign ON lot_products(campaign_id);
CREATE INDEX IF NOT EXISTS idx_lot_numbers_product_status ON lot_numbers(lot_product_id, status);
CREATE INDEX IF NOT EXISTS idx_lot_orders_product ON lot_orders(lot_product_id);
CREATE INDEX IF NOT EXISTS idx_lot_winners_customer ON lot_winners(customer_id);

-- 客服索引
CREATE INDEX IF NOT EXISTS idx_conversations_agent ON cs_conversations(agent_id);
CREATE INDEX IF NOT EXISTS idx_conversations_status ON cs_conversations(status);
CREATE INDEX IF NOT EXISTS idx_messages_conversation ON cs_messages(conversation_id);
CREATE INDEX IF NOT EXISTS idx_tickets_assigned ON cs_tickets(assigned_to);

-- 算法索引
CREATE INDEX IF NOT EXISTS idx_product_scores_total ON alg_product_scores(total_score DESC);
CREATE INDEX IF NOT EXISTS idx_recommendations_user ON alg_recommendations(user_id);

-- 推广索引
CREATE INDEX IF NOT EXISTS idx_campaigns_channel ON prm_campaigns(channel_id);
CREATE INDEX IF NOT EXISTS idx_tracking_campaign ON prm_tracking(campaign_id);

-- 采购索引
CREATE INDEX IF NOT EXISTS idx_purchase_orders_supplier ON pur_purchase_orders(supplier_id);
CREATE INDEX IF NOT EXISTS idx_purchase_items_po ON pur_purchase_items(purchase_order_id);
CREATE INDEX IF NOT EXISTS idx_auto_listing_purchase_item ON pur_auto_listing(purchase_item_id);