/*
  # 创建超级管理员账户和测试域名

  ## 创建内容
  1. 启用pgcrypto扩展（用于密码加密）
  2. 创建超级管理员账户
    - Email: admin@168buy.com
    - Password: Admin@168
  3. 创建测试域名
  4. 验证账户创建
*/

-- 启用pgcrypto扩展
CREATE EXTENSION IF NOT EXISTS pgcrypto;

-- 创建超级管理员账户和测试域名
DO $$
DECLARE
  v_super_admin_role_id uuid;
  v_admin_id uuid;
  v_domain_a_id uuid;
  v_domain_b_id uuid;
BEGIN
  -- 获取超级管理员角色ID
  SELECT id INTO v_super_admin_role_id
  FROM sys_roles
  WHERE name = 'super_admin';
  
  -- 插入超级管理员账户
  INSERT INTO sys_admins (
    email,
    password_hash,
    full_name,
    phone,
    role_id,
    is_super_admin,
    status,
    created_at
  ) VALUES (
    'admin@168buy.com',
    crypt('Admin@168', gen_salt('bf')),
    '超级管理员',
    '13800138000',
    v_super_admin_role_id,
    true,
    'active',
    now()
  )
  ON CONFLICT (email) DO UPDATE 
  SET password_hash = crypt('Admin@168', gen_salt('bf'))
  RETURNING id INTO v_admin_id;
  
  -- 创建测试域名A
  INSERT INTO sys_domains (
    domain,
    display_name,
    owner_id,
    status,
    is_primary,
    ssl_enabled,
    language_code,
    currency_code
  ) VALUES (
    'shop-a.168buy.com',
    '推广站A',
    v_admin_id,
    'active',
    true,
    true,
    'zh-CN',
    'CNY'
  )
  ON CONFLICT (domain) DO NOTHING
  RETURNING id INTO v_domain_a_id;
  
  -- 创建测试域名B
  INSERT INTO sys_domains (
    domain,
    display_name,
    owner_id,
    status,
    is_primary,
    ssl_enabled,
    language_code,
    currency_code
  ) VALUES (
    'shop-b.168buy.com',
    '推广站B',
    v_admin_id,
    'active',
    false,
    true,
    'zh-CN',
    'CNY'
  )
  ON CONFLICT (domain) DO NOTHING
  RETURNING id INTO v_domain_b_id;
  
  RAISE NOTICE '✓ 超级管理员账户创建成功！';
  RAISE NOTICE 'Email: admin@168buy.com';
  RAISE NOTICE 'Password: Admin@168';
  RAISE NOTICE 'Admin ID: %', v_admin_id;
  RAISE NOTICE 'Domain A ID: %', v_domain_a_id;
  RAISE NOTICE 'Domain B ID: %', v_domain_b_id;
END $$;