/*
  # 商品ID增强 - 添加序号后缀

  ## 功能说明
  1. 修改商品ID生成函数，添加自动递增序号
  2. 商品ID格式从 P-XXXXXXXX-XXXX 改为更简洁的格式，带序号
  3. 添加序号计数器表
  4. 确保page_title字段用于单品页面标题

  ## 修改内容
  1. 创建商品序号计数器表
  2. 更新商品ID生成函数
  3. 为现有商品添加序号
*/

-- 1. 创建商品ID序号计数器表
CREATE TABLE IF NOT EXISTS product_id_sequence (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  domain_id uuid REFERENCES sys_domains(id) ON DELETE CASCADE,
  prefix text NOT NULL DEFAULT 'ML',
  current_sequence integer NOT NULL DEFAULT 0,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  UNIQUE(domain_id, prefix)
);

-- 2. 启用RLS
ALTER TABLE product_id_sequence ENABLE ROW LEVEL SECURITY;

-- 3. RLS策略
CREATE POLICY "Users can view sequences for their domains"
  ON product_id_sequence FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM sys_admin_domains ad
      WHERE ad.admin_id = auth.uid()
      AND ad.domain_id = product_id_sequence.domain_id
    )
  );

CREATE POLICY "System can manage sequences"
  ON product_id_sequence FOR ALL
  TO authenticated
  USING (true)
  WITH CHECK (true);

-- 4. 为所有域创建默认序号记录
INSERT INTO product_id_sequence (domain_id, prefix, current_sequence)
SELECT 
  d.id,
  'ML',
  0
FROM sys_domains d
WHERE NOT EXISTS (
  SELECT 1 FROM product_id_sequence ps WHERE ps.domain_id = d.id AND ps.prefix = 'ML'
)
ON CONFLICT (domain_id, prefix) DO NOTHING;

-- 5. 创建新的商品ID生成函数（带序号）
CREATE OR REPLACE FUNCTION generate_product_code_with_sequence(p_domain_id uuid DEFAULT NULL)
RETURNS text AS $$
DECLARE
  v_prefix text := 'ML';
  v_sequence integer;
  v_product_code text;
  v_domain_id uuid;
BEGIN
  -- 获取domain_id
  IF p_domain_id IS NULL THEN
    SELECT id INTO v_domain_id FROM sys_domains LIMIT 1;
  ELSE
    v_domain_id := p_domain_id;
  END IF;
  
  -- 获取并更新序号
  UPDATE product_id_sequence
  SET current_sequence = current_sequence + 1,
      updated_at = now()
  WHERE domain_id = v_domain_id AND prefix = v_prefix
  RETURNING current_sequence INTO v_sequence;
  
  -- 如果没有记录，创建一个
  IF v_sequence IS NULL THEN
    INSERT INTO product_id_sequence (domain_id, prefix, current_sequence)
    VALUES (v_domain_id, v_prefix, 1)
    ON CONFLICT (domain_id, prefix) DO UPDATE
    SET current_sequence = product_id_sequence.current_sequence + 1,
        updated_at = now()
    RETURNING current_sequence INTO v_sequence;
  END IF;
  
  -- 生成格式：ML01, ML02, ..., ML99, ML100
  v_product_code := v_prefix || LPAD(v_sequence::text, 2, '0');
  
  RETURN v_product_code;
END;
$$ LANGUAGE plpgsql;

-- 6. 更新自动生成product_code的触发器函数
CREATE OR REPLACE FUNCTION auto_generate_product_code()
RETURNS TRIGGER AS $$
BEGIN
  IF NEW.product_code IS NULL THEN
    NEW.product_code := generate_product_code_with_sequence(NEW.domain_id);
  END IF;
  
  -- 如果没有设置product_url，使用domain和product_code生成默认URL
  IF NEW.product_url IS NULL AND NEW.domain_id IS NOT NULL THEN
    NEW.product_url := '/product/' || NEW.product_code;
  END IF;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- 7. 为现有没有product_code的商品生成新的ID
DO $$
DECLARE
  product_record RECORD;
BEGIN
  FOR product_record IN 
    SELECT id, domain_id FROM sys_products WHERE product_code IS NULL
  LOOP
    UPDATE sys_products 
    SET product_code = generate_product_code_with_sequence(product_record.domain_id),
        product_url = '/product/' || generate_product_code_with_sequence(product_record.domain_id)
    WHERE id = product_record.id;
  END LOOP;
END $$;

-- 8. 添加状态变更函数
CREATE OR REPLACE FUNCTION update_product_status(
  p_product_id uuid,
  p_status text
)
RETURNS sys_products AS $$
DECLARE
  v_product sys_products;
BEGIN
  UPDATE sys_products
  SET 
    status = p_status,
    updated_at = now()
  WHERE id = p_product_id
  RETURNING * INTO v_product;
  
  RETURN v_product;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;