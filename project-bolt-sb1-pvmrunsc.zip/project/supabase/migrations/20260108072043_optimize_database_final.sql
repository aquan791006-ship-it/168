/*
  # 数据库优化和智能缓存系统

  ## 新增功能
  - 核心表索引优化
  - 查询缓存系统
  - 自动清理机制
*/

-- ============================================
-- 优化核心表索引
-- ============================================

CREATE INDEX IF NOT EXISTS idx_orders_domain_status_v2 ON orders(domain_id, status);
CREATE INDEX IF NOT EXISTS idx_orders_created_v2 ON orders(created_at DESC);

CREATE INDEX IF NOT EXISTS idx_ad_stats_campaign_v2 ON ad_stats(campaign_id, stat_date DESC);
CREATE INDEX IF NOT EXISTS idx_ad_stats_domain_v2 ON ad_stats(domain_id, stat_date DESC);

CREATE INDEX IF NOT EXISTS idx_campaigns_domain_v2 ON ad_campaigns(domain_id, status);

-- ============================================
-- 查询缓存表
-- ============================================

CREATE TABLE IF NOT EXISTS sys_query_cache (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  domain_id uuid REFERENCES sys_domains(id) ON DELETE CASCADE,
  cache_key varchar(500) NOT NULL,
  cache_data jsonb NOT NULL,
  ttl_seconds integer DEFAULT 300,
  hit_count integer DEFAULT 0,
  last_hit_at timestamptz,
  created_at timestamptz DEFAULT now(),
  expires_at timestamptz NOT NULL,
  UNIQUE(domain_id, cache_key)
);

CREATE INDEX idx_sys_cache_domain ON sys_query_cache(domain_id, cache_key);
CREATE INDEX idx_sys_cache_expires ON sys_query_cache(expires_at);

ALTER TABLE sys_query_cache ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Cache access policy"
  ON sys_query_cache FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM sys_admin_domains
      WHERE admin_id = auth.uid() AND domain_id = sys_query_cache.domain_id
    )
  );

-- ============================================
-- 缓存管理函数
-- ============================================

CREATE OR REPLACE FUNCTION get_cached_query(
  p_domain_id uuid,
  p_cache_key varchar
)
RETURNS jsonb
LANGUAGE plpgsql
AS $$
DECLARE
  v_cache_data jsonb;
  v_expires_at timestamptz;
BEGIN
  SELECT cache_data, expires_at 
  INTO v_cache_data, v_expires_at
  FROM sys_query_cache
  WHERE domain_id = p_domain_id
  AND cache_key = p_cache_key;
  
  IF FOUND AND v_expires_at > now() THEN
    UPDATE sys_query_cache
    SET hit_count = hit_count + 1,
        last_hit_at = now()
    WHERE domain_id = p_domain_id AND cache_key = p_cache_key;
    
    RETURN jsonb_build_object(
      'cached', true,
      'data', v_cache_data
    );
  END IF;
  
  IF FOUND AND v_expires_at <= now() THEN
    DELETE FROM sys_query_cache
    WHERE domain_id = p_domain_id AND cache_key = p_cache_key;
  END IF;
  
  RETURN jsonb_build_object('cached', false);
END;
$$;

CREATE OR REPLACE FUNCTION set_cached_query(
  p_domain_id uuid,
  p_cache_key varchar,
  p_cache_data jsonb,
  p_ttl_seconds integer DEFAULT 300
)
RETURNS uuid
LANGUAGE plpgsql
AS $$
DECLARE
  v_cache_id uuid;
BEGIN
  INSERT INTO sys_query_cache (
    domain_id, cache_key, cache_data, ttl_seconds, expires_at
  ) VALUES (
    p_domain_id, p_cache_key, p_cache_data, p_ttl_seconds,
    now() + make_interval(secs := p_ttl_seconds)
  )
  ON CONFLICT (domain_id, cache_key) DO UPDATE SET
    cache_data = EXCLUDED.cache_data,
    expires_at = EXCLUDED.expires_at,
    hit_count = 0,
    created_at = now()
  RETURNING id INTO v_cache_id;
  
  RETURN v_cache_id;
END;
$$;

CREATE OR REPLACE FUNCTION cleanup_expired_data()
RETURNS jsonb
LANGUAGE plpgsql
AS $$
DECLARE
  v_cache_cleaned integer;
  v_metrics_cleaned integer;
BEGIN
  DELETE FROM sys_query_cache
  WHERE expires_at < now();
  GET DIAGNOSTICS v_cache_cleaned = ROW_COUNT;
  
  DELETE FROM sys_performance_metrics
  WHERE recorded_at < now() - interval '30 days';
  GET DIAGNOSTICS v_metrics_cleaned = ROW_COUNT;
  
  RETURN jsonb_build_object(
    'success', true,
    'cache_cleaned', v_cache_cleaned,
    'metrics_cleaned', v_metrics_cleaned,
    'timestamp', now()
  );
END;
$$;

CREATE OR REPLACE FUNCTION get_system_performance_summary(
  p_domain_id uuid
)
RETURNS jsonb
LANGUAGE plpgsql
AS $$
DECLARE
  v_cache_total integer;
  v_cache_hits bigint;
  v_modules_total integer;
  v_modules_healthy integer;
  v_avg_response numeric;
BEGIN
  SELECT 
    COUNT(*),
    SUM(hit_count)
  INTO v_cache_total, v_cache_hits
  FROM sys_query_cache
  WHERE domain_id = p_domain_id;
  
  SELECT 
    COUNT(*),
    COUNT(*) FILTER (WHERE health_status = 'healthy'),
    AVG(avg_response_time)
  INTO v_modules_total, v_modules_healthy, v_avg_response
  FROM sys_module_health
  WHERE domain_id = p_domain_id;
  
  RETURN jsonb_build_object(
    'cache_entries', COALESCE(v_cache_total, 0),
    'cache_hits', COALESCE(v_cache_hits, 0),
    'modules_monitored', COALESCE(v_modules_total, 0),
    'modules_healthy', COALESCE(v_modules_healthy, 0),
    'avg_response_time_ms', ROUND(COALESCE(v_avg_response, 0), 2),
    'timestamp', now()
  );
END;
$$;
