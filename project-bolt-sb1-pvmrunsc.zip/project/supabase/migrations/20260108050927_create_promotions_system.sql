/*
  # 创建促销活动系统

  ## 新增表
  1. `promotions` - 促销活动主表
     - `id` (uuid, 主键)
     - `name` (text) - 活动名称
     - `type` (text) - 活动类型（lucky_draw/discount/flash_sale）
     - `price` (decimal) - 参与价格
     - `product_id` (uuid) - 关联商品
     - `start_time` (timestamptz) - 开始时间
     - `end_time` (timestamptz) - 结束时间
     - `max_participants` (integer) - 最大参与人数
     - `current_participants` (integer) - 当前参与人数
     - `description` (text) - 活动说明
     - `status` (text) - 状态（pending/active/ended）
     - `winner_id` (uuid) - 中奖用户（一元购）
     - `draw_time` (timestamptz) - 开奖时间
     - `created_at` (timestamptz)
     - `updated_at` (timestamptz)

  2. `promotion_participants` - 活动参与记录
     - `id` (uuid, 主键)
     - `promotion_id` (uuid) - 活动ID
     - `user_id` (uuid) - 用户ID
     - `purchase_count` (integer) - 购买次数
     - `total_amount` (decimal) - 支付总额
     - `is_winner` (boolean) - 是否中奖
     - `participated_at` (timestamptz)

  ## 安全策略
  - 启用RLS
  - 认证用户可查看活动
  - 仅管理员可管理活动
*/

CREATE TABLE IF NOT EXISTS promotions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  type text NOT NULL DEFAULT 'lucky_draw',
  price decimal(10,2) NOT NULL DEFAULT 1.00,
  product_id uuid REFERENCES products(id) ON DELETE SET NULL,
  start_time timestamptz NOT NULL,
  end_time timestamptz NOT NULL,
  max_participants integer NOT NULL DEFAULT 100,
  current_participants integer DEFAULT 0,
  description text,
  status text NOT NULL DEFAULT 'pending',
  winner_id uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  draw_time timestamptz,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  CONSTRAINT valid_status CHECK (status IN ('pending', 'active', 'ended')),
  CONSTRAINT valid_type CHECK (type IN ('lucky_draw', 'discount', 'flash_sale')),
  CONSTRAINT valid_time CHECK (end_time > start_time),
  CONSTRAINT valid_participants CHECK (current_participants >= 0 AND current_participants <= max_participants)
);

CREATE TABLE IF NOT EXISTS promotion_participants (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  promotion_id uuid NOT NULL REFERENCES promotions(id) ON DELETE CASCADE,
  user_id uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  purchase_count integer DEFAULT 1,
  total_amount decimal(10,2) NOT NULL,
  is_winner boolean DEFAULT false,
  participated_at timestamptz DEFAULT now(),
  CONSTRAINT valid_purchase_count CHECK (purchase_count > 0)
);

CREATE INDEX IF NOT EXISTS idx_promotions_status ON promotions(status);
CREATE INDEX IF NOT EXISTS idx_promotions_dates ON promotions(start_time, end_time);
CREATE INDEX IF NOT EXISTS idx_promotion_participants_promotion ON promotion_participants(promotion_id);
CREATE INDEX IF NOT EXISTS idx_promotion_participants_user ON promotion_participants(user_id);

ALTER TABLE promotions ENABLE ROW LEVEL SECURITY;
ALTER TABLE promotion_participants ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view active promotions"
  ON promotions FOR SELECT
  USING (true);

CREATE POLICY "Authenticated users can create promotions"
  ON promotions FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE POLICY "Authenticated users can update promotions"
  ON promotions FOR UPDATE
  TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Authenticated users can delete promotions"
  ON promotions FOR DELETE
  TO authenticated
  USING (true);

CREATE POLICY "Anyone can view participants"
  ON promotion_participants FOR SELECT
  USING (true);

CREATE POLICY "Authenticated users can participate"
  ON promotion_participants FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can view own participation"
  ON promotion_participants FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE OR REPLACE FUNCTION update_promotion_timestamp()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER promotion_updated_at
  BEFORE UPDATE ON promotions
  FOR EACH ROW
  EXECUTE FUNCTION update_promotion_timestamp();
