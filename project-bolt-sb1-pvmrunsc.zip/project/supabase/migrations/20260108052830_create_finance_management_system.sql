/*
  # 创建财务管理系统

  ## 功能说明
  安全智能高效的财务管理系统，支持：
  1. 多账户管理（银行、支付宝、微信等）
  2. 收入支出全面管理
  3. 发票和账单管理
  4. 自动对账和核算
  5. 财务报表和分析
  6. 预算管理和预警
  7. 现金流预测

  ## 新增表
  1. `finance_accounts` - 财务账户
  2. `finance_categories` - 收支分类
  3. `finance_transactions` - 财务交易
  4. `finance_invoices` - 发票管理
  5. `finance_budgets` - 预算管理
  6. `finance_reconciliation` - 对账记录
  7. `finance_reports` - 财务报表
  8. `finance_tax_records` - 税务记录

  ## 安全性
  - 启用RLS，所有表都基于domain_id进行隔离
  - 敏感财务数据加密存储
  - 操作日志完整记录
*/

-- 1. 财务账户表
CREATE TABLE IF NOT EXISTS finance_accounts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  domain_id uuid REFERENCES sys_domains(id) ON DELETE CASCADE,
  account_name text NOT NULL,
  account_type text NOT NULL CHECK (account_type IN ('bank', 'alipay', 'wechat', 'cash', 'credit_card', 'other')),
  account_number text,
  bank_name text,
  currency text DEFAULT 'CNY',
  balance numeric(15,2) DEFAULT 0,
  available_balance numeric(15,2) DEFAULT 0,
  frozen_balance numeric(15,2) DEFAULT 0,
  is_default boolean DEFAULT false,
  status text DEFAULT 'active' CHECK (status IN ('active', 'frozen', 'closed')),
  description text,
  created_by uuid REFERENCES sys_admins(id) ON DELETE SET NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- 2. 收支分类表
CREATE TABLE IF NOT EXISTS finance_categories (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  domain_id uuid REFERENCES sys_domains(id) ON DELETE CASCADE,
  category_name text NOT NULL,
  category_type text NOT NULL CHECK (category_type IN ('income', 'expense')),
  parent_id uuid REFERENCES finance_categories(id) ON DELETE SET NULL,
  icon text,
  color text DEFAULT '#3B82F6',
  sort_order integer DEFAULT 0,
  is_system boolean DEFAULT false,
  is_active boolean DEFAULT true,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- 3. 财务交易表
CREATE TABLE IF NOT EXISTS finance_transactions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  domain_id uuid REFERENCES sys_domains(id) ON DELETE CASCADE,
  account_id uuid REFERENCES finance_accounts(id) ON DELETE CASCADE,
  category_id uuid REFERENCES finance_categories(id) ON DELETE SET NULL,
  transaction_type text NOT NULL CHECK (transaction_type IN ('income', 'expense', 'transfer')),
  amount numeric(15,2) NOT NULL,
  balance_after numeric(15,2),
  transaction_date timestamptz DEFAULT now(),
  reference_type text CHECK (reference_type IN ('order', 'purchase', 'advertising', 'salary', 'rent', 'refund', 'manual', 'other')),
  reference_id uuid,
  payer_payee text,
  description text,
  notes text,
  invoice_id uuid,
  is_reconciled boolean DEFAULT false,
  reconciled_at timestamptz,
  tags jsonb DEFAULT '[]',
  attachments jsonb DEFAULT '[]',
  created_by uuid REFERENCES sys_admins(id) ON DELETE SET NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- 4. 发票管理表
CREATE TABLE IF NOT EXISTS finance_invoices (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  domain_id uuid REFERENCES sys_domains(id) ON DELETE CASCADE,
  invoice_number text UNIQUE NOT NULL,
  invoice_type text NOT NULL CHECK (invoice_type IN ('sales', 'purchase', 'expense')),
  invoice_date date NOT NULL,
  due_date date,
  customer_supplier text NOT NULL,
  tax_id text,
  total_amount numeric(15,2) NOT NULL,
  tax_amount numeric(15,2) DEFAULT 0,
  discount_amount numeric(15,2) DEFAULT 0,
  paid_amount numeric(15,2) DEFAULT 0,
  status text DEFAULT 'pending' CHECK (status IN ('pending', 'paid', 'partial', 'overdue', 'cancelled')),
  payment_method text,
  payment_date timestamptz,
  items jsonb DEFAULT '[]',
  notes text,
  attachment_url text,
  is_verified boolean DEFAULT false,
  verified_by uuid REFERENCES sys_admins(id) ON DELETE SET NULL,
  verified_at timestamptz,
  created_by uuid REFERENCES sys_admins(id) ON DELETE SET NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- 5. 预算管理表
CREATE TABLE IF NOT EXISTS finance_budgets (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  domain_id uuid REFERENCES sys_domains(id) ON DELETE CASCADE,
  budget_name text NOT NULL,
  category_id uuid REFERENCES finance_categories(id) ON DELETE CASCADE,
  budget_type text DEFAULT 'monthly' CHECK (budget_type IN ('monthly', 'quarterly', 'yearly')),
  period_start date NOT NULL,
  period_end date NOT NULL,
  budget_amount numeric(15,2) NOT NULL,
  spent_amount numeric(15,2) DEFAULT 0,
  remaining_amount numeric(15,2),
  alert_threshold numeric(5,2) DEFAULT 80.00,
  is_active boolean DEFAULT true,
  notes text,
  created_by uuid REFERENCES sys_admins(id) ON DELETE SET NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- 6. 对账记录表
CREATE TABLE IF NOT EXISTS finance_reconciliation (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  domain_id uuid REFERENCES sys_domains(id) ON DELETE CASCADE,
  account_id uuid REFERENCES finance_accounts(id) ON DELETE CASCADE,
  reconciliation_date date NOT NULL,
  statement_balance numeric(15,2) NOT NULL,
  book_balance numeric(15,2) NOT NULL,
  difference numeric(15,2),
  status text DEFAULT 'pending' CHECK (status IN ('pending', 'completed', 'failed')),
  unmatched_transactions jsonb DEFAULT '[]',
  notes text,
  reconciled_by uuid REFERENCES sys_admins(id) ON DELETE SET NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- 7. 财务报表表
CREATE TABLE IF NOT EXISTS finance_reports (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  domain_id uuid REFERENCES sys_domains(id) ON DELETE CASCADE,
  report_type text NOT NULL CHECK (report_type IN ('income_statement', 'balance_sheet', 'cash_flow', 'profit_loss')),
  report_name text NOT NULL,
  period_start date NOT NULL,
  period_end date NOT NULL,
  report_data jsonb NOT NULL,
  total_income numeric(15,2) DEFAULT 0,
  total_expense numeric(15,2) DEFAULT 0,
  net_profit numeric(15,2) DEFAULT 0,
  generated_by uuid REFERENCES sys_admins(id) ON DELETE SET NULL,
  created_at timestamptz DEFAULT now()
);

-- 8. 税务记录表
CREATE TABLE IF NOT EXISTS finance_tax_records (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  domain_id uuid REFERENCES sys_domains(id) ON DELETE CASCADE,
  tax_type text NOT NULL CHECK (tax_type IN ('vat', 'income_tax', 'other')),
  tax_period text NOT NULL,
  period_start date NOT NULL,
  period_end date NOT NULL,
  taxable_amount numeric(15,2) NOT NULL,
  tax_rate numeric(5,2) NOT NULL,
  tax_amount numeric(15,2) NOT NULL,
  paid_amount numeric(15,2) DEFAULT 0,
  status text DEFAULT 'pending' CHECK (status IN ('pending', 'paid', 'overdue')),
  payment_date timestamptz,
  notes text,
  created_by uuid REFERENCES sys_admins(id) ON DELETE SET NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- 启用RLS
ALTER TABLE finance_accounts ENABLE ROW LEVEL SECURITY;
ALTER TABLE finance_categories ENABLE ROW LEVEL SECURITY;
ALTER TABLE finance_transactions ENABLE ROW LEVEL SECURITY;
ALTER TABLE finance_invoices ENABLE ROW LEVEL SECURITY;
ALTER TABLE finance_budgets ENABLE ROW LEVEL SECURITY;
ALTER TABLE finance_reconciliation ENABLE ROW LEVEL SECURITY;
ALTER TABLE finance_reports ENABLE ROW LEVEL SECURITY;
ALTER TABLE finance_tax_records ENABLE ROW LEVEL SECURITY;

-- 创建索引
CREATE INDEX IF NOT EXISTS idx_finance_accounts_domain ON finance_accounts(domain_id);
CREATE INDEX IF NOT EXISTS idx_finance_categories_domain ON finance_categories(domain_id);
CREATE INDEX IF NOT EXISTS idx_finance_categories_type ON finance_categories(category_type);
CREATE INDEX IF NOT EXISTS idx_finance_transactions_domain ON finance_transactions(domain_id);
CREATE INDEX IF NOT EXISTS idx_finance_transactions_account ON finance_transactions(account_id);
CREATE INDEX IF NOT EXISTS idx_finance_transactions_date ON finance_transactions(transaction_date);
CREATE INDEX IF NOT EXISTS idx_finance_transactions_type ON finance_transactions(transaction_type);
CREATE INDEX IF NOT EXISTS idx_finance_invoices_domain ON finance_invoices(domain_id);
CREATE INDEX IF NOT EXISTS idx_finance_invoices_status ON finance_invoices(status);
CREATE INDEX IF NOT EXISTS idx_finance_budgets_domain ON finance_budgets(domain_id);
CREATE INDEX IF NOT EXISTS idx_finance_reconciliation_domain ON finance_reconciliation(domain_id);
CREATE INDEX IF NOT EXISTS idx_finance_reports_domain ON finance_reports(domain_id);
CREATE INDEX IF NOT EXISTS idx_finance_tax_records_domain ON finance_tax_records(domain_id);

-- RLS 策略 - finance_accounts
CREATE POLICY "Users can view own domain accounts"
  ON finance_accounts FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM sys_admin_domains ad
      WHERE ad.admin_id = auth.uid()
      AND ad.domain_id = finance_accounts.domain_id
    )
  );

CREATE POLICY "Users can manage own domain accounts"
  ON finance_accounts FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM sys_admin_domains ad
      WHERE ad.admin_id = auth.uid()
      AND ad.domain_id = finance_accounts.domain_id
    )
  );

-- RLS 策略 - finance_categories
CREATE POLICY "Users can view own domain categories"
  ON finance_categories FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM sys_admin_domains ad
      WHERE ad.admin_id = auth.uid()
      AND ad.domain_id = finance_categories.domain_id
    )
  );

CREATE POLICY "Users can manage own domain categories"
  ON finance_categories FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM sys_admin_domains ad
      WHERE ad.admin_id = auth.uid()
      AND ad.domain_id = finance_categories.domain_id
    )
  );

-- RLS 策略 - finance_transactions
CREATE POLICY "Users can view own domain transactions"
  ON finance_transactions FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM sys_admin_domains ad
      WHERE ad.admin_id = auth.uid()
      AND ad.domain_id = finance_transactions.domain_id
    )
  );

CREATE POLICY "Users can manage own domain transactions"
  ON finance_transactions FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM sys_admin_domains ad
      WHERE ad.admin_id = auth.uid()
      AND ad.domain_id = finance_transactions.domain_id
    )
  );

-- RLS 策略 - finance_invoices
CREATE POLICY "Users can view own domain invoices"
  ON finance_invoices FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM sys_admin_domains ad
      WHERE ad.admin_id = auth.uid()
      AND ad.domain_id = finance_invoices.domain_id
    )
  );

CREATE POLICY "Users can manage own domain invoices"
  ON finance_invoices FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM sys_admin_domains ad
      WHERE ad.admin_id = auth.uid()
      AND ad.domain_id = finance_invoices.domain_id
    )
  );

-- RLS 策略 - finance_budgets
CREATE POLICY "Users can view own domain budgets"
  ON finance_budgets FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM sys_admin_domains ad
      WHERE ad.admin_id = auth.uid()
      AND ad.domain_id = finance_budgets.domain_id
    )
  );

CREATE POLICY "Users can manage own domain budgets"
  ON finance_budgets FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM sys_admin_domains ad
      WHERE ad.admin_id = auth.uid()
      AND ad.domain_id = finance_budgets.domain_id
    )
  );

-- RLS 策略 - finance_reconciliation
CREATE POLICY "Users can view own domain reconciliation"
  ON finance_reconciliation FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM sys_admin_domains ad
      WHERE ad.admin_id = auth.uid()
      AND ad.domain_id = finance_reconciliation.domain_id
    )
  );

CREATE POLICY "Users can manage own domain reconciliation"
  ON finance_reconciliation FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM sys_admin_domains ad
      WHERE ad.admin_id = auth.uid()
      AND ad.domain_id = finance_reconciliation.domain_id
    )
  );

-- RLS 策略 - finance_reports
CREATE POLICY "Users can view own domain reports"
  ON finance_reports FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM sys_admin_domains ad
      WHERE ad.admin_id = auth.uid()
      AND ad.domain_id = finance_reports.domain_id
    )
  );

CREATE POLICY "Users can create own domain reports"
  ON finance_reports FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM sys_admin_domains ad
      WHERE ad.admin_id = auth.uid()
      AND ad.domain_id = finance_reports.domain_id
    )
  );

-- RLS 策略 - finance_tax_records
CREATE POLICY "Users can view own domain tax records"
  ON finance_tax_records FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM sys_admin_domains ad
      WHERE ad.admin_id = auth.uid()
      AND ad.domain_id = finance_tax_records.domain_id
    )
  );

CREATE POLICY "Users can manage own domain tax records"
  ON finance_tax_records FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM sys_admin_domains ad
      WHERE ad.admin_id = auth.uid()
      AND ad.domain_id = finance_tax_records.domain_id
    )
  );

-- 插入默认收支分类
DO $$
DECLARE
  v_domain_id uuid;
BEGIN
  SELECT id INTO v_domain_id FROM sys_domains LIMIT 1;
  
  IF v_domain_id IS NOT NULL THEN
    -- 收入分类
    INSERT INTO finance_categories (domain_id, category_name, category_type, icon, color, is_system, sort_order) VALUES
      (v_domain_id, '销售收入', 'income', 'ShoppingCart', '#10B981', true, 1),
      (v_domain_id, '服务收入', 'income', 'Briefcase', '#3B82F6', true, 2),
      (v_domain_id, '投资收入', 'income', 'TrendingUp', '#8B5CF6', true, 3),
      (v_domain_id, '其他收入', 'income', 'DollarSign', '#6B7280', true, 4),
      
      -- 支出分类
      (v_domain_id, '采购成本', 'expense', 'Package', '#EF4444', true, 11),
      (v_domain_id, '人员工资', 'expense', 'Users', '#F59E0B', true, 12),
      (v_domain_id, '广告营销', 'expense', 'TrendingUp', '#EC4899', true, 13),
      (v_domain_id, '物流运费', 'expense', 'Truck', '#14B8A6', true, 14),
      (v_domain_id, '房租水电', 'expense', 'Home', '#6366F1', true, 15),
      (v_domain_id, '办公费用', 'expense', 'FileText', '#8B5CF6', true, 16),
      (v_domain_id, '税费', 'expense', 'Receipt', '#DC2626', true, 17),
      (v_domain_id, '其他支出', 'expense', 'MoreHorizontal', '#6B7280', true, 18)
    ON CONFLICT DO NOTHING;
  END IF;
END $$;