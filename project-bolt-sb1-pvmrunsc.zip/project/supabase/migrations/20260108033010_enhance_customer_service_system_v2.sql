/*
  # 客服系统增强 V2

  ## 新增表
  1. `cs_agent_workload` - 客服工作量统计表
     - 实时统计客服当前工作量
     - 用于智能分配客服
  
  2. `cs_assignment_logs` - 客服分配日志表
     - 记录所有客服分配记录
     - 支持分配策略分析

  ## 增强现有表
  - `cs_conversations` - 添加订单关联和自动分配标记

  ## 核心功能
  1. 自动分配最空闲的客服
  2. 客服工作量实时统计
  3. 订单问题自动关联客服
  4. 客服绩效追踪

  ## 安全性
  - 所有表启用RLS
  - 客服只能查看自己的数据
*/

-- 客服工作量统计表
CREATE TABLE IF NOT EXISTS cs_agent_workload (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  agent_id uuid REFERENCES sys_admins(id) ON DELETE CASCADE UNIQUE,
  
  -- 实时工作量
  active_conversations integer DEFAULT 0,
  pending_tickets integer DEFAULT 0,
  
  -- 当日统计
  today_handled_count integer DEFAULT 0,
  today_rating_avg numeric(3,2) DEFAULT 5.00,
  
  -- 状态
  is_online boolean DEFAULT false,
  status text DEFAULT 'offline' CHECK (status IN ('online', 'busy', 'away', 'offline')),
  max_concurrent integer DEFAULT 5,
  
  -- 元数据
  last_activity_at timestamptz,
  updated_at timestamptz DEFAULT now(),
  created_at timestamptz DEFAULT now()
);

-- 客服分配日志表
CREATE TABLE IF NOT EXISTS cs_assignment_logs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  conversation_id uuid REFERENCES cs_conversations(id) ON DELETE CASCADE,
  assigned_agent_id uuid REFERENCES sys_admins(id),
  assignment_method text DEFAULT 'auto' CHECK (assignment_method IN ('auto', 'manual', 'transfer', 'reassign')),
  workload_at_assignment integer,
  assigned_by uuid REFERENCES sys_admins(id),
  notes text,
  created_at timestamptz DEFAULT now()
);

-- 增强会话表
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'cs_conversations' AND column_name = 'order_id'
  ) THEN
    ALTER TABLE cs_conversations ADD COLUMN order_id uuid REFERENCES sys_orders(id);
  END IF;
  
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'cs_conversations' AND column_name = 'auto_assigned'
  ) THEN
    ALTER TABLE cs_conversations ADD COLUMN auto_assigned boolean DEFAULT false;
  END IF;
  
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'cs_conversations' AND column_name = 'assigned_at'
  ) THEN
    ALTER TABLE cs_conversations ADD COLUMN assigned_at timestamptz;
  END IF;
END $$;

-- 启用RLS
ALTER TABLE cs_agent_workload ENABLE ROW LEVEL SECURITY;
ALTER TABLE cs_assignment_logs ENABLE ROW LEVEL SECURITY;

-- RLS策略：管理员和客服可查看工作量统计
CREATE POLICY "Admins and agents can view workload"
  ON cs_agent_workload FOR SELECT TO authenticated
  USING (
    EXISTS (SELECT 1 FROM sys_admins WHERE id = auth.uid())
  );

-- RLS策略：系统可更新工作量
CREATE POLICY "System can update workload"
  ON cs_agent_workload FOR ALL TO authenticated
  USING (
    EXISTS (SELECT 1 FROM sys_admins WHERE id = auth.uid())
  )
  WITH CHECK (
    EXISTS (SELECT 1 FROM sys_admins WHERE id = auth.uid())
  );

-- RLS策略：可查看分配日志
CREATE POLICY "Admins can view assignment logs"
  ON cs_assignment_logs FOR SELECT TO authenticated
  USING (
    EXISTS (SELECT 1 FROM sys_admins WHERE id = auth.uid())
  );

-- RLS策略：可创建分配日志
CREATE POLICY "System can create assignment logs"
  ON cs_assignment_logs FOR INSERT TO authenticated
  WITH CHECK (
    EXISTS (SELECT 1 FROM sys_admins WHERE id = auth.uid())
  );

-- 创建索引
CREATE INDEX IF NOT EXISTS idx_agent_workload_agent ON cs_agent_workload(agent_id);
CREATE INDEX IF NOT EXISTS idx_agent_workload_online ON cs_agent_workload(is_online) WHERE is_online = true;
CREATE INDEX IF NOT EXISTS idx_agent_workload_status ON cs_agent_workload(status);
CREATE INDEX IF NOT EXISTS idx_assignment_logs_conversation ON cs_assignment_logs(conversation_id);
CREATE INDEX IF NOT EXISTS idx_assignment_logs_agent ON cs_assignment_logs(assigned_agent_id);
CREATE INDEX IF NOT EXISTS idx_assignment_logs_method ON cs_assignment_logs(assignment_method);
CREATE INDEX IF NOT EXISTS idx_conversations_order ON cs_conversations(order_id) WHERE order_id IS NOT NULL;
