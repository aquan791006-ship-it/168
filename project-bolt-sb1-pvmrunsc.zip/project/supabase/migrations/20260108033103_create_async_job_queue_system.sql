/*
  # 异步任务队列系统

  ## 新增表
  1. `sys_async_jobs` - 通用异步任务队列
     - 处理所有异步任务（抓取、上架、分配等）
     - 支持优先级和重试机制
     - 避免递归和性能问题

  ## 核心功能
  1. 商品抓取任务
  2. 自动上架任务
  3. 自动补货任务
  4. 拣货员分配任务
  5. 客服分配任务
  6. 发送通知任务

  ## 特性
  - 优先级队列
  - 自动重试机制
  - 错误日志记录
  - 任务状态追踪
  - 防止递归

  ## 安全性
  - 启用RLS
  - 仅管理员可访问
*/

-- 异步任务队列表
CREATE TABLE IF NOT EXISTS sys_async_jobs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  job_type text NOT NULL,
  job_name text NOT NULL,
  
  -- 任务数据
  payload jsonb NOT NULL DEFAULT '{}'::jsonb,
  result jsonb,
  
  -- 状态管理
  status text DEFAULT 'pending' CHECK (status IN 
    ('pending', 'processing', 'completed', 'failed', 'cancelled')
  ),
  priority integer DEFAULT 0,
  retry_count integer DEFAULT 0,
  max_retries integer DEFAULT 3,
  
  -- 时间记录
  scheduled_at timestamptz DEFAULT now(),
  started_at timestamptz,
  completed_at timestamptz,
  next_retry_at timestamptz,
  
  -- 错误信息
  error_message text,
  error_stack text,
  last_error_at timestamptz,
  
  -- 元数据
  created_by uuid REFERENCES sys_admins(id),
  locked_by uuid,
  locked_at timestamptz,
  lock_expires_at timestamptz,
  
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- 创建更新时间的触发器函数
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- 为sys_async_jobs表创建触发器
DROP TRIGGER IF EXISTS update_sys_async_jobs_updated_at ON sys_async_jobs;
CREATE TRIGGER update_sys_async_jobs_updated_at
  BEFORE UPDATE ON sys_async_jobs
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

-- 启用RLS
ALTER TABLE sys_async_jobs ENABLE ROW LEVEL SECURITY;

-- RLS策略：管理员可查看所有任务
CREATE POLICY "Admins can view async jobs"
  ON sys_async_jobs FOR SELECT TO authenticated
  USING (
    EXISTS (SELECT 1 FROM sys_admins WHERE id = auth.uid())
  );

-- RLS策略：管理员可创建任务
CREATE POLICY "Admins can create async jobs"
  ON sys_async_jobs FOR INSERT TO authenticated
  WITH CHECK (
    EXISTS (SELECT 1 FROM sys_admins WHERE id = auth.uid())
  );

-- RLS策略：管理员可更新任务
CREATE POLICY "Admins can update async jobs"
  ON sys_async_jobs FOR UPDATE TO authenticated
  USING (
    EXISTS (SELECT 1 FROM sys_admins WHERE id = auth.uid())
  )
  WITH CHECK (
    EXISTS (SELECT 1 FROM sys_admins WHERE id = auth.uid())
  );

-- RLS策略：管理员可删除任务
CREATE POLICY "Admins can delete async jobs"
  ON sys_async_jobs FOR DELETE TO authenticated
  USING (
    EXISTS (SELECT 1 FROM sys_admins WHERE id = auth.uid())
  );

-- 创建索引以优化查询性能
CREATE INDEX IF NOT EXISTS idx_async_jobs_status ON sys_async_jobs(status);
CREATE INDEX IF NOT EXISTS idx_async_jobs_type ON sys_async_jobs(job_type);
CREATE INDEX IF NOT EXISTS idx_async_jobs_scheduled ON sys_async_jobs(scheduled_at);
CREATE INDEX IF NOT EXISTS idx_async_jobs_priority_scheduled ON sys_async_jobs(priority DESC, scheduled_at ASC) WHERE status = 'pending';
CREATE INDEX IF NOT EXISTS idx_async_jobs_retry ON sys_async_jobs(next_retry_at) WHERE status = 'failed' AND retry_count < max_retries;
CREATE INDEX IF NOT EXISTS idx_async_jobs_locked ON sys_async_jobs(locked_by, lock_expires_at) WHERE status = 'processing';
CREATE INDEX IF NOT EXISTS idx_async_jobs_created ON sys_async_jobs(created_at DESC);

-- 创建函数：获取下一个待处理任务
CREATE OR REPLACE FUNCTION get_next_pending_job(
  p_job_types text[] DEFAULT NULL,
  p_lock_duration interval DEFAULT '5 minutes'::interval
)
RETURNS TABLE(
  id uuid,
  job_type text,
  job_name text,
  payload jsonb
) AS $$
DECLARE
  v_job_id uuid;
  v_lock_id uuid := gen_random_uuid();
BEGIN
  -- 查找优先级最高的待处理任务并锁定
  SELECT aj.id INTO v_job_id
  FROM sys_async_jobs aj
  WHERE aj.status = 'pending'
    AND (p_job_types IS NULL OR aj.job_type = ANY(p_job_types))
    AND aj.scheduled_at <= now()
  ORDER BY aj.priority DESC, aj.scheduled_at ASC
  LIMIT 1
  FOR UPDATE SKIP LOCKED;
  
  -- 如果找到任务，更新状态为processing并加锁
  IF v_job_id IS NOT NULL THEN
    UPDATE sys_async_jobs
    SET status = 'processing',
        started_at = now(),
        locked_by = v_lock_id,
        locked_at = now(),
        lock_expires_at = now() + p_lock_duration
    WHERE sys_async_jobs.id = v_job_id;
    
    -- 返回任务信息
    RETURN QUERY
    SELECT 
      aj.id,
      aj.job_type,
      aj.job_name,
      aj.payload
    FROM sys_async_jobs aj
    WHERE aj.id = v_job_id;
  END IF;
  
  RETURN;
END;
$$ LANGUAGE plpgsql;

-- 创建函数：标记任务完成
CREATE OR REPLACE FUNCTION complete_async_job(
  p_job_id uuid,
  p_result jsonb DEFAULT NULL
)
RETURNS boolean AS $$
BEGIN
  UPDATE sys_async_jobs
  SET status = 'completed',
      result = p_result,
      completed_at = now(),
      locked_by = NULL,
      locked_at = NULL,
      lock_expires_at = NULL
  WHERE id = p_job_id;
  
  RETURN FOUND;
END;
$$ LANGUAGE plpgsql;

-- 创建函数：标记任务失败
CREATE OR REPLACE FUNCTION fail_async_job(
  p_job_id uuid,
  p_error_message text,
  p_error_stack text DEFAULT NULL
)
RETURNS boolean AS $$
DECLARE
  v_current_retry integer;
  v_max_retries integer;
BEGIN
  -- 获取当前重试次数
  SELECT retry_count, max_retries 
  INTO v_current_retry, v_max_retries
  FROM sys_async_jobs
  WHERE id = p_job_id;
  
  -- 增加重试次数
  v_current_retry := v_current_retry + 1;
  
  -- 如果还可以重试，设置为pending并计算下次重试时间
  IF v_current_retry < v_max_retries THEN
    UPDATE sys_async_jobs
    SET status = 'pending',
        retry_count = v_current_retry,
        error_message = p_error_message,
        error_stack = p_error_stack,
        last_error_at = now(),
        next_retry_at = now() + (v_current_retry * interval '5 minutes'),
        locked_by = NULL,
        locked_at = NULL,
        lock_expires_at = NULL
    WHERE id = p_job_id;
  ELSE
    -- 否则标记为最终失败
    UPDATE sys_async_jobs
    SET status = 'failed',
        retry_count = v_current_retry,
        error_message = p_error_message,
        error_stack = p_error_stack,
        last_error_at = now(),
        completed_at = now(),
        locked_by = NULL,
        locked_at = NULL,
        lock_expires_at = NULL
    WHERE id = p_job_id;
  END IF;
  
  RETURN FOUND;
END;
$$ LANGUAGE plpgsql;

-- 创建函数：清理过期锁
CREATE OR REPLACE FUNCTION clean_expired_job_locks()
RETURNS integer AS $$
DECLARE
  v_count integer;
BEGIN
  UPDATE sys_async_jobs
  SET status = 'pending',
      locked_by = NULL,
      locked_at = NULL,
      lock_expires_at = NULL
  WHERE status = 'processing'
    AND lock_expires_at < now();
  
  GET DIAGNOSTICS v_count = ROW_COUNT;
  RETURN v_count;
END;
$$ LANGUAGE plpgsql;
