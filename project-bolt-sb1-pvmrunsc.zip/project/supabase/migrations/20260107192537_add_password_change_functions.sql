/*
  # 添加密码修改功能

  1. 新增功能
    - `verify_admin_password` 函数 - 验证管理员当前密码是否正确
    - `update_admin_password` 函数 - 更新管理员密码
  
  2. 安全性
    - 使用 bcrypt 加密存储密码
    - 验证密码后才能更新
    - 使用 SECURITY DEFINER 确保函数以定义者权限运行
*/

CREATE OR REPLACE FUNCTION verify_admin_password(
  admin_email TEXT,
  admin_password TEXT
)
RETURNS BOOLEAN
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  stored_hash TEXT;
BEGIN
  SELECT password_hash INTO stored_hash
  FROM admins
  WHERE email = admin_email;
  
  IF stored_hash IS NULL THEN
    RETURN FALSE;
  END IF;
  
  RETURN stored_hash = crypt(admin_password, stored_hash);
END;
$$;

CREATE OR REPLACE FUNCTION update_admin_password(
  admin_email TEXT,
  new_password TEXT
)
RETURNS VOID
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  UPDATE admins
  SET 
    password_hash = crypt(new_password, gen_salt('bf')),
    updated_at = now()
  WHERE email = admin_email;
END;
$$;