/*
  # 创建AI智能函数

  ## 功能说明
  1. 自动注册新模块到AI系统
  2. 数据脱敏函数
  3. AI操作审核和执行
  4. AI学习数据管理

  ## 函数列表
  1. `ai_register_module` - 自动注册模块到AI系统
  2. `ai_mask_sensitive_data` - 数据脱敏函数
  3. `ai_submit_operation` - 提交AI操作请求
  4. `ai_review_operation` - 审核AI操作
  5. `ai_execute_operation` - 执行已批准的AI操作
  6. `ai_record_learning` - 记录AI学习数据
  7. `ai_get_module_data` - 获取模块数据（自动脱敏）
*/

-- 1. 自动注册模块到AI系统
CREATE OR REPLACE FUNCTION ai_register_module(
  p_module_key text,
  p_module_name jsonb,
  p_table_names text[],
  p_allowed_operations text[] DEFAULT ARRAY['read'],
  p_data_sensitivity text DEFAULT 'normal',
  p_requires_masking boolean DEFAULT false,
  p_masking_fields jsonb DEFAULT '[]'
)
RETURNS uuid
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  v_module_id uuid;
BEGIN
  -- 插入或更新模块注册
  INSERT INTO ai_module_registry (
    module_key,
    module_name,
    table_names,
    allowed_operations,
    data_sensitivity,
    requires_masking,
    masking_fields,
    is_active
  ) VALUES (
    p_module_key,
    p_module_name,
    p_table_names,
    p_allowed_operations,
    p_data_sensitivity,
    p_requires_masking,
    p_masking_fields,
    true
  )
  ON CONFLICT (module_key) DO UPDATE SET
    module_name = EXCLUDED.module_name,
    table_names = EXCLUDED.table_names,
    allowed_operations = EXCLUDED.allowed_operations,
    data_sensitivity = EXCLUDED.data_sensitivity,
    requires_masking = EXCLUDED.requires_masking,
    masking_fields = EXCLUDED.masking_fields,
    is_active = true,
    registered_at = now()
  RETURNING id INTO v_module_id;

  RETURN v_module_id;
END;
$$;

-- 2. 数据脱敏函数
CREATE OR REPLACE FUNCTION ai_mask_sensitive_data(
  p_module_key text,
  p_table_name text,
  p_field_name text,
  p_field_value text
)
RETURNS text
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  v_rule record;
  v_masked_value text;
  v_keep_first integer;
  v_keep_last integer;
  v_replace_with text;
  v_prefix text;
BEGIN
  -- 获取脱敏规则
  SELECT * INTO v_rule
  FROM ai_data_masking_rules
  WHERE module_key = p_module_key
    AND table_name = p_table_name
    AND field_name = p_field_name
    AND is_active = true
  ORDER BY priority DESC
  LIMIT 1;

  -- 如果没有规则，返回原值
  IF v_rule IS NULL THEN
    RETURN p_field_value;
  END IF;

  -- 根据脱敏方法处理
  CASE v_rule.masking_method
    WHEN 'hash' THEN
      -- 哈希处理
      v_masked_value := encode(digest(p_field_value, 'sha256'), 'hex');
    
    WHEN 'partial' THEN
      -- 部分显示
      v_keep_first := COALESCE((v_rule.masking_config->>'keep_first')::integer, 0);
      v_keep_last := COALESCE((v_rule.masking_config->>'keep_last')::integer, 0);
      v_replace_with := COALESCE(v_rule.masking_config->>'replace_with', '*');
      
      IF length(p_field_value) <= (v_keep_first + v_keep_last) THEN
        v_masked_value := repeat(v_replace_with, length(p_field_value));
      ELSE
        v_masked_value := 
          substring(p_field_value, 1, v_keep_first) ||
          v_replace_with ||
          substring(p_field_value, length(p_field_value) - v_keep_last + 1, v_keep_last);
      END IF;
    
    WHEN 'replace' THEN
      -- 完全替换
      v_replace_with := COALESCE(v_rule.masking_config->>'replace_with', '***');
      v_masked_value := v_replace_with;
    
    WHEN 'anonymize' THEN
      -- 匿名化（添加前缀+随机ID）
      v_prefix := COALESCE(v_rule.masking_config->>'prefix', '用户');
      v_masked_value := v_prefix || substring(encode(digest(p_field_value, 'md5'), 'hex'), 1, 6);
    
    WHEN 'remove' THEN
      -- 移除
      v_masked_value := NULL;
    
    ELSE
      -- 默认返回原值
      v_masked_value := p_field_value;
  END CASE;

  RETURN v_masked_value;
END;
$$;

-- 3. 提交AI操作请求
CREATE OR REPLACE FUNCTION ai_submit_operation(
  p_domain_id uuid,
  p_operation_type text,
  p_target_module text,
  p_target_table text,
  p_operation_data jsonb,
  p_ai_reasoning text,
  p_risk_level text DEFAULT 'medium'
)
RETURNS uuid
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  v_operation_id uuid;
  v_estimated_impact text;
BEGIN
  -- 估算影响
  CASE p_operation_type
    WHEN 'create' THEN
      v_estimated_impact := '将新增 ' || (p_operation_data->>'count')::text || ' 条记录';
    WHEN 'update' THEN
      v_estimated_impact := '将修改 ' || (p_operation_data->>'count')::text || ' 条记录';
    WHEN 'delete' THEN
      v_estimated_impact := '将删除 ' || (p_operation_data->>'count')::text || ' 条记录';
    WHEN 'bulk_update' THEN
      v_estimated_impact := '将批量修改多条记录';
    ELSE
      v_estimated_impact := '将执行系统操作';
  END CASE;

  -- 插入操作队列
  INSERT INTO ai_operation_queue (
    domain_id,
    operation_type,
    target_module,
    target_table,
    operation_data,
    ai_reasoning,
    risk_level,
    estimated_impact,
    requested_by
  ) VALUES (
    p_domain_id,
    p_operation_type,
    p_target_module,
    p_target_table,
    p_operation_data,
    p_ai_reasoning,
    p_risk_level,
    v_estimated_impact,
    auth.uid()
  )
  RETURNING id INTO v_operation_id;

  RETURN v_operation_id;
END;
$$;

-- 4. 审核AI操作
CREATE OR REPLACE FUNCTION ai_review_operation(
  p_operation_id uuid,
  p_approve boolean,
  p_review_notes text DEFAULT NULL
)
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  v_is_super_admin boolean;
BEGIN
  -- 验证是否为超级管理员
  SELECT is_super_admin INTO v_is_super_admin
  FROM sys_admins
  WHERE id = auth.uid();

  IF NOT v_is_super_admin THEN
    RAISE EXCEPTION '只有超级管理员可以审核AI操作';
  END IF;

  -- 更新操作状态
  UPDATE ai_operation_queue
  SET 
    status = CASE WHEN p_approve THEN 'approved' ELSE 'rejected' END,
    reviewed_by = auth.uid(),
    review_notes = p_review_notes,
    reviewed_at = now()
  WHERE id = p_operation_id
    AND status = 'pending';

  RETURN FOUND;
END;
$$;

-- 5. 执行已批准的AI操作（由Edge Function调用）
CREATE OR REPLACE FUNCTION ai_execute_operation(
  p_operation_id uuid
)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  v_operation record;
  v_result jsonb;
BEGIN
  -- 获取操作信息
  SELECT * INTO v_operation
  FROM ai_operation_queue
  WHERE id = p_operation_id
    AND status = 'approved';

  IF v_operation IS NULL THEN
    RETURN jsonb_build_object(
      'success', false,
      'error', '操作不存在或未获批准'
    );
  END IF;

  -- 更新状态为执行中
  UPDATE ai_operation_queue
  SET status = 'executed', executed_at = now()
  WHERE id = p_operation_id;

  -- 记录执行日志
  INSERT INTO ai_execution_logs (
    domain_id,
    operation_queue_id,
    operation_type,
    target_module,
    target_table,
    operation_summary,
    executed_by,
    execution_status
  ) VALUES (
    v_operation.domain_id,
    p_operation_id,
    v_operation.operation_type,
    v_operation.target_module,
    v_operation.target_table,
    v_operation.ai_reasoning,
    auth.uid(),
    'success'
  );

  RETURN jsonb_build_object(
    'success', true,
    'operation_id', p_operation_id,
    'message', '操作已标记为执行'
  );
END;
$$;

-- 6. 记录AI学习数据
CREATE OR REPLACE FUNCTION ai_record_learning(
  p_domain_id uuid,
  p_learning_type text,
  p_context jsonb,
  p_user_input text,
  p_ai_response text,
  p_is_successful boolean DEFAULT true
)
RETURNS uuid
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  v_learning_id uuid;
  v_data_hash text;
BEGIN
  -- 生成数据哈希（用于验证脱敏前后的数据对应关系）
  v_data_hash := encode(
    digest(p_user_input || p_ai_response, 'sha256'),
    'hex'
  );

  -- 插入学习数据
  INSERT INTO ai_learning_data (
    domain_id,
    learning_type,
    context,
    user_input,
    ai_response,
    is_successful,
    is_masked,
    original_data_hash,
    created_by
  ) VALUES (
    p_domain_id,
    p_learning_type,
    p_context,
    p_user_input,
    p_ai_response,
    p_is_successful,
    true,
    v_data_hash,
    auth.uid()
  )
  RETURNING id INTO v_learning_id;

  RETURN v_learning_id;
END;
$$;

-- 7. 获取模块数据（自动应用脱敏）
CREATE OR REPLACE FUNCTION ai_get_module_data(
  p_module_key text,
  p_table_name text,
  p_filters jsonb DEFAULT '{}'
)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  v_module record;
  v_result jsonb;
BEGIN
  -- 获取模块信息
  SELECT * INTO v_module
  FROM ai_module_registry
  WHERE module_key = p_module_key
    AND is_active = true;

  IF v_module IS NULL THEN
    RETURN jsonb_build_object(
      'success', false,
      'error', '模块不存在或未激活'
    );
  END IF;

  -- 检查是否有读取权限
  IF NOT ('read' = ANY(v_module.allowed_operations)) THEN
    RETURN jsonb_build_object(
      'success', false,
      'error', '没有读取权限'
    );
  END IF;

  -- 更新访问统计
  UPDATE ai_module_registry
  SET 
    last_accessed = now(),
    access_count = access_count + 1
  WHERE module_key = p_module_key;

  -- 返回成功信息（实际数据查询和脱敏由前端或Edge Function处理）
  RETURN jsonb_build_object(
    'success', true,
    'module_key', p_module_key,
    'table_name', p_table_name,
    'requires_masking', v_module.requires_masking,
    'masking_fields', v_module.masking_fields
  );
END;
$$;

-- 创建触发器：当新模块被添加到sys_modules时，自动注册到AI系统
CREATE OR REPLACE FUNCTION trigger_auto_register_module_to_ai()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  -- 自动注册新模块到AI系统
  PERFORM ai_register_module(
    NEW.module_key,
    NEW.module_name,
    ARRAY[]::text[],  -- 初始为空，需要后续手动配置
    ARRAY['read'],    -- 默认只读
    'normal',         -- 默认普通敏感度
    false,            -- 默认不需要脱敏
    '[]'::jsonb       -- 空的脱敏字段列表
  );
  
  RETURN NEW;
END;
$$;

-- 如果触发器已存在则删除
DROP TRIGGER IF EXISTS auto_register_module_to_ai ON sys_modules;

-- 创建触发器
CREATE TRIGGER auto_register_module_to_ai
  AFTER INSERT OR UPDATE ON sys_modules
  FOR EACH ROW
  WHEN (NEW.status = 'enabled')
  EXECUTE FUNCTION trigger_auto_register_module_to_ai();