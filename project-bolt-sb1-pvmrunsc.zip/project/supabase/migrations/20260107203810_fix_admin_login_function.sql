/*
  # 修复管理员登录函数

  ## 修复内容
  1. 重新创建sys_admin_login函数，使用正确的密码验证方式
  2. 确保pgcrypto扩展函数可用
*/

-- 删除旧的登录函数
DROP FUNCTION IF EXISTS sys_admin_login(text, text);

-- 重新创建登录函数
CREATE OR REPLACE FUNCTION sys_admin_login(
  p_email text,
  p_password text
)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  v_admin sys_admins;
  v_role sys_roles;
  v_result jsonb;
  v_password_hash text;
BEGIN
  -- 查找管理员
  SELECT * INTO v_admin
  FROM sys_admins
  WHERE email = p_email
    AND status = 'active';
  
  IF NOT FOUND THEN
    RETURN jsonb_build_object(
      'success', false,
      'message', '邮箱或密码错误'
    );
  END IF;
  
  -- 验证密码（使用 pgcrypto 扩展的 crypt 函数）
  -- 使用pgcrypto.crypt明确指定扩展
  SELECT pgcrypto.crypt(p_password, v_admin.password_hash) INTO v_password_hash;
  
  IF v_password_hash != v_admin.password_hash THEN
    RETURN jsonb_build_object(
      'success', false,
      'message', '邮箱或密码错误'
    );
  END IF;
  
  -- 获取角色信息
  SELECT * INTO v_role
  FROM sys_roles
  WHERE id = v_admin.role_id;
  
  -- 更新最后登录时间
  UPDATE sys_admins
  SET last_login_at = now(),
      last_login_ip = inet_client_addr()::text
  WHERE id = v_admin.id;
  
  -- 返回管理员信息
  RETURN jsonb_build_object(
    'success', true,
    'admin', jsonb_build_object(
      'id', v_admin.id,
      'email', v_admin.email,
      'full_name', v_admin.full_name,
      'phone', v_admin.phone,
      'avatar', v_admin.avatar,
      'is_super_admin', v_admin.is_super_admin,
      'status', v_admin.status,
      'role', jsonb_build_object(
        'id', v_role.id,
        'name', v_role.name,
        'display_name', v_role.display_name,
        'level', v_role.level
      )
    )
  );
EXCEPTION
  WHEN OTHERS THEN
    RETURN jsonb_build_object(
      'success', false,
      'message', '登录失败：' || SQLERRM
    );
END;
$$;