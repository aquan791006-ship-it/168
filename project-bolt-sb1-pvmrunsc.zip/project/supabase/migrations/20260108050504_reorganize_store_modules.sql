/*
  # 重组商城模块结构

  1. 变更内容
    - 将商品管理(Products)、订单管理(Orders)整合到商城管理(StoreManagement)模块
    - 网站统计(Analytics)保持独立模块
    - 更新模块路由配置

  2. 实施步骤
    - 禁用旧的 Products 和 Orders 路由显示
    - 创建新的 StoreManagement 模块和路由
    - 保持 Analytics 独立
*/

-- 禁用旧的商品和订单路由（不显示在菜单中）
UPDATE sys_module_routes
SET is_menu_item = false
WHERE route_path IN ('/admin/products', '/admin/orders');

-- 创建商城管理模块（如果不存在）
INSERT INTO sys_modules (
  module_key,
  module_name,
  description,
  icon,
  category,
  module_version,
  is_core,
  status
) VALUES (
  'module.store_management',
  '{"zh": "商城管理", "en": "Store Management"}',
  '{"zh": "管理商城前台展示、商品库存和订单", "en": "Manage store display, products and orders"}',
  'Store',
  'sales',
  '1.0.0',
  true,
  'enabled'
) ON CONFLICT (module_key) DO UPDATE SET
  module_name = EXCLUDED.module_name,
  description = EXCLUDED.description,
  icon = EXCLUDED.icon,
  status = 'enabled';

-- 创建商城管理路由
DO $$
DECLARE
  v_module_id uuid;
BEGIN
  SELECT id INTO v_module_id FROM sys_modules WHERE module_key = 'module.store_management';
  
  DELETE FROM sys_module_routes WHERE route_path = '/admin/store';
  
  INSERT INTO sys_module_routes (
    module_id,
    route_path,
    component_name,
    menu_label,
    menu_icon,
    is_menu_item,
    menu_order,
    requires_auth
  ) VALUES (
    v_module_id,
    '/admin/store',
    'StoreManagement',
    '{"zh": "商城管理", "en": "Store Management"}',
    'Store',
    true,
    20,
    true
  );
END $$;

-- 确保 Analytics 模块存在且启用
INSERT INTO sys_modules (
  module_key,
  module_name,
  description,
  icon,
  category,
  module_version,
  is_core,
  status
) VALUES (
  'module.analytics',
  '{"zh": "网站统计", "en": "Analytics"}',
  '{"zh": "查看网站访问数据和业务统计报表", "en": "View website analytics and business reports"}',
  'BarChart3',
  'analytics',
  '1.0.0',
  true,
  'enabled'
) ON CONFLICT (module_key) DO UPDATE SET
  module_name = EXCLUDED.module_name,
  description = EXCLUDED.description,
  icon = EXCLUDED.icon,
  status = 'enabled';

-- 确保 Analytics 路由存在且正确
DO $$
DECLARE
  v_module_id uuid;
BEGIN
  SELECT id INTO v_module_id FROM sys_modules WHERE module_key = 'module.analytics';
  
  DELETE FROM sys_module_routes WHERE route_path = '/admin/analytics';
  
  INSERT INTO sys_module_routes (
    module_id,
    route_path,
    component_name,
    menu_label,
    menu_icon,
    is_menu_item,
    menu_order,
    requires_auth
  ) VALUES (
    v_module_id,
    '/admin/analytics',
    'Analytics',
    '{"zh": "网站统计", "en": "Analytics"}',
    'BarChart3',
    true,
    30,
    true
  );
END $$;

-- 更新菜单排序
UPDATE sys_module_routes SET menu_order = 10 WHERE route_path = '/admin/dashboard';
UPDATE sys_module_routes SET menu_order = 20 WHERE route_path = '/admin/store';
UPDATE sys_module_routes SET menu_order = 30 WHERE route_path = '/admin/analytics';
UPDATE sys_module_routes SET menu_order = 40 WHERE route_path = '/admin/smart-purchase';
UPDATE sys_module_routes SET menu_order = 50 WHERE route_path = '/admin/warehouses';
UPDATE sys_module_routes SET menu_order = 60 WHERE route_path = '/admin/stock-alerts';
UPDATE sys_module_routes SET menu_order = 70 WHERE route_path = '/admin/logistics';
UPDATE sys_module_routes SET menu_order = 80 WHERE route_path = '/admin/customer-service';
UPDATE sys_module_routes SET menu_order = 90 WHERE route_path = '/admin/promotions';
UPDATE sys_module_routes SET menu_order = 100 WHERE route_path = '/admin/smartinsight';
UPDATE sys_module_routes SET menu_order = 110 WHERE route_path = '/admin/settings';
