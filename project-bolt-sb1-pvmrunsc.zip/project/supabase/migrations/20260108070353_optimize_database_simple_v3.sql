/*
  # 数据库优化 - 简化版

  ## 功能说明
  针对现有表结构进行安全的索引优化和创建辅助函数
  
  ## 优化内容
  1. 基础索引优化
  2. 性能分析视图
  3. 维护函数
*/

-- ============================================
-- 产品表索引优化
-- ============================================

DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_indexes WHERE indexname = 'idx_products_domain_created') THEN
    CREATE INDEX idx_products_domain_created 
    ON sys_products(domain_id, created_at DESC);
  END IF;
  
  IF NOT EXISTS (SELECT 1 FROM pg_indexes WHERE indexname = 'idx_products_status') THEN
    CREATE INDEX idx_products_status 
    ON sys_products(status);
  END IF;
END $$;

-- ============================================
-- 订单表索引优化
-- ============================================

DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_indexes WHERE indexname = 'idx_orders_domain_created') THEN
    CREATE INDEX idx_orders_domain_created 
    ON sys_orders(domain_id, created_at DESC);
  END IF;
  
  IF NOT EXISTS (SELECT 1 FROM pg_indexes WHERE indexname = 'idx_orders_payment_status') THEN
    CREATE INDEX idx_orders_payment_status 
    ON sys_orders(payment_status);
  END IF;
  
  IF NOT EXISTS (SELECT 1 FROM pg_indexes WHERE indexname = 'idx_orders_order_status') THEN
    CREATE INDEX idx_orders_order_status 
    ON sys_orders(order_status);
  END IF;
END $$;

-- ============================================
-- 链接追踪表索引优化
-- ============================================

DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_indexes WHERE indexname = 'idx_link_visits_created') THEN
    CREATE INDEX idx_link_visits_created 
    ON sys_link_visits(visited_at DESC);
  END IF;
  
  IF NOT EXISTS (SELECT 1 FROM pg_indexes WHERE indexname = 'idx_tracked_links_domain') THEN
    CREATE INDEX idx_tracked_links_domain 
    ON sys_tracked_links(domain_id);
  END IF;
END $$;

-- ============================================
-- 模块表索引优化
-- ============================================

DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_indexes WHERE indexname = 'idx_modules_key') THEN
    CREATE INDEX idx_modules_key 
    ON sys_modules(module_key);
  END IF;
  
  IF NOT EXISTS (SELECT 1 FROM pg_indexes WHERE indexname = 'idx_module_routes_path') THEN
    CREATE INDEX idx_module_routes_path 
    ON sys_module_routes(route_path);
  END IF;
END $$;

-- ============================================
-- 性能分析视图
-- ============================================

CREATE OR REPLACE VIEW v_daily_performance AS
SELECT 
  DATE_TRUNC('day', recorded_at) as day,
  metric_type,
  COUNT(*) as count,
  AVG(metric_value) as avg_value,
  MAX(metric_value) as max_value
FROM sys_performance_metrics
WHERE recorded_at > now() - interval '30 days'
GROUP BY DATE_TRUNC('day', recorded_at), metric_type;

CREATE OR REPLACE VIEW v_daily_errors AS
SELECT 
  DATE_TRUNC('day', created_at) as day,
  error_type,
  severity,
  COUNT(*) as error_count
FROM sys_error_logs
WHERE created_at > now() - interval '30 days'
GROUP BY DATE_TRUNC('day', created_at), error_type, severity;

-- ============================================
-- 维护和优化函数
-- ============================================

CREATE OR REPLACE FUNCTION cleanup_old_data()
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  v_deleted_metrics integer;
  v_deleted_errors integer;
  v_result jsonb;
BEGIN
  DELETE FROM sys_performance_metrics 
  WHERE recorded_at < now() - interval '90 days';
  GET DIAGNOSTICS v_deleted_metrics = ROW_COUNT;
  
  DELETE FROM sys_error_logs 
  WHERE created_at < now() - interval '90 days'
  AND severity NOT IN ('critical', 'fatal');
  GET DIAGNOSTICS v_deleted_errors = ROW_COUNT;
  
  v_result := jsonb_build_object(
    'timestamp', now(),
    'deleted_metrics', v_deleted_metrics,
    'deleted_errors', v_deleted_errors,
    'status', 'success'
  );
  
  RETURN v_result;
END;
$$;

CREATE OR REPLACE FUNCTION get_system_health_status()
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  v_result jsonb;
  v_error_count integer;
  v_critical_count integer;
BEGIN
  SELECT 
    COUNT(*),
    COUNT(*) FILTER (WHERE severity IN ('critical', 'fatal'))
  INTO v_error_count, v_critical_count
  FROM sys_error_logs
  WHERE created_at > now() - interval '1 hour';
  
  v_result := jsonb_build_object(
    'timestamp', now(),
    'status', CASE 
      WHEN v_critical_count > 0 THEN 'critical'
      WHEN v_error_count > 10 THEN 'warning'
      ELSE 'healthy'
    END,
    'errors_last_hour', v_error_count,
    'critical_errors', v_critical_count,
    'recommendations', CASE
      WHEN v_critical_count > 0 THEN jsonb_build_array('检查关键错误', '立即处理')
      WHEN v_error_count > 10 THEN jsonb_build_array('监控错误趋势', '考虑优化')
      ELSE jsonb_build_array('系统运行正常')
    END
  );
  
  RETURN v_result;
END;
$$;

CREATE OR REPLACE FUNCTION record_performance_metric(
  p_metric_type varchar,
  p_metric_name varchar,
  p_metric_value numeric,
  p_module_key varchar DEFAULT NULL
)
RETURNS uuid
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  v_metric_id uuid;
BEGIN
  INSERT INTO sys_performance_metrics (
    metric_type,
    metric_name,
    metric_value,
    module_key,
    metric_unit
  ) VALUES (
    p_metric_type,
    p_metric_name,
    p_metric_value,
    p_module_key,
    CASE p_metric_type
      WHEN 'response_time' THEN 'ms'
      WHEN 'memory' THEN 'MB'
      WHEN 'cpu' THEN '%'
      ELSE NULL
    END
  ) RETURNING id INTO v_metric_id;
  
  RETURN v_metric_id;
END;
$$;

COMMENT ON FUNCTION cleanup_old_data IS '清理历史数据';
COMMENT ON FUNCTION get_system_health_status IS '获取系统健康状态';
COMMENT ON FUNCTION record_performance_metric IS '记录性能指标';
COMMENT ON VIEW v_daily_performance IS '每日性能汇总';
COMMENT ON VIEW v_daily_errors IS '每日错误汇总';
