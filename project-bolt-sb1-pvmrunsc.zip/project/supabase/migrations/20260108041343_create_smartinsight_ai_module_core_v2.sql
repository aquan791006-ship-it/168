/*
  # SmartInsight AI 模块 - 核心架构 v2

  ## 设计理念
  SmartInsight 是一个企业级 AI 插件模块，为 168全球购 ERP 提供：
  1. **智能数据分析** - 自动分析业务数据，生成洞察报告
  2. **自主工作流** - AI 驱动的自动化业务流程
  3. **预测分析** - 基于历史数据的趋势预测
  4. **异常检测** - 实时监控业务指标异常
  5. **智能推荐** - 基于数据的决策建议
*/

-- 1. AI 分析任务表
CREATE TABLE IF NOT EXISTS ai_analysis_tasks (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  
  task_key varchar(100) UNIQUE NOT NULL,
  task_name jsonb NOT NULL DEFAULT '{"zh": "", "en": ""}',
  description jsonb DEFAULT '{"zh": "", "en": ""}',
  
  task_type varchar(50) NOT NULL DEFAULT 'data_analysis',
  analysis_category varchar(50) NOT NULL DEFAULT 'general',
  
  data_source jsonb NOT NULL DEFAULT '{}',
  data_query text,
  
  analysis_config jsonb NOT NULL DEFAULT '{}',
  output_format varchar(30) DEFAULT 'json',
  
  schedule_type varchar(30) DEFAULT 'manual',
  schedule_cron varchar(100),
  
  status varchar(30) NOT NULL DEFAULT 'inactive',
  is_enabled boolean DEFAULT true,
  
  total_executions integer DEFAULT 0,
  success_count integer DEFAULT 0,
  failure_count integer DEFAULT 0,
  last_execution_at timestamptz,
  last_execution_status varchar(30),
  last_execution_duration_ms integer,
  
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  created_by uuid,
  
  CONSTRAINT valid_ai_task_type CHECK (task_type IN (
    'data_analysis', 'trend_prediction', 'anomaly_detection',
    'recommendation', 'classification', 'clustering', 'sentiment_analysis'
  )),
  CONSTRAINT valid_ai_category CHECK (analysis_category IN (
    'sales', 'inventory', 'customer', 'financial', 
    'operations', 'marketing', 'general'
  )),
  CONSTRAINT valid_ai_schedule CHECK (schedule_type IN ('manual', 'cron', 'event_trigger', 'real_time')),
  CONSTRAINT valid_ai_task_status CHECK (status IN ('inactive', 'active', 'running', 'paused', 'error')),
  CONSTRAINT valid_ai_output CHECK (output_format IN ('json', 'csv', 'report', 'visualization'))
);

CREATE INDEX IF NOT EXISTS idx_ai_tasks_type ON ai_analysis_tasks(task_type);
CREATE INDEX IF NOT EXISTS idx_ai_tasks_status ON ai_analysis_tasks(status);
CREATE INDEX IF NOT EXISTS idx_ai_tasks_enabled ON ai_analysis_tasks(is_enabled);

-- 2. AI 任务执行历史
CREATE TABLE IF NOT EXISTS ai_task_executions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  task_id uuid REFERENCES ai_analysis_tasks(id) ON DELETE CASCADE,
  
  execution_id varchar(100) UNIQUE NOT NULL,
  
  started_at timestamptz DEFAULT now(),
  completed_at timestamptz,
  duration_ms integer,
  
  status varchar(30) NOT NULL DEFAULT 'running',
  
  input_data jsonb DEFAULT '{}',
  output_data jsonb DEFAULT '{}',
  
  records_processed integer DEFAULT 0,
  insights_generated integer DEFAULT 0,
  
  error_message text,
  error_details jsonb,
  
  trigger_type varchar(30) DEFAULT 'manual',
  triggered_by uuid,
  
  CONSTRAINT valid_ai_exec_status CHECK (status IN ('running', 'completed', 'failed', 'cancelled')),
  CONSTRAINT valid_ai_trigger CHECK (trigger_type IN ('manual', 'scheduled', 'event', 'api'))
);

CREATE INDEX IF NOT EXISTS idx_ai_task_execs_task ON ai_task_executions(task_id);
CREATE INDEX IF NOT EXISTS idx_ai_task_execs_status ON ai_task_executions(status);
CREATE INDEX IF NOT EXISTS idx_ai_task_execs_started ON ai_task_executions(started_at DESC);

-- 3. AI 工作流定义表
CREATE TABLE IF NOT EXISTS ai_workflows (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  
  workflow_key varchar(100) UNIQUE NOT NULL,
  workflow_name jsonb NOT NULL DEFAULT '{"zh": "", "en": ""}',
  description jsonb DEFAULT '{"zh": "", "en": ""}',
  
  workflow_type varchar(50) NOT NULL DEFAULT 'sequential',
  category varchar(50) DEFAULT 'automation',
  
  workflow_definition jsonb NOT NULL DEFAULT '{}',
  
  trigger_config jsonb NOT NULL DEFAULT '{}',
  trigger_type varchar(30) NOT NULL DEFAULT 'manual',
  
  execution_config jsonb DEFAULT '{}',
  max_concurrent_executions integer DEFAULT 1,
  timeout_seconds integer DEFAULT 3600,
  
  status varchar(30) NOT NULL DEFAULT 'draft',
  is_enabled boolean DEFAULT false,
  
  version varchar(20) DEFAULT '1.0.0',
  version_history jsonb DEFAULT '[]',
  
  total_executions integer DEFAULT 0,
  success_count integer DEFAULT 0,
  failure_count integer DEFAULT 0,
  last_execution_at timestamptz,
  
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  created_by uuid,
  
  CONSTRAINT valid_ai_workflow_type CHECK (workflow_type IN (
    'sequential', 'parallel', 'conditional', 'loop', 'dag'
  )),
  CONSTRAINT valid_ai_wf_trigger CHECK (trigger_type IN (
    'manual', 'scheduled', 'event', 'webhook', 'data_change'
  )),
  CONSTRAINT valid_ai_wf_status CHECK (status IN ('draft', 'published', 'active', 'paused', 'archived'))
);

CREATE INDEX IF NOT EXISTS idx_ai_workflows_type ON ai_workflows(workflow_type);
CREATE INDEX IF NOT EXISTS idx_ai_workflows_status ON ai_workflows(status);
CREATE INDEX IF NOT EXISTS idx_ai_workflows_enabled ON ai_workflows(is_enabled);

-- 4. AI 工作流执行记录
CREATE TABLE IF NOT EXISTS ai_workflow_executions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  workflow_id uuid REFERENCES ai_workflows(id) ON DELETE CASCADE,
  
  execution_id varchar(100) UNIQUE NOT NULL,
  
  started_at timestamptz DEFAULT now(),
  completed_at timestamptz,
  duration_ms integer,
  
  status varchar(30) NOT NULL DEFAULT 'running',
  
  execution_context jsonb DEFAULT '{}',
  input_data jsonb DEFAULT '{}',
  output_data jsonb DEFAULT '{}',
  
  nodes_status jsonb DEFAULT '{}',
  current_node varchar(100),
  
  total_nodes integer DEFAULT 0,
  completed_nodes integer DEFAULT 0,
  failed_nodes integer DEFAULT 0,
  
  error_message text,
  error_node varchar(100),
  error_details jsonb,
  
  trigger_type varchar(30) DEFAULT 'manual',
  triggered_by uuid,
  
  CONSTRAINT valid_ai_wf_exec_status CHECK (status IN (
    'running', 'completed', 'failed', 'cancelled', 'paused'
  ))
);

CREATE INDEX IF NOT EXISTS idx_ai_wf_execs_workflow ON ai_workflow_executions(workflow_id);
CREATE INDEX IF NOT EXISTS idx_ai_wf_execs_status ON ai_workflow_executions(status);
CREATE INDEX IF NOT EXISTS idx_ai_wf_execs_started ON ai_workflow_executions(started_at DESC);

-- 5. AI 洞察表
CREATE TABLE IF NOT EXISTS ai_insights (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  
  insight_key varchar(100) NOT NULL,
  insight_title jsonb NOT NULL DEFAULT '{"zh": "", "en": ""}',
  insight_summary jsonb NOT NULL DEFAULT '{"zh": "", "en": ""}',
  
  insight_type varchar(50) NOT NULL DEFAULT 'observation',
  category varchar(50) NOT NULL DEFAULT 'general',
  severity varchar(20) DEFAULT 'info',
  
  insight_data jsonb NOT NULL DEFAULT '{}',
  metrics jsonb DEFAULT '{}',
  
  related_task_id uuid REFERENCES ai_analysis_tasks(id),
  related_workflow_id uuid REFERENCES ai_workflows(id),
  related_entities jsonb DEFAULT '[]',
  
  confidence_score numeric(5,2) DEFAULT 0.00,
  impact_score numeric(5,2) DEFAULT 0.00,
  priority integer DEFAULT 5,
  
  status varchar(30) DEFAULT 'new',
  is_actionable boolean DEFAULT false,
  
  user_rating integer,
  user_feedback text,
  is_acknowledged boolean DEFAULT false,
  acknowledged_at timestamptz,
  acknowledged_by uuid,
  
  valid_from timestamptz DEFAULT now(),
  valid_until timestamptz,
  
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  
  CONSTRAINT valid_ai_insight_type CHECK (insight_type IN (
    'observation', 'trend', 'anomaly', 'prediction', 
    'recommendation', 'alert', 'opportunity', 'risk'
  )),
  CONSTRAINT valid_ai_severity CHECK (severity IN ('info', 'low', 'medium', 'high', 'critical')),
  CONSTRAINT valid_ai_insight_status CHECK (status IN ('new', 'reviewing', 'acted_upon', 'dismissed', 'expired')),
  CONSTRAINT valid_ai_rating CHECK (user_rating IS NULL OR (user_rating >= 1 AND user_rating <= 5))
);

CREATE INDEX IF NOT EXISTS idx_ai_insights_type ON ai_insights(insight_type);
CREATE INDEX IF NOT EXISTS idx_ai_insights_category ON ai_insights(category);
CREATE INDEX IF NOT EXISTS idx_ai_insights_severity ON ai_insights(severity);
CREATE INDEX IF NOT EXISTS idx_ai_insights_status ON ai_insights(status);
CREATE INDEX IF NOT EXISTS idx_ai_insights_created ON ai_insights(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_ai_insights_priority ON ai_insights(priority DESC);

-- 6. AI 预测表
CREATE TABLE IF NOT EXISTS ai_predictions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  
  prediction_key varchar(100) NOT NULL,
  prediction_name jsonb NOT NULL DEFAULT '{"zh": "", "en": ""}',
  
  prediction_type varchar(50) NOT NULL DEFAULT 'time_series',
  target_metric varchar(100) NOT NULL,
  
  prediction_date date NOT NULL,
  prediction_period varchar(20) NOT NULL DEFAULT 'daily',
  
  predicted_value numeric(20,4) NOT NULL,
  actual_value numeric(20,4),
  
  confidence_interval_lower numeric(20,4),
  confidence_interval_upper numeric(20,4),
  confidence_level numeric(5,2) DEFAULT 95.00,
  
  model_id uuid,
  model_version varchar(20),
  model_accuracy numeric(5,2),
  
  related_task_id uuid REFERENCES ai_analysis_tasks(id),
  related_entities jsonb DEFAULT '{}',
  
  status varchar(30) DEFAULT 'active',
  
  accuracy_score numeric(5,2),
  error_rate numeric(5,2),
  
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  
  CONSTRAINT valid_ai_pred_type CHECK (prediction_type IN (
    'time_series', 'classification', 'regression', 'demand_forecast', 'trend'
  )),
  CONSTRAINT valid_ai_period CHECK (prediction_period IN (
    'hourly', 'daily', 'weekly', 'monthly', 'quarterly', 'yearly'
  )),
  CONSTRAINT valid_ai_pred_status CHECK (status IN ('active', 'verified', 'expired', 'inaccurate'))
);

CREATE INDEX IF NOT EXISTS idx_ai_predictions_type ON ai_predictions(prediction_type);
CREATE INDEX IF NOT EXISTS idx_ai_predictions_date ON ai_predictions(prediction_date);
CREATE INDEX IF NOT EXISTS idx_ai_predictions_status ON ai_predictions(status);
CREATE INDEX IF NOT EXISTS idx_ai_predictions_metric ON ai_predictions(target_metric);

-- 7. AI 智能规则表
CREATE TABLE IF NOT EXISTS ai_rules (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  
  rule_key varchar(100) UNIQUE NOT NULL,
  rule_name jsonb NOT NULL DEFAULT '{"zh": "", "en": ""}',
  description jsonb DEFAULT '{"zh": "", "en": ""}',
  
  rule_type varchar(50) NOT NULL DEFAULT 'condition_action',
  category varchar(50) DEFAULT 'automation',
  
  conditions jsonb NOT NULL DEFAULT '[]',
  actions jsonb NOT NULL DEFAULT '[]',
  
  priority integer DEFAULT 5,
  execution_order integer DEFAULT 0,
  
  trigger_events jsonb DEFAULT '[]',
  trigger_frequency varchar(30) DEFAULT 'on_event',
  
  status varchar(30) DEFAULT 'active',
  is_enabled boolean DEFAULT true,
  
  total_triggers integer DEFAULT 0,
  total_executions integer DEFAULT 0,
  success_count integer DEFAULT 0,
  failure_count integer DEFAULT 0,
  last_executed_at timestamptz,
  
  valid_from timestamptz DEFAULT now(),
  valid_until timestamptz,
  
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  created_by uuid,
  
  CONSTRAINT valid_ai_rule_type CHECK (rule_type IN (
    'condition_action', 'threshold', 'pattern_match', 'ml_based', 'composite'
  )),
  CONSTRAINT valid_ai_rule_status CHECK (status IN ('draft', 'active', 'paused', 'archived')),
  CONSTRAINT valid_ai_trigger_freq CHECK (trigger_frequency IN (
    'on_event', 'real_time', 'periodic', 'manual'
  ))
);

CREATE INDEX IF NOT EXISTS idx_ai_rules_type ON ai_rules(rule_type);
CREATE INDEX IF NOT EXISTS idx_ai_rules_status ON ai_rules(status);
CREATE INDEX IF NOT EXISTS idx_ai_rules_enabled ON ai_rules(is_enabled);
CREATE INDEX IF NOT EXISTS idx_ai_rules_priority ON ai_rules(priority DESC);

-- 8. AI 规则执行日志
CREATE TABLE IF NOT EXISTS ai_rule_executions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  rule_id uuid REFERENCES ai_rules(id) ON DELETE CASCADE,
  
  executed_at timestamptz DEFAULT now(),
  duration_ms integer,
  
  status varchar(30) NOT NULL DEFAULT 'success',
  
  trigger_event varchar(100),
  trigger_data jsonb DEFAULT '{}',
  
  conditions_met boolean,
  conditions_result jsonb DEFAULT '{}',
  
  actions_executed jsonb DEFAULT '[]',
  actions_result jsonb DEFAULT '{}',
  
  error_message text,
  
  CONSTRAINT valid_ai_rule_exec_status CHECK (status IN ('success', 'partial', 'failed', 'skipped'))
);

CREATE INDEX IF NOT EXISTS idx_ai_rule_execs_rule ON ai_rule_executions(rule_id);
CREATE INDEX IF NOT EXISTS idx_ai_rule_execs_status ON ai_rule_executions(status);
CREATE INDEX IF NOT EXISTS idx_ai_rule_execs_time ON ai_rule_executions(executed_at DESC);

-- RLS 策略
ALTER TABLE ai_analysis_tasks ENABLE ROW LEVEL SECURITY;
ALTER TABLE ai_task_executions ENABLE ROW LEVEL SECURITY;
ALTER TABLE ai_workflows ENABLE ROW LEVEL SECURITY;
ALTER TABLE ai_workflow_executions ENABLE ROW LEVEL SECURITY;
ALTER TABLE ai_insights ENABLE ROW LEVEL SECURITY;
ALTER TABLE ai_predictions ENABLE ROW LEVEL SECURITY;
ALTER TABLE ai_rules ENABLE ROW LEVEL SECURITY;
ALTER TABLE ai_rule_executions ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Authenticated users can view AI tasks"
  ON ai_analysis_tasks FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Authenticated users can manage AI tasks"
  ON ai_analysis_tasks FOR ALL
  TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Authenticated users can view task executions"
  ON ai_task_executions FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Authenticated users can view workflows"
  ON ai_workflows FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Authenticated users can manage workflows"
  ON ai_workflows FOR ALL
  TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Authenticated users can view workflow executions"
  ON ai_workflow_executions FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Authenticated users can view insights"
  ON ai_insights FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Authenticated users can manage insights"
  ON ai_insights FOR ALL
  TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Authenticated users can view predictions"
  ON ai_predictions FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Authenticated users can view rules"
  ON ai_rules FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Authenticated users can manage rules"
  ON ai_rules FOR ALL
  TO authenticated
  USING (true)
  WITH CHECK (true);
