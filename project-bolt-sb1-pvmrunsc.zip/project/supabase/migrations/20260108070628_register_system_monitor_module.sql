/*
  # 注册系统监控模块

  ## 功能说明
  注册系统监控和性能分析模块路由
  
  ## 新增路由
  - /admin/system/monitor: 系统监控仪表板（超级管理员）
*/

DO $$
DECLARE
  v_module_id uuid;
BEGIN
  SELECT id INTO v_module_id FROM sys_modules WHERE module_key = 'system_monitor';

  IF v_module_id IS NULL THEN
    INSERT INTO sys_modules (
      module_key,
      module_name,
      description,
      module_version,
      category,
      icon,
      color,
      status,
      is_core,
      is_system,
      module_type
    ) VALUES (
      'system_monitor',
      '{"zh": "系统监控", "en": "System Monitor"}'::jsonb,
      '{"zh": "实时监控系统性能、资源使用和健康状态", "en": "Real-time monitoring of system performance, resource usage and health"}'::jsonb,
      '1.0.0',
      'system',
      'activity',
      'green',
      'enabled',
      true,
      true,
      'full'
    ) RETURNING id INTO v_module_id;
  END IF;

  IF NOT EXISTS (SELECT 1 FROM sys_module_routes WHERE route_path = '/admin/system/monitor') THEN
    INSERT INTO sys_module_routes (
      module_id,
      route_path,
      component_name,
      is_menu_item,
      menu_label,
      menu_icon,
      menu_order,
      requires_auth,
      required_permissions,
      is_active
    ) VALUES (
      v_module_id,
      '/admin/system/monitor',
      'SystemMonitor',
      true,
      '{"zh": "系统监控", "en": "System Monitor"}'::jsonb,
      'activity',
      999,
      true,
      '["system.manage"]'::jsonb,
      true
    );
  END IF;

  RAISE NOTICE '系统监控模块已注册';
END $$;
