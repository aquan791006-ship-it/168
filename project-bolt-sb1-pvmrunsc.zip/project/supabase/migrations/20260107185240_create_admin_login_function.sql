/*
  # Create Admin Login Function

  1. New Functions
    - `admin_login(p_email, p_password)` - Authenticates admin users
      - Validates email and password
      - Returns success status and admin data
      - Checks if admin account is active

  2. Security
    - Function is publicly accessible for login purposes
    - Password verification using crypt extension
    - Returns sanitized admin data without password hash
*/

CREATE EXTENSION IF NOT EXISTS pgcrypto;

CREATE OR REPLACE FUNCTION admin_login(
  p_email TEXT,
  p_password TEXT
)
RETURNS JSON
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  v_admin RECORD;
  v_result JSON;
BEGIN
  SELECT * INTO v_admin
  FROM admins
  WHERE email = p_email
  AND (status = 'active' OR status IS NULL)
  AND deleted_at IS NULL;

  IF NOT FOUND THEN
    RETURN json_build_object(
      'success', false,
      'message', 'Invalid email or password'
    );
  END IF;

  IF v_admin.password_hash = crypt(p_password, v_admin.password_hash) THEN
    v_result := json_build_object(
      'success', true,
      'message', 'Login successful',
      'admin', json_build_object(
        'id', v_admin.id,
        'email', v_admin.email,
        'full_name', v_admin.full_name,
        'is_super_admin', v_admin.is_super_admin,
        'status', v_admin.status,
        'permissions', v_admin.permissions,
        'department_id', v_admin.department_id,
        'admin_type', v_admin.admin_type
      )
    );
    
    RETURN v_result;
  ELSE
    RETURN json_build_object(
      'success', false,
      'message', 'Invalid email or password'
    );
  END IF;
END;
$$;
