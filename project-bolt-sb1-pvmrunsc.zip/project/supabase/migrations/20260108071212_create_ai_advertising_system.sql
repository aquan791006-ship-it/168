/*
  # 创建AI广告智能优化系统

  ## 功能说明
  为广告推广模块添加完整的AI智能分析和优化功能
  
  ## 新增功能
  - AI性能分析
  - 智能优化建议
  - 自动化优化
*/

-- ============================================
-- AI优化建议表
-- ============================================

CREATE TABLE IF NOT EXISTS ad_optimization_recommendations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  domain_id uuid REFERENCES sys_domains(id) ON DELETE CASCADE,
  campaign_id uuid REFERENCES ad_campaigns(id) ON DELETE CASCADE,
  recommendation_type varchar(100) NOT NULL,
  priority varchar(50) DEFAULT 'medium',
  title text NOT NULL,
  description text NOT NULL,
  current_metrics jsonb DEFAULT '{}'::jsonb,
  expected_improvement jsonb DEFAULT '{}'::jsonb,
  action_items jsonb DEFAULT '[]'::jsonb,
  ai_confidence_score numeric(5,2),
  is_auto_applicable boolean DEFAULT false,
  is_applied boolean DEFAULT false,
  applied_at timestamptz,
  applied_by uuid REFERENCES sys_admins(id),
  status varchar(50) DEFAULT 'pending',
  created_at timestamptz DEFAULT now(),
  expires_at timestamptz,
  CONSTRAINT valid_rec_type CHECK (
    recommendation_type IN ('budget_increase', 'budget_decrease', 'pause_ad', 
      'audience_optimization', 'creative_optimization', 'bidding_strategy')
  ),
  CONSTRAINT valid_rec_priority CHECK (
    priority IN ('low', 'medium', 'high', 'critical')
  ),
  CONSTRAINT valid_rec_status CHECK (
    status IN ('pending', 'applied', 'dismissed', 'expired')
  )
);

DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_indexes WHERE indexname = 'idx_ad_rec_domain') THEN
    CREATE INDEX idx_ad_rec_domain ON ad_optimization_recommendations(domain_id);
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_indexes WHERE indexname = 'idx_ad_rec_campaign') THEN
    CREATE INDEX idx_ad_rec_campaign ON ad_optimization_recommendations(campaign_id);
  END IF;
END $$;

ALTER TABLE ad_optimization_recommendations ENABLE ROW LEVEL SECURITY;

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'ad_optimization_recommendations' 
    AND policyname = 'Users view domain recommendations'
  ) THEN
    CREATE POLICY "Users view domain recommendations"
      ON ad_optimization_recommendations FOR SELECT
      TO authenticated
      USING (
        EXISTS (
          SELECT 1 FROM sys_admin_domains sad
          WHERE sad.admin_id = auth.uid() AND sad.domain_id = ad_optimization_recommendations.domain_id
        )
      );
  END IF;
END $$;

-- ============================================
-- AI分析函数
-- ============================================

CREATE OR REPLACE FUNCTION analyze_campaign_performance(
  p_campaign_id uuid,
  p_days integer DEFAULT 7
)
RETURNS jsonb
LANGUAGE plpgsql
AS $$
DECLARE
  v_result jsonb;
  v_spend numeric := 0;
  v_revenue numeric := 0;
  v_clicks bigint := 0;
  v_impressions bigint := 0;
  v_roas numeric := 0;
  v_ctr numeric := 0;
BEGIN
  SELECT
    COALESCE(SUM(spend), 0),
    COALESCE(SUM(revenue), 0),
    COALESCE(SUM(clicks), 0),
    COALESCE(SUM(impressions), 0)
  INTO v_spend, v_revenue, v_clicks, v_impressions
  FROM ad_stats
  WHERE campaign_id = p_campaign_id
  AND stat_date >= CURRENT_DATE - p_days;
  
  IF v_spend > 0 THEN
    v_roas := v_revenue / v_spend;
  END IF;
  
  IF v_impressions > 0 THEN
    v_ctr := (v_clicks::numeric / v_impressions) * 100;
  END IF;
  
  v_result := jsonb_build_object(
    'campaign_id', p_campaign_id,
    'total_spend', v_spend,
    'total_revenue', v_revenue,
    'total_clicks', v_clicks,
    'metrics', jsonb_build_object(
      'roas', ROUND(v_roas, 2),
      'ctr', ROUND(v_ctr, 2)
    ),
    'performance_score', CASE
      WHEN v_roas >= 4 THEN 'excellent'
      WHEN v_roas >= 2.5 THEN 'good'
      WHEN v_roas >= 1.5 THEN 'average'
      ELSE 'poor'
    END
  );
  
  RETURN v_result;
END;
$$;

-- ============================================
-- 生成AI优化建议
-- ============================================

CREATE OR REPLACE FUNCTION generate_ai_recommendations(
  p_domain_id uuid
)
RETURNS jsonb
LANGUAGE plpgsql
AS $$
DECLARE
  v_campaign record;
  v_analysis jsonb;
  v_count integer := 0;
BEGIN
  DELETE FROM ad_optimization_recommendations
  WHERE domain_id = p_domain_id
  AND status = 'pending'
  AND created_at < now() - interval '7 days';
  
  FOR v_campaign IN
    SELECT id, campaign_name, daily_budget
    FROM ad_campaigns
    WHERE domain_id = p_domain_id
    AND status = 'active'
    ORDER BY created_at DESC
    LIMIT 10
  LOOP
    v_analysis := analyze_campaign_performance(v_campaign.id, 7);
    
    IF (v_analysis->'metrics'->>'roas')::numeric >= 3.0 THEN
      INSERT INTO ad_optimization_recommendations (
        domain_id, campaign_id, recommendation_type, priority,
        title, description, current_metrics, ai_confidence_score,
        action_items, expires_at
      ) VALUES (
        p_domain_id, v_campaign.id, 'budget_increase', 'high',
        '建议增加高效广告预算',
        format('广告活动"%s"的ROAS达到%.2f，表现优异。建议增加30%%预算以扩大收益。', 
          v_campaign.campaign_name, (v_analysis->'metrics'->>'roas')::numeric),
        v_analysis->'metrics',
        85.5,
        jsonb_build_array(
          format('将每日预算从¥%.2f增加到¥%.2f', v_campaign.daily_budget, v_campaign.daily_budget * 1.3),
          '监控未来3天的效果',
          '如果ROAS保持在2.5以上，可继续增加'
        ),
        now() + interval '7 days'
      );
      v_count := v_count + 1;
    END IF;
    
    IF (v_analysis->'metrics'->>'ctr')::numeric < 1.0 AND (v_analysis->>'total_clicks')::bigint > 10 THEN
      INSERT INTO ad_optimization_recommendations (
        domain_id, campaign_id, recommendation_type, priority,
        title, description, current_metrics, ai_confidence_score,
        action_items, expires_at
      ) VALUES (
        p_domain_id, v_campaign.id, 'creative_optimization', 'medium',
        '优化广告创意提升点击率',
        format('广告活动"%s"的CTR为%.2f%%，低于行业平均。建议优化广告创意。', 
          v_campaign.campaign_name, (v_analysis->'metrics'->>'ctr')::numeric),
        v_analysis->'metrics',
        72.3,
        jsonb_build_array(
          '测试新的广告文案和视觉元素',
          '使用更具吸引力的CTA',
          'A/B测试不同创意版本',
          '参考高点击率的竞品广告'
        ),
        now() + interval '7 days'
      );
      v_count := v_count + 1;
    END IF;
    
    IF (v_analysis->'metrics'->>'roas')::numeric < 1.0 AND (v_analysis->>'total_spend')::numeric > 500 THEN
      INSERT INTO ad_optimization_recommendations (
        domain_id, campaign_id, recommendation_type, priority,
        title, description, current_metrics, ai_confidence_score,
        action_items, is_auto_applicable, expires_at
      ) VALUES (
        p_domain_id, v_campaign.id, 'pause_ad', 'critical',
        '建议暂停低效广告活动',
        format('广告活动"%s"的ROAS仅为%.2f，低于盈亏平衡点。建议暂停并重新评估。', 
          v_campaign.campaign_name, (v_analysis->'metrics'->>'roas')::numeric),
        v_analysis->'metrics',
        91.2,
        jsonb_build_array(
          '立即暂停广告投放',
          '分析低效原因',
          '优化后再重新启动',
          '调整受众定位或营销目标'
        ),
        true,
        now() + interval '3 days'
      );
      v_count := v_count + 1;
    END IF;
  END LOOP;
  
  RETURN jsonb_build_object(
    'success', true,
    'recommendations_generated', v_count,
    'generated_at', now()
  );
END;
$$;

-- ============================================
-- 获取AI建议列表
-- ============================================

CREATE OR REPLACE FUNCTION get_ai_recommendations(
  p_domain_id uuid,
  p_status varchar DEFAULT 'pending'
)
RETURNS TABLE (
  id uuid,
  campaign_id uuid,
  campaign_name varchar,
  recommendation_type varchar,
  priority varchar,
  title text,
  description text,
  current_metrics jsonb,
  action_items jsonb,
  ai_confidence_score numeric,
  is_auto_applicable boolean,
  created_at timestamptz
)
LANGUAGE sql
AS $$
  SELECT 
    r.id,
    r.campaign_id,
    c.campaign_name,
    r.recommendation_type,
    r.priority,
    r.title,
    r.description,
    r.current_metrics,
    r.action_items,
    r.ai_confidence_score,
    r.is_auto_applicable,
    r.created_at
  FROM ad_optimization_recommendations r
  LEFT JOIN ad_campaigns c ON c.id = r.campaign_id
  WHERE r.domain_id = p_domain_id
  AND (p_status IS NULL OR r.status = p_status)
  AND r.expires_at > now()
  ORDER BY 
    CASE r.priority
      WHEN 'critical' THEN 1
      WHEN 'high' THEN 2
      WHEN 'medium' THEN 3
      ELSE 4
    END,
    r.created_at DESC;
$$;

COMMENT ON FUNCTION analyze_campaign_performance IS 'AI分析广告活动性能';
COMMENT ON FUNCTION generate_ai_recommendations IS '生成AI优化建议';
COMMENT ON FUNCTION get_ai_recommendations IS '获取AI优化建议列表';
