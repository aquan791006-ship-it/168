/*
  # 创建测试主推广员账户

  ## 创建内容
  1. 创建主推广员A账户（promoter_a@168buy.com）
    - 拥有域名shop-a.168buy.com
    - 创建测试产品和订单
  
  2. 创建主推广员B账户（promoter_b@168buy.com）
    - 拥有域名shop-b.168buy.com
    - 创建测试产品和订单

  3. 验证数据隔离
*/

DO $$
DECLARE
  v_promoter_role_id uuid;
  v_promoter_a_id uuid;
  v_promoter_b_id uuid;
  v_domain_a_id uuid;
  v_domain_b_id uuid;
  v_product_a_id uuid;
  v_product_b_id uuid;
  v_super_admin_id uuid;
BEGIN
  -- 获取角色ID
  SELECT id INTO v_promoter_role_id FROM sys_roles WHERE name = 'promoter';
  SELECT id INTO v_super_admin_id FROM sys_admins WHERE email = 'admin@168buy.com';
  
  -- 获取域名ID
  SELECT id INTO v_domain_a_id FROM sys_domains WHERE domain = 'shop-a.168buy.com';
  SELECT id INTO v_domain_b_id FROM sys_domains WHERE domain = 'shop-b.168buy.com';
  
  -- 创建主推广员A
  INSERT INTO sys_admins (
    email,
    password_hash,
    full_name,
    phone,
    role_id,
    parent_admin_id,
    is_super_admin,
    status,
    created_by
  ) VALUES (
    'promoter_a@168buy.com',
    crypt('Promoter@123', gen_salt('bf')),
    '主推广员A',
    '13800138001',
    v_promoter_role_id,
    v_super_admin_id,
    false,
    'active',
    v_super_admin_id
  )
  ON CONFLICT (email) DO UPDATE 
  SET password_hash = crypt('Promoter@123', gen_salt('bf'))
  RETURNING id INTO v_promoter_a_id;
  
  -- 创建主推广员B
  INSERT INTO sys_admins (
    email,
    password_hash,
    full_name,
    phone,
    role_id,
    parent_admin_id,
    is_super_admin,
    status,
    created_by
  ) VALUES (
    'promoter_b@168buy.com',
    crypt('Promoter@123', gen_salt('bf')),
    '主推广员B',
    '13800138002',
    v_promoter_role_id,
    v_super_admin_id,
    false,
    'active',
    v_super_admin_id
  )
  ON CONFLICT (email) DO UPDATE 
  SET password_hash = crypt('Promoter@123', gen_salt('bf'))
  RETURNING id INTO v_promoter_b_id;
  
  -- 更新域名所有权
  UPDATE sys_domains SET owner_id = v_promoter_a_id WHERE id = v_domain_a_id;
  UPDATE sys_domains SET owner_id = v_promoter_b_id WHERE id = v_domain_b_id;
  
  -- 创建主推广员A的测试产品
  INSERT INTO sys_products (
    domain_id,
    serial_number,
    product_type,
    title,
    description,
    base_price,
    stock,
    status,
    created_by
  ) VALUES (
    v_domain_a_id,
    'A-001',
    'single',
    '{"zh-CN": "推广站A的测试产品", "en": "Test Product for Shop A"}'::jsonb,
    '{"zh-CN": "这是推广站A专属的测试产品"}'::jsonb,
    99.00,
    100,
    'active',
    v_promoter_a_id
  )
  RETURNING id INTO v_product_a_id;
  
  -- 创建主推广员B的测试产品
  INSERT INTO sys_products (
    domain_id,
    serial_number,
    product_type,
    title,
    description,
    base_price,
    stock,
    status,
    created_by
  ) VALUES (
    v_domain_b_id,
    'B-001',
    'single',
    '{"zh-CN": "推广站B的测试产品", "en": "Test Product for Shop B"}'::jsonb,
    '{"zh-CN": "这是推广站B专属的测试产品"}'::jsonb,
    199.00,
    50,
    'active',
    v_promoter_b_id
  )
  RETURNING id INTO v_product_b_id;
  
  -- 创建主推广员A的测试订单
  INSERT INTO sys_orders (
    order_number,
    domain_id,
    customer_name,
    customer_phone,
    customer_email,
    customer_address,
    province,
    city,
    detailed_address,
    total_amount,
    final_amount,
    payment_method,
    order_status
  ) VALUES (
    sys_generate_order_number(),
    v_domain_a_id,
    '张三',
    '13900139000',
    'zhangsan@example.com',
    '{"province":"广东省","city":"深圳市","district":"南山区"}'::jsonb,
    '广东省',
    '深圳市',
    '科技园南区',
    99.00,
    99.00,
    'cod',
    'pending'
  );
  
  -- 创建主推广员B的测试订单
  INSERT INTO sys_orders (
    order_number,
    domain_id,
    customer_name,
    customer_phone,
    customer_email,
    customer_address,
    province,
    city,
    detailed_address,
    total_amount,
    final_amount,
    payment_method,
    order_status
  ) VALUES (
    sys_generate_order_number(),
    v_domain_b_id,
    '李四',
    '13900139001',
    'lisi@example.com',
    '{"province":"北京市","city":"北京市","district":"朝阳区"}'::jsonb,
    '北京市',
    '北京市',
    '三里屯',
    199.00,
    199.00,
    'cod',
    'pending'
  );
  
  RAISE NOTICE '✓ 测试账户创建成功！';
  RAISE NOTICE 'Promoter A: promoter_a@168buy.com / Promoter@123';
  RAISE NOTICE 'Promoter B: promoter_b@168buy.com / Promoter@123';
  RAISE NOTICE 'Product A ID: %', v_product_a_id;
  RAISE NOTICE 'Product B ID: %', v_product_b_id;
END $$;