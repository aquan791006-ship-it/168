/*
  # 模块管理核心函数

  ## 功能
  1. 模块启用/禁用
  2. 模块依赖检查
  3. 模块安装/卸载
  4. 事件发布/订阅
  5. 动态路由注册
*/

-- 1. 检查模块依赖是否满足
CREATE OR REPLACE FUNCTION check_module_dependencies(p_module_id uuid)
RETURNS boolean AS $$
DECLARE
  v_dep record;
  v_dep_module record;
BEGIN
  FOR v_dep IN 
    SELECT * FROM sys_module_dependencies 
    WHERE module_id = p_module_id AND dependency_type = 'required'
  LOOP
    SELECT * INTO v_dep_module 
    FROM sys_modules 
    WHERE id = v_dep.depends_on_module_id;
    
    IF v_dep_module.id IS NULL THEN
      RAISE EXCEPTION 'Required dependency module not found: %', v_dep.depends_on_module_id;
    END IF;
    
    IF v_dep_module.status NOT IN ('enabled', 'installed') THEN
      RAISE EXCEPTION 'Required dependency module % is not enabled', v_dep_module.module_key;
    END IF;
  END LOOP;
  
  RETURN true;
END;
$$ LANGUAGE plpgsql;

-- 2. 启用模块
CREATE OR REPLACE FUNCTION enable_module(
  p_module_key varchar,
  p_user_id uuid DEFAULT NULL
)
RETURNS jsonb AS $$
DECLARE
  v_module record;
  v_result jsonb;
  v_history_id uuid;
BEGIN
  SELECT * INTO v_module FROM sys_modules WHERE module_key = p_module_key;
  
  IF v_module.id IS NULL THEN
    RETURN jsonb_build_object(
      'success', false,
      'error', 'Module not found: ' || p_module_key
    );
  END IF;
  
  IF v_module.status = 'enabled' THEN
    RETURN jsonb_build_object(
      'success', false,
      'error', 'Module already enabled'
    );
  END IF;
  
  IF NOT check_module_dependencies(v_module.id) THEN
    RETURN jsonb_build_object(
      'success', false,
      'error', 'Module dependencies not satisfied'
    );
  END IF;
  
  INSERT INTO sys_module_install_history (
    module_id,
    action,
    from_version,
    to_version,
    status,
    performed_by
  ) VALUES (
    v_module.id,
    'enable',
    v_module.module_version,
    v_module.module_version,
    'in_progress',
    p_user_id
  ) RETURNING id INTO v_history_id;
  
  UPDATE sys_modules
  SET status = 'enabled',
      enabled_at = now(),
      updated_at = now()
  WHERE id = v_module.id;
  
  UPDATE sys_module_install_history
  SET status = 'completed',
      completed_at = now()
  WHERE id = v_history_id;
  
  INSERT INTO sys_module_events (
    event_name,
    publisher_module_id,
    event_data,
    event_type
  ) VALUES (
    'module.enabled',
    v_module.id,
    jsonb_build_object(
      'module_key', v_module.module_key,
      'module_name', v_module.module_name
    ),
    'system'
  );
  
  RETURN jsonb_build_object(
    'success', true,
    'module_key', v_module.module_key,
    'status', 'enabled'
  );
END;
$$ LANGUAGE plpgsql;

-- 3. 禁用模块
CREATE OR REPLACE FUNCTION disable_module(
  p_module_key varchar,
  p_user_id uuid DEFAULT NULL
)
RETURNS jsonb AS $$
DECLARE
  v_module record;
  v_dependent_modules text[];
  v_history_id uuid;
BEGIN
  SELECT * INTO v_module FROM sys_modules WHERE module_key = p_module_key;
  
  IF v_module.id IS NULL THEN
    RETURN jsonb_build_object(
      'success', false,
      'error', 'Module not found: ' || p_module_key
    );
  END IF;
  
  IF v_module.is_core = true OR v_module.is_system = true THEN
    RETURN jsonb_build_object(
      'success', false,
      'error', 'Cannot disable core or system module'
    );
  END IF;
  
  IF v_module.status != 'enabled' THEN
    RETURN jsonb_build_object(
      'success', false,
      'error', 'Module is not enabled'
    );
  END IF;
  
  SELECT array_agg(m.module_key) INTO v_dependent_modules
  FROM sys_module_dependencies d
  JOIN sys_modules m ON d.module_id = m.id
  WHERE d.depends_on_module_id = v_module.id
    AND d.dependency_type = 'required'
    AND m.status = 'enabled';
  
  IF array_length(v_dependent_modules, 1) > 0 THEN
    RETURN jsonb_build_object(
      'success', false,
      'error', 'Cannot disable module. Other enabled modules depend on it',
      'dependent_modules', v_dependent_modules
    );
  END IF;
  
  INSERT INTO sys_module_install_history (
    module_id,
    action,
    from_version,
    to_version,
    status,
    performed_by
  ) VALUES (
    v_module.id,
    'disable',
    v_module.module_version,
    v_module.module_version,
    'in_progress',
    p_user_id
  ) RETURNING id INTO v_history_id;
  
  UPDATE sys_modules
  SET status = 'disabled',
      disabled_at = now(),
      updated_at = now()
  WHERE id = v_module.id;
  
  UPDATE sys_module_install_history
  SET status = 'completed',
      completed_at = now()
  WHERE id = v_history_id;
  
  INSERT INTO sys_module_events (
    event_name,
    publisher_module_id,
    event_data,
    event_type
  ) VALUES (
    'module.disabled',
    v_module.id,
    jsonb_build_object(
      'module_key', v_module.module_key,
      'module_name', v_module.module_name
    ),
    'system'
  );
  
  RETURN jsonb_build_object(
    'success', true,
    'module_key', v_module.module_key,
    'status', 'disabled'
  );
END;
$$ LANGUAGE plpgsql;

-- 4. 获取已启用模块的路由
CREATE OR REPLACE FUNCTION get_enabled_module_routes()
RETURNS TABLE (
  route_path varchar,
  component_name varchar,
  menu_label jsonb,
  menu_icon varchar,
  menu_order integer,
  is_menu_item boolean,
  module_key varchar,
  module_name jsonb,
  requires_auth boolean,
  required_permissions jsonb,
  meta jsonb
) AS $$
BEGIN
  RETURN QUERY
  SELECT 
    r.route_path,
    r.component_name,
    r.menu_label,
    r.menu_icon,
    r.menu_order,
    r.is_menu_item,
    m.module_key,
    m.module_name,
    r.requires_auth,
    r.required_permissions,
    r.meta
  FROM sys_module_routes r
  JOIN sys_modules m ON r.module_id = m.id
  WHERE m.status = 'enabled'
    AND r.is_active = true
  ORDER BY r.menu_order, r.route_path;
END;
$$ LANGUAGE plpgsql;

-- 5. 获取已启用模块的 API 端点
CREATE OR REPLACE FUNCTION get_enabled_module_apis()
RETURNS TABLE (
  api_key varchar,
  api_path varchar,
  http_method varchar,
  edge_function_name varchar,
  handler_type varchar,
  module_key varchar,
  requires_auth boolean,
  required_permissions jsonb,
  rate_limit integer
) AS $$
BEGIN
  RETURN QUERY
  SELECT 
    a.api_key,
    a.api_path,
    a.http_method,
    a.edge_function_name,
    a.handler_type,
    m.module_key,
    a.requires_auth,
    a.required_permissions,
    a.rate_limit
  FROM sys_module_apis a
  JOIN sys_modules m ON a.module_id = m.id
  WHERE m.status = 'enabled'
    AND a.is_active = true
  ORDER BY a.api_path;
END;
$$ LANGUAGE plpgsql;

-- 6. 发布模块事件
CREATE OR REPLACE FUNCTION publish_module_event(
  p_event_name varchar,
  p_publisher_module_key varchar,
  p_event_data jsonb DEFAULT '{}',
  p_event_type varchar DEFAULT 'notification',
  p_priority integer DEFAULT 5
)
RETURNS uuid AS $$
DECLARE
  v_module_id uuid;
  v_event_id uuid;
BEGIN
  SELECT id INTO v_module_id
  FROM sys_modules
  WHERE module_key = p_publisher_module_key;
  
  INSERT INTO sys_module_events (
    event_name,
    publisher_module_id,
    event_data,
    event_type,
    priority,
    status
  ) VALUES (
    p_event_name,
    v_module_id,
    p_event_data,
    p_event_type,
    p_priority,
    'pending'
  ) RETURNING id INTO v_event_id;
  
  RETURN v_event_id;
END;
$$ LANGUAGE plpgsql;

-- 7. 获取模块统计信息
CREATE OR REPLACE FUNCTION get_module_statistics()
RETURNS jsonb AS $$
DECLARE
  v_stats jsonb;
BEGIN
  SELECT jsonb_build_object(
    'total_modules', COUNT(*),
    'enabled_modules', COUNT(*) FILTER (WHERE status = 'enabled'),
    'disabled_modules', COUNT(*) FILTER (WHERE status = 'disabled'),
    'installed_modules', COUNT(*) FILTER (WHERE status = 'installed'),
    'core_modules', COUNT(*) FILTER (WHERE is_core = true),
    'by_category', (
      SELECT jsonb_object_agg(
        category,
        count
      )
      FROM (
        SELECT category, COUNT(*) as count
        FROM sys_modules
        GROUP BY category
      ) cat_counts
    )
  ) INTO v_stats
  FROM sys_modules;
  
  RETURN v_stats;
END;
$$ LANGUAGE plpgsql;

-- 8. 批量启用模块（处理依赖顺序）
CREATE OR REPLACE FUNCTION batch_enable_modules(
  p_module_keys varchar[],
  p_user_id uuid DEFAULT NULL
)
RETURNS jsonb AS $$
DECLARE
  v_module_key varchar;
  v_result jsonb;
  v_results jsonb[] := ARRAY[]::jsonb[];
  v_success_count integer := 0;
  v_error_count integer := 0;
BEGIN
  FOREACH v_module_key IN ARRAY p_module_keys
  LOOP
    BEGIN
      v_result := enable_module(v_module_key, p_user_id);
      
      IF (v_result->>'success')::boolean THEN
        v_success_count := v_success_count + 1;
      ELSE
        v_error_count := v_error_count + 1;
      END IF;
      
      v_results := array_append(v_results, v_result);
    EXCEPTION WHEN OTHERS THEN
      v_error_count := v_error_count + 1;
      v_results := array_append(v_results, jsonb_build_object(
        'success', false,
        'module_key', v_module_key,
        'error', SQLERRM
      ));
    END;
  END LOOP;
  
  RETURN jsonb_build_object(
    'success_count', v_success_count,
    'error_count', v_error_count,
    'results', to_jsonb(v_results)
  );
END;
$$ LANGUAGE plpgsql;
