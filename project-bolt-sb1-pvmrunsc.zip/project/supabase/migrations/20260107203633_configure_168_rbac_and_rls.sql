/*
  # 168全球购 - 配置RBAC权限和RLS策略

  ## 配置内容
  1. 分配角色权限
  2. 启用所有表的RLS
  3. 创建RLS策略（基于JWT claims，避免递归）
  4. 创建辅助函数
*/

-- ============================================
-- 分配角色权限
-- ============================================

-- 为超级管理员分配所有权限
INSERT INTO sys_role_permissions (role_id, permission_id)
SELECT r.id, p.id
FROM sys_roles r
CROSS JOIN sys_permissions p
WHERE r.name = 'super_admin'
ON CONFLICT DO NOTHING;

-- 为主推广员分配权限
INSERT INTO sys_role_permissions (role_id, permission_id)
SELECT r.id, p.id
FROM sys_roles r
CROSS JOIN sys_permissions p
WHERE r.name = 'promoter'
  AND p.code IN (
    'admins.view_own', 'admins.create',
    'domains.view_own', 'domains.create', 'domains.update',
    'products.view_own', 'products.create', 'products.update', 'products.delete',
    'orders.view_own', 'orders.update', 'orders.export',
    'analytics.view_own'
  )
ON CONFLICT DO NOTHING;

-- 为运营人员分配权限
INSERT INTO sys_role_permissions (role_id, permission_id)
SELECT r.id, p.id
FROM sys_roles r
CROSS JOIN sys_permissions p
WHERE r.name = 'operator'
  AND p.code IN (
    'products.view_own', 'products.create', 'products.update',
    'orders.view_own', 'orders.update',
    'analytics.view_own'
  )
ON CONFLICT DO NOTHING;

-- 为查看者分配权限
INSERT INTO sys_role_permissions (role_id, permission_id)
SELECT r.id, p.id
FROM sys_roles r
CROSS JOIN sys_permissions p
WHERE r.name = 'viewer'
  AND p.code IN (
    'products.view_own',
    'orders.view_own',
    'analytics.view_own'
  )
ON CONFLICT DO NOTHING;

-- ============================================
-- 启用RLS
-- ============================================

ALTER TABLE sys_roles ENABLE ROW LEVEL SECURITY;
ALTER TABLE sys_permissions ENABLE ROW LEVEL SECURITY;
ALTER TABLE sys_role_permissions ENABLE ROW LEVEL SECURITY;
ALTER TABLE sys_admins ENABLE ROW LEVEL SECURITY;
ALTER TABLE sys_domains ENABLE ROW LEVEL SECURITY;
ALTER TABLE sys_admin_domains ENABLE ROW LEVEL SECURITY;
ALTER TABLE sys_operation_logs ENABLE ROW LEVEL SECURITY;
ALTER TABLE sys_products ENABLE ROW LEVEL SECURITY;
ALTER TABLE sys_product_images ENABLE ROW LEVEL SECURITY;
ALTER TABLE sys_product_modules ENABLE ROW LEVEL SECURITY;
ALTER TABLE sys_product_skus ENABLE ROW LEVEL SECURITY;
ALTER TABLE sys_product_prices ENABLE ROW LEVEL SECURITY;
ALTER TABLE sys_orders ENABLE ROW LEVEL SECURITY;
ALTER TABLE sys_order_items ENABLE ROW LEVEL SECURITY;
ALTER TABLE sys_order_logs ENABLE ROW LEVEL SECURITY;
ALTER TABLE sys_blacklist ENABLE ROW LEVEL SECURITY;
ALTER TABLE sys_risk_rules ENABLE ROW LEVEL SECURITY;
ALTER TABLE sys_analytics_logs ENABLE ROW LEVEL SECURITY;
ALTER TABLE sys_analytics_hourly ENABLE ROW LEVEL SECURITY;
ALTER TABLE sys_analytics_daily ENABLE ROW LEVEL SECURITY;

-- ============================================
-- 创建RLS策略
-- ============================================

-- 角色和权限表（所有认证用户可查看）
CREATE POLICY "认证用户可查看角色"
  ON sys_roles FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "认证用户可查看权限"
  ON sys_permissions FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "认证用户可查看角色权限"
  ON sys_role_permissions FOR SELECT
  TO authenticated
  USING (true);

-- 管理员表策略
CREATE POLICY "管理员可查看自己的信息"
  ON sys_admins FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "管理员可更新自己的信息"
  ON sys_admins FOR UPDATE
  TO authenticated
  USING (id::text = (current_setting('request.jwt.claims', true)::json->>'admin_id'))
  WITH CHECK (id::text = (current_setting('request.jwt.claims', true)::json->>'admin_id'));

CREATE POLICY "超级管理员可管理所有管理员"
  ON sys_admins FOR ALL
  TO authenticated
  USING ((current_setting('request.jwt.claims', true)::json->>'is_super_admin')::boolean = true);

-- 域名表策略
CREATE POLICY "管理员可查看域名"
  ON sys_domains FOR SELECT
  TO authenticated
  USING (
    (current_setting('request.jwt.claims', true)::json->>'is_super_admin')::boolean = true
    OR owner_id::text = (current_setting('request.jwt.claims', true)::json->>'admin_id')
    OR EXISTS (
      SELECT 1 FROM sys_admin_domains 
      WHERE domain_id = sys_domains.id 
      AND admin_id::text = (current_setting('request.jwt.claims', true)::json->>'admin_id')
    )
  );

CREATE POLICY "超级管理员可管理所有域名"
  ON sys_domains FOR ALL
  TO authenticated
  USING ((current_setting('request.jwt.claims', true)::json->>'is_super_admin')::boolean = true);

CREATE POLICY "域名所有者可管理自己的域名"
  ON sys_domains FOR ALL
  TO authenticated
  USING (owner_id::text = (current_setting('request.jwt.claims', true)::json->>'admin_id'));

-- 管理员域名权限表策略
CREATE POLICY "管理员可查看域名权限"
  ON sys_admin_domains FOR SELECT
  TO authenticated
  USING (true);

-- 产品表策略
CREATE POLICY "管理员可查看产品"
  ON sys_products FOR SELECT
  TO authenticated
  USING (
    (current_setting('request.jwt.claims', true)::json->>'is_super_admin')::boolean = true
    OR EXISTS (
      SELECT 1 FROM sys_domains d
      WHERE d.id = sys_products.domain_id
      AND (
        d.owner_id::text = (current_setting('request.jwt.claims', true)::json->>'admin_id')
        OR EXISTS (
          SELECT 1 FROM sys_admin_domains ad
          WHERE ad.domain_id = d.id
          AND ad.admin_id::text = (current_setting('request.jwt.claims', true)::json->>'admin_id')
        )
      )
    )
  );

CREATE POLICY "超级管理员可管理所有产品"
  ON sys_products FOR ALL
  TO authenticated
  USING ((current_setting('request.jwt.claims', true)::json->>'is_super_admin')::boolean = true);

CREATE POLICY "域名管理员可管理产品"
  ON sys_products FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM sys_domains d
      WHERE d.id = sys_products.domain_id
      AND (
        d.owner_id::text = (current_setting('request.jwt.claims', true)::json->>'admin_id')
        OR EXISTS (
          SELECT 1 FROM sys_admin_domains ad
          WHERE ad.domain_id = d.id
          AND ad.admin_id::text = (current_setting('request.jwt.claims', true)::json->>'admin_id')
          AND ad.access_level IN ('owner', 'manager')
        )
      )
    )
  );

-- 产品图片表策略
CREATE POLICY "管理员可查看产品图片"
  ON sys_product_images FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "管理员可管理产品图片"
  ON sys_product_images FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM sys_products p
      JOIN sys_domains d ON d.id = p.domain_id
      WHERE p.id = sys_product_images.product_id
      AND (
        (current_setting('request.jwt.claims', true)::json->>'is_super_admin')::boolean = true
        OR d.owner_id::text = (current_setting('request.jwt.claims', true)::json->>'admin_id')
      )
    )
  );

-- 订单表策略
CREATE POLICY "管理员可查看订单"
  ON sys_orders FOR SELECT
  TO authenticated
  USING (
    (current_setting('request.jwt.claims', true)::json->>'is_super_admin')::boolean = true
    OR EXISTS (
      SELECT 1 FROM sys_domains d
      WHERE d.id = sys_orders.domain_id
      AND (
        d.owner_id::text = (current_setting('request.jwt.claims', true)::json->>'admin_id')
        OR EXISTS (
          SELECT 1 FROM sys_admin_domains ad
          WHERE ad.domain_id = d.id
          AND ad.admin_id::text = (current_setting('request.jwt.claims', true)::json->>'admin_id')
        )
      )
    )
  );

CREATE POLICY "超级管理员可管理所有订单"
  ON sys_orders FOR ALL
  TO authenticated
  USING ((current_setting('request.jwt.claims', true)::json->>'is_super_admin')::boolean = true);

CREATE POLICY "域名管理员可管理订单"
  ON sys_orders FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM sys_domains d
      WHERE d.id = sys_orders.domain_id
      AND d.owner_id::text = (current_setting('request.jwt.claims', true)::json->>'admin_id')
    )
  );

-- 订单明细表策略
CREATE POLICY "管理员可查看订单明细"
  ON sys_order_items FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "管理员可管理订单明细"
  ON sys_order_items FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM sys_orders o
      JOIN sys_domains d ON d.id = o.domain_id
      WHERE o.id = sys_order_items.order_id
      AND (
        (current_setting('request.jwt.claims', true)::json->>'is_super_admin')::boolean = true
        OR d.owner_id::text = (current_setting('request.jwt.claims', true)::json->>'admin_id')
      )
    )
  );

-- 数据分析表策略
CREATE POLICY "管理员可查看分析日志"
  ON sys_analytics_logs FOR SELECT
  TO authenticated
  USING (
    (current_setting('request.jwt.claims', true)::json->>'is_super_admin')::boolean = true
    OR EXISTS (
      SELECT 1 FROM sys_domains d
      WHERE d.id = sys_analytics_logs.domain_id
      AND (
        d.owner_id::text = (current_setting('request.jwt.claims', true)::json->>'admin_id')
        OR EXISTS (
          SELECT 1 FROM sys_admin_domains ad
          WHERE ad.domain_id = d.id
          AND ad.admin_id::text = (current_setting('request.jwt.claims', true)::json->>'admin_id')
        )
      )
    )
  );

-- 其他表的基本策略（允许认证用户访问）
CREATE POLICY "管理员可访问产品模块"
  ON sys_product_modules FOR ALL
  TO authenticated
  USING (true);

CREATE POLICY "管理员可访问产品SKU"
  ON sys_product_skus FOR ALL
  TO authenticated
  USING (true);

CREATE POLICY "管理员可访问产品价格"
  ON sys_product_prices FOR ALL
  TO authenticated
  USING (true);

CREATE POLICY "管理员可访问订单日志"
  ON sys_order_logs FOR ALL
  TO authenticated
  USING (true);

CREATE POLICY "管理员可访问黑名单"
  ON sys_blacklist FOR ALL
  TO authenticated
  USING (true);

CREATE POLICY "管理员可访问风控规则"
  ON sys_risk_rules FOR ALL
  TO authenticated
  USING (true);

CREATE POLICY "管理员可访问操作日志"
  ON sys_operation_logs FOR ALL
  TO authenticated
  USING (true);

CREATE POLICY "管理员可访问小时统计"
  ON sys_analytics_hourly FOR ALL
  TO authenticated
  USING (true);

CREATE POLICY "管理员可访问日统计"
  ON sys_analytics_daily FOR ALL
  TO authenticated
  USING (true);

-- ============================================
-- 创建辅助函数
-- ============================================

-- 1. 管理员登录函数
CREATE OR REPLACE FUNCTION sys_admin_login(
  p_email text,
  p_password text
)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_admin sys_admins;
  v_role sys_roles;
  v_result jsonb;
BEGIN
  -- 查找管理员
  SELECT * INTO v_admin
  FROM sys_admins
  WHERE email = p_email
    AND status = 'active';
  
  IF NOT FOUND THEN
    RETURN jsonb_build_object(
      'success', false,
      'message', '邮箱或密码错误'
    );
  END IF;
  
  -- 验证密码（使用 pgcrypto 扩展的 crypt 函数）
  IF v_admin.password_hash != crypt(p_password, v_admin.password_hash) THEN
    RETURN jsonb_build_object(
      'success', false,
      'message', '邮箱或密码错误'
    );
  END IF;
  
  -- 获取角色信息
  SELECT * INTO v_role
  FROM sys_roles
  WHERE id = v_admin.role_id;
  
  -- 更新最后登录时间
  UPDATE sys_admins
  SET last_login_at = now()
  WHERE id = v_admin.id;
  
  -- 返回管理员信息
  RETURN jsonb_build_object(
    'success', true,
    'admin', jsonb_build_object(
      'id', v_admin.id,
      'email', v_admin.email,
      'full_name', v_admin.full_name,
      'phone', v_admin.phone,
      'avatar', v_admin.avatar,
      'is_super_admin', v_admin.is_super_admin,
      'role', jsonb_build_object(
        'id', v_role.id,
        'name', v_role.name,
        'display_name', v_role.display_name
      )
    )
  );
END;
$$;

-- 2. 检查管理员权限
CREATE OR REPLACE FUNCTION sys_check_permission(
  p_admin_id uuid,
  p_permission_code text
)
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_is_super boolean;
  v_has_permission boolean;
BEGIN
  -- 检查是否为超级管理员
  SELECT is_super_admin INTO v_is_super
  FROM sys_admins
  WHERE id = p_admin_id;
  
  IF v_is_super THEN
    RETURN true;
  END IF;
  
  -- 检查角色权限
  SELECT EXISTS(
    SELECT 1
    FROM sys_admins a
    JOIN sys_role_permissions rp ON rp.role_id = a.role_id
    JOIN sys_permissions p ON p.id = rp.permission_id
    WHERE a.id = p_admin_id
      AND p.code = p_permission_code
  ) INTO v_has_permission;
  
  RETURN COALESCE(v_has_permission, false);
END;
$$;

-- 3. 获取管理员可访问的域名
CREATE OR REPLACE FUNCTION sys_get_admin_domains(p_admin_id uuid)
RETURNS TABLE(
  domain_id uuid,
  domain text,
  display_name text,
  access_level text
)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  -- 如果是超级管理员，返回所有域名
  IF EXISTS(SELECT 1 FROM sys_admins WHERE id = p_admin_id AND is_super_admin = true) THEN
    RETURN QUERY
    SELECT d.id, d.domain, d.display_name, 'owner'::text
    FROM sys_domains d
    WHERE d.status = 'active';
  ELSE
    -- 返回管理员拥有或有权限的域名
    RETURN QUERY
    SELECT DISTINCT d.id, d.domain, d.display_name,
           CASE 
             WHEN d.owner_id = p_admin_id THEN 'owner'::text
             ELSE COALESCE(ad.access_level, 'viewer'::text)
           END as access_level
    FROM sys_domains d
    LEFT JOIN sys_admin_domains ad ON ad.domain_id = d.id AND ad.admin_id = p_admin_id
    WHERE d.status = 'active'
      AND (d.owner_id = p_admin_id OR ad.admin_id = p_admin_id);
  END IF;
END;
$$;

-- 4. 生成订单号
CREATE OR REPLACE FUNCTION sys_generate_order_number()
RETURNS text
LANGUAGE plpgsql
AS $$
DECLARE
  v_prefix text := '168';
  v_date text := to_char(now(), 'YYYYMMDD');
  v_random text := lpad(floor(random() * 999999)::text, 6, '0');
BEGIN
  RETURN v_prefix || v_date || v_random;
END;
$$;