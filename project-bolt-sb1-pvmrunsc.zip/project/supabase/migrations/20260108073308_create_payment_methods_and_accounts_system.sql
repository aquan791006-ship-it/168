/*
  # 创建付款方式和支付账号管理系统

  ## 新增表
  
  ### 1. sys_payment_methods
  全局付款方式配置表，定义系统支持的所有付款方式
  
  字段说明：
  - id: 唯一标识
  - domain_id: 域名ID（多租户隔离）
  - method_code: 付款方式代码（cod, alipay, wechat, bank, usdt, etc）
  - method_name: 显示名称
  - method_type: 方法类型（offline=线下, online=在线）
  - description: 描述说明
  - icon_url: 图标URL
  - is_enabled: 是否启用
  - display_order: 显示顺序
  - require_account: 是否需要配置收款账号
  - settings: 额外配置（JSON格式）
  
  ### 2. sys_payment_accounts
  在线支付收款账号配置表
  
  字段说明：
  - id: 唯一标识
  - domain_id: 域名ID
  - payment_method_id: 关联的付款方式ID
  - account_name: 账号名称
  - account_type: 账号类型（personal=个人, business=企业）
  - account_info: 账号信息（JSON，存储不同支付方式的具体信息）
  - qr_code_url: 收款二维码URL
  - is_primary: 是否为主账号
  - is_active: 是否激活
  - notes: 备注说明
  
  ## 功能说明
  1. 支持灵活配置各种付款方式
  2. 支持线下和在线支付方式
  3. 支持多个收款账号配置
  4. 支持二维码收款
  5. 支持主账号切换
  6. 完全的多租户隔离
  
  ## 安全
  - 启用RLS行级安全
  - 仅超级管理员可管理
  - 数据按域名严格隔离
*/

CREATE TABLE IF NOT EXISTS sys_payment_methods (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  domain_id uuid REFERENCES sys_domains(id) ON DELETE CASCADE,
  method_code varchar(50) NOT NULL,
  method_name varchar(100) NOT NULL,
  method_type varchar(20) DEFAULT 'offline',
  description text,
  icon_url text,
  is_enabled boolean DEFAULT true,
  display_order integer DEFAULT 0,
  require_account boolean DEFAULT false,
  settings jsonb DEFAULT '{}'::jsonb,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  CONSTRAINT valid_method_type CHECK (method_type IN ('offline', 'online')),
  CONSTRAINT unique_method_per_domain UNIQUE (domain_id, method_code)
);

CREATE INDEX idx_payment_methods_domain ON sys_payment_methods(domain_id);
CREATE INDEX idx_payment_methods_enabled ON sys_payment_methods(domain_id, is_enabled) 
  WHERE is_enabled = true;
CREATE INDEX idx_payment_methods_order ON sys_payment_methods(display_order);

ALTER TABLE sys_payment_methods ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Super admins manage payment methods"
  ON sys_payment_methods FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM sys_admins
      WHERE id = auth.uid()
      AND domain_id = sys_payment_methods.domain_id
      AND is_super_admin = true
    )
  );

CREATE POLICY "Public view enabled payment methods"
  ON sys_payment_methods FOR SELECT
  TO anon
  USING (is_enabled = true);

CREATE TABLE IF NOT EXISTS sys_payment_accounts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  domain_id uuid REFERENCES sys_domains(id) ON DELETE CASCADE,
  payment_method_id uuid REFERENCES sys_payment_methods(id) ON DELETE CASCADE,
  account_name varchar(200) NOT NULL,
  account_type varchar(20) DEFAULT 'personal',
  account_info jsonb DEFAULT '{}'::jsonb,
  qr_code_url text,
  is_primary boolean DEFAULT false,
  is_active boolean DEFAULT true,
  notes text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  CONSTRAINT valid_account_type CHECK (account_type IN ('personal', 'business', 'merchant'))
);

CREATE INDEX idx_payment_accounts_domain ON sys_payment_accounts(domain_id);
CREATE INDEX idx_payment_accounts_method ON sys_payment_accounts(payment_method_id);
CREATE INDEX idx_payment_accounts_primary ON sys_payment_accounts(domain_id, is_primary) 
  WHERE is_primary = true;
CREATE INDEX idx_payment_accounts_active ON sys_payment_accounts(domain_id, is_active) 
  WHERE is_active = true;

ALTER TABLE sys_payment_accounts ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Super admins manage payment accounts"
  ON sys_payment_accounts FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM sys_admins
      WHERE id = auth.uid()
      AND domain_id = sys_payment_accounts.domain_id
      AND is_super_admin = true
    )
  );

CREATE POLICY "Public view active payment accounts"
  ON sys_payment_accounts FOR SELECT
  TO anon
  USING (is_active = true);

CREATE OR REPLACE FUNCTION initialize_default_payment_methods(p_domain_id uuid)
RETURNS jsonb
LANGUAGE plpgsql
AS $$
DECLARE
  v_count integer;
  v_result jsonb;
BEGIN
  SELECT COUNT(*) INTO v_count
  FROM sys_payment_methods
  WHERE domain_id = p_domain_id;
  
  IF v_count > 0 THEN
    RETURN jsonb_build_object(
      'success', false,
      'message', 'Payment methods already initialized',
      'count', v_count
    );
  END IF;
  
  INSERT INTO sys_payment_methods (domain_id, method_code, method_name, method_type, description, display_order, require_account)
  VALUES
    (p_domain_id, 'cod', '货到付款', 'offline', '送货上门，现金/扫码支付', 1, false),
    (p_domain_id, 'alipay', '支付宝', 'online', '支付宝在线支付', 2, true),
    (p_domain_id, 'wechat', '微信支付', 'online', '微信在线支付', 3, true),
    (p_domain_id, 'bank', '银行转账', 'online', '银行卡转账支付', 4, true),
    (p_domain_id, 'usdt', 'USDT', 'online', '泰达币数字货币支付', 5, true),
    (p_domain_id, 'usd', '美元支付', 'online', '美元在线支付', 6, true),
    (p_domain_id, 'cny', '人民币支付', 'online', '人民币在线支付', 7, true);
  
  v_result := jsonb_build_object(
    'success', true,
    'message', 'Default payment methods initialized',
    'count', 7
  );
  
  RETURN v_result;
END;
$$;

CREATE OR REPLACE FUNCTION set_primary_payment_account(
  p_account_id uuid,
  p_domain_id uuid
)
RETURNS jsonb
LANGUAGE plpgsql
AS $$
DECLARE
  v_method_id uuid;
BEGIN
  SELECT payment_method_id INTO v_method_id
  FROM sys_payment_accounts
  WHERE id = p_account_id AND domain_id = p_domain_id;
  
  IF v_method_id IS NULL THEN
    RETURN jsonb_build_object(
      'success', false,
      'error', 'Account not found'
    );
  END IF;
  
  UPDATE sys_payment_accounts
  SET is_primary = false
  WHERE payment_method_id = v_method_id
  AND domain_id = p_domain_id
  AND is_primary = true;
  
  UPDATE sys_payment_accounts
  SET is_primary = true
  WHERE id = p_account_id;
  
  RETURN jsonb_build_object(
    'success', true,
    'message', 'Primary account updated',
    'account_id', p_account_id
  );
END;
$$;

CREATE OR REPLACE FUNCTION get_enabled_payment_methods_with_accounts(p_domain_id uuid)
RETURNS jsonb
LANGUAGE plpgsql
AS $$
DECLARE
  v_result jsonb;
BEGIN
  SELECT jsonb_agg(
    jsonb_build_object(
      'id', pm.id,
      'method_code', pm.method_code,
      'method_name', pm.method_name,
      'method_type', pm.method_type,
      'description', pm.description,
      'icon_url', pm.icon_url,
      'require_account', pm.require_account,
      'accounts', (
        SELECT jsonb_agg(
          jsonb_build_object(
            'id', pa.id,
            'account_name', pa.account_name,
            'account_type', pa.account_type,
            'account_info', pa.account_info,
            'qr_code_url', pa.qr_code_url,
            'is_primary', pa.is_primary
          )
          ORDER BY pa.is_primary DESC, pa.created_at DESC
        )
        FROM sys_payment_accounts pa
        WHERE pa.payment_method_id = pm.id
        AND pa.is_active = true
      )
    )
    ORDER BY pm.display_order, pm.created_at
  ) INTO v_result
  FROM sys_payment_methods pm
  WHERE pm.domain_id = p_domain_id
  AND pm.is_enabled = true;
  
  RETURN COALESCE(v_result, '[]'::jsonb);
END;
$$;

COMMENT ON TABLE sys_payment_methods IS '全局付款方式配置表';
COMMENT ON TABLE sys_payment_accounts IS '在线支付收款账号配置表';
COMMENT ON FUNCTION initialize_default_payment_methods IS '初始化默认付款方式';
COMMENT ON FUNCTION set_primary_payment_account IS '设置主收款账号';
COMMENT ON FUNCTION get_enabled_payment_methods_with_accounts IS '获取启用的付款方式及其收款账号';
