# SmartInsight AI 模块架构文档

## 🎯 模块概述

**SmartInsight** 是为 168全球购 ERP 系统设计的企业级 AI 插件模块，提供智能数据分析和自主工作流处理能力。作为可组合式 ERP 架构的一部分，SmartInsight 可以随时启用或禁用，且不影响主系统运行。

### 核心能力

1. **智能数据分析** - 自动分析业务数据，生成可执行的洞察
2. **自主工作流引擎** - AI 驱动的自动化业务流程
3. **预测分析** - 基于历史数据的趋势预测和需求预测
4. **异常检测** - 实时监控业务指标，自动识别异常
5. **智能推荐** - 基于数据的决策建议和优化方案
6. **规则引擎** - 灵活配置的业务规则自动化执行

---

## 🏗️ 系统架构

### 1. 整体架构

```
┌─────────────────────────────────────────────────────────────┐
│                     前端展示层 (React)                        │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐      │
│  │ AI 智能中心  │  │  洞察看板    │  │  工作流编辑器 │      │
│  └──────────────┘  └──────────────┘  └──────────────┘      │
└─────────────────────────────────────────────────────────────┘
                              ↕
┌─────────────────────────────────────────────────────────────┐
│                  业务逻辑层 (Supabase RPC)                    │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐      │
│  │ 任务管理器   │  │ 工作流引擎   │  │  规则引擎    │      │
│  └──────────────┘  └──────────────┘  └──────────────┘      │
└─────────────────────────────────────────────────────────────┘
                              ↕
┌─────────────────────────────────────────────────────────────┐
│                  数据持久层 (PostgreSQL)                      │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐      │
│  │  任务表      │  │  工作流表    │  │   洞察表     │      │
│  │  规则表      │  │  预测表      │  │   模型表     │      │
│  └──────────────┘  └──────────────┘  └──────────────┘      │
└─────────────────────────────────────────────────────────────┘
                              ↕
┌─────────────────────────────────────────────────────────────┐
│              AI 服务层 (Edge Functions / 外部 API)            │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐      │
│  │  OpenAI      │  │  Anthropic   │  │  本地模型    │      │
│  └──────────────┘  └──────────────┘  └──────────────┘      │
└─────────────────────────────────────────────────────────────┘
```

### 2. 模块类型

- **类型**: 全栈模块 (Full Stack Module)
- **前端**: React 组件 + 动态路由
- **后端**: Supabase RPC 函数 + Edge Functions
- **数据库**: PostgreSQL 表 + 视图
- **集成**: 通过事件总线与其他模块通信

---

## 📊 数据库架构

### 核心表结构

#### 1. **ai_analysis_tasks** - AI 分析任务表

存储 AI 分析任务的定义和配置。

```sql
关键字段:
- task_key: 任务唯一标识
- task_name: 任务名称 (多语言)
- task_type: 任务类型 (趋势预测、异常检测、聚类等)
- data_source: 数据源配置 (JSON)
- analysis_config: 分析配置 (JSON)
- schedule_type: 调度类型 (手动、定时、事件触发)
- status: 任务状态 (inactive, active, running, error)
- is_enabled: 是否启用
- 统计字段: total_executions, success_count, failure_count
```

#### 2. **ai_task_executions** - 任务执行历史表

记录每次 AI 任务的执行详情。

```sql
关键字段:
- execution_id: 执行唯一标识
- task_id: 关联任务
- status: 执行状态 (running, completed, failed)
- input_data: 输入数据 (JSON)
- output_data: 输出数据 (JSON)
- records_processed: 处理记录数
- insights_generated: 生成洞察数
- duration_ms: 执行耗时
- error_message: 错误信息
```

#### 3. **ai_workflows** - AI 工作流定义表

定义自动化工作流的结构和配置。

```sql
关键字段:
- workflow_key: 工作流唯一标识
- workflow_name: 工作流名称 (多语言)
- workflow_type: 工作流类型 (sequential, parallel, conditional, DAG)
- workflow_definition: 工作流定义 (JSON - 节点和边)
- trigger_config: 触发配置
- trigger_type: 触发类型 (manual, scheduled, event, webhook)
- execution_config: 执行配置
- status: 状态 (draft, published, active, paused)
- version: 版本号
```

**工作流定义示例**:
```json
{
  "nodes": [
    {
      "id": "fetch_data",
      "type": "data_query",
      "config": {"query": "SELECT * FROM orders"}
    },
    {
      "id": "analyze",
      "type": "ai_analysis",
      "config": {"task_key": "sales_trend_analysis"}
    },
    {
      "id": "send_notification",
      "type": "notification",
      "config": {"recipients": ["admin@example.com"]}
    }
  ],
  "edges": [
    {"from": "fetch_data", "to": "analyze"},
    {"from": "analyze", "to": "send_notification"}
  ]
}
```

#### 4. **ai_workflow_executions** - 工作流执行记录表

记录工作流的执行历史和状态。

```sql
关键字段:
- execution_id: 执行唯一标识
- workflow_id: 关联工作流
- status: 执行状态 (running, completed, failed, paused)
- execution_context: 执行上下文 (JSON)
- nodes_status: 各节点状态 (JSON)
- current_node: 当前执行节点
- total_nodes, completed_nodes, failed_nodes: 节点统计
- error_node: 失败节点
```

#### 5. **ai_insights** - AI 洞察表

存储 AI 生成的业务洞察和建议。

```sql
关键字段:
- insight_key: 洞察唯一标识
- insight_title: 洞察标题 (多语言)
- insight_summary: 洞察摘要 (多语言)
- insight_type: 洞察类型 (observation, trend, anomaly, prediction, recommendation)
- category: 业务类别 (sales, inventory, customer, etc.)
- severity: 严重程度 (info, low, medium, high, critical)
- insight_data: 洞察详细数据 (JSON)
- confidence_score: 置信度分数 (0-100)
- impact_score: 影响分数 (0-100)
- priority: 优先级 (1-10)
- is_actionable: 是否可执行
- user_rating: 用户评分 (1-5)
- status: 状态 (new, reviewing, acted_upon, dismissed)
```

#### 6. **ai_predictions** - AI 预测表

存储预测分析结果。

```sql
关键字段:
- prediction_key: 预测唯一标识
- prediction_type: 预测类型 (time_series, classification, demand_forecast)
- target_metric: 目标指标
- prediction_date: 预测日期
- prediction_period: 预测周期 (daily, weekly, monthly)
- predicted_value: 预测值
- actual_value: 实际值 (用于验证)
- confidence_interval_lower/upper: 置信区间
- model_accuracy: 模型准确度
- accuracy_score: 准确度评分 (实际值录入后)
```

#### 7. **ai_rules** - 智能规则表

定义自动化业务规则。

```sql
关键字段:
- rule_key: 规则唯一标识
- rule_name: 规则名称 (多语言)
- rule_type: 规则类型 (condition_action, threshold, pattern_match, ml_based)
- conditions: 条件列表 (JSON数组)
- actions: 动作列表 (JSON数组)
- priority: 优先级
- trigger_events: 触发事件列表
- trigger_frequency: 触发频率 (on_event, real_time, periodic)
- is_enabled: 是否启用
- 统计字段: total_triggers, total_executions, success_count
```

**规则示例**:
```json
{
  "conditions": [
    {
      "field": "inventory.quantity",
      "operator": "less_than",
      "value": "inventory.reorder_point"
    }
  ],
  "actions": [
    {
      "type": "create_insight",
      "params": {
        "insight_type": "alert",
        "severity": "high",
        "category": "inventory"
      }
    },
    {
      "type": "send_notification",
      "params": {
        "channels": ["email", "system"],
        "recipients": ["inventory_manager"]
      }
    }
  ]
}
```

#### 8. **ai_rule_executions** - 规则执行日志表

记录规则的执行历史。

```sql
关键字段:
- rule_id: 关联规则
- executed_at: 执行时间
- trigger_event: 触发事件
- trigger_data: 触发数据
- conditions_met: 条件是否满足
- conditions_result: 条件评估结果
- actions_executed: 已执行的动作
- actions_result: 动作执行结果
```

---

## 🔧 核心功能函数

### 1. 任务管理函数

#### **execute_ai_analysis_task** - 执行 AI 分析任务
```sql
功能: 启动一个 AI 分析任务
参数:
  - p_task_key: 任务标识
  - p_trigger_type: 触发类型 (manual, scheduled, event)
  - p_triggered_by: 触发人 (可选)
返回:
  {
    "success": true,
    "execution_id": "exec_xxx",
    "status": "running"
  }
```

#### **complete_ai_task_execution** - 完成任务执行
```sql
功能: 标记任务执行完成并记录结果
参数:
  - p_execution_id: 执行ID
  - p_status: 状态 (completed, failed)
  - p_output_data: 输出数据
  - p_records_processed: 处理记录数
  - p_insights_generated: 生成洞察数
  - p_error_message: 错误信息 (可选)
```

### 2. 洞察管理函数

#### **create_ai_insight** - 创建 AI 洞察
```sql
功能: 创建一条新的 AI 洞察
参数:
  - p_insight_key: 洞察标识
  - p_insight_title: 标题
  - p_insight_summary: 摘要
  - p_insight_type: 类型
  - p_severity: 严重程度
  - p_confidence_score: 置信度
  - p_impact_score: 影响分数
返回:
  {
    "success": true,
    "insight_id": "uuid"
  }
```

### 3. 工作流管理函数

#### **execute_ai_workflow** - 执行工作流
```sql
功能: 启动一个 AI 工作流
参数:
  - p_workflow_key: 工作流标识
  - p_input_data: 输入数据
  - p_trigger_type: 触发类型
返回:
  {
    "success": true,
    "execution_id": "wf_exec_xxx",
    "status": "running"
  }
```

### 4. 规则执行函数

#### **execute_ai_rule** - 执行智能规则
```sql
功能: 执行一条智能规则
参数:
  - p_rule_key: 规则标识
  - p_trigger_event: 触发事件
  - p_trigger_data: 触发数据
返回:
  {
    "success": true,
    "conditions_met": true,
    "status": "success"
  }
```

### 5. 统计函数

#### **get_ai_insights_statistics** - 获取洞察统计
```sql
返回:
  {
    "total_insights": 156,
    "new_insights": 12,
    "by_type": {"trend": 45, "anomaly": 23, ...},
    "by_severity": {"high": 8, "medium": 15, ...},
    "high_priority": 5
  }
```

#### **get_ai_tasks_statistics** - 获取任务统计
```sql
返回:
  {
    "total_tasks": 25,
    "active_tasks": 18,
    "running_tasks": 3,
    "total_executions": 1250,
    "success_rate": 95.6,
    "by_type": {"trend_prediction": 8, ...}
  }
```

#### **get_ai_workflows_statistics** - 获取工作流统计
```sql
返回:
  {
    "total_workflows": 12,
    "active_workflows": 8,
    "total_executions": 456,
    "success_rate": 98.2,
    "by_type": {"sequential": 6, "parallel": 2}
  }
```

---

## 🎨 前端组件

### 主要页面

#### 1. **SmartInsight 主页** (`/admin/smartinsight`)
- 仪表板总览
- 关键指标统计卡片
- 最新 AI 洞察列表
- 活跃分析任务
- 快速操作入口

#### 2. **AI 洞察页面** (`/admin/smartinsight/insights`)
- 洞察列表和筛选
- 按类型、严重程度、类别筛选
- 洞察详情查看
- 用户反馈和评分

#### 3. **工作流管理页面** (`/admin/smartinsight/workflows`)
- 工作流列表
- 可视化工作流编辑器
- 工作流执行历史
- 节点库和模板

#### 4. **预测分析页面** (`/admin/smartinsight/predictions`)
- 预测结果展示
- 趋势图表
- 准确度评估
- 模型性能监控

---

## 🔄 工作流引擎

### 节点类型

SmartInsight 工作流引擎支持多种节点类型：

1. **数据节点**
   - `data_query` - 数据库查询
   - `api_call` - API 调用
   - `file_read` - 文件读取

2. **处理节点**
   - `ai_analysis` - AI 分析
   - `transform` - 数据转换
   - `aggregate` - 数据聚合
   - `filter` - 数据过滤

3. **决策节点**
   - `condition` - 条件判断
   - `switch` - 多路分支
   - `loop` - 循环处理

4. **动作节点**
   - `notification` - 发送通知
   - `email` - 发送邮件
   - `create_insight` - 创建洞察
   - `update_record` - 更新记录
   - `trigger_workflow` - 触发工作流

5. **集成节点**
   - `webhook` - Webhook 调用
   - `event_publish` - 发布事件
   - `external_api` - 外部 API

### 执行模式

1. **顺序执行** (Sequential)
   - 节点按顺序依次执行
   - 前一节点完成后才执行下一节点

2. **并行执行** (Parallel)
   - 多个节点同时执行
   - 所有节点完成后继续下一步

3. **条件执行** (Conditional)
   - 根据条件选择执行路径
   - 支持 if-else 逻辑

4. **DAG 执行** (Directed Acyclic Graph)
   - 复杂的依赖关系
   - 自动优化执行顺序

---

## 🎯 应用场景

### 1. 销售分析与预测

**场景**: 自动分析每日销售数据，预测未来趋势

**实现**:
```
AI 任务: sales_trend_analysis
- 数据源: orders 表
- 分析类型: trend_prediction
- 调度: 每日 9:00 自动执行

生成洞察:
- 销售趋势: "过去7天销售额增长15%"
- 预测: "预计未来7天日均销售额 ¥45,000"
- 建议: "建议增加热销商品库存"
```

### 2. 库存异常检测

**场景**: 实时监控库存变化，自动识别异常

**实现**:
```
AI 规则: low_stock_alert_rule
- 触发: inventory.updated 事件
- 条件: quantity < reorder_point
- 动作:
  1. 创建高优先级洞察
  2. 发送通知给库存管理员
  3. 触发自动补货工作流 (可选)
```

### 3. 客户分群与精准营销

**场景**: 基于购买行为自动分群客户

**实现**:
```
AI 任务: customer_segmentation
- 数据源: orders + customers
- 分析类型: clustering
- 算法: K-means (5 clusters)
- 特征: 购买频次、客单价、最近购买时间

输出:
- VIP 客户: 高频次高客单价
- 潜力客户: 高客单价低频次
- 活跃客户: 高频次低客单价
- 沉睡客户: 长时间未购买
- 新客户: 首次购买

工作流:
1. 执行客户分群
2. 为每个分群生成营销策略
3. 自动发送个性化营销邮件
```

### 4. 自动化日报生成

**场景**: 每日自动生成运营报告

**实现**:
```
AI 工作流: daily_sales_report
- 触发: 定时 (每日 9:00)
- 节点:
  1. 查询当日订单数据
  2. 执行销售趋势分析
  3. 生成可视化报告
  4. 发送邮件给管理层
```

---

## 🔌 集成与扩展

### 与其他模块集成

SmartInsight 通过事件总线与其他模块无缝集成：

#### 1. **订单模块集成**
```javascript
// 订单创建时触发分析
eventBus.subscribe('order.created', async (data) => {
  // 触发客户价值分析
  await supabase.rpc('execute_ai_rule', {
    p_rule_key: 'high_value_customer_rule',
    p_trigger_event: 'order.created',
    p_trigger_data: data
  });
});
```

#### 2. **库存模块集成**
```javascript
// 库存更新时检测异常
eventBus.subscribe('inventory.updated', async (data) => {
  // 触发库存异常检测
  await supabase.rpc('execute_ai_task', {
    p_task_key: 'inventory_anomaly_detection',
    p_trigger_type: 'event'
  });
});
```

#### 3. **营销模块集成**
```javascript
// SmartInsight 发布洞察
eventBus.publish('ai.insight_created', {
  insight_type: 'recommendation',
  category: 'marketing',
  action: 'create_promotion'
});

// 营销模块订阅并执行
eventBus.subscribe('ai.insight_created', (data) => {
  if (data.category === 'marketing') {
    // 根据 AI 建议创建营销活动
    createMarketingCampaign(data);
  }
});
```

### 外部 AI 服务集成

SmartInsight 支持多种 AI 服务提供商：

1. **OpenAI**
   - GPT-4 文本分析
   - 嵌入向量生成
   - 自然语言处理

2. **Anthropic Claude**
   - 长文本理解
   - 复杂推理
   - 安全性分析

3. **本地模型**
   - TensorFlow/PyTorch 模型
   - 隐私敏感场景
   - 定制化需求

---

## 📈 性能优化

### 1. 查询优化
- 所有关键字段建立索引
- 使用物化视图加速常用查询
- 分页和限流避免大查询

### 2. 执行优化
- 异步任务处理
- 任务队列和优先级
- 并发控制和限流

### 3. 缓存策略
- Redis 缓存热门洞察
- 查询结果缓存
- 预测结果缓存

### 4. 监控告警
- 任务执行时间监控
- 失败率告警
- 资源使用监控

---

## 🔒 安全性设计

### 1. 数据访问控制
- Row Level Security (RLS) 策略
- 基于角色的权限控制
- 审计日志记录

### 2. API 安全
- JWT 认证
- API 速率限制
- 输入验证和清洗

### 3. AI 模型安全
- 提示注入防护
- 输出内容审核
- 敏感数据脱敏

---

## 📚 使用示例

### 示例 1: 创建自定义分析任务

```sql
INSERT INTO ai_analysis_tasks (
  task_key,
  task_name,
  task_type,
  analysis_category,
  data_source,
  analysis_config,
  schedule_type,
  is_enabled
) VALUES (
  'product_recommendation',
  '{"zh": "商品推荐分析", "en": "Product Recommendation"}',
  'recommendation',
  'sales',
  '{
    "table": "orders",
    "join": ["products", "customers"],
    "features": ["product_id", "customer_id", "quantity", "total_amount"]
  }',
  '{
    "algorithm": "collaborative_filtering",
    "top_n": 10,
    "confidence_threshold": 0.7
  }',
  'cron',
  true
);
```

### 示例 2: 手动执行分析任务

```javascript
const { data, error } = await supabase.rpc('execute_ai_analysis_task', {
  p_task_key: 'product_recommendation',
  p_trigger_type: 'manual'
});

if (data && data.success) {
  console.log('任务已启动:', data.execution_id);
}
```

### 示例 3: 创建自动化规则

```sql
INSERT INTO ai_rules (
  rule_key,
  rule_name,
  rule_type,
  conditions,
  actions,
  trigger_events,
  is_enabled
) VALUES (
  'high_cart_abandonment_alert',
  '{"zh": "购物车放弃预警", "en": "Cart Abandonment Alert"}',
  'threshold',
  '[
    {
      "field": "cart_abandonment_rate",
      "operator": "greater_than",
      "value": 0.5
    }
  ]',
  '[
    {
      "type": "create_insight",
      "params": {
        "insight_type": "alert",
        "severity": "medium",
        "message": "购物车放弃率异常偏高"
      }
    },
    {
      "type": "trigger_workflow",
      "params": {
        "workflow_key": "cart_recovery_campaign"
      }
    }
  ]',
  '["cart.abandoned"]',
  true
);
```

---

## 🚀 部署与运维

### 1. 启用模块

访问模块管理中心 (`/admin/modules`)，找到 **SmartInsight AI**，点击"启用"。

### 2. 配置模块

在模块管理中配置以下参数：
- `ai_provider`: AI 服务提供商 (openai/anthropic/local)
- `enable_auto_insights`: 是否自动生成洞察
- `enable_predictions`: 是否启用预测分析
- `confidence_threshold`: 洞察置信度阈值

### 3. 创建分析任务

进入 SmartInsight 主页，创建您的第一个分析任务：
1. 选择任务类型（趋势预测/异常检测/聚类等）
2. 配置数据源
3. 设置分析参数
4. 选择调度方式
5. 启用任务

### 4. 监控运行状态

通过主页仪表板监控：
- 任务执行统计
- 洞察生成情况
- 工作流运行状态
- 系统健康度

---

## 📊 未来路线图

### Phase 1 (已完成)
- ✅ 核心数据库架构
- ✅ 基础 RPC 函数
- ✅ 主页仪表板
- ✅ 模块注册和集成

### Phase 2 (规划中)
- [ ] 可视化工作流编辑器
- [ ] 更多预置分析模板
- [ ] 实时数据流处理
- [ ] 高级图表和可视化

### Phase 3 (规划中)
- [ ] LLM 集成 (GPT-4/Claude)
- [ ] 自然语言查询
- [ ] 自动化报告生成
- [ ] 移动端支持

### Phase 4 (规划中)
- [ ] AutoML 自动建模
- [ ] 联邦学习支持
- [ ] 多租户隔离
- [ ] 模型市场

---

## 💡 最佳实践

### 1. 任务设计
- 保持任务单一职责
- 合理设置执行频率
- 避免过于复杂的查询
- 设置超时和重试机制

### 2. 工作流设计
- 节点粒度适中
- 合理使用并行执行
- 做好错误处理
- 记录详细日志

### 3. 规则设计
- 条件表达式清晰
- 避免规则冲突
- 设置合理优先级
- 定期审查和优化

### 4. 洞察管理
- 及时处理高优先级洞察
- 提供用户反馈
- 定期清理过期洞察
- 建立洞察响应流程

---

## 🆘 故障排查

### 常见问题

#### 1. 任务执行失败
- 检查数据源配置是否正确
- 验证分析配置参数
- 查看错误日志
- 检查权限设置

#### 2. 工作流卡住
- 检查节点配置
- 查看执行日志
- 验证依赖关系
- 检查超时设置

#### 3. 洞察不准确
- 调整置信度阈值
- 增加训练数据
- 优化特征选择
- 调整模型参数

---

## 📞 技术支持

如需技术支持或有任何问题，请：
1. 查阅本文档
2. 查看系统日志
3. 联系技术团队
4. 提交 GitHub Issue

---

**SmartInsight AI** - 让数据智能驱动业务决策 🚀
