#!/bin/bash

# SmartInsight - VPS 服务器直接部署脚本
# 适用于：电脑上没有源代码，直接在服务器上部署的情况

set -e

echo "=================================="
echo "SmartInsight 服务器直接部署"
echo "=================================="

# 颜色定义
GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
NC='\033[0m'

# 检查是否在服务器上运行
if [ -z "$SSH_CONNECTION" ] && [ -z "$SSH_CLIENT" ]; then
    echo -e "${YELLOW}警告：看起来您在本地电脑上运行此脚本${NC}"
    echo -e "${YELLOW}此脚本应该直接在 VPS 服务器上运行${NC}"
    read -p "确定继续？(y/n) " -n 1 -r
    echo
    if [[ ! $REPLY =~ ^[Yy]$ ]]; then
        exit 1
    fi
fi

# 1. 检查必要工具
echo -e "\n${GREEN}[1/7] 检查必要工具...${NC}"

check_command() {
    if ! command -v $1 &> /dev/null; then
        echo -e "${RED}未安装 $1，正在安装...${NC}"
        return 1
    else
        echo -e "${GREEN}✓ $1 已安装${NC}"
        return 0
    fi
}

# 更新包管理器
if ! check_command node || ! check_command npm; then
    echo "安装 Node.js..."
    curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
    sudo apt-get install -y nodejs
fi

if ! check_command nginx; then
    echo "安装 Nginx..."
    sudo apt-get update
    sudo apt-get install -y nginx
fi

if ! check_command git; then
    echo "安装 Git..."
    sudo apt-get install -y git
fi

if ! check_command pm2; then
    echo "安装 PM2..."
    sudo npm install -g pm2
fi

# 2. 配置项目信息
echo -e "\n${GREEN}[2/7] 配置项目信息${NC}"

read -p "输入您的域名（例如：example.com 或 IP 地址）: " DOMAIN
read -p "输入项目安装目录 [默认: /var/www/smartinsight]: " INSTALL_DIR
INSTALL_DIR=${INSTALL_DIR:-/var/www/smartinsight}

echo -e "\n项目将安装到: ${GREEN}$INSTALL_DIR${NC}"
echo -e "域名/IP: ${GREEN}$DOMAIN${NC}"

# 3. 创建安装目录
echo -e "\n${GREEN}[3/7] 创建安装目录...${NC}"
sudo mkdir -p $INSTALL_DIR
sudo chown -R $USER:$USER $INSTALL_DIR

# 4. 获取源代码
echo -e "\n${GREEN}[4/7] 获取项目源代码...${NC}"
cd $INSTALL_DIR

# 如果已存在，先备份
if [ -d "$INSTALL_DIR/project" ]; then
    echo "发现已存在的项目，创建备份..."
    sudo mv $INSTALL_DIR/project $INSTALL_DIR/project.backup.$(date +%Y%m%d_%H%M%S)
fi

echo "请选择获取代码的方式："
echo "1) 从 Git 仓库克隆（需要提供仓库地址）"
echo "2) 手动上传（稍后您需要上传代码到 $INSTALL_DIR）"

read -p "选择 (1/2): " CODE_METHOD

if [ "$CODE_METHOD" = "1" ]; then
    read -p "输入 Git 仓库地址: " GIT_REPO
    git clone $GIT_REPO project
    cd project
elif [ "$CODE_METHOD" = "2" ]; then
    echo -e "\n${YELLOW}请将项目文件上传到: $INSTALL_DIR/project${NC}"
    echo "您可以使用以下命令从本地上传（在本地电脑运行）："
    echo -e "${GREEN}scp -r /local/path/to/project root@$DOMAIN:$INSTALL_DIR/${NC}"
    echo ""
    read -p "上传完成后按回车继续..."
    cd project
else
    echo -e "${RED}无效的选择${NC}"
    exit 1
fi

# 5. 配置环境变量
echo -e "\n${GREEN}[5/7] 配置环境变量...${NC}"

read -p "Supabase URL: " SUPABASE_URL
read -p "Supabase Anon Key: " SUPABASE_ANON_KEY

# 前端环境变量
cat > .env.production <<EOF
VITE_SUPABASE_URL=$SUPABASE_URL
VITE_SUPABASE_ANON_KEY=$SUPABASE_ANON_KEY
EOF

echo -e "${GREEN}✓ 环境变量配置完成${NC}"

# 6. 构建和部署
echo -e "\n${GREEN}[6/7] 安装依赖并构建项目...${NC}"

# 安装前端依赖
npm install

# 构建前端
npm run build

# 部署前端到 Nginx
echo "部署前端文件..."
sudo mkdir -p /var/www/html/smartinsight
sudo cp -r dist/* /var/www/html/smartinsight/
sudo chown -R www-data:www-data /var/www/html/smartinsight

# 7. 配置 Nginx
echo -e "\n${GREEN}[7/7] 配置 Nginx...${NC}"

sudo tee /etc/nginx/sites-available/smartinsight > /dev/null <<EOF
server {
    listen 80;
    server_name $DOMAIN;

    root /var/www/html/smartinsight;
    index index.html;

    # Gzip 压缩
    gzip on;
    gzip_vary on;
    gzip_min_length 1024;
    gzip_types text/plain text/css text/xml text/javascript application/x-javascript application/xml+rss application/javascript application/json;

    location / {
        try_files \$uri \$uri/ /index.html;
    }

    # 静态资源缓存
    location ~* \.(js|css|png|jpg|jpeg|gif|ico|svg|woff|woff2|ttf|eot)$ {
        expires 1y;
        add_header Cache-Control "public, immutable";
    }
}
EOF

# 启用站点
sudo ln -sf /etc/nginx/sites-available/smartinsight /etc/nginx/sites-enabled/

# 测试 Nginx 配置
sudo nginx -t

# 重启 Nginx
sudo systemctl restart nginx

# 完成
echo -e "\n${GREEN}=================================="
echo "✓ 部署完成！"
echo "==================================${NC}"
echo ""
echo "访问地址: http://$DOMAIN"
echo "项目目录: $INSTALL_DIR/project"
echo ""
echo -e "${YELLOW}后续操作：${NC}"
echo "1. 如需 HTTPS，运行: sudo certbot --nginx -d $DOMAIN"
echo "2. 查看 Nginx 日志: sudo tail -f /var/log/nginx/error.log"
echo "3. 重新部署: cd $INSTALL_DIR/project && npm run build && sudo cp -r dist/* /var/www/html/smartinsight/"
echo ""
echo -e "${GREEN}祝使用愉快！${NC}"
