===================================
SmartInsight AI 系统 - 下载说明
===================================

由于您在 bolt.new 云端开发环境中，有以下几种方式获取项目代码：

方法1：推送到 GitHub（最推荐）
-------------------------------
1. 在 GitHub 上创建一个新仓库
2. 在 bolt.new 终端中运行：
   git init
   git add .
   git commit -m "Initial commit"
   git remote add origin https://github.com/你的用户名/你的仓库名.git
   git push -u origin main

3. 然后在本地克隆：
   git clone https://github.com/你的用户名/你的仓库名.git

方法2：复制代码文件
-------------------
由于文件较多，建议重点复制以下核心文件：

前端核心：
- src/           (所有前端代码)
- public/        (静态资源)
- *.config.js    (配置文件)
- package.json   (依赖配置)
- .env           (环境变量)

后端核心：
- server/        (所有后端代码)

数据库：
- supabase/migrations/  (数据库迁移文件)

方法3：使用 bolt.new 的发布功能
-------------------------------
点击右上角"发布"按钮，部署到：
- Netlify
- Vercel
- 或其他平台

部署后，可以从平台的仪表板下载代码或连接 GitHub

关键文件说明
-----------
✅ 必须复制的文件：
   - src/ 目录（前端全部代码）
   - server/ 目录（后端全部代码）
   - supabase/migrations/ (数据库结构)
   - package.json (前端依赖)
   - server/package.json (后端依赖)
   - .env (环境变量配置)

✅ 配置文件：
   - vite.config.js
   - tailwind.config.js
   - postcss.config.js

✅ 部署文档：
   - 部署指南.md
   - 快速部署手册.md
   - 使用手册.md

下载后本地启动
-------------
1. 安装前端依赖：
   npm install

2. 配置 .env 文件（Supabase 配置）

3. 启动开发服务器：
   npm run dev

4. 构建生产版本：
   npm run build

如需帮助，请参考项目中的文档！
