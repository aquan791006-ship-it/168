# SmartInsight AI ERP 后端服务

## 简介

这是 SmartInsight AI ERP 系统的独立后端服务，使用 Node.js + Express + PostgreSQL + Prisma 构建。

## 技术栈

- **运行环境**: Node.js 18+
- **Web 框架**: Express 4.x
- **数据库**: PostgreSQL 14+
- **ORM**: Prisma 5.x
- **认证**: JWT (jsonwebtoken)
- **密码加密**: bcryptjs

## 目录结构

```
server/
├── src/
│   ├── config/
│   │   └── database.js          # 数据库连接配置
│   ├── middleware/
│   │   ├── auth.js              # JWT 认证中间件
│   │   ├── errorHandler.js      # 错误处理中间件
│   │   └── logger.js            # 日志记录中间件
│   ├── routes/
│   │   ├── auth.js              # 认证路由
│   │   ├── admin.js             # 管理员管理
│   │   ├── products.js          # 商品管理
│   │   ├── orders.js            # 订单管理
│   │   ├── stores.js            # 店铺管理
│   │   ├── modules.js           # 模块管理
│   │   ├── links.js             # 链接追踪
│   │   ├── announcements.js     # 公告管理
│   │   └── payments.js          # 支付管理
│   ├── utils/
│   │   ├── jwt.js               # JWT 工具函数
│   │   └── password.js          # 密码处理工具
│   └── index.js                 # 应用入口
├── prisma/
│   └── schema.prisma            # 数据库模型定义
├── .env.example                 # 环境变量示例
├── package.json
└── README.md
```

## 快速开始

### 1. 安装依赖

```bash
cd server
npm install
```

### 2. 配置环境变量

复制 `.env.example` 为 `.env` 并配置：

```bash
cp .env.example .env
nano .env
```

必须配置的环境变量：

```env
# 数据库连接（必填）
DATABASE_URL="postgresql://用户名:密码@localhost:5432/数据库名"

# JWT 密钥（必填，建议使用随机字符串）
JWT_SECRET="your-super-secret-jwt-key-change-this"

# 服务器端口（可选，默认 3000）
PORT=3000

# 前端地址（用于 CORS，必填）
FRONTEND_URL="http://localhost:5173"
```

### 3. 初始化数据库

```bash
# 生成 Prisma Client
npm run prisma:generate

# 推送数据库模型（创建表）
npm run prisma:push

# 或使用迁移
npm run prisma:migrate
```

### 4. 创建初始管理员

在数据库中手动创建第一个管理员账号：

```sql
INSERT INTO sys_admins (username, password_hash, display_name, role, is_active, can_manage_domains)
VALUES (
  'admin',
  '$2a$10$YourHashedPasswordHere',  -- 使用 bcrypt 加密的密码
  '超级管理员',
  'super_admin',
  true,
  true
);
```

或者使用以下 Node.js 脚本生成密码哈希：

```javascript
const bcrypt = require('bcryptjs');
const password = 'admin123456';
bcrypt.hash(password, 10).then(hash => console.log(hash));
```

### 5. 启动服务

开发模式（热重载）：
```bash
npm run dev
```

生产模式：
```bash
npm start
```

服务将在 `http://localhost:3000` 启动。

## API 文档

### 认证 API

#### POST /api/auth/login
登录

请求体：
```json
{
  "username": "admin",
  "password": "admin123456"
}
```

响应：
```json
{
  "token": "eyJhbGciOiJIUzI1NiIs...",
  "admin": {
    "id": 1,
    "username": "admin",
    "display_name": "超级管理员",
    "role": "super_admin"
  },
  "expiresIn": "7d"
}
```

#### GET /api/auth/me
获取当前登录管理员信息（需要认证）

请求头：
```
Authorization: Bearer <token>
```

#### POST /api/auth/change-password
修改密码（需要认证）

请求体：
```json
{
  "currentPassword": "old_password",
  "newPassword": "new_password"
}
```

#### POST /api/auth/logout
退出登录（需要认证）

### 管理员管理 API

#### GET /api/admin
获取管理员列表（需要 super_admin 权限）

查询参数：
- `page`: 页码（默认 1）
- `limit`: 每页数量（默认 20）
- `role`: 角色筛选
- `is_active`: 状态筛选

#### POST /api/admin
创建管理员（需要 super_admin 权限）

#### PATCH /api/admin/:id
更新管理员（需要 super_admin 权限）

#### DELETE /api/admin/:id
删除管理员（需要 super_admin 权限）

### 商品管理 API

#### GET /api/products
获取商品列表

查询参数：
- `page`: 页码
- `limit`: 每页数量
- `store_id`: 店铺ID筛选
- `category`: 分类筛选
- `is_active`: 状态筛选
- `search`: 搜索关键词

#### GET /api/products/:id
获取商品详情

#### POST /api/products
创建商品（需要认证）

#### PATCH /api/products/:id
更新商品（需要认证）

#### DELETE /api/products/:id
删除商品（需要认证）

#### POST /api/products/bulk
批量创建商品（需要认证）

### 订单管理 API

#### GET /api/orders
获取订单列表（需要认证）

#### GET /api/orders/:id
获取订单详情（需要认证）

#### POST /api/orders
创建订单（公开接口）

#### PATCH /api/orders/:id
更新订单（需要认证）

#### DELETE /api/orders/:id
删除订单（需要认证）

## 部署指南

### 宝塔面板部署

#### 1. 安装 Node.js

在宝塔面板：
- 软件商店 → 搜索 "Node.js" → 安装
- 推荐安装 Node.js 18 或更高版本

#### 2. 安装 PostgreSQL

在宝塔面板：
- 软件商店 → 搜索 "PostgreSQL" → 安装
- 创建数据库和用户

#### 3. 上传代码

将 `server` 目录上传到服务器，例如：
```
/www/wwwroot/smartinsight/server/
```

#### 4. 安装依赖和配置

```bash
cd /www/wwwroot/smartinsight/server
npm install --production
cp .env.example .env
nano .env  # 配置环境变量
npm run prisma:generate
npm run prisma:push
```

#### 5. 使用 PM2 管理进程

安装 PM2：
```bash
npm install -g pm2
```

启动应用：
```bash
pm2 start src/index.js --name smartinsight-api
pm2 save
pm2 startup
```

查看日志：
```bash
pm2 logs smartinsight-api
```

#### 6. 配置 Nginx 反向代理

在宝塔面板添加反向代理：

```nginx
location /api {
    proxy_pass http://localhost:3000;
    proxy_http_version 1.1;
    proxy_set_header Upgrade $http_upgrade;
    proxy_set_header Connection 'upgrade';
    proxy_set_header Host $host;
    proxy_set_header X-Real-IP $remote_addr;
    proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
    proxy_cache_bypass $http_upgrade;
}
```

### Docker 部署

创建 `Dockerfile`：

```dockerfile
FROM node:18-alpine

WORKDIR /app

COPY package*.json ./
RUN npm install --production

COPY . .

RUN npx prisma generate

EXPOSE 3000

CMD ["node", "src/index.js"]
```

创建 `docker-compose.yml`：

```yaml
version: '3.8'

services:
  postgres:
    image: postgres:14
    environment:
      POSTGRES_DB: smartinsight
      POSTGRES_USER: admin
      POSTGRES_PASSWORD: your_password
    volumes:
      - postgres_data:/var/lib/postgresql/data
    ports:
      - "5432:5432"

  api:
    build: .
    ports:
      - "3000:3000"
    environment:
      DATABASE_URL: postgresql://admin:your_password@postgres:5432/smartinsight
      JWT_SECRET: your_jwt_secret
      NODE_ENV: production
      FRONTEND_URL: https://your-domain.com
    depends_on:
      - postgres

volumes:
  postgres_data:
```

启动：
```bash
docker-compose up -d
```

## 维护和监控

### 查看日志

使用 PM2：
```bash
pm2 logs smartinsight-api
```

使用 Docker：
```bash
docker-compose logs -f api
```

### 数据库备份

```bash
# 备份
pg_dump -U admin -d smartinsight > backup.sql

# 恢复
psql -U admin -d smartinsight < backup.sql
```

### 性能监控

安装 PM2 Plus（可选）：
```bash
pm2 plus
```

### 更新部署

```bash
# 拉取最新代码
git pull

# 安装依赖
npm install

# 更新数据库
npm run prisma:generate
npm run prisma:migrate

# 重启服务
pm2 restart smartinsight-api
```

## 常见问题

### 1. 数据库连接失败

检查：
- PostgreSQL 服务是否启动
- 数据库连接字符串是否正确
- 数据库用户权限是否足够

### 2. JWT 认证失败

检查：
- JWT_SECRET 是否配置
- token 是否正确传递
- token 是否过期

### 3. CORS 错误

检查：
- FRONTEND_URL 是否配置正确
- 前端请求头是否包含正确的 Origin

### 4. 端口被占用

更改 `.env` 中的 PORT 配置

## 安全建议

1. 使用强密码作为 JWT_SECRET
2. 定期备份数据库
3. 使用 HTTPS
4. 限制数据库访问权限
5. 定期更新依赖包
6. 配置防火墙规则
7. 使用环境变量管理敏感信息

## 许可证

MIT
