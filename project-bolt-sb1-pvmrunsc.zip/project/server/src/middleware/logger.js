import prisma from '../config/database.js';

export const logRequest = (req, res, next) => {
  const start = Date.now();

  res.on('finish', async () => {
    const duration = Date.now() - start;
    const logData = {
      method: req.method,
      path: req.path,
      status: res.statusCode,
      duration: `${duration}ms`,
      ip: req.ip,
      adminId: req.admin?.id
    };

    console.log(JSON.stringify(logData));

    if (res.statusCode >= 400 && process.env.NODE_ENV === 'production') {
      try {
        await prisma.sys_logs.create({
          data: {
            level: res.statusCode >= 500 ? 'error' : 'warn',
            message: `${req.method} ${req.path} - ${res.statusCode}`,
            meta: logData,
            admin_id: req.admin?.id,
            ip_address: req.ip
          }
        });
      } catch (error) {
        console.error('日志记录失败:', error);
      }
    }
  });

  next();
};
