export const errorHandler = (err, req, res, next) => {
  console.error('错误:', err);

  if (err.name === 'PrismaClientKnownRequestError') {
    if (err.code === 'P2002') {
      return res.status(409).json({
        error: '数据冲突',
        message: '该记录已存在'
      });
    }
    if (err.code === 'P2025') {
      return res.status(404).json({
        error: '未找到',
        message: '请求的资源不存在'
      });
    }
  }

  if (err.name === 'ValidationError') {
    return res.status(400).json({
      error: '验证失败',
      message: err.message
    });
  }

  res.status(err.status || 500).json({
    error: err.message || '服务器内部错误',
    ...(process.env.NODE_ENV === 'development' && { stack: err.stack })
  });
};

export const notFoundHandler = (req, res) => {
  res.status(404).json({
    error: '未找到',
    message: `路由 ${req.method} ${req.path} 不存在`
  });
};
