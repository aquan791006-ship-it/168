import jwt from 'jsonwebtoken';
import prisma from '../config/database.js';

export const authenticate = async (req, res, next) => {
  try {
    const authHeader = req.headers.authorization;

    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return res.status(401).json({ error: '未提供认证令牌' });
    }

    const token = authHeader.substring(7);

    const decoded = jwt.verify(token, process.env.JWT_SECRET);

    const admin = await prisma.sys_admins.findUnique({
      where: { id: decoded.adminId },
      select: {
        id: true,
        username: true,
        display_name: true,
        email: true,
        role: true,
        permissions: true,
        is_active: true,
        can_manage_domains: true,
        managed_domain_id: true
      }
    });

    if (!admin || !admin.is_active) {
      return res.status(401).json({ error: '无效的认证令牌' });
    }

    req.admin = admin;
    next();
  } catch (error) {
    if (error.name === 'JsonWebTokenError') {
      return res.status(401).json({ error: '无效的认证令牌' });
    }
    if (error.name === 'TokenExpiredError') {
      return res.status(401).json({ error: '认证令牌已过期' });
    }
    console.error('认证错误:', error);
    return res.status(500).json({ error: '认证失败' });
  }
};

export const requireRole = (roles) => {
  return (req, res, next) => {
    if (!req.admin) {
      return res.status(401).json({ error: '未认证' });
    }

    const allowedRoles = Array.isArray(roles) ? roles : [roles];

    if (!allowedRoles.includes(req.admin.role)) {
      return res.status(403).json({ error: '权限不足' });
    }

    next();
  };
};

export const requirePermission = (permission) => {
  return (req, res, next) => {
    if (!req.admin) {
      return res.status(401).json({ error: '未认证' });
    }

    if (req.admin.role === 'super_admin') {
      return next();
    }

    const permissions = req.admin.permissions || {};
    if (!permissions[permission]) {
      return res.status(403).json({ error: '权限不足' });
    }

    next();
  };
};
