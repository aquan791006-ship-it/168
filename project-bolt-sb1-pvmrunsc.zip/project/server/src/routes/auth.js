import express from 'express';
import prisma from '../config/database.js';
import { hashPassword, comparePassword } from '../utils/password.js';
import { generateToken } from '../utils/jwt.js';
import { authenticate } from '../middleware/auth.js';

const router = express.Router();

router.post('/login', async (req, res, next) => {
  try {
    const { username, password } = req.body;

    if (!username || !password) {
      return res.status(400).json({ error: '请提供用户名和密码' });
    }

    const admin = await prisma.sys_admins.findUnique({
      where: { username },
      include: {
        domains: true
      }
    });

    if (!admin) {
      return res.status(401).json({ error: '用户名或密码错误' });
    }

    if (!admin.is_active) {
      return res.status(403).json({ error: '账号已被禁用' });
    }

    const isValidPassword = await comparePassword(password, admin.password_hash);

    if (!isValidPassword) {
      return res.status(401).json({ error: '用户名或密码错误' });
    }

    await prisma.sys_admins.update({
      where: { id: admin.id },
      data: { last_login: new Date() }
    });

    const token = generateToken(admin.id);

    const { password_hash, ...adminData } = admin;

    res.json({
      token,
      admin: adminData,
      expiresIn: process.env.JWT_EXPIRES_IN || '7d'
    });
  } catch (error) {
    next(error);
  }
});

router.get('/me', authenticate, async (req, res, next) => {
  try {
    const admin = await prisma.sys_admins.findUnique({
      where: { id: req.admin.id },
      select: {
        id: true,
        username: true,
        display_name: true,
        email: true,
        phone: true,
        role: true,
        permissions: true,
        is_active: true,
        can_manage_domains: true,
        managed_domain_id: true,
        last_login: true,
        created_at: true
      }
    });

    res.json(admin);
  } catch (error) {
    next(error);
  }
});

router.post('/change-password', authenticate, async (req, res, next) => {
  try {
    const { currentPassword, newPassword } = req.body;

    if (!currentPassword || !newPassword) {
      return res.status(400).json({ error: '请提供当前密码和新密码' });
    }

    if (newPassword.length < 6) {
      return res.status(400).json({ error: '新密码长度至少为 6 个字符' });
    }

    const admin = await prisma.sys_admins.findUnique({
      where: { id: req.admin.id }
    });

    const isValidPassword = await comparePassword(currentPassword, admin.password_hash);

    if (!isValidPassword) {
      return res.status(401).json({ error: '当前密码错误' });
    }

    const newPasswordHash = await hashPassword(newPassword);

    await prisma.sys_admins.update({
      where: { id: req.admin.id },
      data: { password_hash: newPasswordHash }
    });

    res.json({ message: '密码修改成功' });
  } catch (error) {
    next(error);
  }
});

router.post('/logout', authenticate, (req, res) => {
  res.json({ message: '退出登录成功' });
});

export default router;
