import express from 'express';
import prisma from '../config/database.js';
import { authenticate } from '../middleware/auth.js';

const router = express.Router();

router.get('/', authenticate, async (req, res, next) => {
  try {
    const { page = 1, limit = 20, domain_id, is_active } = req.query;
    const skip = (page - 1) * limit;

    const where = {};
    if (domain_id) where.domain_id = parseInt(domain_id);
    if (is_active !== undefined) where.is_active = is_active === 'true';

    const [stores, total] = await Promise.all([
      prisma.sys_stores.findMany({
        where,
        include: {
          domain: true,
          admin: {
            select: {
              id: true,
              username: true,
              display_name: true
            }
          }
        },
        skip: parseInt(skip),
        take: parseInt(limit),
        orderBy: { created_at: 'desc' }
      }),
      prisma.sys_stores.count({ where })
    ]);

    res.json({
      data: stores,
      pagination: {
        total,
        page: parseInt(page),
        limit: parseInt(limit),
        totalPages: Math.ceil(total / limit)
      }
    });
  } catch (error) {
    next(error);
  }
});

router.get('/:id', authenticate, async (req, res, next) => {
  try {
    const { id } = req.params;

    const store = await prisma.sys_stores.findUnique({
      where: { id: parseInt(id) },
      include: {
        domain: true,
        admin: {
          select: {
            id: true,
            username: true,
            display_name: true
          }
        }
      }
    });

    if (!store) {
      return res.status(404).json({ error: '店铺不存在' });
    }

    res.json(store);
  } catch (error) {
    next(error);
  }
});

router.post('/', authenticate, async (req, res, next) => {
  try {
    const {
      store_name,
      domain_id,
      admin_id,
      store_config,
      is_active = true
    } = req.body;

    if (!store_name || !domain_id || !admin_id) {
      return res.status(400).json({ error: '店铺名称、域名ID和管理员ID为必填项' });
    }

    const store = await prisma.sys_stores.create({
      data: {
        store_name,
        domain_id: parseInt(domain_id),
        admin_id: parseInt(admin_id),
        store_config,
        is_active
      },
      include: {
        domain: true,
        admin: {
          select: {
            id: true,
            username: true,
            display_name: true
          }
        }
      }
    });

    res.status(201).json(store);
  } catch (error) {
    next(error);
  }
});

router.patch('/:id', authenticate, async (req, res, next) => {
  try {
    const { id } = req.params;
    const { store_name, store_config, is_active } = req.body;

    const updateData = {};
    if (store_name !== undefined) updateData.store_name = store_name;
    if (store_config !== undefined) updateData.store_config = store_config;
    if (is_active !== undefined) updateData.is_active = is_active;

    const store = await prisma.sys_stores.update({
      where: { id: parseInt(id) },
      data: updateData,
      include: {
        domain: true,
        admin: {
          select: {
            id: true,
            username: true,
            display_name: true
          }
        }
      }
    });

    res.json(store);
  } catch (error) {
    next(error);
  }
});

router.delete('/:id', authenticate, async (req, res, next) => {
  try {
    const { id } = req.params;

    await prisma.sys_stores.delete({
      where: { id: parseInt(id) }
    });

    res.json({ message: '店铺已删除' });
  } catch (error) {
    next(error);
  }
});

export default router;
