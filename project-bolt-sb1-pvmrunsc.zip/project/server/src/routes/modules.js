import express from 'express';
import prisma from '../config/database.js';
import { authenticate, requireRole } from '../middleware/auth.js';

const router = express.Router();

router.get('/', async (req, res, next) => {
  try {
    const { module_type, is_enabled } = req.query;

    const where = {};
    if (module_type) where.module_type = module_type;
    if (is_enabled !== undefined) where.is_enabled = is_enabled === 'true';

    const modules = await prisma.sys_modules.findMany({
      where,
      orderBy: [
        { display_order: 'asc' },
        { created_at: 'asc' }
      ]
    });

    res.json(modules);
  } catch (error) {
    next(error);
  }
});

router.get('/:id', async (req, res, next) => {
  try {
    const { id } = req.params;

    const module = await prisma.sys_modules.findUnique({
      where: { id: parseInt(id) }
    });

    if (!module) {
      return res.status(404).json({ error: '模块不存在' });
    }

    res.json(module);
  } catch (error) {
    next(error);
  }
});

router.post('/', authenticate, requireRole(['super_admin']), async (req, res, next) => {
  try {
    const {
      module_key,
      module_name,
      module_type,
      description,
      icon,
      route_path,
      is_core = false,
      is_enabled = true,
      display_order = 0,
      parent_module,
      config
    } = req.body;

    if (!module_key || !module_name || !module_type) {
      return res.status(400).json({ error: '模块标识、名称和类型为必填项' });
    }

    const module = await prisma.sys_modules.create({
      data: {
        module_key,
        module_name,
        module_type,
        description,
        icon,
        route_path,
        is_core,
        is_enabled,
        display_order,
        parent_module,
        config
      }
    });

    res.status(201).json(module);
  } catch (error) {
    next(error);
  }
});

router.patch('/:id', authenticate, requireRole(['super_admin']), async (req, res, next) => {
  try {
    const { id } = req.params;
    const {
      module_name,
      description,
      icon,
      route_path,
      is_enabled,
      display_order,
      config
    } = req.body;

    const updateData = {};
    if (module_name !== undefined) updateData.module_name = module_name;
    if (description !== undefined) updateData.description = description;
    if (icon !== undefined) updateData.icon = icon;
    if (route_path !== undefined) updateData.route_path = route_path;
    if (is_enabled !== undefined) updateData.is_enabled = is_enabled;
    if (display_order !== undefined) updateData.display_order = display_order;
    if (config !== undefined) updateData.config = config;

    const module = await prisma.sys_modules.update({
      where: { id: parseInt(id) },
      data: updateData
    });

    res.json(module);
  } catch (error) {
    next(error);
  }
});

router.delete('/:id', authenticate, requireRole(['super_admin']), async (req, res, next) => {
  try {
    const { id } = req.params;

    const module = await prisma.sys_modules.findUnique({
      where: { id: parseInt(id) }
    });

    if (module && module.is_core) {
      return res.status(400).json({ error: '核心模块不能删除' });
    }

    await prisma.sys_modules.delete({
      where: { id: parseInt(id) }
    });

    res.json({ message: '模块已删除' });
  } catch (error) {
    next(error);
  }
});

export default router;
