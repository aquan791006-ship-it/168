import express from 'express';
import prisma from '../config/database.js';
import { authenticate } from '../middleware/auth.js';

const router = express.Router();

router.get('/', authenticate, async (req, res, next) => {
  try {
    const { page = 1, limit = 20, is_active } = req.query;
    const skip = (page - 1) * limit;

    const where = { admin_id: req.admin.id };
    if (is_active !== undefined) where.is_active = is_active === 'true';

    const [links, total] = await Promise.all([
      prisma.sys_tracked_links.findMany({
        where,
        include: {
          clicks: {
            select: {
              id: true,
              clicked_at: true
            },
            orderBy: { clicked_at: 'desc' },
            take: 10
          }
        },
        skip: parseInt(skip),
        take: parseInt(limit),
        orderBy: { created_at: 'desc' }
      }),
      prisma.sys_tracked_links.count({ where })
    ]);

    res.json({
      data: links,
      pagination: {
        total,
        page: parseInt(page),
        limit: parseInt(limit),
        totalPages: Math.ceil(total / limit)
      }
    });
  } catch (error) {
    next(error);
  }
});

router.get('/:id', authenticate, async (req, res, next) => {
  try {
    const { id } = req.params;

    const link = await prisma.sys_tracked_links.findUnique({
      where: { id: parseInt(id) },
      include: {
        clicks: {
          orderBy: { clicked_at: 'desc' },
          take: 100
        }
      }
    });

    if (!link) {
      return res.status(404).json({ error: '链接不存在' });
    }

    if (link.admin_id !== req.admin.id && req.admin.role !== 'super_admin') {
      return res.status(403).json({ error: '权限不足' });
    }

    res.json(link);
  } catch (error) {
    next(error);
  }
});

router.post('/', authenticate, async (req, res, next) => {
  try {
    const { original_url, title, expires_at } = req.body;

    if (!original_url) {
      return res.status(400).json({ error: '原始URL为必填项' });
    }

    const short_code = Math.random().toString(36).substring(2, 8);

    const link = await prisma.sys_tracked_links.create({
      data: {
        short_code,
        original_url,
        title,
        admin_id: req.admin.id,
        expires_at: expires_at ? new Date(expires_at) : null
      }
    });

    res.status(201).json(link);
  } catch (error) {
    next(error);
  }
});

router.patch('/:id', authenticate, async (req, res, next) => {
  try {
    const { id } = req.params;
    const { title, is_active, expires_at } = req.body;

    const link = await prisma.sys_tracked_links.findUnique({
      where: { id: parseInt(id) }
    });

    if (!link) {
      return res.status(404).json({ error: '链接不存在' });
    }

    if (link.admin_id !== req.admin.id && req.admin.role !== 'super_admin') {
      return res.status(403).json({ error: '权限不足' });
    }

    const updateData = {};
    if (title !== undefined) updateData.title = title;
    if (is_active !== undefined) updateData.is_active = is_active;
    if (expires_at !== undefined) updateData.expires_at = expires_at ? new Date(expires_at) : null;

    const updatedLink = await prisma.sys_tracked_links.update({
      where: { id: parseInt(id) },
      data: updateData
    });

    res.json(updatedLink);
  } catch (error) {
    next(error);
  }
});

router.delete('/:id', authenticate, async (req, res, next) => {
  try {
    const { id } = req.params;

    const link = await prisma.sys_tracked_links.findUnique({
      where: { id: parseInt(id) }
    });

    if (!link) {
      return res.status(404).json({ error: '链接不存在' });
    }

    if (link.admin_id !== req.admin.id && req.admin.role !== 'super_admin') {
      return res.status(403).json({ error: '权限不足' });
    }

    await prisma.sys_tracked_links.delete({
      where: { id: parseInt(id) }
    });

    res.json({ message: '链接已删除' });
  } catch (error) {
    next(error);
  }
});

router.get('/redirect/:short_code', async (req, res, next) => {
  try {
    const { short_code } = req.params;

    const link = await prisma.sys_tracked_links.findUnique({
      where: { short_code }
    });

    if (!link || !link.is_active) {
      return res.status(404).json({ error: '链接不存在或已失效' });
    }

    if (link.expires_at && new Date() > new Date(link.expires_at)) {
      return res.status(410).json({ error: '链接已过期' });
    }

    await prisma.$transaction([
      prisma.sys_tracked_links.update({
        where: { id: link.id },
        data: { click_count: { increment: 1 } }
      }),
      prisma.sys_link_clicks.create({
        data: {
          link_id: link.id,
          ip_address: req.ip,
          user_agent: req.get('user-agent'),
          referer: req.get('referer')
        }
      })
    ]);

    res.redirect(link.original_url);
  } catch (error) {
    next(error);
  }
});

export default router;
