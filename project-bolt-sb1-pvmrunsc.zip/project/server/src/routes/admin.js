import express from 'express';
import prisma from '../config/database.js';
import { hashPassword } from '../utils/password.js';
import { authenticate, requireRole } from '../middleware/auth.js';

const router = express.Router();

router.use(authenticate);

router.get('/', requireRole(['super_admin']), async (req, res, next) => {
  try {
    const { page = 1, limit = 20, role, is_active } = req.query;
    const skip = (page - 1) * limit;

    const where = {};
    if (role) where.role = role;
    if (is_active !== undefined) where.is_active = is_active === 'true';

    const [admins, total] = await Promise.all([
      prisma.sys_admins.findMany({
        where,
        select: {
          id: true,
          username: true,
          display_name: true,
          email: true,
          phone: true,
          role: true,
          permissions: true,
          is_active: true,
          can_manage_domains: true,
          managed_domain_id: true,
          last_login: true,
          created_at: true,
          updated_at: true
        },
        skip: parseInt(skip),
        take: parseInt(limit),
        orderBy: { created_at: 'desc' }
      }),
      prisma.sys_admins.count({ where })
    ]);

    res.json({
      data: admins,
      pagination: {
        total,
        page: parseInt(page),
        limit: parseInt(limit),
        totalPages: Math.ceil(total / limit)
      }
    });
  } catch (error) {
    next(error);
  }
});

router.get('/:id', requireRole(['super_admin', 'admin']), async (req, res, next) => {
  try {
    const { id } = req.params;

    if (req.admin.role !== 'super_admin' && req.admin.id !== parseInt(id)) {
      return res.status(403).json({ error: '权限不足' });
    }

    const admin = await prisma.sys_admins.findUnique({
      where: { id: parseInt(id) },
      select: {
        id: true,
        username: true,
        display_name: true,
        email: true,
        phone: true,
        role: true,
        permissions: true,
        is_active: true,
        can_manage_domains: true,
        managed_domain_id: true,
        last_login: true,
        created_at: true,
        updated_at: true
      }
    });

    if (!admin) {
      return res.status(404).json({ error: '管理员不存在' });
    }

    res.json(admin);
  } catch (error) {
    next(error);
  }
});

router.post('/', requireRole(['super_admin']), async (req, res, next) => {
  try {
    const {
      username,
      password,
      display_name,
      email,
      phone,
      role = 'admin',
      permissions,
      can_manage_domains = false,
      managed_domain_id
    } = req.body;

    if (!username || !password) {
      return res.status(400).json({ error: '用户名和密码为必填项' });
    }

    if (password.length < 6) {
      return res.status(400).json({ error: '密码长度至少为 6 个字符' });
    }

    const password_hash = await hashPassword(password);

    const admin = await prisma.sys_admins.create({
      data: {
        username,
        password_hash,
        display_name,
        email,
        phone,
        role,
        permissions,
        can_manage_domains,
        managed_domain_id
      },
      select: {
        id: true,
        username: true,
        display_name: true,
        email: true,
        phone: true,
        role: true,
        permissions: true,
        is_active: true,
        can_manage_domains: true,
        managed_domain_id: true,
        created_at: true
      }
    });

    res.status(201).json(admin);
  } catch (error) {
    next(error);
  }
});

router.patch('/:id', requireRole(['super_admin']), async (req, res, next) => {
  try {
    const { id } = req.params;
    const {
      display_name,
      email,
      phone,
      role,
      permissions,
      is_active,
      can_manage_domains,
      managed_domain_id
    } = req.body;

    const updateData = {};
    if (display_name !== undefined) updateData.display_name = display_name;
    if (email !== undefined) updateData.email = email;
    if (phone !== undefined) updateData.phone = phone;
    if (role !== undefined) updateData.role = role;
    if (permissions !== undefined) updateData.permissions = permissions;
    if (is_active !== undefined) updateData.is_active = is_active;
    if (can_manage_domains !== undefined) updateData.can_manage_domains = can_manage_domains;
    if (managed_domain_id !== undefined) updateData.managed_domain_id = managed_domain_id;

    const admin = await prisma.sys_admins.update({
      where: { id: parseInt(id) },
      data: updateData,
      select: {
        id: true,
        username: true,
        display_name: true,
        email: true,
        phone: true,
        role: true,
        permissions: true,
        is_active: true,
        can_manage_domains: true,
        managed_domain_id: true,
        updated_at: true
      }
    });

    res.json(admin);
  } catch (error) {
    next(error);
  }
});

router.delete('/:id', requireRole(['super_admin']), async (req, res, next) => {
  try {
    const { id } = req.params;

    if (req.admin.id === parseInt(id)) {
      return res.status(400).json({ error: '不能删除自己的账号' });
    }

    await prisma.sys_admins.delete({
      where: { id: parseInt(id) }
    });

    res.json({ message: '管理员已删除' });
  } catch (error) {
    next(error);
  }
});

router.post('/:id/reset-password', requireRole(['super_admin']), async (req, res, next) => {
  try {
    const { id } = req.params;
    const { newPassword } = req.body;

    if (!newPassword || newPassword.length < 6) {
      return res.status(400).json({ error: '密码长度至少为 6 个字符' });
    }

    const password_hash = await hashPassword(newPassword);

    await prisma.sys_admins.update({
      where: { id: parseInt(id) },
      data: { password_hash }
    });

    res.json({ message: '密码重置成功' });
  } catch (error) {
    next(error);
  }
});

export default router;
