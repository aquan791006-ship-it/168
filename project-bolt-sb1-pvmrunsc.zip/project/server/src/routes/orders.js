import express from 'express';
import prisma from '../config/database.js';
import { authenticate } from '../middleware/auth.js';

const router = express.Router();

router.get('/', authenticate, async (req, res, next) => {
  try {
    const {
      page = 1,
      limit = 20,
      store_id,
      status,
      payment_status,
      search
    } = req.query;

    const skip = (page - 1) * limit;
    const where = {};

    if (store_id) where.store_id = parseInt(store_id);
    if (status) where.status = status;
    if (payment_status) where.payment_status = payment_status;
    if (search) {
      where.OR = [
        { order_number: { contains: search, mode: 'insensitive' } },
        { customer_name: { contains: search, mode: 'insensitive' } },
        { customer_phone: { contains: search, mode: 'insensitive' } }
      ];
    }

    const [orders, total] = await Promise.all([
      prisma.sys_orders.findMany({
        where,
        include: {
          store: {
            select: {
              id: true,
              store_name: true
            }
          },
          order_items: {
            include: {
              product: {
                select: {
                  id: true,
                  product_id: true,
                  product_name: true,
                  images: true
                }
              }
            }
          }
        },
        skip: parseInt(skip),
        take: parseInt(limit),
        orderBy: { created_at: 'desc' }
      }),
      prisma.sys_orders.count({ where })
    ]);

    res.json({
      data: orders,
      pagination: {
        total,
        page: parseInt(page),
        limit: parseInt(limit),
        totalPages: Math.ceil(total / limit)
      }
    });
  } catch (error) {
    next(error);
  }
});

router.get('/:id', authenticate, async (req, res, next) => {
  try {
    const { id } = req.params;

    const order = await prisma.sys_orders.findUnique({
      where: { id: parseInt(id) },
      include: {
        store: {
          select: {
            id: true,
            store_name: true,
            domain_id: true
          }
        },
        order_items: {
          include: {
            product: true
          }
        }
      }
    });

    if (!order) {
      return res.status(404).json({ error: '订单不存在' });
    }

    res.json(order);
  } catch (error) {
    next(error);
  }
});

router.post('/', async (req, res, next) => {
  try {
    const {
      customer_name,
      customer_phone,
      customer_email,
      shipping_address,
      payment_method,
      store_id,
      items
    } = req.body;

    if (!customer_name || !customer_phone || !store_id || !items || items.length === 0) {
      return res.status(400).json({ error: '必填项缺失' });
    }

    const orderCount = await prisma.sys_orders.count();
    const order_number = `ORD${Date.now()}${String(orderCount + 1).padStart(4, '0')}`;

    let total_amount = 0;
    const orderItems = [];

    for (const item of items) {
      const product = await prisma.sys_products.findUnique({
        where: { id: item.product_id }
      });

      if (!product) {
        return res.status(404).json({ error: `商品 ID ${item.product_id} 不存在` });
      }

      if (product.stock < item.quantity) {
        return res.status(400).json({
          error: `商品 ${product.product_name} 库存不足`
        });
      }

      const subtotal = product.price * item.quantity;
      total_amount += parseFloat(subtotal);

      orderItems.push({
        product_id: item.product_id,
        quantity: item.quantity,
        unit_price: product.price,
        subtotal
      });
    }

    const order = await prisma.$transaction(async (tx) => {
      const newOrder = await tx.sys_orders.create({
        data: {
          order_number,
          customer_name,
          customer_phone,
          customer_email,
          shipping_address,
          total_amount,
          payment_method,
          store_id: parseInt(store_id),
          order_items: {
            create: orderItems
          }
        },
        include: {
          order_items: {
            include: {
              product: true
            }
          },
          store: {
            select: {
              id: true,
              store_name: true
            }
          }
        }
      });

      for (const item of items) {
        await tx.sys_products.update({
          where: { id: item.product_id },
          data: {
            stock: {
              decrement: item.quantity
            }
          }
        });
      }

      return newOrder;
    });

    res.status(201).json(order);
  } catch (error) {
    next(error);
  }
});

router.patch('/:id', authenticate, async (req, res, next) => {
  try {
    const { id } = req.params;
    const { status, payment_status, shipping_address } = req.body;

    const updateData = {};
    if (status !== undefined) updateData.status = status;
    if (payment_status !== undefined) updateData.payment_status = payment_status;
    if (shipping_address !== undefined) updateData.shipping_address = shipping_address;

    const order = await prisma.sys_orders.update({
      where: { id: parseInt(id) },
      data: updateData,
      include: {
        order_items: {
          include: {
            product: true
          }
        },
        store: {
          select: {
            id: true,
            store_name: true
          }
        }
      }
    });

    res.json(order);
  } catch (error) {
    next(error);
  }
});

router.delete('/:id', authenticate, async (req, res, next) => {
  try {
    const { id } = req.params;

    const order = await prisma.sys_orders.findUnique({
      where: { id: parseInt(id) },
      include: { order_items: true }
    });

    if (!order) {
      return res.status(404).json({ error: '订单不存在' });
    }

    if (order.status !== 'cancelled') {
      await prisma.$transaction(async (tx) => {
        for (const item of order.order_items) {
          await tx.sys_products.update({
            where: { id: item.product_id },
            data: {
              stock: {
                increment: item.quantity
              }
            }
          });
        }

        await tx.sys_orders.delete({
          where: { id: parseInt(id) }
        });
      });
    } else {
      await prisma.sys_orders.delete({
        where: { id: parseInt(id) }
      });
    }

    res.json({ message: '订单已删除' });
  } catch (error) {
    next(error);
  }
});

export default router;
