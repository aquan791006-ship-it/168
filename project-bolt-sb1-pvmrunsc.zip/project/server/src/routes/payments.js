import express from 'express';
import prisma from '../config/database.js';
import { authenticate, requireRole } from '../middleware/auth.js';

const router = express.Router();

router.get('/methods', async (req, res, next) => {
  try {
    const { is_active = true } = req.query;

    const methods = await prisma.sys_payment_methods.findMany({
      where: { is_active: is_active === 'true' },
      orderBy: { display_order: 'asc' }
    });

    res.json(methods);
  } catch (error) {
    next(error);
  }
});

router.post('/methods', authenticate, requireRole(['super_admin', 'admin']), async (req, res, next) => {
  try {
    const {
      method_name,
      method_type,
      icon,
      is_active = true,
      display_order = 0,
      config
    } = req.body;

    if (!method_name || !method_type) {
      return res.status(400).json({ error: '支付方式名称和类型为必填项' });
    }

    const method = await prisma.sys_payment_methods.create({
      data: {
        method_name,
        method_type,
        icon,
        is_active,
        display_order,
        config
      }
    });

    res.status(201).json(method);
  } catch (error) {
    next(error);
  }
});

router.patch('/methods/:id', authenticate, requireRole(['super_admin', 'admin']), async (req, res, next) => {
  try {
    const { id } = req.params;
    const {
      method_name,
      method_type,
      icon,
      is_active,
      display_order,
      config
    } = req.body;

    const updateData = {};
    if (method_name !== undefined) updateData.method_name = method_name;
    if (method_type !== undefined) updateData.method_type = method_type;
    if (icon !== undefined) updateData.icon = icon;
    if (is_active !== undefined) updateData.is_active = is_active;
    if (display_order !== undefined) updateData.display_order = display_order;
    if (config !== undefined) updateData.config = config;

    const method = await prisma.sys_payment_methods.update({
      where: { id: parseInt(id) },
      data: updateData
    });

    res.json(method);
  } catch (error) {
    next(error);
  }
});

router.delete('/methods/:id', authenticate, requireRole(['super_admin', 'admin']), async (req, res, next) => {
  try {
    const { id } = req.params;

    await prisma.sys_payment_methods.delete({
      where: { id: parseInt(id) }
    });

    res.json({ message: '支付方式已删除' });
  } catch (error) {
    next(error);
  }
});

router.get('/accounts', authenticate, async (req, res, next) => {
  try {
    const { is_active = true, payment_type } = req.query;

    const where = { is_active: is_active === 'true' };
    if (payment_type) where.payment_type = payment_type;

    const accounts = await prisma.sys_payment_accounts.findMany({
      where,
      orderBy: { display_order: 'asc' }
    });

    res.json(accounts);
  } catch (error) {
    next(error);
  }
});

router.post('/accounts', authenticate, requireRole(['super_admin', 'admin']), async (req, res, next) => {
  try {
    const {
      account_name,
      payment_type,
      account_number,
      qr_code,
      is_active = true,
      display_order = 0
    } = req.body;

    if (!account_name || !payment_type || !account_number) {
      return res.status(400).json({ error: '账户名称、支付类型和账号为必填项' });
    }

    const account = await prisma.sys_payment_accounts.create({
      data: {
        account_name,
        payment_type,
        account_number,
        qr_code,
        is_active,
        display_order
      }
    });

    res.status(201).json(account);
  } catch (error) {
    next(error);
  }
});

router.patch('/accounts/:id', authenticate, requireRole(['super_admin', 'admin']), async (req, res, next) => {
  try {
    const { id } = req.params;
    const {
      account_name,
      payment_type,
      account_number,
      qr_code,
      is_active,
      display_order
    } = req.body;

    const updateData = {};
    if (account_name !== undefined) updateData.account_name = account_name;
    if (payment_type !== undefined) updateData.payment_type = payment_type;
    if (account_number !== undefined) updateData.account_number = account_number;
    if (qr_code !== undefined) updateData.qr_code = qr_code;
    if (is_active !== undefined) updateData.is_active = is_active;
    if (display_order !== undefined) updateData.display_order = display_order;

    const account = await prisma.sys_payment_accounts.update({
      where: { id: parseInt(id) },
      data: updateData
    });

    res.json(account);
  } catch (error) {
    next(error);
  }
});

router.delete('/accounts/:id', authenticate, requireRole(['super_admin', 'admin']), async (req, res, next) => {
  try {
    const { id } = req.params;

    await prisma.sys_payment_accounts.delete({
      where: { id: parseInt(id) }
    });

    res.json({ message: '支付账户已删除' });
  } catch (error) {
    next(error);
  }
});

export default router;
