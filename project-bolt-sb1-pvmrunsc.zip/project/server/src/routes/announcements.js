import express from 'express';
import prisma from '../config/database.js';
import { authenticate, requireRole } from '../middleware/auth.js';

const router = express.Router();

router.get('/', async (req, res, next) => {
  try {
    const { is_active = true } = req.query;
    const now = new Date();

    const where = { is_active: is_active === 'true' };

    const announcements = await prisma.sys_announcements.findMany({
      where: {
        ...where,
        OR: [
          { start_time: null },
          { start_time: { lte: now } }
        ],
        AND: [
          {
            OR: [
              { end_time: null },
              { end_time: { gte: now } }
            ]
          }
        ]
      },
      orderBy: [
        { priority: 'desc' },
        { created_at: 'desc' }
      ]
    });

    res.json(announcements);
  } catch (error) {
    next(error);
  }
});

router.get('/:id', async (req, res, next) => {
  try {
    const { id } = req.params;

    const announcement = await prisma.sys_announcements.findUnique({
      where: { id: parseInt(id) }
    });

    if (!announcement) {
      return res.status(404).json({ error: '公告不存在' });
    }

    res.json(announcement);
  } catch (error) {
    next(error);
  }
});

router.post('/', authenticate, requireRole(['super_admin', 'admin']), async (req, res, next) => {
  try {
    const {
      title,
      content,
      type = 'info',
      priority = 0,
      is_active = true,
      start_time,
      end_time,
      target_users
    } = req.body;

    if (!title || !content) {
      return res.status(400).json({ error: '标题和内容为必填项' });
    }

    const announcement = await prisma.sys_announcements.create({
      data: {
        title,
        content,
        type,
        priority,
        is_active,
        start_time: start_time ? new Date(start_time) : null,
        end_time: end_time ? new Date(end_time) : null,
        target_users,
        created_by: req.admin.id
      }
    });

    res.status(201).json(announcement);
  } catch (error) {
    next(error);
  }
});

router.patch('/:id', authenticate, requireRole(['super_admin', 'admin']), async (req, res, next) => {
  try {
    const { id } = req.params;
    const {
      title,
      content,
      type,
      priority,
      is_active,
      start_time,
      end_time,
      target_users
    } = req.body;

    const updateData = {};
    if (title !== undefined) updateData.title = title;
    if (content !== undefined) updateData.content = content;
    if (type !== undefined) updateData.type = type;
    if (priority !== undefined) updateData.priority = priority;
    if (is_active !== undefined) updateData.is_active = is_active;
    if (start_time !== undefined) updateData.start_time = start_time ? new Date(start_time) : null;
    if (end_time !== undefined) updateData.end_time = end_time ? new Date(end_time) : null;
    if (target_users !== undefined) updateData.target_users = target_users;

    const announcement = await prisma.sys_announcements.update({
      where: { id: parseInt(id) },
      data: updateData
    });

    res.json(announcement);
  } catch (error) {
    next(error);
  }
});

router.delete('/:id', authenticate, requireRole(['super_admin', 'admin']), async (req, res, next) => {
  try {
    const { id } = req.params;

    await prisma.sys_announcements.delete({
      where: { id: parseInt(id) }
    });

    res.json({ message: '公告已删除' });
  } catch (error) {
    next(error);
  }
});

export default router;
