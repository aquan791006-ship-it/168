import express from 'express';
import prisma from '../config/database.js';
import { authenticate } from '../middleware/auth.js';

const router = express.Router();

router.get('/', async (req, res, next) => {
  try {
    const {
      page = 1,
      limit = 20,
      store_id,
      category,
      is_active,
      search
    } = req.query;

    const skip = (page - 1) * limit;
    const where = {};

    if (store_id) where.store_id = parseInt(store_id);
    if (category) where.category = category;
    if (is_active !== undefined) where.is_active = is_active === 'true';
    if (search) {
      where.OR = [
        { product_name: { contains: search, mode: 'insensitive' } },
        { product_id: { contains: search, mode: 'insensitive' } }
      ];
    }

    const [products, total] = await Promise.all([
      prisma.sys_products.findMany({
        where,
        include: {
          store: {
            select: {
              id: true,
              store_name: true
            }
          }
        },
        skip: parseInt(skip),
        take: parseInt(limit),
        orderBy: { created_at: 'desc' }
      }),
      prisma.sys_products.count({ where })
    ]);

    res.json({
      data: products,
      pagination: {
        total,
        page: parseInt(page),
        limit: parseInt(limit),
        totalPages: Math.ceil(total / limit)
      }
    });
  } catch (error) {
    next(error);
  }
});

router.get('/:id', async (req, res, next) => {
  try {
    const { id } = req.params;

    const product = await prisma.sys_products.findUnique({
      where: { id: parseInt(id) },
      include: {
        store: {
          select: {
            id: true,
            store_name: true,
            domain_id: true
          }
        }
      }
    });

    if (!product) {
      return res.status(404).json({ error: '商品不存在' });
    }

    res.json(product);
  } catch (error) {
    next(error);
  }
});

router.post('/', authenticate, async (req, res, next) => {
  try {
    const {
      product_id,
      product_name,
      category,
      price,
      cost,
      stock = 0,
      description,
      images,
      specifications,
      is_active = true,
      store_id
    } = req.body;

    if (!product_name || !price || !store_id) {
      return res.status(400).json({ error: '商品名称、价格和店铺ID为必填项' });
    }

    let generatedProductId = product_id;
    if (!generatedProductId) {
      const count = await prisma.sys_products.count({
        where: { store_id: parseInt(store_id) }
      });
      generatedProductId = `P${String(count + 1).padStart(6, '0')}`;
    }

    const product = await prisma.sys_products.create({
      data: {
        product_id: generatedProductId,
        product_name,
        category,
        price,
        cost,
        stock,
        description,
        images,
        specifications,
        is_active,
        store_id: parseInt(store_id)
      },
      include: {
        store: {
          select: {
            id: true,
            store_name: true
          }
        }
      }
    });

    res.status(201).json(product);
  } catch (error) {
    next(error);
  }
});

router.patch('/:id', authenticate, async (req, res, next) => {
  try {
    const { id } = req.params;
    const {
      product_name,
      category,
      price,
      cost,
      stock,
      description,
      images,
      specifications,
      is_active
    } = req.body;

    const updateData = {};
    if (product_name !== undefined) updateData.product_name = product_name;
    if (category !== undefined) updateData.category = category;
    if (price !== undefined) updateData.price = price;
    if (cost !== undefined) updateData.cost = cost;
    if (stock !== undefined) updateData.stock = stock;
    if (description !== undefined) updateData.description = description;
    if (images !== undefined) updateData.images = images;
    if (specifications !== undefined) updateData.specifications = specifications;
    if (is_active !== undefined) updateData.is_active = is_active;

    const product = await prisma.sys_products.update({
      where: { id: parseInt(id) },
      data: updateData,
      include: {
        store: {
          select: {
            id: true,
            store_name: true
          }
        }
      }
    });

    res.json(product);
  } catch (error) {
    next(error);
  }
});

router.delete('/:id', authenticate, async (req, res, next) => {
  try {
    const { id } = req.params;

    await prisma.sys_products.delete({
      where: { id: parseInt(id) }
    });

    res.json({ message: '商品已删除' });
  } catch (error) {
    next(error);
  }
});

router.post('/bulk', authenticate, async (req, res, next) => {
  try {
    const { products, store_id } = req.body;

    if (!Array.isArray(products) || products.length === 0) {
      return res.status(400).json({ error: '请提供商品列表' });
    }

    if (!store_id) {
      return res.status(400).json({ error: '请提供店铺ID' });
    }

    const count = await prisma.sys_products.count({
      where: { store_id: parseInt(store_id) }
    });

    const productsToCreate = products.map((product, index) => ({
      product_id: product.product_id || `P${String(count + index + 1).padStart(6, '0')}`,
      product_name: product.product_name,
      category: product.category,
      price: product.price,
      cost: product.cost,
      stock: product.stock || 0,
      description: product.description,
      images: product.images,
      specifications: product.specifications,
      is_active: product.is_active !== undefined ? product.is_active : true,
      store_id: parseInt(store_id)
    }));

    const result = await prisma.sys_products.createMany({
      data: productsToCreate
    });

    res.status(201).json({
      message: `成功导入 ${result.count} 个商品`,
      count: result.count
    });
  } catch (error) {
    next(error);
  }
});

export default router;
