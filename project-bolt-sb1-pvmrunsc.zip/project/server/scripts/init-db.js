import { PrismaClient } from '@prisma/client';
import bcrypt from 'bcryptjs';

const prisma = new PrismaClient();

async function initDatabase() {
  try {
    console.log('开始初始化数据库...\n');

    const adminCount = await prisma.sys_admins.count();

    if (adminCount > 0) {
      console.log('⚠️  数据库已有管理员账号，跳过初始化');
      return;
    }

    console.log('创建默认超级管理员...');
    const defaultPassword = process.env.DEFAULT_ADMIN_PASSWORD || 'admin123456';
    const passwordHash = await bcrypt.hash(defaultPassword, 10);

    const admin = await prisma.sys_admins.create({
      data: {
        username: 'admin',
        password_hash: passwordHash,
        display_name: '超级管理员',
        email: 'admin@example.com',
        role: 'super_admin',
        is_active: true,
        can_manage_domains: true
      }
    });

    console.log('✅ 超级管理员创建成功');
    console.log(`   用户名: ${admin.username}`);
    console.log(`   密码: ${defaultPassword}`);
    console.log('   ⚠️  请登录后立即修改密码！\n');

    console.log('创建默认域名...');
    const domain = await prisma.sys_domains.create({
      data: {
        domain_name: 'localhost',
        domain_status: 'active',
        owner_admin_id: admin.id
      }
    });
    console.log(`✅ 默认域名创建成功: ${domain.domain_name}\n`);

    console.log('创建默认店铺...');
    const store = await prisma.sys_stores.create({
      data: {
        store_name: '默认店铺',
        domain_id: domain.id,
        admin_id: admin.id,
        is_active: true,
        store_config: {
          theme: 'default',
          currency: 'CNY'
        }
      }
    });
    console.log(`✅ 默认店铺创建成功: ${store.store_name}\n`);

    console.log('初始化核心模块...');
    const modules = [
      {
        module_key: 'dashboard',
        module_name: '控制台',
        module_type: 'core',
        icon: 'LayoutDashboard',
        route_path: '/dashboard',
        is_core: true,
        display_order: 0
      },
      {
        module_key: 'products',
        module_name: '商品管理',
        module_type: 'business',
        icon: 'Package',
        route_path: '/products',
        is_core: true,
        display_order: 1
      },
      {
        module_key: 'orders',
        module_name: '订单管理',
        module_type: 'business',
        icon: 'ShoppingCart',
        route_path: '/orders',
        is_core: true,
        display_order: 2
      },
      {
        module_key: 'stores',
        module_name: '店铺管理',
        module_type: 'business',
        icon: 'Store',
        route_path: '/stores',
        is_core: true,
        display_order: 3
      },
      {
        module_key: 'settings',
        module_name: '系统设置',
        module_type: 'system',
        icon: 'Settings',
        route_path: '/settings',
        is_core: true,
        display_order: 99
      }
    ];

    for (const module of modules) {
      await prisma.sys_modules.create({ data: module });
    }
    console.log(`✅ ${modules.length} 个核心模块创建成功\n`);

    console.log('🎉 数据库初始化完成！');
    console.log('\n请使用以下账号登录：');
    console.log(`用户名: admin`);
    console.log(`密码: ${defaultPassword}`);
    console.log('\n⚠️  强烈建议登录后立即修改密码！\n');

  } catch (error) {
    console.error('❌ 初始化失败:', error);
    process.exit(1);
  } finally {
    await prisma.$disconnect();
  }
}

initDatabase();
