import bcrypt from 'bcryptjs';
import { PrismaClient } from '@prisma/client';
import readline from 'readline';

const prisma = new PrismaClient();

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout
});

function question(query) {
  return new Promise(resolve => rl.question(query, resolve));
}

async function createAdmin() {
  try {
    console.log('\n=== 创建管理员账号 ===\n');

    const username = await question('用户名: ');
    const password = await question('密码: ');
    const displayName = await question('显示名称: ');
    const email = await question('邮箱（可选）: ');
    const roleInput = await question('角色 (super_admin/admin) [super_admin]: ');

    const role = roleInput || 'super_admin';

    if (!username || !password) {
      console.error('❌ 用户名和密码不能为空');
      process.exit(1);
    }

    if (password.length < 6) {
      console.error('❌ 密码长度至少为 6 个字符');
      process.exit(1);
    }

    console.log('\n正在创建管理员...');

    const passwordHash = await bcrypt.hash(password, 10);

    const admin = await prisma.sys_admins.create({
      data: {
        username,
        password_hash: passwordHash,
        display_name: displayName || username,
        email: email || null,
        role,
        is_active: true,
        can_manage_domains: role === 'super_admin'
      }
    });

    console.log('\n✅ 管理员创建成功！');
    console.log('\n账号信息：');
    console.log(`ID: ${admin.id}`);
    console.log(`用户名: ${admin.username}`);
    console.log(`显示名称: ${admin.display_name}`);
    console.log(`角色: ${admin.role}`);
    console.log(`邮箱: ${admin.email || '未设置'}`);
    console.log('\n请使用此账号登录系统。');

  } catch (error) {
    if (error.code === 'P2002') {
      console.error('\n❌ 错误：用户名已存在');
    } else {
      console.error('\n❌ 创建失败:', error.message);
    }
    process.exit(1);
  } finally {
    rl.close();
    await prisma.$disconnect();
  }
}

createAdmin();
